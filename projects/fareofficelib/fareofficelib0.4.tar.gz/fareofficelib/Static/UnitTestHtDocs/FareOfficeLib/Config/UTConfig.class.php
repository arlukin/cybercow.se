<?php
/**
* Unit test for all functions in UTConfig.class.php.
*
*	@author Daniel Lindh <daniel@fareoffice.com>
* @ingroup unittests
*/
class UTConfig extends foUnitTestBase
{
	public function doTest()
	{
		$this->_testConfig();
		$this->_testSiteConfig();
		$this->_testDbConfig();
	}

	private function _testConfig()
	{
		$config = new Config();
		$this->setSectionLabel('Config');
		eval($this->needNotEmpty('$config->getEnvironmentDir()'));

		eval($this->needEmpty('$config->setEnvironmentDir("/var/www/fareofficeroot")'));
		eval($this->needEqual('$config->getEnvironmentDir()', '"/var/www/fareofficeroot/"'));

		eval($this->needEqual('$config->getLogDir()', '"/var/www/fareofficeroot/Log/"'));
		eval($this->needEqual('$config->getSiteDir()', '"/var/www/fareofficeroot/Site/"'));

		eval($this->needNotEmpty('$config->getSites()'));

		foreach($config->getSites() as $siteConfig)
		{
			eval($this->needEqual('get_class($siteConfig)', '"SiteConfig"'));
		}
	}

	private function _testSiteConfig()
	{
		$config = new Config();
		$this->setSectionLabel('SiteConfig');
		eval($this->needNotEmpty('$dbConfig = $config->getDbConfig()'));
		eval($this->needEmpty('$dbConfig->getDSN("mysql_database")'));

		eval($this->needEmpty('$dbConfig->clearDSN()'));

		eval($this->needEmpty('$dbConfig->setDSN("mysql_database", "mysql", "localhost", "root", "", "mysql")'));
		eval($this->needEqual('$dbConfig->getDSN("mysql_database")', 'array(\'phptype\'=>\'mysql\',\'hostspec\'=>\'localhost\',\'username\'=>\'root\',\'password\'=>\'\',\'database\'=>\'mysql\')'));

		eval($this->needEqual('$config->getDBDSN("mysql_database")', 'array(\'phptype\'=>\'mysql\',\'hostspec\'=>\'localhost\',\'username\'=>\'root\',\'password\'=>\'\',\'database\'=>\'mysql\')'));
	}

	private function _testDbConfig()
	{
		$config = new Config();
		$this->setSectionLabel('DbConfig');
		eval($this->needNotEmpty('$config->getSite("fareofficelib")'));

		eval($this->needEqual('$config->getSite("fareofficelib")->getLogDir()', '"/var/www/fareofficeroot/Site/fareofficelib/Temp/Log/"'));
		eval($this->needEqual('$config->getSite("fareofficelib")->getCacheDir()', '"/var/www/fareofficeroot/Site/fareofficelib/Temp/Cache/"'));

	}
}
?>
