<?php
/**
* Unit test for all functions in String.php.
*
*	@author Daniel Lindh <daniel@fareoffice.com>
* @ingroup unittests
*/
class UTString extends foUnitTestBase
{
	public function doTest()
	{
		$this->_testEmptyString();
	}

	private function _testEmptyString()
	{
		$this->setSectionLabel('emptyString, return true test');

		$emptyString = "";
		eval($this->needTrue('emptyString($emptyString)'));

		$nullVar = NULL;
		eval($this->needTrue('emptyString($nullVar)'));

		$emptyArray = array();
		eval($this->needTrue('emptyString($emptyArray)'));

		eval($this->needTrue('emptyString($this->declaredButEmptyVar)'));

		//
		$this->setSectionLabel('emptyString, return false test');
		$falseVar = false;
		eval($this->needFalse('emptyString($falseVar)'));

		$trueVar = true;
		eval($this->needFalse('emptyString($trueVar)'));

		$notEmptyString = "kalle";
		eval($this->needFalse('emptyString($notEmptyString)'));

		$notEmptyArray = array(1, 2, 3);
		eval($this->needFalse('emptyString($notEmptyArray)'));

		eval($this->needFalse('emptyString($this->declaredButNotEmptyVar)'));
	}

	private $declaredButEmptyVar;
	private $declaredButNotEmptyVar = "not empty";
}
?>
