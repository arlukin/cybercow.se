<?php
/**
* Unit test for all functions in Date.php.
*
*	@author Daniel Lindh <daniel@fareoffice.com>
* @ingroup unittests
*/
class UTDate extends foUnitTestBase
{
	public function doTest()
	{
		$this->_testIsValidDate();
		$this->_testIsValidTime();
	}

	private function _testIsValidDate()
	{
		$this->setSectionLabel('isValidDate');
		eval($this->needTrue('isValidDate("2006-01-01")'));
		eval($this->needTrue('isValidDate("2006-01-01 21:02:02")'));
		eval($this->needTrue('isValidDate("now")'));
		eval($this->needTrue('isValidDate("12jan2009")'));
		eval($this->needFalse('isValidDate("2009jan12")'));
		eval($this->needFalse('isValidDate("asdfasf")'));
		eval($this->needFalse('isValidDate("")'));
	}

	private function _testIsValidTime()
	{
		$this->setSectionLabel('isValidTime');
		eval($this->needTrue('isValidTime("21:02:02")'));
		eval($this->needFalse('isValidTime("21:00")'));
		eval($this->needFalse('isValidTime("25:02:02")'));
		eval($this->needFalse('isValidTime("21:62:02")'));
		eval($this->needFalse('isValidTime("21:02:62")'));
		eval($this->needFalse('isValidTime("2009jan12")'));
		eval($this->needFalse('isValidTime("asdfasf")'));
		eval($this->needFalse('isValidTime("")'));
	}
}
?>
