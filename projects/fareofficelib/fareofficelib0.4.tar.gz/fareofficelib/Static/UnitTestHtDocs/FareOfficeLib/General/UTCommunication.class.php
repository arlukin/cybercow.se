<?php
/**
* Unit test for all functions in Communication.class.php.
*
*	@author Daniel Lindh <daniel@fareoffice.com>
* @ingroup unittests
*/
class UTCommunication extends foUnitTestBase
{
	public function doTest()
	{
		eval($this->needNotEmpty('"Tests are disabled"'));
		/*
		$this->_testSendEmail();
		$this->_testSendSms();
		*/
	}

	private function _testSendEmail()
	{
		$this->setSectionLabel('sendEmail');
		$communication = new Communication(new FileLock('/tmp/locks/'));
		eval($this->needFalse('$communication->sendEmail
		(
			"from@example.com",
			"to@example.com",
			"I\'m afraid I have some bad news.",
			"Well that\'s a switch.",
			"<b>Well that\"s a switch.</b>"
		)'));
	}

	private function _testSendSms()
	{
		$this->setSectionLabel('sendEmail');
		$communication = new Communication(new FileLock('/tmp/locks/'));
		eval($this->needFalse('$communication->sendSms
		(
			"sms@example.com",
			"fareofficelib",
			"073xxxxx",
			"I\'m afraid I have some bad news. Well that\'s a switch."
		)'));
	}
}
?>
