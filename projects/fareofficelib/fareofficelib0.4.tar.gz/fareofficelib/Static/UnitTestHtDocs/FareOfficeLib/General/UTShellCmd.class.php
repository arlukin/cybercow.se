<?php
/**
* Unit test for all functions in ShellCmd.class.php.
*
*	@author Daniel Lindh <daniel@fareoffice.com>
* @ingroup unittests
*/
class UTShellCmd extends foUnitTestBase
{
	public function doTest()
	{
		$this->testExec();
		// Hard to create general unit test for ssh functions
		// $this->testSshExec();
	}

  function testExec()
  {
		$this->setSectionLabel('exec');

		try
	 	{
			eval($this->needEqual('ShellCmd::exec("uname")', '"Linux\n"'));
			eval($this->needEqual('ShellCmd::exec("uptime | wc -l")', '"1\n"'));
			eval($this->needEqual('ShellCmd::exec("wc", "I may be synthetic, but I\'m not stupid.\n\n")', '"      2       8      41\n"'));
	 	}
	 	catch (Exception $e)
	 	{
			eval($this->needEmpty('$e->getMessage()'));
	 	}

		try
	 	{
			ShellCmd::exec("ls -2");
	 	}
	 	catch (Exception $e)
	 	{
			eval($this->needEqual('$e->getMessage()', '"ls: invalid option -- \'2\'\nTry `ls --help\' for more information.\n Exit code: 2"'));
	 	}
  }

  function testSshExec()
  {
		$this->setSectionLabel('sshExec');

		try
	 	{
			eval($this->needEqual('ShellCmd::sshExec("arlukin@localhost", "uname")', '"Linux\n"'));
			eval($this->needEqual('ShellCmd::sshExec("arlukin@localhost", "uptime | wc -l")', '"1\n"'));
			eval($this->needEqual('ShellCmd::sshExec("arlukin@localhost", "wc", "I may be synthetic, but I\'m not stupid.\n\n")', '"      2       8      41\n"'));
	 	}
	 	catch (Exception $e)
	 	{
			eval($this->needEmpty('$e->getMessage()'));
	 	}

		try
	 	{
			ShellCmd::sshExec("arlukin@localhost", "ls -2");
	 	}
	 	catch (Exception $e)
	 	{
			eval($this->needEqual('$e->getMessage()', '"ls: invalid option -- \'2\'\nTry `ls --help\' for more information.\n Exit code: 2"'));
	 	}
  }
}

?>
