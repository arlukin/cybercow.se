<?php
/**
* Unit test for all functions in Benchmark.php.
*
*	@author Daniel Lindh <daniel@fareoffice.com>
* @ingroup unittests
*/
class UTBenchmark extends foUnitTestBase
{
	public function doTest()
	{
		$this->_testBenchmark();
	}

	private function _testBenchmark()
	{
		$timer = new Benchmark();

		$this->setSectionLabel('Benchmark');
		$timer->start();
		$timer->stop();

		$this->setSectionLabel('getElapsedTime');
		eval($this->needDate('$timer->getStartTime()'));
		eval($this->needDate('$timer->getStopTime()'));
		eval($this->needDate('$timer->getElapsedTime()'));
	}
}
?>
