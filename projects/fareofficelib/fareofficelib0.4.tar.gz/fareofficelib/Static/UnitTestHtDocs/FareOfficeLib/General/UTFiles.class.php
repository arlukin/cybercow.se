<?php
/**
* Unit test for all functions in Files.php.
*
*	@author Daniel Lindh <daniel@fareoffice.com>
* @ingroup unittests
*/
class UTFiles extends foUnitTestBase
{
	public function doTest()
	{
		$this->_testFileList();
	}

	private function _testFileList()
	{
		$this->setSectionLabel('fileList');

		eval($this->needEqual('fileList(".")', 'array(\'1\' => \'./FareOfficeLib\',\'16\' => \'./FareOfficeLib/Config\',\'17\' => \'./FareOfficeLib/Config/UTConfig.class.php\',\'18\' => \'./FareOfficeLib/Db\',\'19\' => \'./FareOfficeLib/Db/UTDb.class.php\',\'14\' => \'./FareOfficeLib/FoUnitTest\',\'15\' => \'./FareOfficeLib/FoUnitTest/UTFOUnitTestBase.class.php\',\'2\' => \'./FareOfficeLib/General\',\'11\' => \'./FareOfficeLib/General/UTArray.class.php\',\'7\' => \'./FareOfficeLib/General/UTBenchmark.class.php\',\'13\' => \'./FareOfficeLib/General/UTCommunication.class.php\',\'8\' => \'./FareOfficeLib/General/UTDate.class.php\',\'4\' => \'./FareOfficeLib/General/UTFileLock.class.php\',\'3\' => \'./FareOfficeLib/General/UTFiles.class.php\',\'12\' => \'./FareOfficeLib/General/UTPhpCronTab.php\',\'6\' => \'./FareOfficeLib/General/UTShellCmd.class.php\',\'5\' => \'./FareOfficeLib/General/UTString.class.php\',\'10\' => \'./FareOfficeLib/General/UTUrl.class.php\',\'9\' => \'./FareOfficeLib/General/UTUrlRequest.class.php\',\'0\' => \'./index.php\')'));
		eval($this->needEqual('fileList(".", "FILE")', 'array(\'13\' => \'./FareOfficeLib/Config/UTConfig.class.php\',\'14\' => \'./FareOfficeLib/Db/UTDb.class.php\',\'12\' => \'./FareOfficeLib/FoUnitTest/UTFOUnitTestBase.class.php\',\'9\' => \'./FareOfficeLib/General/UTArray.class.php\',\'5\' => \'./FareOfficeLib/General/UTBenchmark.class.php\',\'11\' => \'./FareOfficeLib/General/UTCommunication.class.php\',\'6\' => \'./FareOfficeLib/General/UTDate.class.php\',\'2\' => \'./FareOfficeLib/General/UTFileLock.class.php\',\'1\' => \'./FareOfficeLib/General/UTFiles.class.php\',\'10\' => \'./FareOfficeLib/General/UTPhpCronTab.php\',\'4\' => \'./FareOfficeLib/General/UTShellCmd.class.php\',\'3\' => \'./FareOfficeLib/General/UTString.class.php\',\'8\' => \'./FareOfficeLib/General/UTUrl.class.php\',\'7\' => \'./FareOfficeLib/General/UTUrlRequest.class.php\',\'0\' => \'./index.php\')'));
		eval($this->needEqual('fileList(".", "DIR")', 'array(\'0\' => \'./FareOfficeLib\',\'3\' => \'./FareOfficeLib/Config\',\'4\' => \'./FareOfficeLib/Db\',\'2\' => \'./FareOfficeLib/FoUnitTest\',\'1\' => \'./FareOfficeLib/General\')'));
		eval($this->needEqual('fileList(".", "FILE", FALSE)', 'array(\'0\'=>\'./index.php\')'));
	}
}
?>
