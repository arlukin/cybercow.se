<?php
/**
* Unit test for all functions in FileLock.php.
*
*	@author Daniel Lindh <daniel@fareoffice.com>
* @ingroup unittests
*/
class UTFileLock extends foUnitTestBase
{
	public function doTest()
	{
		$this->_test();
	}

	private function _test()
	{
		$this->setSectionLabel('deleteAllLocks');
 		$lockRoot = new FileLock('/');
		eval($this->needFalse('$lockRoot->deleteAllLocks()'));

 		$lockEmpty = new FileLock('');
		eval($this->needFalse('$lockEmpty->deleteAllLocks()'));

		$this->setSectionLabel('isLockExpired');
		$lock = new FileLock('/tmp/locks/');
		eval($this->needTrue('$lock->deleteAllLocks()'));

 		eval($this->needTrue('$lock->isLockExpired("SMS", 60, false)'));
		eval($this->needFalse('$lock->isLockExpired("SMS", 60, false)'));
		eval($this->needFalse('$lock->isLockExpired("SMS", 60, false)'));

		eval($this->needTrue('$lock->isLockExpired("SMS", 60, true)'));
		eval($this->needFalse('$lock->isLockExpired("SMS", 60, true)'));
		eval($this->needFalse('$lock->isLockExpired("SMS", 60, true)'));

		eval($this->needTrue('$lock->isLockExpired("EMAIL")'));
		eval($this->needFalse('$lock->isLockExpired("EMAIL")'));

		eval($this->needTrue('$lock->isLockExpired("PHONE", 0)'));
		sleep(1);
		eval($this->needTrue('$lock->isLockExpired("PHONE", 0)'));
	}
}
?>
