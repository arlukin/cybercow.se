<?php
/**
* Unit test for all functions in PhpCronTab.php.
*
*	@author Daniel Lindh <daniel@fareoffice.com>
* @ingroup unittests
*/
class UTPhpCronTab extends foUnitTestBase
{
	public function doTest()
	{
		$this->_testGetCurrentTime();
		$this->_testCheckMinute();
		$this->_testCheckHour();
		$this->_testCheckDayOfMonth();
		$this->_testCheckMonth();
		$this->_testCheckDayOfWeek();
	}

	private function _testGetCurrentTime()
	{
		$this->setSectionLabel('getCurrentTime');
		$phpCronTab = new PhpCronTab;

		$time = time();
		$phpCronTab->setCurrentTime($time);
		eval($this->needEqual('$phpCronTab->getCurrentTime()', '$time'));
	}

	public function _testCheckMinute()
	{
		$this->setSectionLabel('checkClock minute');
		$phpCronTab = new PhpCronTab;
		$phpCronTab->setCurrentTime(strtotime("2009-05-02 12:02"));

		$phpCronTab->addUnixFormatEx('1', '*', '*', '*', '*');
		eval($this->needFalse('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->addUnixFormatEx('*/3', '*', '*', '*', '*');
		eval($this->needFalse('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->clearUnixFormat();
		$phpCronTab->addUnixFormatEx('*/1', '*', '*', '*', '*');
		eval($this->needTrue('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->clearUnixFormat();
		$phpCronTab->addUnixFormatEx('2', '*', '*', '*', '*');
		eval($this->needTrue('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->clearUnixFormat();
		$phpCronTab->addUnixFormatEx('1-10', '*', '*', '*', '*');
		eval($this->needTrue('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->clearUnixFormat();
		$phpCronTab->addUnixFormatEx('1-1', '*', '*', '*', '*');
		eval($this->needFalse('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->clearUnixFormat();
		$phpCronTab->addUnixFormatEx('3-60', '*', '*', '*', '*');
		eval($this->needFalse('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->clearUnixFormat();
		$phpCronTab->addUnixFormatEx('1,3,5,8', '*', '*', '*', '*');
		eval($this->needFalse('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->clearUnixFormat();
		$phpCronTab->addUnixFormatEx('5,4,2,3', '*', '*', '*', '*');
		eval($this->needTrue('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->clearUnixFormat();
		$phpCronTab->addUnixFormatEx('6,7,2', '*', '*', '*', '*');
		eval($this->needTrue('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->clearUnixFormat();
		$phpCronTab->addUnixFormatEx('2,6,7', '*', '*', '*', '*');
		eval($this->needTrue('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->clearUnixFormat();
		$phpCronTab->addUnixFormatEx('*', '*', '*', '*', '*');
		eval($this->needTrue('$phpCronTab->isTimeToExecute()'));
	}

	public function _testCheckHour()
	{
		$this->setSectionLabel('checkClock hour');
		$phpCronTab = new PhpCronTab;
		$phpCronTab->setCurrentTime(strtotime("2009-05-02 12:02"));

		$phpCronTab->addUnixFormatEx('*', '13', '*', '*', '*');
		eval($this->needFalse('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->addUnixFormatEx('*', '*/10', '*', '*', '*');
		eval($this->needFalse('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->clearUnixFormat();
		$phpCronTab->addUnixFormatEx('*', '*/2', '*', '*', '*');
		eval($this->needTrue('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->clearUnixFormat();
		$phpCronTab->addUnixFormatEx('*', '*/4', '*', '*', '*');
		eval($this->needTrue('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->clearUnixFormat();
		$phpCronTab->addUnixFormatEx('*', '12', '*', '*', '*');
		eval($this->needTrue('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->clearUnixFormat();
		$phpCronTab->addUnixFormatEx('*', '*', '*', '*', '*');
		eval($this->needTrue('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->clearUnixFormat();
		$phpCronTab->addUnixFormatEx('2', '12', '*', '*', '*');
		eval($this->needTrue('$phpCronTab->isTimeToExecute()'));
	}

	public function _testCheckDayOfMonth()
	{
		$this->setSectionLabel('checkDayOfMonth');
		$phpCronTab = new PhpCronTab;
		$phpCronTab->setCurrentTime(strtotime("2009-05-02 12:02"));

		$phpCronTab->addUnixFormatEx('*', '*', '45', '*', '*');
		eval($this->needFalse('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->addUnixFormatEx('*', '*', 's', '*', '*');
		eval($this->needFalse('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->addUnixFormatEx('*', '*', '0', '*', '*');
		eval($this->needFalse('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->addUnixFormatEx('*', '*', '1', '*', '*');
		eval($this->needFalse('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->addUnixFormatEx('*', '*', '3', '*', '*');
		eval($this->needFalse('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->addUnixFormatEx('*', '*', '2', '*', '*');
		eval($this->needTrue('$phpCronTab->isTimeToExecute()'));
	}

	public function _testCheckMonth()
	{
		$this->setSectionLabel('checkMonth');
		$phpCronTab = new PhpCronTab;
		$phpCronTab->setCurrentTime(strtotime("2009-05-02 12:02"));

		$phpCronTab->addUnixFormatEx('*', '*', '*', '33', '*');
		eval($this->needFalse('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->addUnixFormatEx('*', '*', '*', '-2', '*');
		eval($this->needFalse('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->addUnixFormatEx('*', '*', '*', '2', '*');
		eval($this->needFalse('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->addUnixFormatEx('*', '*', '*', '4', '*');
		eval($this->needFalse('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->addUnixFormatEx('*', '*', '*', '6', '*');
		eval($this->needFalse('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->addUnixFormatEx('*', '*', '*', '5', '*');
		eval($this->needTrue('$phpCronTab->isTimeToExecute()'));
	}


	public function _testCheckDayOfWeek()
	{
		$this->setSectionLabel('checkDayOfWeek');
		$phpCronTab = new PhpCronTab;
		$phpCronTab->setCurrentTime(strtotime("2009-05-02 12:02"));

		$phpCronTab->addUnixFormatEx('*', '*', '*', '*', '23');
		eval($this->needFalse('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->addUnixFormatEx('*', '*', '*', '*', '0');
		eval($this->needFalse('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->addUnixFormatEx('*', '*', '*', '*', '1');
		eval($this->needFalse('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->addUnixFormatEx('*', '*', '*', '*', '2');
		eval($this->needFalse('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->addUnixFormatEx('*', '*', '*', '*', '3');
		eval($this->needFalse('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->addUnixFormatEx('*', '*', '*', '*', '4');
		eval($this->needFalse('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->addUnixFormatEx('*', '*', '*', '*', '5');
		eval($this->needFalse('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->addUnixFormatEx('*', '*', '*', '*', '7');
		eval($this->needFalse('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->addUnixFormatEx('*', '*', '*', '*', '8');
		eval($this->needFalse('$phpCronTab->isTimeToExecute()'));

		$phpCronTab->addUnixFormatEx('*', '*', '*', '*', '6');
		eval($this->needTrue('$phpCronTab->isTimeToExecute()'));
	}
}

?>
