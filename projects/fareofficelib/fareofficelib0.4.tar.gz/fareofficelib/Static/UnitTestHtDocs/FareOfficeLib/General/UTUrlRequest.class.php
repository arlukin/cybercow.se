<?php
/**
* Unit test for all functions in UrlRequst.class.php.
*
*	@author Daniel Lindh <daniel@fareoffice.com>
* @ingroup unittests
*/
class UTUrlRequest extends foUnitTestBase
{
	public function doTest()
	{
		$this->_testGet();
		$this->_testGetDateTime();
		$this->_testGetBool();
		$this->_testGetString();
		$this->_testgetInt();
	}

	private function _testGet()
	{
		$this->setSectionLabel('get');

		eval($this->needFalse('UrlRequst::get("start")'));
		eval($this->needFalse('UrlRequst::isSetArg("start")'));

		UrlRequst::setDefault('start', '2001-01-01');
		eval($this->needTrue('UrlRequst::isSetArg("start")'));
		eval($this->needEqual('UrlRequst::get("start")', '"2001-01-01"'));
		eval($this->needDiff('UrlRequst::get("start")', '"2s001-01-01"'));
	}

	private function _testGetDateTime()
	{
		$this->setSectionLabel('getDateTime');

		eval($this->needFalse('UrlRequst::getDateTime("startTime")'));
		eval($this->needFalse('UrlRequst::isSetArg("startTime")'));

		UrlRequst::setDefault('startTime', '2001-01-01');
		eval($this->needTrue('UrlRequst::isSetArg("startTime")'));
		eval($this->needDate('UrlRequst::getDateTime("startTime")'));
	}

	private function _testGetBool()
	{
		$this->setSectionLabel('getBool');

		eval($this->needFalse('UrlRequst::getBool("enable")'));

		UrlRequst::set('enable', 'false');
		eval($this->needFalse('UrlRequst::getBool("enable")'));

		UrlRequst::set('enable', 'nO');
		eval($this->needFalse('UrlRequst::getBool("enable")'));

		UrlRequst::set('enable', '0');
		eval($this->needFalse('UrlRequst::getBool("enable")'));

		UrlRequst::set('enable', 'FalSe');
		eval($this->needFalse('UrlRequst::getBool("enable")'));

		UrlRequst::set('enable', 'true');
		eval($this->needTrue('UrlRequst::getBool("enable")'));

		UrlRequst::set('enable', 'yes');
		eval($this->needTrue('UrlRequst::getBool("enable")'));

		UrlRequst::set('enable', '1');
		eval($this->needTrue('UrlRequst::getBool("enable")'));

		UrlRequst::set('enable', 'TruE');
		eval($this->needTrue('UrlRequst::getBool("enable")'));
	}

	private function _testGetString()
	{
		$this->setSectionLabel('getString');

		eval($this->needEmpty('UrlRequst::getString("string")', '""'));

		UrlRequst::setDefault('string', 'That\'s it man, game over man, game over!');
		eval($this->needEqual('UrlRequst::getString("string")', '"That\'s it man, game over man, game over!"'));

		UrlRequst::setDefault('string', 'What the fuck are we gonna do now? What are we gonna do?');
		eval($this->needEqual('UrlRequst::getString("string")', '"That\'s it man, game over man, game over!"'));

		UrlRequst::set('string', 'Maybe we could build a fire, sing a couple of songs, huh?');
		eval($this->needEqual('UrlRequst::getString("string")', '"Maybe we could build a fire, sing a couple of songs, huh?"'));
	}

	private function _testgetInt()
	{
		$this->setSectionLabel('getInt');

		eval($this->needFalse('UrlRequst::getInt("number")'));

		UrlRequst::set('number', 'asdfsdf');
		eval($this->needFalse('UrlRequst::getInt("number")'));

		UrlRequst::set('number', '123');
		eval($this->needEqual('UrlRequst::getInt("number")', '"123"'));

		UrlRequst::set('number', '123');
		eval($this->needEqual('UrlRequst::getInt("number")', '123'));

		UrlRequst::set('number', '123,34');
		eval($this->needFalse('UrlRequst::getInt("number")', '123'));
	}
}

?>
