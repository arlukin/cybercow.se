<?php
/**
* Unit test for the class foUnitTestBase.
*
*	@author Daniel Lindh <daniel@fareoffice.com>
* @ingroup unittests
*/
class utFOUnitTestBase extends foUnitTestBase
{
	public function doTest()
	{
		$this->_testNeedEmpty();
		$this->_testNeedNotEmpty();
		$this->_testNeedTrue();
		$this->_testNeedFalse();
		$this->_testNeedEqual();
		$this->_testNeedDiff();
		$this->_testNeedDiffReq();
		$this->_testNeedDate();
	}

	private function _testNeedEmpty()
	{
		$this->setSectionLabel('needEmpty');
		$this->addSectionText('Will check FOUnitTestBase::needEmpty().');

		// Will succeed
		eval($this->needEmpty('""'));

		$nullVar = NULL;
		eval($this->needEmpty('$nullVar'));

		$emptyArray = array();
		eval($this->needEmpty('$emptyArray'));
	}

	private function _testNeedNotEmpty()
	{
		$this->setSectionLabel('needNotEmpty');

		// Will succeed
		eval($this->needNotEmpty('"Fareoffice"'));
		eval($this->needNotEmpty('0'));

		$nonEmptyVar = 'Fareoffice';
		eval($this->needNotEmpty('$nonEmptyVar'));

		$trueVar = true;
		eval($this->needNotEmpty('$trueVar'));

		$nonEmptyArray = array(0,1,2);
		eval($this->needNotEmpty('$nonEmptyArray'));
	}

	private function _testNeedTrue()
	{
		$this->setSectionLabel('needTrue');

		eval($this->needTrue('(1==1)'));
		eval($this->needTrue('true'));
		eval($this->needTrue('!false'));

		$trueVar = true;
		eval($this->needTrue('$trueVar'));
	}

	private function _testNeedFalse()
	{
		$this->setSectionLabel('needFalse');

		eval($this->needFalse('(1 != 1)'));
		eval($this->needFalse('false'));
		eval($this->needFalse('!true'));

		$falseVar = false;
		eval($this->needFalse('$falseVar'));
	}

	private function _testNeedEqual()
	{
		$this->setSectionLabel('needEqual');

		eval($this->needEqual('(3+2)', '5'));

		$numVar = 5;
		eval($this->needEqual('$numVar', '5'));

		$stringVar = 'Fareoffice';
		eval($this->needEqual('$stringVar', '"Fareoffice"'));

		$rootDir = dir("/tmp");
		eval($this->needEqual('$rootDir->path', '"/tmp"'));

		$arr = array(1,2,3,4);
		eval($this->needEqual('$arr', 'unserialize("a:4:{i:0;i:1;i:1;i:2;i:2;i:3;i:3;i:4;}")'));
	}

	private function _testNeedDiff()
	{
		$this->setSectionLabel('needDiff');

		eval($this->needDiff('(3+2)', '4'));

		$numVar = 5;
		eval($this->needDiff('$numVar', '4'));

		$stringVar = 'Fareoffice';
		eval($this->needDiff('$stringVar', '"fareoffice"'));

		$rootDir = dir("/tmp");
		eval($this->needDiff('$rootDir->path', '"/tMp"'));

		$arr = array(1,2,3,4);
		eval($this->needDiff('$arr', 'unserialize("a:4:{i:0;si:1;i:1;i:2;i:2;i:3;i:3;i:4;}")'));
	}

	private function _testNeedDiffReq()
	{
		$this->setSectionLabel('needEqualReg');

		eval($this->needEqualReg('(3+102)', '"/^[\d]{2,3}$/"'));

		$numVar = 5;
		eval($this->needEqualReg('$numVar', '"/^[5]$/"'));

		$stringVar = 'Fareoffice';
		eval($this->needEqualReg('$stringVar', '"/^[\w]*$/"'));

		$rootDir = dir("/tmp");
		eval($this->needEqualReg('$rootDir->path', '"/^[\/][\w]*$/"'));

		$today = date('dMY H:i:s', strtotime('now'));
		eval($this->needEqualReg('$today', '"/^[\d]{2}[\w]{3}[\d]{4} [\d]{2}[:][\d]{2}[:][\d]{2}$/"'));
	}

	private function _testNeedDate()
	{
		$this->setSectionLabel('needDate');

		eval($this->needDate('"2001-01-01"'));
		eval($this->needDate('"2001-01-30"'));
		eval($this->needDate('"2001-01-20 20:00"'));
		eval($this->needDate('"2001-01-20 20:00:00"'));
		eval($this->needDate('"2001-01-20 20:00:00"'));
		eval($this->needDate('"01jan2009"'));
	}
}
?>
