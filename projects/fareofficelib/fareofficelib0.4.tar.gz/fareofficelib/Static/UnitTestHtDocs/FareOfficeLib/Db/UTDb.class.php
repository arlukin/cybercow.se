<?php
/**
* Unit test for all functions in Db.php.
*
*	@author Daniel Lindh <daniel@fareoffice.com>
* @ingroup unittests
*/
class UTDb extends foUnitTestBase
{
	public function doTest()
	{
		$this->_testDbClass();
		$this->_testEscN();
		$this->_testEscS();
	}

	private function _testDbClass()
	{
		$this->setSectionLabel('Db class');
		$config = new Config();

		eval($this->needNotEmpty('$db = new Db($config)'));
		eval($this->needEmpty('$db->setConfigName("mysql")'));
		eval($this->needEqual('$db->getConfigName()', '"mysql"'));
		eval($this->needEmpty('$db->pushConfigName("dead_database")'));
		eval($this->needEqual('$db->getConfigName()', '"dead_database"'));
		eval($this->needEmpty('$db->popConfigName()'));
		eval($this->needEqual('$db->getConfigName()', '"mysql"'));
		eval($this->needNotEmpty('$conn = $db->getConnection()'));
		eval($this->needNotEmpty('$resultSet = $db->executeQuery("select \"Hey, Bishop. Do the thing with the knife. \" as col1")'));
		$resultSet->next();
		eval($this->needEqual('$resultSet->getRecordCount()', '1'));
		eval($this->needEqual('$resultSet->getString("col1")', '"Hey, Bishop. Do the thing with the knife. "'));
	}

	private function _testEscN()
	{
		$this->setSectionLabel('escN');

		$emptyString = "";
		eval($this->needEqual('escN($emptyString)', '"NULL"'));

		$number23 = 23;
		eval($this->needEqual('escN($number23)', 23));

		$zeroNumber = 0;
		eval($this->needEqual('escN($zeroNumber)', 0));
	}

	private function _testEscS()
	{
		$this->setSectionLabel('escS');

		$emptyString = "";
		eval($this->needEqual('escS($emptyString)', '"NULL"'));

		$notEmptyString = "Game over man";
		eval($this->needEqual('escS($notEmptyString)', "'\'Game over man\''"));
		eval($this->needEqual('escS($notEmptyString, "%", ESC_NONE)', "'\'Game over man\''"));
		eval($this->needEqual('escS($notEmptyString, "%", ESC_LAST)', "'\'Game over man%\''"));
		eval($this->needEqual('escS($notEmptyString, "%", ESC_FIRST)', "'\'%Game over man\''"));
		eval($this->needEqual('escS($notEmptyString, "%", ESC_BOTH)', "'\'%Game over man%\''"));

		$number23 = 23;
		eval($this->needEqual('escS($number23)', "'\'23\''"));

		$zeroNumber = 0;
		eval($this->needEqual('escS($zeroNumber)', "'\'0\''"));

		$zeroNumber = 0;
		eval($this->needEqual('escS($zeroNumber)', 0));
	}
}
?>
