<?php
/**
 * Global constans and defines.
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @ingroup general
 */

	/**
	 * Path to the directory where the library are installed.
	 */
	define('FAREOFFICE_LIB_ROOT', realpath(dirname(__FILE__)) . '/');

	/**
	 * Unix syntax of a new line
	 */
	DEFINE('NEWLINE', "\r\n");
?>
