<?php

/**
 * Include files
 */
//include_once(FAREOFFICE_LIB_ROOT  . 'creole/Creole.php');
include_once('creole/Creole.php');

/**
*	Functions to communicate with the database server.
*
*	@author Daniel Lindh <daniel@fareoffice.com>
* @ingroup db
*/
class Db
{
	/**
	 *
	 */
	public function Db(Config $config_)
	{
		$this->_config = $config_;
	}

	/**
	 * Execute a database query.
	 *
	 * @param $sql_ - string -
	 * 				The sql query.
	 *
	 * @return ResultSet
	 */
	public function executeQuery($sql_)
	{
		$conn = $this->getConnection();
		return $conn->executeQuery($sql_);
	}

	/**
	 * Get a creole database Connection.
	 *
	 * @return Connection
	 */
	function getConnection()
	{
		$dsn = $this->_config->getDBDSN($this->getConfigName());

		return  Creole::getConnection($dsn);
	}

	/**
	 * Set database config name.
	 *
	 * @param $configName_ - string -
	 * 				A config name. Ie foMaster
	 */
	public function setConfigName($configName_)
	{
		$this->_configName = $configName_;
	}

	/**
	 * Get current config name that is used.
	 *
	 * @return string
	 */
	public function getConfigName()
	{
		return $this->_configName;
	}

	/**
	 * Set a new datbase config name, and save the old one on a stack.
	 *
	 * @param $configName_ - string -
	 * 				A config name. Ie foMaster
	 */
	public function pushConfigName($configName_)
	{
		array_push($this->_configNameStack, $this->_configName);
		$this->setConfigName($configName_);
	}

	/**
	 * Set the last pushed config name.
	 *
	 */
	public function popConfigName()
	{
		$this->_configName = array_pop($this->_configNameStack);
	}

	/**
	 * The current used database config name.
	 */
	private $_configName = 'foMaster';

	/**
	 * An array used as a stack with config names.
	 *
	 * @see Db::pushConfigName()
	 */
	private $_configNameStack = array();
}
?>
