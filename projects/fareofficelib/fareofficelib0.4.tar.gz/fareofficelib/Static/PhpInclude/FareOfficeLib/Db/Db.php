<?php
/**
*	Includes database manipulating functions
*
*	@author Daniel Lindh <daniel@fareoffice.com>
* @ingroup db
* @file Db/Db.php
*/

/**
 * Escape/prepare variables for numeric SQL queries.
 *
 * Example:
 * @code
 * // Will create UPDATE user SET login_count = NULL;
 * $loginCount = NULL;
 * $sql = 'UPDATE user SET login_count = ' . $escN($loginCount;
 * @endcode
 * @public
 */
function &escN(&$value)
{
	if (emptyString($value))
	{
		return 'NULL';
	}
	else
	{
		return $value;
	}
};

/**
 * Escape/prepare variables for string SQL queries.
 *
 * Example:
 * @code
 * // Will create UPDATE user SET user_name = "Daniel";
 * $userName = 'Daniel';
 * $sql = 'UPDATE user SET user_name = ' . escS($userName);
 *
 * // Will create SELECT * FROM user WHERE user LIKE 'Daniel%';
 * $userName = 'Daniel';
 * $sql = 'SELECT * FROM user WHERE user LIKE ' . escS($userName, '%');
 * @endcode
 * @public
 */
define ('ESC_NONE',  0);
define ('ESC_LAST',  1);
define ('ESC_FIRST', 2);
define ('ESC_BOTH',  3);
function &escS(&$value, $tkn = '', $type = ESC_LAST)
{
	if (is_array($value) || is_object($value))
	{
		$v = serialize($value);
	}
	else
	{
		$v =& $value;
	}

	if (emptyString($v))
	{
		$ret = 'NULL';
	}
	else
	{
		switch ($type)
		{
			case ESC_LAST:
				$ret = '\'' . mysql_real_escape_string($v) . $tkn.'\'';
				break;

			case ESC_FIRST:
				$ret = '\'' . $tkn . mysql_real_escape_string($v).'\'';
				break;

			case ESC_BOTH:
				$ret = '\'' . $tkn . mysql_real_escape_string($v) . $tkn.'\'';
				break;

			case ESC_NONE:
				$ret = '\'' . mysql_real_escape_string($v).'\'';
				break;

			default:
				ASSERTLOG(TRUE, LOG_SYSTEMERROR, 'ecsS: Invalid type', EL_LEVEL_3, ECAT_SYSTEM_CORE);
				exit;
		}
	}

	return $ret;
}
?>
