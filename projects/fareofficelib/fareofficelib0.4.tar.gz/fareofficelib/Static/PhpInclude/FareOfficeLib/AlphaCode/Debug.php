<?php
/**
 *	Includes debug functions
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @ingroup general
 * @file Debug.php
 * @todo Find all code that are using assertlog, and modify.
 * @todo Create a common interface for debug and unit test classes
 * 			 something assertNeedFalse etc.
 */

	// ERROR REPORT LEVELS (assertLog, PHP ERROR REPORTER)
	define('EL_LEVEL_0', 0); // Debug, Only trace output on screen. No mail sent! Trace no exit!
	define('EL_LEVEL_1', 1); // Notice, Mail is sent  Trace no exit!
	define('EL_LEVEL_2', 2); // Warning
	define('EL_LEVEL_3', 3); // Error
	define('EL_LEVEL_4', 4); // Critical Error with On call alert!

	define('ECAT_DIAGNOSTIC', 											'ECAT_DIAGNOSTIC'); 	// Errors in the diagnostic application

	/**
	 * Enter description here...
	 *
	 * @param $condition_ - bool -
	 * 				true  - Everything is ok.
	 * 				false - Invalid condition, should assert.
	 * @param $errLevel_
	 * @param $errCategory_
	 * @param $subject_
	 * @param $variables_
	 */
	function assertLog($condition_, $errLevel_, $errCategory_, $subject_, $variables_ = array())
	{
		// Go through all assertLog, and see if any level should be changed,
		// maybe more SMS errors. Because most of the problems should never occure.
		if (!$condition_)
		{
			echo "<pre>asserted";
			var_dump(debug_backtrace());
			echo "</pre>";
			exit;
		}
	}
?>
