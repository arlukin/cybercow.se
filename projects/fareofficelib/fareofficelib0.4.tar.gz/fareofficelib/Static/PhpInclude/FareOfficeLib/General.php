<?php
/**
* General PHP functionality such as string, db and array manipulations.
*
*	@author Daniel Lindh <daniel@fareoffice.com>
*	@defgroup general General
*/

include_once('General/Array.php');
include_once('General/Benchmark.class.php');
include_once('3dPart/Rmail/Rmail.php');
include_once('General/Communication.class.php');
include_once('General/Date.php');
include_once('General/FileLock.class.php');
include_once('General/Files.php');
include_once('General/PhpCronTab.class.php');
include_once('General/ShellCmd.class.php');
include_once('General/String.php');
include_once('General/Url.class.php');
include_once('General/UrlRequest.class.php');
?>
