<?php
$this->setEnvironmentDir('/var/www/fareofficeroot/');

$dbConfig->setDSN('mysql', 		'mysql', 'localhost', 'root', '', 'mysql');

?>
