<?php
/**
* Database functions.
*
*	@author Daniel Lindh <daniel@fareoffice.com>
*	@defgroup db Db
*/

include_once('Db/Db.class.php');
include_once('Db/Db.php');
?>
