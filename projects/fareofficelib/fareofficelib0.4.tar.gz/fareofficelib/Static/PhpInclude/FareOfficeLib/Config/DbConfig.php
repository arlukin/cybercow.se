<?php
/**
 * Holds login information to the database server.
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @ingroup config
 */
class DbConfig
{
	/**
	 * Remove all database configurations.
	 */
	public function clearDSN()
	{
		return $this->_configurations = array();
	}

	/**
   * Set the database dsn:s that can be used.
	 *
	 * @param $configName_ - string -
	 * 				Name of the configuration, doesn't need to be the same as the database name.
	 *
	 * @param $dbType_ - string -
	 * 				The database server type.
	 *
	 * @param $hostip_ - string -
	 * 				The ip number (or domain name) to the database server.
	 *
	 * @param $username_ - string -
	 * 				Username to the datbase server.
	 *
	 * @param $password_ - string -
	 * 				Password to the datbase server.
	 *
	 * @param $dbName_ - string -
	 * 				The name of the database in the database server.
	 */
	public function setDSN($configName_, $dbType_, $hostip_, $username_, $password_, $dbName_)
	{
		$configName_ = strtolower($configName_);
		$this->_configurations[$configName_] = array
		(
			'phptype'  => $dbType_,
      'hostspec' => $hostip_,
      'username' => $username_,
      'password' => $password_,
      'database' => $dbName_
		);
	}

	/**
	 * Get the dsn name to the database.
	 *
	 * @param $configName_ - string -
	 * 				The name of the database configuration.
	 * 				For more information see dbConfig::setDSN()
	 *
	 * @return array	An array with DB DSN info.
	 */
	public function getDSN($configName_)
	{
		$configName_ = strtolower($configName_);
		return $this->_configurations[$configName_];
	}

	/**
	 * Array list with dsn information.
	 *
	 * $configurations['fomaster']['phptype']  = 'mysql;
	 * $configurations['fomaster']['hostspec'] = '192.168.2.250';
	 * $configurations['fomaster']['username'] = 'username';
	 * $configurations['fomaster']['password'] = 'xxx';
	 * $configurations['fomaster']['database'] = 'foMaster';
	 */
	private $_configurations;
}
?>
