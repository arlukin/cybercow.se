<?php
/**
 * Classes that handles general configuration of the systems.
 *
 * The directory model we are using at Fareoffice are also controlled
 * by this class. The model looks like the following.
 *
 * app/Config/
 * app/Log/
 *
 * app/Site/www.fareoffice.com/Static/HtDocs
 * app/Site/www.fareoffice.com/Static/PhpInclude
 * app/Site/www.fareoffice.com/Temp/Log
 * app/Site/www.fareoffice.com/Temp/Cache
 *
 * app/Site/www.customer.com/Static/HtDocs
 * app/Site/www.customer.com/Static/PhpInclude
 * app/Site/www.customer.com/Temp/Log
 * app/Site/www.customer.com/Temp/Cache
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @ingroup config
 */

/**
 * Include files
 */
require_once(FAREOFFICE_LIB_ROOT . 'General/Files.php');
require_once('SiteConfig.php');
require_once('DbConfig.php');

/**
 * Environment settings for the application server.
 */
class Config
{
	/**
	 * Read all default settings from 'Settings.php'
	 */
	public function Config()
	{
		$dbConfig = $this->getDbConfig();

		include(FAREOFFICE_LIB_ROOT . 'Settings.php');
	}

	/**
	 * Set the directory where the application is installed.
	 * Ie. '/opt/RootLive/'
	 *
	 * @return string
	 */
	public function setEnvironmentDir($name_)
	{
		$this->_environmentDir = rtrim($name_, '/') . '/';
	}

	/**
	 * Returns the directory where the application is installed.
	 * Ie. '/opt/RootLive/'
	 *
	 * @return string
	 */
	public function getEnvironmentDir()
	{
		return $this->_environmentDir;
	}

	/**
	 * Returns the directory where the general log files are saved.
	 *
	 * Ie. '/opt/RootLive/Log/'
	 *
	 * @return string
	 */
	public function getLogDir()
	{
		return $this->getEnvironmentDir() . 'Log/';
	}

	/**
	 * Returns the directory where all sites/dists are installed.
	 *
	 * Ie. '/opt/RootLive/Site/'
	 *
	 * @return string
	 */
	public function getSiteDir()
	{
		return $this->getEnvironmentDir() . 'Site/';
	}

	/**
	 * Get a list with SiteConfig objects, one for each installed site/dist.
	 *
	 * @return SiteConfig	Returns an array with SiteConfig objects.
	 */
	public function getSites()
	{
		if (!is_array($this->sites))
		{
			$this->_sites = array();
			foreach(fileList($this->getSiteDir(), 'DIR', FALSE) as $site)
			{
				$this->_sites[basename($site)] = new SiteConfig($site . '/');
			}
		}
		return $this->_sites;
	}

	/**
	 * Get a list with SiteConfig objects, one for each installed site/dist.
	 *
	 * @return SiteConfig	Returns an array with SiteConfig objects.
	 */
	public function getSite($siteName_)
	{
		$siteArr = $this->getSites();
		return $siteArr[$siteName_];
	}

	/**
	 * Get the dsn name to the database.
	 *
	 * @param $configName_ - string -
	 * 				The name of the database configuration.
	 * 				For more information see {@link DbConfig::setDSN()}
	 *
	 * @return array	An array with DB DSN info.
	 * 								arr['phptype']  = 'mysql;
	 * 								arr['hostspec'] = '192.168.2.250';
	 * 								arr['username'] = 'username';
	 * 								arr['password'] = 'xxx';
	 * 								arr['database'] = 'foMaster';
	 */
	public function getDBDSN($configName_)
	{
		return $this->getDbConfig()->getDSN($configName_);
	}

	/**
	 * Get a DbConfig object.
	 *
	 * The DbConfig object holds all database configurations.
	 *
	 * @return dbConfig
	 */
	public function getDbConfig()
	{
		if (!is_object($this->dbConfig))
		{
			$this->dbConfig = new DbConfig();
		}

		return $this->dbConfig;
	}

	/**
	 * See setEnvironmentDir()
	 */
	private $_environmentDir;

	/**
	 * Holds a DbConfig instance Config::getDbConfig()}
	 *
	 * With this variable getDbConfig() don't need to recreate
	 * the instance at each call.
	 */
	private $_dbConfig;

	/**
	 * A list of SiteConfig objects.
	 */
	private $_sites;
}

?>
