<?php
/**
 * Environment settings for a site.
 *
 * Each directory under /opt/RootLive/Site is a Site. This
 * class will have a representation object for each Site. The
 * representation is created by {@link Config}
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @ingroup config
 */
class SiteConfig
{
	/**
	 * Constructor
	 *
	 * Will set the site directory.
	 *
	 * @param $siteDir_ - string -
	 * 				Site directory.
	 */
	public function __construct($siteDir_)
	{
		$this->_siteDir = $siteDir_;
	}

	/**
	 * Get the log file directory for this site.
	 *
	 * @return string
	 */
	public function getLogDir()
	{
		return $this->_siteDir . 'Temp/Log/';
	}

 /**
	 * Get the cache file directory for this site.
	 *
	 * @return string
	 */
	public function getCacheDir()
	{
		return $this->_siteDir . 'Temp/Cache/';
	}

	/**
	 * The site directory.
	 *
	 * Example
	 * @code
	 * /opt/RootLive/Site/DistSysOpProduction
	 * @endcode
	 */
	private $_siteDir;
}
?>
