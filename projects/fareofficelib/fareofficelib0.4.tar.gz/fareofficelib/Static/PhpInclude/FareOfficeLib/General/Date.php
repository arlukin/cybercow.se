<?php
/**
 * Includes date manipulating functions
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @ingroup general
 * @file Date.php
 */

/**
 * Returns true if the input variable is a valid date or datetime.
 *
 * @code
 * isValidDate('2006-01-01');
 * isValidDate("2006-01-01 21:02:02")'));
 * isValidDate("now")'));
 * isValidDate("12jan2009")'));
 * @endcode
 *
 * @param $date_ - dateTime -
 * 				The date to validate.
 *
 * @return - boolean -
 */
function isValidDate($date_)
{
	$time = strtotime($date_);
	if ($time === false)
	{
		return false;
	}

	return true;
}

/**
 * Returns true if the input variable is a valid time.
 *  - Need to have all parts of the time hh:mm:ss
 *
 * @code
 * isValidTime('21:02:00');
 * @endcode
 *
 * @param $time_ - string -
 * @return - boolean-
 */
function isValidTime($time_)
{
	$matches = NULL;
	preg_match('/^([\d]{1,2})[:]{1}([\d]{2})[:]{1}([\d]{2})$/', $time_, $matches);

	if
	(
		empty($matches) ||
		$matches[1] < 0 ||
		$matches[1] >= 24 ||
		$matches[2] < 0 ||
		$matches[2] >= 60 ||
		$matches[3] < 0 ||
		$matches[3] >= 60
	)
	{
		return false;
	}
	else
	{
		return true;
	}
}

?>
