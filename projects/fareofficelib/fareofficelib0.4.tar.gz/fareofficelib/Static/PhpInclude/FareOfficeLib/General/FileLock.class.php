<?php
/**
 * Include files
 */
	require_once('ILock.php');

/**
 * Does a server global lock on a lock name.
 *
 * A file with the lock name are saved to the file system,
 * if that file is older then $lockTime_ seconds this function returns
 * true.
 *
 * This is used to see how long ago a certatin operation was done.
 * Example, If it's more then 15 minutes since we last did send
 * and SMS message we can now send a new.
 *
 * Example:
 * @code
 * $lock = new FileLock('/tmp/locks/');
 * if ($lock->_isLockExpired('SMS'))
 * {
 *   // Send SMS
 * }
 *
 * if ($lock->_isLockExpired('/usr/root/master/%more?d=true', 60, TRUE))
 * {
 *   // Send SMS
 * }
 * @endcode
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @ingroup general
 */
class FileLock implements ILock
{
	/**
	 * Constructor
	 *
	 * @param $lockPath_ - string -
	 * 				The path to where to save the lock files.
	 * 				Ie. /tmp/locks/
	 */
	function FileLock($lockPath_)
	{
		$this->setLockPath($lockPath_);
	}

	/**
	 * Set the lock path.
	 *
	 * @param $lockPath_ - string -
	 * 				The path to where to save the lock files.
	 * 				Ie. /tmp/locks/
	 */
	public function setLockPath($lockPath_)
	{
		$this->_lockPath = rtrim($lockPath_, '/') . '/';

		if (!file_exists($this->_lockPath))
		{
			if (!@mkdir($this->_lockPath, 0755, true))
			{
				// @todo add assertlog
				//assertLog(false, EL_LEVEL_3, ECAT_DIAGNOSTIC, 'Couldnt create lockPath: ' . $this->_lockPath);

				echo('Couldnt create path');
				exit;
			}
		}
	}

	/**
	 * Get The path to where the lock files are stored.
	 *
	 * Ie. /tmp/locks
	 *
	 * @return	- string -
	 */
	public function getLockPath()
	{
		// @todo add assertlog
		//assertLog(!empty($this->_lockPath), EL_LEVEL_3, ECAT_DIAGNOSTIC, 'Couldnt create lockPath: ' . $this->_lockPath);
		return $this->_lockPath;
	}

	/**
	 * Delete all lock files, both expired and not expired.
	 *
	 * @return - boolean - true if files where deleted successfully.
	 */
	public function deleteAllLocks()
	{
		$path = $this->getLockPath();

		if
		(
			!empty($path) &&
			$path != '/'
		)
		{
			exec('rm ' . $path . '*.lock', $arr, $retval);
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * Check if the file is locked.
	 *
	 * An entity is locked in the system, if that entity was locked more
	 * then $lockTime_ seconds ago, this funtion returns true.
	 *
	 * This is used to see how long ago a certatin operation was done.
	 * Example, If it's more then 1 minute since we last did send
	 * an SMS message we can now send a new.
	 *
	 * @param	$lockName_ - string -
	 * 				The name of the lock/variable/file.
	 *
	 * @param	$lockTime_ - string -
	 * 				Seconds the lockTitle is locked before expiring.
	 *
	 * @param	$compressName_ - boolean -
	 * 				true - An md5 will be done on the filename/lockName_.
	 *
	 * @return	- boolean -
	 */
	public function isLockExpired
	(
		$lockName_,
		$lockTime_ = 60,
		$compressName_ = true
	)
	{
		$fileName = $this->_getFileName($lockName_, $compressName_);

		$retVal = false;
		if
		(
			!file_exists($fileName) ||
			filemtime($fileName) < (time() - $lockTime_)
		)
		{
			$handle = @fopen($fileName, 'w');

			if ($handle !== false)
			{
				fwrite($handle, $lockName_);
				$retVal = true;
				fclose($handle);
			}
		}

		return $retVal;
	}

	/**
	 * Returns a valid file path for the $lockName_.
	 */
	private function _getFileName($lockName_, $compressName_)
	{
		if ($compressName_)
		{
			$lockName_ = md5($lockName_);
		}

		$fileName = $this->getLockPath() . md5($lockName_) . '.lock';

		return $fileName;
	}

	/**
	 * The path to where to save the lock files.
	 * Ie. /tmp/locks/
	 */
	private $_lockPath;
}

?>
