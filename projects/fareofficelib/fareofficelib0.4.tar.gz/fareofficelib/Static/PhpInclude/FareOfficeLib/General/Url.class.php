<?php
/**
 * Includes URL manipulating functions
 *
 * These functions are based on
 * http://www.chrsen.dk/fundanemt/files/scripter/php/misc/rfc3986.php
 *
 * @author Christian Hansen <chrsen@fundanemt.com>
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @ingroup general
 */
class Url
{
  /**
   * Transform relative uri into target uri, rfc3986 compatible.
	 * Read more at <http://rfc.net/rfc3986.html> section 5.2
	 *
	 * @code
	 * // Will give http://cybercow.se/php/ex/error/index.php
	 * $url = url::absUrl("http://cybercow.se/php/ex/absurl/index.php", "../error/index.php")
	 * @endcode
   */
  public function absUrl($base_, $url_)
  {
  	static $urlCache = array();

  	$urlKey = md5($base_. '___' . $url_);
  	if (!array_key_exists($urlKey, $urlCache))
  	{
			preg_match("/^(([^:\/?#]+):)?(\/\/([^\/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?/",$url_,$urlComp);
		  list(,,$Rscheme,,$Rauthority,$Rpath,,$Rquery,,$Rfragment) = $urlComp;

		  if ( isset($Rscheme) && !empty($Rscheme) )
		  {
		    $Tscheme    = $Rscheme;
		    $Tauthority = $Rauthority;
		    $Tpath      = url::_removeDotSegments($Rpath);
		    $Tquery     = $Rquery;

		  }
		  else
		  {
	      if ( isset($Rauthority) && !empty($Rauthority) )
	      {
	       	$Tauthority = $Rauthority;
	        $Tpath      = url::_removeDotSegments($Rpath);
	        $Tquery     = $Rquery;
	      }
	      else
	      {
					preg_match("/^(([^:\/?#]+):)?(\/\/([^\/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?/",$base_,$baseComp);
				  list(,,$Bscheme,,$Bauthority,$Bpath,,$Bquery,,$Bfragment) = $baseComp;

		      if ( $Rpath == "")
		      {
		        $Tpath = $Bpath;
		        if ( isset($Rquery) && !empty($Rquery) )
		        {
		        	$Tquery = $Rquery;
		        }
		        else
		        {
		        	$Tquery = $Bquery;
		        }
		      }
		      else
		      {
		        if ( preg_match("/^\//", $Rpath) )
		        {
		        	$Tpath = url::_removeDotSegments($Rpath);
		        }
		        else
		        {
		          $Tpath = url::_merge($Bpath,$Bauthority,$Rpath);
		        	$Tpath = url::_removeDotSegments($Tpath);
		        }// preg_match("/^//", $Rpath)

		        $Tquery = $Rquery;
		      }//if $Rpath == ""

		      $Tauthority = $Bauthority;
	      }// isset($Rauthority) && !empty($Rauthority)

	      $Tscheme = $Bscheme;

		  }// isset($Rscheme) && !empty($Rscheme)

		  $Tfragment = $Rfragment;

		  $result = "";

		  if ( isset($Tscheme) && !empty($Tscheme) )
		  {
		  	$result .= $Tscheme . ":";
		  }

		  if ( isset($Tauthority) && !empty($Tauthority) )
		  {
		  	$result .= "//" . $Tauthority;
		  }

		  $result .= $Tpath;

		  if ( isset($Tquery) && !empty($Tquery) )
		  {
		  	$result .= "?" . $Tquery;
		  }

		  if ( isset($Tfragment) && !empty($Tfragment) )
		  {
		  	$result .= "#" . $Tfragment;
		  }

		  $urlCache[$urlKey] = $result;
  	}

  	return $urlCache[$urlKey];
  }//function


  private function _removeDotSegments($path)
  {
		/*
		   1.  The input buffer is initialized with the now-appended path
		       components and the output buffer is initialized to the empty
		       string.
		*/
    $bInput = $path;
    $bOutput = "";
		/*
		   2.  While the input buffer is not empty, loop as follows:
		*/
    while( !empty($bInput) )
    {
			/*
			       A.  If the input buffer begins with a prefix of "../" or "./",
			           then remove that prefix from the input buffer; otherwise,
			*/
      if ( preg_match("/^(\.\.\/|\.\/)/", $bInput, $match) )
      {
      	$bInput = preg_replace("/^" . preg_quote($match[1], "/") . "/","",$bInput);
      }
			/*
			       B.  if the input buffer begins with a prefix of "/./" or "/.",
			           where "." is a complete path segment, then replace that
			           prefix with "/" in the input buffer; otherwise,
			*/
      else if ( preg_match("/^(\/\.\/|\/\.$)/",$bInput, $match) )
      {
      	$bInput = preg_replace("/^" . preg_quote($match[1], "/") . "/","/",$bInput);
      }

			/*
			       C.  if the input buffer begins with a prefix of "/../" or "/..",
			           where ".." is a complete path segment, then replace that
			           prefix with "/" in the input buffer and remove the last
			           segment and its preceding "/" (if any) from the output
			           buffer; otherwise,
			*/
      else if ( preg_match("/^(\/\.\.\/|\/\.\.$)/",$bInput, $match) )
      {
	    	$bInput = preg_replace ( "/^" . preg_quote($match[0], "/") . "/","/",$bInput);
        $bOutput = preg_replace ( "/\/?[^\/]+$/", "", $bOutput);
      }
			/*
			       D.  if the input buffer consists only of "." or "..", then remove
			           that from the input buffer; otherwise,
			*/
      else if ( preg_match("/^(\.\.|\.)$/",$bInput, $match) )
      {
      	$bInput = preg_replace("/^" . preg_quote($match[1], "/") . "/","",$bInput);
      }
			/*
			       E.  move the first path segment in the input buffer to the end of
			           the output buffer, including the initial "/" character (if
			           any) and any subsequent characters up to, but not including,
			           the next "/" character or the end of the input buffer.
			*/
      else
      {
	      preg_match("/^\/?[^\/]*/",$bInput,$match);
	      $bInput = preg_replace("/^" . preg_quote($match[0], "/") . "/","",$bInput);
	      $bOutput .= $match[0];
      }
    }//while
		/*
		   3.  Finally, the output buffer is returned as the result of
		       removeDotSegments.
		*/
    return $bOutput;
  }


  private function _merge($Bpath,$Bauthority,$Rpath)
  {
	  if ( isset($Bauthority) && !empty($Bauthority) && empty($Bpath) )
	  {
	  	return "/" . $Rpath;
	  }
	  else
	  {
	  	return preg_replace("/[^\/]*$/","",$Bpath) . $Rpath;
	  }
  }
}
?>
