<?php

/**
 * Sends SMS and Email messages.
 *
 * This class uses Rmail written by Richard Heyes at www.phpguru.org.
 * The documentation can be found here.
 * http://www.phpguru.org/downloads/Rmail/Rmail%20for%20PHP/docs.html
 *
 * An installation of the Rmail package are included in fareofficelib,
 * to minimize any hazzle getting fareofficelib up and working. But the
 * copyright for Rmail is still owned by Richard Heyes.
 *
 * Example:
 * <code>
 * $sendLock = new FileLock('/tmp/locks/');
 * $communication = new Communication($sendLock);
 * $communication->sendSms('monitor.fareoffice.com', '0731234567', 'Hello world);
 * </code>
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @ingroup general
 */
class Communication
{
	/**
	 * Constructor
	 *
	 * @param	$sendLock_ - iLock -
	 * 				A lock object that will handle how often an SMS can be sent.
	 */
	public function Communication(iLock $sendLock_)
	{
		$this->_sendLock = $sendLock_;
	}

	/**
	 * Send an email.
	 *
	 * Supports both plain text and html messages.
	 *
	 * @param $from_ - string -
	 * 				The from email address. Ie. info(at)example.com
	 *
	 * @param $toArr_ - array -
	 * 				The to email addresses, can be many.
	 * 				$toArr_[] = 'daniel(at)example.com';
	 * 				$toArr_[] = 'support(at)example.com';
	 *
	 * @param $subject_ - string -
	 * 				The email subject.
	 *
	 * @param $text_ - string -
	 * 				The text part of the email.
	 *
	 * 				An email can have both a text and an html part,
	 * 				the html part will be read if the email client
	 * 				supports html, or else the text part will be used.
	 *
	 * 				This argument and/or $html needs to be used,
	 * 				if this argument is empty the $html_
	 * 				will be used for the text part of the message
	 * 				but with striped html tags.
	 *
	 * @param $html_ - string -
	 * 				The HTML part of the email.
	 *
	 * @return	- string - errorMessage
	 * 					If sendEmail fails, an error message will be returned.
	 * 					If sendEmail succededs, false will be returned.
	 */
	public function sendEmail($from_, $toArr_, $subject_, $text_, $html_ = NULL)
	{
		if (!empty($from_) && !empty($toArr_) && !empty($subject_) && (!empty($text_) || !empty($html_)))
		{
			$mail = new Rmail();

			if (!empty($html_))
			{
				if (empty($text_))
				{
					$text_ = strip_tags($html_);
				}

				$mail->setHTML($html_, $text_);
			}
			else
			{
				$mail->setText($text_);
			}

			$mail->setReturnPath($from_);
			$mail->setFrom($from_);
			$mail->setSubject($subject_);

			if (!is_array($toArr_))
			{
				$toArr_ = array($toArr_);
			}

			$mailResult = $mail->send($toArr_);

			if (!$mailResult)
			{
				return 'Failed to send mail';
			}
			else
			{
				return false;
			}
		}
		else
		{
			return 'Failed to send mail, one or more parameters wasn\'t entered.';
		}
	}

	/**
	 * Sends an SMS message to a mobile phone.
	 *
	 * The function uses the (at)esms.nu service.
	 *
	 * @param $fromEmail_ - string -
	 * 				esms requires all sms-emails to be sent from a
	 * 				registered email-address.
	 * 				Ie. sms(at)example.com
	 *
	 * @param $fromName_ - string -
	 * 				The from name that will be displayed in the SMS
	 * 				Ie. Daniel 0731234567
	 *
	 * @param $toArr_ - string -
	 * 				A list of cell phone numbers that will recieve the
	 * 				message.
	 * 				Ie. 0731234567
	 *
	 * @param $message_ - string -
	 * 				The text that will be sent on the sms.
	 * 				The message will be truncated to 160 chars.
	 *
	 * @param $repeatTime_ - integer
	 * 				The number of seconds to wait until next
	 * 				sms can be sent. To prevent sms flooding.
	 *
	 * @return $errorMessage - string -
	 * 				If sendEmail fails, an error message will be returned.
	 * 				If sendEmail succededs, false will be returned.
	 */
	public function sendSms($fromEmail_, $fromName_, $toArr_, $message_, $repeatTime_ = 60)
	{
		if (!empty($message_))
		{
			$message_ = substr($message_, 0, 160);
			if (!empty($this->_sendLock) || $this->_sendLock->isLockExpired('SMS', $repeatTime_, false))
			{
				$cellPhoneArr = array();
				if (!is_array($toArr_))
				{
					$toArr_ = array($toArr_);
				}
				foreach ($toArr_ as $cellPhone)
				{
					$cellPhoneArr[] = $cellPhone . '@esms.nu';
				}
				return $this->sendEmail($fromEmail_, $cellPhoneArr, $fromName_, $message_);
			}
			else
			{
				return 'Failed to send sms, to many at to short time.';
			}
		}
	}

	/**
	 * A lock object that will handle how often
	 * an SMS can be sent.
	 *
	 * $_sendLock - ILock -
	 */
	private $_sendLock;
}

?>
