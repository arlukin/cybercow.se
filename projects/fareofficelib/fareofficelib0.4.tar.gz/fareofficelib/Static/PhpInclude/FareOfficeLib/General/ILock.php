<?php
/**
 * Declare the interface 'iLock'
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @ingroup general
 */
interface ILock
{
	/**
	 * Check if a specified name is locked.
	 *
	 * An entity is locked in the system, if that entity was locked more
	 * then $lockTime_ seconds ago, this funtion returns true.
	 *
	 * This is used to see how long ago a certatin operation was done.
	 * Example, If it's more then 1 minute since we last did send
	 * an SMS message we can now send a new.
	 *
	 * @param	$lockName_ - string -
	 * 				The name of the lock/variable/file.
	 *
	 * @param	$lockTime_ - string -
	 * 				Seconds the lockTitle is locked before expiring.
	 *
	 * @param	$compressName_ - boolean -
	 * 				true - An md5 will be done on the filename/lockName_.
	 *
	 * @return	- boolean -
	 */
	public function isLockExpired
	(
		$lockName_,
		$lockTime_ = 60,
		$compressName_ = true
	);
}
?>
