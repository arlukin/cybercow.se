<?php
/**
 * Functions to benchmark how long time some other code has taken to execute.
 *
 * @code
 * $timer = new Benchmark();
 * $timer->start();
 * // do some stuff;
 * $timer->stop();
 * echo $timer->getElapsedTime();
 * @endcode
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @ingroup general
 */
class Benchmark
{
	/**
	 * Constructor
	 *
	 * Set the time zone to Europe/Stockholm.
	 */
	public function __construct()
	{
		date_default_timezone_set('Europe/Stockholm');
		$this->_startAt = NULL;
		$this->_stopAt = NULL;
	}

	/**
	 * Start the timer.
	 */
	public function start()
	{
		$this->_stopAt = NULL;
		$this->_startAt = time();
	}

	/**
	 * Stop the timer.
	 *
	 * @return - int- The elapsed time measured in the number of seconds
	 * 							  since the Unix Epoch (January 1 1970 00:00:00 GMT).
	 */
	public function stop()
	{
		$this->_stopAt = time();
		return $this->_stopAt - $this->_startAt;
	}

	/**
	 * Get the start time.
	 *
	 * @return - date - The time the benchmark started
	 */
	public function getStartTime()
	{
		return date('dMY H:i:s', $this->_startAt);
	}

	/**
	 * Get the stop time.
	 *
	 * @return - date - The time the benchmark stoped
	 */
	public function getStopTime()
	{
		return date('dMY H:i:s', $this->_stopAt);
	}

	/**
	 * Get the elapsed time between start and stop.
	 *
	 * @return - string -
	 */
	public function getElapsedTime()
	{
		$totalSeconds = $this->_stopAt - $this->_startAt;
		$hours = floor($totalSeconds / 3600);
		$minutes = floor(($totalSeconds % 60) / 60);
		$seconds = ($totalSeconds % 3600);
		return str_pad($hours, 2, '0', STR_PAD_LEFT).':'.str_pad($minutes, 2, '0', STR_PAD_LEFT).':'.str_pad($seconds, 2, '0', STR_PAD_LEFT);
	}

	/**
	 * The start time measured in the number of seconds since the Unix Epoch (1970).
	 */
	private $_startAt;

	/**
	 * The stop time measured in the number of seconds since the Unix Epoch (1970).
	 */
	private $_stopAt;
}

?>
