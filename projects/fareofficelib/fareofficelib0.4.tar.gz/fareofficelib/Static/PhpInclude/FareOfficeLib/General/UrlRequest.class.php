<?php
/**
 * Include files
 */
require_once('Date.php');

/**
 * Used to get and validate URL variables.
 *
 * The variables will be retrieved from HTTP POST, HTTP GET and
 * HTTP Cookies.
 *
 * All variables are validated to prevent any kind of variable injection.
 * All POST, GET or Cookie variables should be cleaned with the this
 * class.
 *
 * @code
 * UrlRequst::dateTime('startTime');
 * echo(UrlRequst::get('startTime'));
 * @endcode
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @ingroup general
 */
class UrlRequst
{
	/**
	 * Set a value to the URL argument.
	 *
	 * @param $attributeName_ - string -
	 * @param $value_ - string -
	 */
	static public function set($attributeName_, $value_)
	{
		$_REQUEST[$attributeName_] = $value_;
	}

	/**
	 * Set an default value of an URL argument.
	 *
	 * If the argument is not present on the URL (_REQUEST), this default
	 * value will be returned by all getters in this class.
	 *
	 * @param $attributeName_ - string -
	 * @param $value_ - string -
	 */
	static public function setDefault($attributeName_, $value_)
	{
		if (!UrlRequst::isSetArg($attributeName_))
		{
			$_REQUEST[$attributeName_] = $value_;
		}
	}

	/**
	 * Return true if the argument is present on the URL (_REQUEST).
	 *
	 * @return - boolean -
	 */
	static public function isSetArg($attributeName_)
	{
		if (array_key_exists($attributeName_, $_REQUEST))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * Return an argument from the URL with now validation.
	 *
	 * @param $attributeName_ - string -
	 * @return mixed
	 */
	static public function get($attributeName_)
	{
		return $_REQUEST[$attributeName_];
	}

	/**
	 * Return an argument from the URL and validate it to be a date or dateTime.
	 *
	 * @param $attributeName_ - dateTime -
	 */
	static public function getDateTime($attributeName_)
	{
		if (!isValidDate(UrlRequst::get($attributeName_)))
		{
			return false;
		}
		else
		{
			return UrlRequst::get($attributeName_);
		}
	}

	/**
	 * Return an argument from the URL and validate it to be boolean
	 *
	 * A valid boolean is case insensitive true, false, yes, no, 1 and 0.
	 *
	 * If nothing is entered in the parameter false will be returned.
	 *
	 * @param $attributeName_ - bool -
	 */
	static public function getBool($attributeName_)
	{
		if (UrlRequst::isSetArg($attributeName_))
		{
			switch (strtolower(UrlRequst::get($attributeName_)))
			{
				case 'true':
				case 'yes':
				case '1':
					return true;

				case 'false':
				case 'no':
				case '0':
					return false;

				default:
					die('Invalid parameter for ' . $attributeName_);
			}
		}
		else
		{
			return false;
		}
	}

	/**
	 * Return an argument from the URL and validate it to be string
	 *
	 * If nothing is entered in the parameter NULL will be returned.
	 *
	 * @param $attributeName_ - string -
	 */
	static public function getString($attributeName_)
	{
		if (UrlRequst::isSetArg($attributeName_))
		{
			return UrlRequst::get($attributeName_);
		}
		else
		{
			return null;
		}
	}

	/**
	 * Return an argument from the URL and validate it to be integer
	 *
	 * If nothing is entered in the parameter NULL will be returned.
	 *
	 * @param $attributeName_ - string -
	 */
	static public function getInt($attributeName_)
	{
		if (!ctype_digit(UrlRequst::get($attributeName_)))
		{
			return false;
		}
		else
		{
			return UrlRequst::get($attributeName_);
		}
	}
}

?>
