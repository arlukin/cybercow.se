<?php
/**
 * Includes string manipulating functions
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @ingroup general
 * @file String.php
 */

/**
 * Returns FALSE if var has a non-empty value.
 *
 * The following things are considered to be empty:
 *
 * "" (an empty string)
 * NULL
 * array() (an empty array)
 * var $var; (a variable declared, but without a value in a class)
 */
function emptyString(&$value)
{
	if (empty($value) && $value != '0')
		return true;

	return false;
}
?>
