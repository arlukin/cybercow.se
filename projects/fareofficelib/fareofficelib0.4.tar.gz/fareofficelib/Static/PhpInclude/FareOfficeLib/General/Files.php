<?php
/**
 * Functions that manipulates with the file system.
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @ingroup general
 * @file Files.php
 */

/**
 * List all entities in one directory.
 *
 * @param $directory_ - string -
 * 				The directory to list files from.
 * 				Doesn't matter if it ends with / or not.
 * 				Ie. /var/www
 *
 * @param	$type_ - string -
 * 				Can be [ALL|FILE|DIR], defines which type of entities to list.
 * 				FILE - List files in directory.
 * 				DIR	 - List directories in directory.
 * 				ALL  - List both FILE and DIR
 *
 * @param	$recursive_ - boolean -
 * 				Go through all directories recursively.
 *
 * @param $sort_ - boolean -
 * 				Sort all the result.
 *
 * @return array	listOffiles
 * 								List of all the files, not the directories.
 * 								listOffiles[] = '/opt/RootLive/Sites/HtDocs/Admin/Admin.php';
 * 								listOffiles[] = '/opt/RootLive/Sites/Phpinc/Content/Content.php';
 */
function fileList($directory_, $type_ = 'ALL', $recursive_ = true, $sort_ = true)
{
	// @todo add assertlog here
	// assertLog($type_ == 'ALL' || $type_ == 'FILE' || $type_ == 'DIR' , EL_LEVEL_3, ECAT_DIAGNOSTIC, 'fileList invalid type: ' . $type_);

	$directory_ = rtrim($directory_, '/') . '/';
	$type_ = strtoupper($type_);

	$result = array();
	if(is_dir($directory_))
	{
		$thisDir = dir($directory_);

		while(!empty($thisDir) && $entry = $thisDir->read())
		{
			if (($entry != '.') && ($entry != '..'))
			{
				$path = $directory_.$entry;
				if (is_file($path) && ($type_ == 'ALL' || $type_ == 'FILE'))
				{
					$result[] =	$path;
				}
				elseif (is_dir($path))
				{
					if (($type_ == 'ALL' || $type_ == 'DIR'))
					{
						$result[] =	$path;
					}

					if ($recursive_)
					{
						$result = array_merge($result, fileList($path, $type_, true, false));
					}
				}
			}
		}
	}

	if (!empty($result) && $sort_)
	{
		asort($result);
	}

	return $result;
}

?>
