<?php
/**
* Functions/classes used to config the FareOfficeLib.
*
*	@author Daniel Lindh <daniel@fareoffice.com>
*	@defgroup config Config
*/

include_once('Config/Config.php');
include_once('Config/DbConfig.php');
include_once('Config/SiteConfig.php');
?>
