<?php
/**
 * FareOffice Unit Test framework.
 *
 * The simplest way to use the FareOffice Unit Test framework, is to
 * keep the current default installation folder path. By that you can
 * execute your unit tests by browsing the file (or your choosen url)
 * http://localhost/fareofficelib/UnitTestHtDocs/index.php
 *
 * That index file contains this simple code, and doesn't need to do
 * anything else.
 * @code
 * include_once('FareOfficeLib/FareOfficeLib.php');
 * $testSuite = &new foUnitTest('./');
 * $testSuite->writeTestSuiteGui();
 * @endcode
 *
 * Then you can just start create your own unit test and place them in
 * the folder
 * /var/www/fareofficelib/UnitTestHtDocs/xxx/utExample.php
 *
 * I'll advice you to add the prefix ut, to both file and class. This
 * to prevent that the class has already been declared.
 *
 * @code
 * // File: utFOUnitTestBase.php
 * class utFOUnitTestBase extends foUnitTestBase
 * {
 *		public function doTest()
 *		{
 *			$this->_testNeedEmpty();
 *		}
 *
 *		private function _testNeedEmpty()
 *		{
 *			$this->setSectionLabel('needEmpty');
 *			$this->addSectionText('Will check FOUnitTestBase::needEmpty().');
 *
 *			// Will succeed
 *			eval($this->needEmpty('""'));
 *
 *			$nullVar = NULL;
 *			eval($this->needEmpty('$nullVar'));
 *
 *			$emptyArray = array();
 *			eval($this->needEmpty('$emptyArray'));
 *		}
 *	}*
 *	@endcode
 *
 *
 * @defgroup founittest FOUnitTest
 * @author Daniel Lindh <daniel@fareoffice.com>
 *
 * @todo 	Write support for batch execution of the unit tests and then
 * 			 	email the result.
 * @todo 	Write FOUnitTestBase::needEqualSqlResult
 * @todo 	Write FOUnitTestBase::needLess($x, 5)
 * @todo 	Write FOUnitTestBase::needMore($x, 5)
 * @todo 	Write FOUnitTestBase::needBetween($value, $min, $max)
 * @todo 	Write FOUnitTestBase::needKeyExist($arr, array('a', 'b'))
 *				The array $arr must have atleast the keys 'a' and 'b'
 * @todo 	Write FOUnitTestBase::needValueExist($arr, array('a', 'b'))
 * 				The array $arr must have the atleast nodes with the values
 * 				of 'a' and 'b'.
 * @todo 	Print statistic about how long time it takes to run a test case.
 * @todo	Functionality that prints the contents of the arguments from
 * 				needEqual etc. For example when needEqual fails in this case
 * 		  	$stringVar = "Game over man";
 * 				eval($this->needEqual('$stringVar', '5'));
 * 				It will print something like
 * 				Copy:
 *				'Game over man'
 */

include_once('FOUnitTest/FOUnitTest.class.php');
?>
