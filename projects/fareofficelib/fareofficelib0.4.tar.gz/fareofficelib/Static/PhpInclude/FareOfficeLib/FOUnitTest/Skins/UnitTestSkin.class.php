<?php
/**
 * The abstract base class that are used by all Unit Test Skins.
 *
 * The Unit Test Skin classes are responsible for all GUI output.
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @ingroup founittest
 */
abstract class unitTestSkin
{
	/**
	 * Set the parent FOUnitTest class.
	 *
	 * The parent information about the tests that the skin needs.
	 */
	public function setParent(FOUnitTest $parent_)
	{
		$this->_parent = $parent_;
	}

	/**
	 * Get the parent FOUnitTest class.
	 */
	public function getParent()
	{
		return $this->_parent;
	}

	/**
	*	Write webpage header for the Unit Test Gui.
	*
	* The execution order for the webpage building are
	* begin();
	* writeGuiResult();
	* end();
	*
	* These three functions should create a full html page with html, head
	* and body tags.
	*/
	abstract public function begin();

	/**
	*	Write webpage footer for the Unit Test Gui.
	*
	* @see: begin()
	*/
	abstract public function end();

	/**
	*	Will write a html result from a UnitTest result.
	*
	* @see: begin()
	*/
	abstract public function writeGuiResult($testResult);

	/**
	 * Object handler to FOUnitTest
	 */
	private $_parent;
}
?>
