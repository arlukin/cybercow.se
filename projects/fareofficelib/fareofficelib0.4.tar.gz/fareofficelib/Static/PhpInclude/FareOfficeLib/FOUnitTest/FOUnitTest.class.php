<?php
include_once('FOUnitTestBase.class.php');

/**
*	Will be used to gather a group of foUnitTestBase inherited classes.
*
* These can be executed in a batch, or be viewed one by one in the
* integrated GUI.
*
*	@code
* include_once('FareOfficeLib/FareOfficeLib.php');
* $testSuite = &new foUnitTest('./');
* $testSuite->writeTestSuiteGui();
*	@endcode
*
*	@author Daniel Lindh <daniel@fareoffice.com>
* @ingroup founittest
*
*/
class FOUnitTest
{
	/**
	*	Constructor
	*
	*	@param	$testCaseRoot_ - mixed -
	*					The root for which all the testcases are located in.
	*					This is a file server location.
	*
	*/
	public function FOUnitTest($testCaseRoot_)
	{
		$this->_retriveURLArguments();
		$this->_initializeSkin();

		$this->_testCaseFilesArr = array();
		$this->_testCaseRoot = $testCaseRoot_;
	}

	/**
	*	Write the test suite GUI.
	*/
	public function writeTestSuiteGui()
	{
		$this->_doRetriveAllTestCases();

		$this->_begin();
			if ($this->_bRunAllTests)
			{
				$this->_runAllTests();
			}
			else
			{
				$this->_runTest($this->_currentTestCase);
			}

		$this->_end();
	}

	/**
	 * If true, the GUI should only report failes.
	 */
	public function getOnlyReportFailes()
	{
		return $this->_bOnlyReportFailes;
	}

	/**
	 * If true, the GUI should report more details on failed tests.
	 */
	public function getReportFailDetails()
	{
		return $this->_bReportFailDetails;
	}

	/**
	 * The test case that should be executed.
	 *
	 * If returning 0, no test case to should be executed.
	 */
	public function getCurrentTestCase()
	{
		return $this->_currentTestCase;
	}

	/**
	 * Total number of test case classes/files.
	 */
	public function getNumOfTestCases()
	{
		return $this->_numOfTestCases;
	}

	/**
	 * Get all test case classes/files.
	 */
	public function getTestCaseFiles()
	{
		return $this->_testCaseFilesArr;
	}

	/**
	 * Get arguments from the URL, set default values if not used on url.
	 */
	private function _retriveURLArguments()
	{
		// Default will be false
		if ($_GET['formOnlyReportFailes'] == '1')
		{
			$this->_bOnlyReportFailes = true;
		}
		else
		{
			$this->_bOnlyReportFailes = false;
		}

		// Default will be true
		if ($_GET['formEchoDetails'] == '1' || !array_key_exists('formEchoDetails', $_GET))
		{
			$this->_bReportFailDetails = true;
		}
		else
		{
			$this->_bReportFailDetails = false;
		}

		// Default will be false
		if ($_GET['formRunAllTests'] == '1')
		{
			$this->_bRunAllTests = true;
		}
		else
		{
			$this->_bRunAllTests = false;
		}

		// Default will be 0
		$this->_currentTestCase = $_GET['formTestCase'];

		if (empty($this->_currentTestCase))
		{
			$this->_currentTestCase = 0;
		}
	}

	/**
	 * Create an object instance for the GUI Skin.
	 */
	private function _initializeSkin()
	{
		$this->_skin = 'Standard';
		include('Skins/'.$this->_skin.'.class.php');
		$this->_skinObj = & new $this->_skin;
		$this->_skinObj->setParent($this);
	}

	/**
	*	Will run all unit tests.
	*/
	private function _runAllTests()
	{
		foreach($this->_testCaseFilesArr as $key => $row)
		{
			$this->_runTest($key);
		}
	}

	/**
	*	Will run one test in the $this->_testCaseFilesArr
	*	specified by the $testCaseNumber_.
	*
	*	@param	$testCaseNumber_ - mixed -
	*					The number of the unit test in the unitTestFileArr
	*/
	private function _runTest($testCaseNumber_)
	{
		if ($testCaseNumber_ > 0)
		{
			include_once($this->_testCaseFilesArr[$testCaseNumber_]['path']);
			$obj = &new	$this->_testCaseFilesArr[$testCaseNumber_]['class_name'];
			$obj->doTest();

			$this->_writeGuiResult($obj->getTestResult());
			unset($obj);
		}
	}

	/**
	* Will retrive all the test case classes in the $this->_testCaseRoot
	* directory.
	*/
	private function _doRetriveAllTestCases()
	{
		$files = array();
		$this->_fillWithFilesFromDir($files, $this->_testCaseRoot);

		if (!empty($files))
		{
			asort($files);

			$testCase = count($this->_testCaseFilesArr);
			foreach($files as $file)
			{
				$testCase++;
				$pathParts = pathinfo($file);

				$this->_testCaseFilesArr[$testCase] = array
				(
					'package' => $pathParts['dirname'],
					'path' => $file,
					'class_name' => substr($pathParts['basename'], 0, strpos($pathParts['basename'], '.'))
				);
				$this->_numOfTestCases++;
			}
		}
	}

	/**
	* Fill $files_InOut with all .php files in the $path including subdirectories.
	*/
	private function _fillWithFilesFromDir(&$files_InOut, $path_, $addFiles_ = FALSE)
	{
		if (is_dir($path_))
		{
			$result = dir($path_);

			while($entry = $result->read())
			{
				if (is_file($path_.$entry) && $addFiles_)
				{
					if (strtolower(substr($entry,-4)) == '.php')
					{
						$files_InOut[] = $path_.$entry;
					}
				}
				elseif(is_dir($path_.'/'.$entry) && $entry != '.' && $entry != '..')
				{
					$this->_fillWithFilesFromDir($files_InOut, $path_ . $entry . '/', TRUE);
				}
			}
		}
	}

	/**
	*	Will write a webpage header for the test.
	*/
	private function _begin()
	{
		$this->_skinObj->begin();
	}

	/**
	*	Will write a webpage footer for the test.
	*/
	private function _end()
	{
		$this->_skinObj->end();
	}

	/**
	*	Will write a html result out from a UnitTest result.
	*/
	private function _writeGuiResult(&$testResult_)
	{
		$this->_skinObj->writeGuiResult($testResult_);
	}

	/**
	 * Choosen skin class used by the GUI.
	 */
	private $_skin;

	/**
	 * Instance of skin object.
	 */
	private $_skinObj;

	/**
	 * Root in which all testcases are located.
	 */
	private $_testCaseRoot;

	/**
	 * Array with all test case classes.
	 */
	private $_testCaseFilesArr;

	/**
	 * Total number of test case classes/files.
	 */
	private $_numOfTestCases;

	/**
	 * The number of the current test case choosen
	 * with the gui navigator.
	 */
	private $_currentTestCase;

	/**
	 * Will only report failed tests.
	 */
	private $_bOnlyReportFailes;

	/**
	 * Will report a detailed result for failed tests.
	 */
	private $_bReportFailDetails;

	/**
	 * Run all tests
	 */
	private $_bRunAllTests;
}
?>
