#if ! defined( CRITICAL_SECTION_CLASS_HEADER )

/*
** Author: Samuel R. Blackburn
** Internet: wfc@pobox.com
**
** You can use it any way you like as long as you don't try to sell it.
**
** Any attempt to sell WFC in source code form must have the permission
** of the original author. You can produce commercial executables with
** WFC but you can't sell WFC.
**
** Copyright, 1998, Samuel R. Blackburn
**
** $Workfile: CCriticalSection.hpp $
** $Revision: 3 $
** $Modtime: 3/08/98 12:03p $
*/

#define CRITICAL_SECTION_CLASS_HEADER

class CCriticalSection
{
   protected:

      CRITICAL_SECTION m_CriticalSection;

   public:

      // Construction

      CCriticalSection();

      /*
      ** Destructor should be virtual according to MSJ article in Sept 1992
      ** "Do More with Less Code:..."
      */

      virtual ~CCriticalSection();

      /*
      ** Methods
      */

      virtual void Enter( void );
      virtual void Exit( void );

#if( _WIN32_WINNT >= 0x0400 )

      virtual BOOL TryToEnter( void );

#endif // _WIN32_WINNT
};

class CCriticalSectionGuard
{
   protected:

      CCriticalSection * m_CriticalSection;

   public:

      CCriticalSectionGuard( CCriticalSection * section )
      {
         m_CriticalSection = section;
         m_CriticalSection->Enter();
      };

      CCriticalSectionGuard( CCriticalSection& section )
      {
         m_CriticalSection = &section;
         m_CriticalSection->Enter();
      };

     ~CCriticalSectionGuard()
      {
         m_CriticalSection->Exit();
      };
};

#endif // CRITICAL_SECTION_CLASS_HEADER
