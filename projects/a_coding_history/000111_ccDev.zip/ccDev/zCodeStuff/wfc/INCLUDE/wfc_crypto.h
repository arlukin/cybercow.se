#if ! defined( WINCRYPT_PATCH_HEADER_FILE )

/*
** Author: Samuel R. Blackburn
** Internet: wfc@pobox.com
**
** You can use it any way you like as long as you don't try to sell it.
**
** Any attempt to sell WFC in source code form must have the permission
** of the original author. You can produce commercial executables with
** WFC but you can't sell WFC.
**
** Copyright, 1998, Samuel R. Blackburn
**
** $Workfile: wfc_crypto.h $
** $Revision: 5 $
** $Modtime: 3/08/98 11:59a $
*/

#define WINCRYPT_PATCH_HEADER_FILE

#if ! defined( ALG_SID_3DES )
#define ALG_SID_3DES			3
#define ALG_SID_DESX			4
#define ALG_SID_IDEA			5
#define ALG_SID_CAST			6
#define ALG_SID_SAFERSK64		7
#define ALD_SID_SAFERSK128		8
#endif // ALG_SID_3DES

#if ! defined( ALG_SID_SAFERSK128 )
// Fix a Microsoft typo
#define ALG_SID_SAFERSK128 8
#endif // ALG_SID_SAFERSK128

#if ! defined( CRYPT_MODE_CBCI )
// KP_MODE
#define CRYPT_MODE_CBCI			6	// ANSI CBC Interleaved
#define CRYPT_MODE_CFBP			7	// ANSI CFB Pipelined
#define CRYPT_MODE_OFBP			8	// ANSI OFB Pipelined
#define CRYPT_MODE_CBCOFM		9	// ANSI CBC + OF Masking
#define CRYPT_MODE_CBCOFMI		10	// ANSI CBC + OFM Interleaved
#endif // CRYPT_MODE_CBCI

// Hash sub ids
#if ! defined( ALG_SID_RIPEMD )
#define ALG_SID_RIPEMD			6
#define ALG_SID_RIPEMD160		7
#define ALG_SID_SSL3SHAMD5		8
#endif // ALG_SID_RIPEMD

// exported key blob definitions
#if ! defined( PRIVATEKEYBLOB )
#define PRIVATEKEYBLOB          0x7
#endif // PRIVATEKEYBLOB

#if ! defined( PP_CLIENT_HWND )
#define PP_CLIENT_HWND          1
#endif // PP_CLIENT_HWND

// Microsoft redefined a provider!!! I really hate when they break my code

#if ! defined( PROV_MS_MAIL )
#define PROV_MS_MAIL 5
#endif // PROV_MS_MAIL

#if ! defined( CRYPT_MACHINE_KEYSET )
#define CRYPT_MACHINE_KEYSET 0x00000020
#endif // CRYPT_MACHINE_KEYSET

#endif // WINCRYPT_PATCH_HEADER_FILE
