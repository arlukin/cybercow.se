#if ! defined( PORT_INFORMATION_CLASS_HEADER )

/*
** Author: Samuel R. Blackburn
** Internet: wfc@pobox.com
**
** You can use it any way you like as long as you don't try to sell it.
**
** Any attempt to sell WFC in source code form must have the permission
** of the original author. You can produce commercial executables with
** WFC but you can't sell WFC.
**
** Copyright, 1998, Samuel R. Blackburn
**
** $Workfile: PortInformation.hpp $
** $Revision: 6 $
** $Modtime: 3/08/98 12:00p $
*/

#define PORT_INFORMATION_CLASS_HEADER

class CPortInformation : public CObject
{
   DECLARE_SERIAL( CPortInformation )

   public:

      CPortInformation();
      CPortInformation( const PORT_INFO_1 * source );
      CPortInformation( const PORT_INFO_2 * source );
      CPortInformation( const CPortInformation& source );

      virtual ~CPortInformation();

      CString Name;
      CString Monitor;
      CString Description;
      DWORD   Type;
      CString TypeName;

      virtual void Copy( const PORT_INFO_1 * source );
      virtual void Copy( const PORT_INFO_2 * source );
      virtual void Copy( const CPortInformation& source );
      virtual void Empty( void );
      virtual void Serialize( CArchive& archive );
      virtual void TypeToString( DWORD type, CString& string ) const;

      virtual CPortInformation& operator = ( const CPortInformation& source );

#if defined( _DEBUG )

      virtual void Dump( CDumpContext& dump_context ) const;

#endif // _DEBUG
};

#endif // PORT_INFORMATION_CLASS_HEADER
