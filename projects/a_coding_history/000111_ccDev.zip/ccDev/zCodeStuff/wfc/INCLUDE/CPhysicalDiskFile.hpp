#if ! defined( PHYSICAL_DISK_FILE_CLASS_HEADER )

/*
** Author: Samuel R. Blackburn
** Internet: wfc@pobox.com
**
** You can use it any way you like as long as you don't try to sell it.
**
** Any attempt to sell WFC in source code form must have the permission
** of the original author. You can produce commercial executables with
** WFC but you can't sell WFC.
**
** Copyright, 1998, Samuel R. Blackburn
**
** $Workfile: CPhysicalDiskFile.hpp $
** $Revision: 2 $
** $Modtime: 9/17/98 6:47a $
*/

#define PHYSICAL_DISK_FILE_CLASS_HEADER

class CPhysicalDiskFile : public CFile
{
   private:

      // Don't allow canonical behavior...

      CPhysicalDiskFile( const CPhysicalDiskFile& ) {};
      CPhysicalDiskFile& operator=( const CPhysicalDiskFile& ) { return( *this ); };

   protected:

      DWORD m_BufferSize;
      DWORD m_BufferOffset;

      DISK_GEOMETRY m_DiskGeometry;

      BYTE * m_Buffer;

      virtual BOOL m_SetSectorSize( void );

   public:

      /*
      ** Constructors
      */

      CPhysicalDiskFile();

      /*
      ** Destructor should be virtual according to MSJ article in Sept 1992
      ** "Do More with Less Code:..."
      */

      virtual ~CPhysicalDiskFile();

      /*
      ** Methods
      */

      // CFile overrides
      virtual void  Close( void );
      virtual DWORD GetLength( void ) const;
      virtual UINT  Read( void * buffer, UINT count );
      virtual void  SetLength( DWORD );
      virtual void  Write( void * buffer, UINT count );

      // New Methods
      virtual DWORD GetMediaType( void ) const;
      virtual BOOL  GetSectorSize( DWORD& number_of_bytes_per_sector ) const;
      virtual BOOL  Open( LPCTSTR filename, UINT open_flags, CFileException * error = NULL );
      virtual BOOL  Open( int physical_disk_number, UINT open_flags, CFileException * error = NULL );

#if defined( _DEBUG )

      virtual void Dump( CDumpContext& dump_context ) const;

#endif // _DEBUG
};

#endif // PHYSICAL_DISK_FILE_CLASS_HEADER
