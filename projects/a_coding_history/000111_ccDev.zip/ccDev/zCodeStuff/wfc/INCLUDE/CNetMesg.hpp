#if ! defined( NET_MESSAGE_CLASS_HEADER )

/*
** Author: Samuel R. Blackburn
** Internet: wfc@pobox.com
**
** You can use it any way you like as long as you don't try to sell it.
**
** Any attempt to sell WFC in source code form must have the permission
** of the original author. You can produce commercial executables with
** WFC but you can't sell WFC.
**
** Copyright, 1998, Samuel R. Blackburn
**
** $Workfile: CNetMesg.hpp $
** $Revision: 3 $
** $Modtime: 3/08/98 12:02p $
*/

#define NET_MESSAGE_CLASS_HEADER

class CMessageInformation : public CObject
{
   DECLARE_SERIAL( CMessageInformation )

   private:

      void m_Initialize( void );

   public:

      CMessageInformation();

      /*
      ** Can't make Copy take a const pointer because Microsoft screwed up the 
      ** net API header files...
      */

      CMessageInformation( MSG_INFO_0 *source );
      CMessageInformation( MSG_INFO_1 *source );
      CMessageInformation( const CMessageInformation& source );
      virtual ~CMessageInformation();

      /*
      ** Patterned after MSG_INFO_1
      */

      CString Name;
      DWORD   ForwardFlag;
      CString ForwardName;

      /*
      ** Can't make Copy take a const pointer because Microsoft screwed up the 
      ** net API header files...
      */

      virtual void Copy( MSG_INFO_0 *source );
      virtual void Copy( MSG_INFO_1 *source );
      virtual void Copy( const CMessageInformation& source );
      virtual void Empty( void );
      virtual void Serialize( CArchive& archive );
};

class CNetMessage : public CNetwork
{
   DECLARE_SERIAL( CNetMessage )

   private:

      void m_Initialize( void );

   protected:

      /*
      ** Workstation information variables
      */

      MSG_INFO_0 *m_InformationBuffer0;
      MSG_INFO_1 *m_InformationBuffer1;

      DWORD m_ResumeHandle;
      DWORD m_CurrentEntryNumber;
      DWORD m_NumberOfEntriesRead;
      DWORD m_TotalNumberOfEntries;

   public:

      CNetMessage();
      CNetMessage( LPCTSTR machine_name );
      virtual ~CNetMessage();

      virtual void  Close( void );
      virtual BOOL  Enumerate( void );
      virtual BOOL  GetNext( CMessageInformation& information );
      virtual void  Serialize( CArchive& archive );
};

#endif // NET_MESSAGE_CLASS_HEADER
