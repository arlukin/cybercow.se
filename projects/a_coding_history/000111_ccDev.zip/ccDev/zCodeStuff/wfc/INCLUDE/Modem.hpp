#if ! defined( MODEM_CLASS_HEADER )

/*
** Author: Samuel R. Blackburn
** Internet: wfc@pobox.com
**
** You can use it any way you like as long as you don't try to sell it.
**
** Any attempt to sell WFC in source code form must have the permission
** of the original author. You can produce commercial executables with
** WFC but you can't sell WFC.
**
** Copyright, 1998, Samuel R. Blackburn
**
** $Workfile: modem.hpp $
** $Revision: 7 $
** $Modtime: 3/08/98 12:00p $
*/

#define MODEM_CLASS_HEADER

class CModem : public CSerialFile
{
   DECLARE_SERIAL( CModem )

   private:

      // Don't allow canonical behavior (i.e. don't allow this class
      // to be passed by value)

      CModem( const CModem& ) {};
      CModem& operator=( const CModem& ) { return( *this ); };

   private:

      void m_Initialize( void );

   protected:

      BOOL m_IsConnected;
      BOOL m_UsePulseDialing;

      CString m_PhoneNumber;

   public:

      CModem();

      /*
      ** Destructor should be virtual according to MSJ article in Sept 1992
      ** "Do More with Less Code:..."
      */

      virtual ~CModem();

      virtual BOOL Connect( DWORD number_of_seonds_to_wait = 30 );
      virtual BOOL Disconnect( void ); // Sends +++ATH
      virtual BOOL IsConnected( void ) const;
      virtual void GetPhoneNumber( CString& phone_number_to_dial ) const;
      virtual void SetPhoneNumber( const CString& phone_number_to_dial );
      
      // MFC Stuff

      virtual void  Serialize( CArchive& archive );

#if defined( _DEBUG )

      virtual void Dump( CDumpContext& dump_context ) const;

#endif // _DEBUG
};

#endif // MODEM_CLASS_HEADER
