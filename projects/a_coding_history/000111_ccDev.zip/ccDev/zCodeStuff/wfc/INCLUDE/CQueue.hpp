#if ! defined ( QUEUE_CLASS_HEADER )

/*
** Author: Samuel R. Blackburn
** Internet: wfc@pobox.com
**
** You can use it any way you like as long as you don't try to sell it.
**
** Any attempt to sell WFC in source code form must have the permission
** of the original author. You can produce commercial executables with
** WFC but you can't sell WFC.
**
** Copyright, 1998, Samuel R. Blackburn
**
** $Workfile: CQueue.hpp $
** $Revision: 10 $
** $Modtime: 10/25/98 7:02a $
*/

#define QUEUE_CLASS_HEADER

class CQueue
{
   private:

      // Don't allow these sorts of things

      inline CQueue( const CQueue& ) {};
      inline CQueue& operator = ( const CQueue& ){ return( *this ); };

   protected:

      // What we want to protect

      CRITICAL_SECTION m_AddCriticalSection;
      CRITICAL_SECTION m_GetCriticalSection;

      void * * m_Items;

      DWORD m_AddIndex;
      DWORD m_GetIndex;
      DWORD m_Size;

      inline void m_GrowBy( DWORD number_of_new_items );

   public:

      inline  CQueue( DWORD initial_size = 1024 );
      inline ~CQueue();

      inline BOOL  Add( DWORD new_item ) { return( Add( (void *) new_item ) ); };
      inline BOOL  Add( void * new_item );
      inline void  Empty( void ) { m_AddIndex = 0; m_GetIndex = 0; };
      inline BOOL  Get( DWORD& item );
      inline BOOL  Get( void * & item );
      inline DWORD GetLength( void ) const;
      inline DWORD GetMaximumLength( void ) const { return( m_Size ); };

#if defined( _DEBUG )

      virtual void Dump( CDumpContext& dump_context ) const;

#endif // _DEBUG
};   

inline CQueue::CQueue( DWORD initial_size )
{
   m_AddIndex = 0;
   m_GetIndex = 0;
   m_Items    = NULL;

   if ( initial_size == 0 )
   {
      initial_size = 1;
   }

   try
   {
      m_Items = (void **) malloc( initial_size * sizeof( void * ) );
      m_Size = initial_size;
   }
   catch( ... )
   {
      m_Items = NULL;
      m_Size  = 0;
   }

   ::InitializeCriticalSection( &m_AddCriticalSection );
   ::InitializeCriticalSection( &m_GetCriticalSection );
}

inline CQueue::~CQueue()
{
   if ( m_Items != NULL )
   {
      free( m_Items );
      m_Items = NULL;
   }

   m_AddIndex = 0;
   m_GetIndex = 0;
   m_Size     = 0;

   ::DeleteCriticalSection( &m_AddCriticalSection );
   ::DeleteCriticalSection( &m_GetCriticalSection );
}

inline BOOL CQueue::Add( void * item )
{
   // Block other threads from entering Add();
   ::EnterCriticalSection( &m_AddCriticalSection );

   // Add the item

   m_Items[ m_AddIndex ] = item;

   // Make sure m_AddIndex is never invalid

   m_AddIndex = ( ( m_AddIndex + 1 ) >= m_Size ) ? 0 : m_AddIndex + 1;

   if ( m_AddIndex == m_GetIndex )
   {
      // The queue is full. We need to grow.
      m_GrowBy( m_Size );
   }

   // Let other threads call Add() now.
   ::LeaveCriticalSection( &m_AddCriticalSection );

   return( TRUE );
}

inline BOOL CQueue::Get( DWORD& item )
{
   item = 0;

   void * pointer = NULL;

   if ( Get( pointer ) != FALSE )
   {
      item = reinterpret_cast< DWORD >( pointer );
      return( TRUE );
   }

   return( FALSE );
}

inline BOOL CQueue::Get( void * & item )
{
   // Prevent other threads from entering Get()
   ::EnterCriticalSection( &m_GetCriticalSection );

   if ( m_GetIndex == m_AddIndex )
   {
      // Let's check to see if our queue has grown too big

      if ( m_Size > 1024 )
      {
         // Yup, we're too big for our britches

         ::EnterCriticalSection( &m_AddCriticalSection );

         // Now, no one can add to the queue

         if ( m_GetIndex == m_AddIndex )
         {
            free( m_Items );
            m_Items    = (void **) malloc( 1024 * sizeof( void * ) );
            m_Size     = 1024;
            m_AddIndex = 0;
            m_GetIndex = 0;
         }
         else
         {
            // m_GetIndex != m_AddIndex, this means that someone added
            // to the queue between the time we checked m_Size for being
            // too big and the time we entered the add critical section.
            // If this happened then we are too busy to shrink
         }

         ::LeaveCriticalSection( &m_AddCriticalSection );
      }

      // Let other threads call Get() now
      ::LeaveCriticalSection( &m_GetCriticalSection );
      return( FALSE );
   }

   item = m_Items[ m_GetIndex ];

   // Make sure m_GetIndex is never invalid

   m_GetIndex = ( ( m_GetIndex + 1 ) >= m_Size ) ? 0 : m_GetIndex + 1;

   // Let other threads call Get() now
   ::LeaveCriticalSection( &m_GetCriticalSection );

   return( TRUE );
}

inline DWORD CQueue::GetLength( void ) const
{
   // This is a very expensive process!
   // No one can call Add() or Get() while we're computing this

   DWORD number_of_items_in_the_queue = 0;

   ::EnterCriticalSection( const_cast< CRITICAL_SECTION * >( &m_AddCriticalSection ) );
   ::EnterCriticalSection( const_cast< CRITICAL_SECTION * >( &m_GetCriticalSection ) );

   number_of_items_in_the_queue = ( m_AddIndex >= m_GetIndex ) ?
                                  ( m_AddIndex - m_GetIndex  ) :
                                  ( ( m_AddIndex + m_Size ) - m_GetIndex );

   ::LeaveCriticalSection( const_cast< CRITICAL_SECTION * >( &m_GetCriticalSection ) );
   ::LeaveCriticalSection( const_cast< CRITICAL_SECTION * >( &m_AddCriticalSection ) );

   return( number_of_items_in_the_queue );
}

inline void CQueue::m_GrowBy( DWORD number_of_new_items )
{
   // Prevent other threads from calling Get().
   // We don't need to enter the AddCriticalSection because
   // m_GrowBy() is only called from Add();

   void * * new_array       = NULL;
   void * * pointer_to_free = NULL;

   DWORD new_size = m_Size + number_of_new_items;

   try
   {
      new_array = (void **) malloc( new_size * sizeof( void * ) );
   }
   catch( ... )
   {
      new_array = NULL;
   }

   if ( new_array == NULL )
   {
      return;
   }

   // Prevent other threads from getting
   ::EnterCriticalSection( &m_GetCriticalSection );

   // Now copy all of the old items from the old queue to the new one.

   // Get the entries from the get-index to the end of the array
   ::memcpy( new_array, &m_Items[ m_GetIndex ], ( m_Size - m_GetIndex ) * sizeof( void * ) );

   // Get the entries from the beginning of the array to the add-index
   ::memcpy( &new_array[ m_Size - m_GetIndex ], m_Items, m_AddIndex * sizeof( void * ) );

   m_AddIndex      = m_Size;
   m_GetIndex      = 0;
   m_Size          = new_size;
   pointer_to_free = m_Items;
   m_Items         = new_array;

   ::LeaveCriticalSection( &m_GetCriticalSection );

   free( pointer_to_free );
}

#endif // QUEUE_CLASS_HEADER
