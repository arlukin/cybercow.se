#if ! defined( WEATHER_CLASS_HEADER_FILE )

/*
** Author: Samuel R. Blackburn
** Internet: wfc@pobox.com
**
** You can use it any way you like as long as you don't try to sell it.
**
** Any attempt to sell WFC in source code form must have the permission
** of the original author. You can produce commercial executables with
** WFC but you can't sell WFC.
**
** Copyright, 1998, Samuel R. Blackburn
**
** $Workfile: CWeather.hpp $
** $Revision: 4 $
** $Modtime: 3/08/98 12:01p $
*/

#define WEATHER_CLASS_HEADER_FILE

class CWeather : public CObject
{
   DECLARE_SERIAL( CWeather )

   public:

      CWeather();
      CWeather( const CWeather& source );

      /*
      ** Destructor should be virtual according to MSJ article in Sept 1992
      ** "Do More with Less Code:..."
      */

      virtual ~CWeather();

      enum _TemperatureUnits
      {
         Farenheit,
         Celcius
      };

      enum _WindSpeedUnits
      {
         MilesPerHour,
         KilometersPerHour
      };

      enum _BarometricPressureUnits
      {
         Inches
      };

      /*
      ** Data
      */

      CString Location;
      CTime   Time;
      double  Temperature;
      int     TemperatureUnits;
      double  HumidityPercent;
      double  WindSpeed;
      int     WindSpeedUnits;
      CString WindDirection;
      double  BarometricPressure;
      int     BarometricPressureUnits;
      CString Description;

      /*
      ** Methods
      */

      virtual int  Compare( const CWeather& source ) const;
      virtual void Copy( const CWeather& source );
      virtual void Empty( void );
      virtual void Serialize( CArchive& archive );

      /*
      ** Operators
      */

      virtual CWeather& operator = ( const CWeather& source );
      virtual BOOL operator == ( const CWeather& source ) const;
      virtual BOOL operator <  ( const CWeather& source ) const;
      virtual BOOL operator >  ( const CWeather& source ) const;
      virtual BOOL operator <= ( const CWeather& source ) const;
      virtual BOOL operator >= ( const CWeather& source ) const;

#if defined( _DEBUG )

      virtual void Dump( CDumpContext& dump_context ) const;

#endif // _DEBUG
};

#endif // EVENT_LOG_CLASS
