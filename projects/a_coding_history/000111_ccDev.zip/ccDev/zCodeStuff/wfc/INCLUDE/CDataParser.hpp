#if ! defined ( DATA_PARSER_CLASS_HEADER )

/*
** Author: Samuel R. Blackburn
** Internet: wfc@pobox.com
**
** You can use it any way you like as long as you don't try to sell it.
**
** Any attempt to sell WFC in source code form must have the permission
** of the original author. You can produce commercial executables with
** WFC but you can't sell WFC.
**
** Copyright, 1998, Samuel R. Blackburn
**
** $Workfile: CDataParser.hpp $
** $Revision: 7 $
** $Modtime: 11/21/98 5:55p $
*/

#define DATA_PARSER_CLASS_HEADER

class CDataParser
{
   private:

      // Don't allow canonical behavior (i.e. don't allow this class
      // to be passed by value)

      CDataParser( const CDataParser& ) {};
      CDataParser& operator=( const CDataParser& ) { return( *this ); };

   protected:

#if defined( _DEBUG )

      DWORD m_LastIndex;
      DWORD m_NumberOfTimesWeHaveBeenAskedForTheSameIndex;

#endif // _DEBUG

      BOOL         m_AutomaticallyDelete;
      CByteArray * m_Data;

      virtual void m_Initialize( void );

   public:

      CDataParser();

      /*
      ** Destructor should be virtual according to MSJ article in Sept 1992
      ** "Do More with Less Code:..."
      */

      virtual ~CDataParser();

      virtual void  Empty( void );
      virtual BOOL  Find( const CParsePoint& parse_point, BYTE byte_to_find, CParsePoint& found_at ) const;
      virtual BOOL  Find( const CParsePoint& parse_point, const CString& string_to_find, CParsePoint& found_at ) const;
      virtual BOOL  Find( const CParsePoint& parse_point, const CByteArray& bytes_to_find, CParsePoint& found_at ) const;
      virtual BOOL  FindNoCase( const CParsePoint& parse_point, const CString& string_to_find, CParsePoint& found_at ) const;
      virtual BOOL  FindNoCase( const CParsePoint& parse_point, const CByteArray& bytes_to_find, CParsePoint& found_at ) const;
      virtual BOOL  Get( CParsePoint& parse_point, DWORD length, CByteArray& bytes_to_get ) const;
      virtual BOOL  Get( CParsePoint& parse_point, DWORD length, CString& string_to_get ) const;
      virtual BYTE  GetAt( DWORD index ) const;
      virtual DWORD GetSize( void ) const;
      virtual BOOL  GetUntilAndIncluding( CParsePoint& parse_point, BYTE termination_byte, CString& string_to_get ) const;
      virtual BOOL  GetUntilAndIncluding( CParsePoint& parse_point, const CString& termination_characters, CString& string_to_get ) const;
      virtual BOOL  GetUntilAndIncluding( CParsePoint& parse_point, const CByteArray& termination_bytes, CString& string_to_get ) const;
      virtual BOOL  GetUntilAndIncluding( CParsePoint& parse_point, BYTE termination_byte, CByteArray& bytes_to_get ) const;
      virtual BOOL  Initialize( CByteArray * data, BOOL automatically_delete = FALSE );
      virtual BOOL  Initialize( const CStringArray& strings );

#if defined( _DEBUG )

      virtual void  Dump( CDumpContext& dump_context ) const;

#endif // _DEBUG
};

#endif // DATA_PARSER_CLASS_HEADER
