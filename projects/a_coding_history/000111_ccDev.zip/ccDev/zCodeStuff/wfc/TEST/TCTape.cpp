#include "test.h"
#pragma hdrstop

/*
** Author: Samuel R. Blackburn
** Internet: wfc@pobox.com
**
** You can use it any way you like as long as you don't try to sell it.
**
** Any attempt to sell WFC in source code form must have the permission
** of the original author. You can produce commercial executables with
** WFC but you can't sell WFC.
**
** Copyright, 1997, Samuel R. Blackburn
**
** $Workfile: TCTape.cpp $
** $Revision: 2 $
** $Modtime: 3/08/98 3:31p $
*/

void list_features( DWORD low, DWORD high );

void test_CTape( UINT tape_drive_number_to_test )
{
   WFCTRACEINIT( TEXT( "test_CTape()" ) );

   CMicrosoftTape tape;

   if ( tape.Open( tape_drive_number_to_test ) == FALSE )
   {
      WFCTRACEVAL( TEXT( "Can't open TAPE" ), tape_drive_number_to_test );
      ReportError( tape.GetErrorCode() );
      return;
   }
   else
   {
      WFCTRACE( TEXT( "Tape opened" ) );
   }

   CTapeGetDriveParameters drive_parameters;

   if ( tape.GetParameters( drive_parameters ) == FALSE )
   {
      WFCTRACEVAL( TEXT( "Can't get drive parameters TAPE" ), tape_drive_number_to_test );
      ReportError( tape.GetErrorCode() );
      return;
   }

   TRACE( TEXT( "Drive Parameters:\n" ) );
   TRACE( TEXT( "  ECC                   = %s\n" ), ( ( drive_parameters.ECC            != FALSE ) ? TEXT( "True" ) : TEXT( "False" ) ) );
   TRACE( TEXT( "  Compression           = %s\n" ), ( ( drive_parameters.Compression    != FALSE ) ? TEXT( "True" ) : TEXT( "False" ) ) );
   TRACE( TEXT( "  DataPadding           = %s\n" ), ( ( drive_parameters.DataPadding    != FALSE ) ? TEXT( "True" ) : TEXT( "False" ) ) );
   TRACE( TEXT( "  ReportSetmarks        = %s\n" ), ( ( drive_parameters.ReportSetmarks != FALSE ) ? TEXT( "True" ) : TEXT( "False" ) ) );
   TRACE( TEXT( "  DefaultBlockSize      = %ld\n" ), drive_parameters.DefaultBlockSize );
   TRACE( TEXT( "  MaximumBlockSize      = %ld\n" ), drive_parameters.MaximumBlockSize );
   TRACE( TEXT( "  MinimumBlockSize      = %ld\n" ), drive_parameters.MinimumBlockSize );
   TRACE( TEXT( "  MaximumPartitionCount = %ld\n" ), drive_parameters.MaximumPartitionCount );
   TRACE( TEXT( "  FeaturesLow           = %lX\n" ), drive_parameters.FeaturesLow );
   TRACE( TEXT( "  FeaturesHigh          = %lX\n" ), drive_parameters.FeaturesHigh );
   TRACE( TEXT( "  EOTWarningZoneSize    = %ld\n" ), drive_parameters.EOTWarningZoneSize );

   list_features( drive_parameters.FeaturesLow, drive_parameters.FeaturesHigh );

   CTapeGetMediaParameters media_parameters;

   if ( tape.GetParameters( media_parameters ) == FALSE )
   {
      TRACE( TEXT( "Can't get media parameters TAPE%u\n" ), tape_drive_number_to_test );
      ReportError( tape.GetErrorCode() );
      return;
   }
   else
   {
      TRACE( TEXT( "Media Parameters:\n" ) );
      TRACE( TEXT( "  Capacity.Low   = %lu\n" ), media_parameters.Capacity.LowPart   );
      TRACE( TEXT( "  Capacity.High  = %lu\n" ), media_parameters.Capacity.HighPart  );
      TRACE( TEXT( "  Remaining.Low  = %lu\n" ), media_parameters.Remaining.LowPart  );
      TRACE( TEXT( "  Remaining.High = %lu\n" ), media_parameters.Remaining.HighPart );
      TRACE( TEXT( "  PartitionCount = %lu\n" ), media_parameters.PartitionCount     );
      TRACE( TEXT( "  WriteProtected = %s\n" ), ( ( media_parameters.WriteProtected != FALSE ) ? TEXT( "True" ) : TEXT( "False" ) ) );
   }

#if defined( _DEBUG )   
   tape.Dump( afxDump );
#endif
}

void list_features( DWORD low, DWORD high )
{
   if ( low & TAPE_DRIVE_COMPRESSION )
   {
      TRACE( TEXT( "Device supports hardware data compression.\n" ) );
   }

   if ( low & TAPE_DRIVE_ECC )
   {
      TRACE( TEXT( "Device supports hardware error correction.\n" ) );
   }

   if ( low & TAPE_DRIVE_ERASE_BOP_ONLY )
   {
      TRACE( TEXT( "Device performs the erase operation from the beginning-of-partition marker only.\n" ) );
   }

   if ( low & TAPE_DRIVE_ERASE_LONG )
   {
      TRACE( TEXT( "Device performs a long erase operation.\n" ) );
   }

   if ( low & TAPE_DRIVE_ERASE_IMMEDIATE )
   {
      TRACE( TEXT( "Device performs an immediate erase operation that is, it returns when the erase operation begins.\n" ) );
   }

   if ( low & TAPE_DRIVE_ERASE_SHORT )
   {
      TRACE( TEXT( "Device performs a short erase operation.\n" ) );
   }

   if ( low & TAPE_DRIVE_FIXED )
   {
      TRACE( TEXT( "Device creates fixed data partitions.\n" ) );
   }

   if ( low & TAPE_DRIVE_FIXED_BLOCK )
   {
      TRACE( TEXT( "Device supports fixed-length block mode.\n" ) );
   }

   if ( low & TAPE_DRIVE_INITIATOR )
   {
      TRACE( TEXT( "Device creates initiator-defined partitions.\n" ) );
   }

   if ( low & TAPE_DRIVE_PADDING )
   {
      TRACE( TEXT( "Device supports data padding.\n" ) );
   }

   if ( low & TAPE_DRIVE_GET_ABSOLUTE_BLK )
   {
      TRACE( TEXT( "Device provides the current device-specific block address.\n" ) );
   }

   if ( low & TAPE_DRIVE_GET_LOGICAL_BLK )
   {
      TRACE( TEXT( "Device provides the current logical block address (and logical tape partition).\n" ) );
   }

   if ( low & TAPE_DRIVE_REPORT_SMKS )
   {
      TRACE( TEXT( "Device supports setmark reporting.\n" ) );
   }

   if ( low & TAPE_DRIVE_SELECT )
   {
      TRACE( TEXT( "Device creates select data partitions.\n" ) );
   }

   if ( low & TAPE_DRIVE_SET_EOT_WZ_SIZE )
   {
      TRACE( TEXT( "Device supports setting the end-of-medium warning size.\n" ) );
   }

   if ( low & TAPE_DRIVE_TAPE_CAPACITY )
   {
      TRACE( TEXT( "Device returns the maximum capacity of the tape.\n" ) );
   }

   if ( low & TAPE_DRIVE_TAPE_REMAINING )
   {
      TRACE( TEXT( "Device returns the remaining capacity of the tape.\n" ) );
   }

   if ( low & TAPE_DRIVE_VARIABLE_BLOCK )
   {
      TRACE( TEXT( "Device supports variable-length block mode.\n" ) );
   }

   if ( low & TAPE_DRIVE_WRITE_PROTECT )
   {
      TRACE( TEXT( "Device returns an error if the tape is write-enabled or write-protected.\n" ) );
   }

   if ( high & TAPE_DRIVE_ABS_BLK_IMMED )
   {
      TRACE( TEXT( "Device moves the tape to a device-specific block address and returns as soon as the move begins.\n" ) );
   }

   if ( high & TAPE_DRIVE_ABSOLUTE_BLK )
   {
      TRACE( TEXT( "Device moves the tape to a device specific block address.\n" ) );
   }

   if ( high & TAPE_DRIVE_END_OF_DATA )
   {
      TRACE( TEXT( "Device moves the tape to the end-of-data marker in a partition.\n" ) );
   }

   if ( high & TAPE_DRIVE_FILEMARKS )
   {
      TRACE( TEXT( "Device moves the tape forward (or backward) a specified number of filemarks.\n" ) );
   }

   if ( high & TAPE_DRIVE_LOAD_UNLOAD )
   {
      TRACE( TEXT( "Device enables and disables the device for further operations.\n" ) );
   }

   if ( high & TAPE_DRIVE_LOAD_UNLD_IMMED )
   {
      TRACE( TEXT( "Device supports immediate load and unload operations.\n" ) );
   }

   if ( high & TAPE_DRIVE_LOCK_UNLOCK )
   {
      TRACE( TEXT( "Device enables and disables the tape ejection mechanism.\n" ) );
   }

   if ( high & TAPE_DRIVE_LOCK_UNLK_IMMED )
   {
      TRACE( TEXT( "Device supports immediate lock and unlock operations.\n" ) );
   }

   if ( high & TAPE_DRIVE_LOG_BLK_IMMED )
   {
      TRACE( TEXT( "Device moves the tape to a logical block address in a partition and returns as soon as the move begins.\n" ) );
   }

   if ( high & TAPE_DRIVE_LOGICAL_BLK )
   {
      TRACE( TEXT( "Device moves the tape to a logical block address in a partition.\n" ) );
   }

   if ( high & TAPE_DRIVE_RELATIVE_BLKS )
   {
      TRACE( TEXT( "Device moves the tape forward (or backward) a specified number of blocks.\n" ) );
   }

   if ( high & TAPE_DRIVE_REVERSE_POSITION )
   {
      TRACE( TEXT( "Device moves the tape backward over blocks, filemarks, or setmarks.\n" ) );
   }

   if ( high & TAPE_DRIVE_REWIND_IMMEDIATE )
   {
      TRACE( TEXT( "Device supports immediate rewind operation.\n" ) );
   }

   if ( high & TAPE_DRIVE_SEQUENTIAL_FMKS )
   {
      TRACE( TEXT( "Device moves the tape forward (or backward) to the first occurrence of a specified number of consecutive filemarks.\n" ) );
   }

   if ( high & TAPE_DRIVE_SEQUENTIAL_SMKS )
   {
      TRACE( TEXT( "Device moves the tape forward (or backward) to the first occurrence of a specified number of consecutive setmarks.\n" ) );
   }

   if ( high & TAPE_DRIVE_SET_BLOCK_SIZE )
   {
      TRACE( TEXT( "Device supports setting the size of a fixed-length logical block or setting the variable-length block mode.\n" ) );
   }

   if ( high & TAPE_DRIVE_SET_COMPRESSION )
   {
      TRACE( TEXT( "Device enables and disables hardware data compression.\n" ) );
   }

   if ( high & TAPE_DRIVE_SET_ECC )
   {
      TRACE( TEXT( "Device enables and disables hardware error correction.\n" ) );
   }

   if ( high & TAPE_DRIVE_SET_PADDING )
   {
      TRACE( TEXT( "Device enables and disables data padding.\n" ) );
   }

   if ( high & TAPE_DRIVE_SET_REPORT_SMKS )
   {
      TRACE( TEXT( "Device enables and disables the reporting of setmarks.\n" ) );
   }

   if ( high & TAPE_DRIVE_SETMARKS )
   {
      TRACE( TEXT( "Device moves the tape forward (or reverse) a specified number of setmarks.\n" ) );
   }

   if ( high & TAPE_DRIVE_SPACE_IMMEDIATE )
   {
      TRACE( TEXT( "Device supports immediate spacing.\n" ) );
   }

   if ( high & TAPE_DRIVE_TENSION )
   {
      TRACE( TEXT( "Device supports tape tensioning.\n" ) );
   }

   if ( high & TAPE_DRIVE_TENSION_IMMED )
   {
      TRACE( TEXT( "Device supports immediate tape tensioning.\n" ) );
   }

   if ( high & TAPE_DRIVE_WRITE_FILEMARKS )
   {
      TRACE( TEXT( "Device writes filemarks.\n" ) );
   }

   if ( high & TAPE_DRIVE_WRITE_LONG_FMKS )
   {
      TRACE( TEXT( "Device writes long filemarks.\n" ) );
   }

   if ( high & TAPE_DRIVE_WRITE_MARK_IMMED )
   {
      TRACE( TEXT( "Device supports immediate writing of short and long filemarks.\n" ) );
   }

   if ( high & TAPE_DRIVE_WRITE_SETMARKS )
   {
      TRACE( TEXT( "Device writes setmarks.\n" ) );
   }

   if ( high & TAPE_DRIVE_WRITE_SHORT_FMKS )
   {
      TRACE( TEXT( "Device writes short filemarks.\n" ) );
   }

   if ( high & TAPE_DRIVE_FORMAT )
   {
      TRACE( TEXT( "TAPE_DRIVE_FORMAT\n" ) );
   }

   if ( high & TAPE_DRIVE_FORMAT_IMMEDIATE )
   {
      TRACE( TEXT( "TAPE_DRIVE_FORMAT_IMMEDIATE\n" ) );
   }
}
