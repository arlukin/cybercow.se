#include "test.h"
#pragma hdrstop

/*
** Author: Samuel R. Blackburn
** Internet: wfc@pobox.com
**
** You can use it any way you like as long as you don't try to sell it.
**
** Any attempt to sell WFC in source code form must have the permission
** of the original author. You can produce commercial executables with
** WFC but you can't sell WFC.
**
** Copyright, 1997, Samuel R. Blackburn
**
** $Workfile: test_CReedSolomonErrorCorrectionCode.cpp $
** $Revision: 2 $
** $Modtime: 3/08/98 3:31p $
*/

void test_CReedSolomonErrorCorrectionCode( void )
{
   WFCTRACEINIT( TEXT( "test_CReedSolomonErrorCorrectionCode()" ) );

   CReedSolomonErrorCorrectionCode transmitter;

   CByteArray data;

   data.Add( 'A' );

   data.InsertAt( 0, 'A', 220 ); // for a total of 513 A's

   CByteArray encoded_data;

   if ( transmitter.Encode( data, encoded_data ) == FALSE )
   {
      WFCTRACE( TEXT( "Can't encode\n" ) );
      return;
   }

   // We have encoded the data. Time to transmit it.

   // Now the parity for the data is computed. Let's muck with the data

   // Here's our sloppy communications path. It adds errors to the data

   CRandomNumberGenerator random_number; // 1853265048
   
   // Add some errors

   int number_of_errors_to_introduce = encoded_data.GetSize() / 16;
   int error_number = 0;

   WFCTRACEVAL( TEXT( "Adding this many errors to the data " ), number_of_errors_to_introduce );

   int index = 0;

   BYTE random_value = 0;

   DWORD value = 0;

   CString debug_string;

   while( error_number < number_of_errors_to_introduce )
   {
      value = random_number.GetInteger();
      random_value = (BYTE) (value % 256);

      // Make sure we're introducing an error

      while( random_value == 'A' )
      {
         value = random_number.GetInteger();
         random_value = (BYTE) (value % 256);
      }

      index = random_number.GetInteger() % encoded_data.GetSize();

      debug_string.Format( TEXT( "Setting data.ElementAt( %d ) to %02X\n" ), index, (int) random_value );
      WFCTRACE( debug_string );

      encoded_data.ElementAt( index ) = random_value;

      error_number++;
   }

   // We would now transmit data to the receiver

   CReedSolomonErrorCorrectionCode receiver;

   CByteArray decoded_data;

   int number_of_errors_corrected = receiver.Decode( encoded_data, decoded_data );

   if ( number_of_errors_corrected != (-1) )
   {
      // SUCCESS!

      WFCTRACE( TEXT( "SUCCESS!\n" ) );
      _tprintf( TEXT( "Decoded!\n" ) );
   }

   WFCTRACEVAL( TEXT( "Number of errors corrected " ), number_of_errors_corrected );
   WFCTRACEVAL( TEXT( "Number of bytes in decoded data " ), decoded_data.GetSize() );

   if ( data.GetSize() != decoded_data.GetSize() )
   {
      WFCTRACE( TEXT( "FAILED length test" ) );
      WFCTRACEVAL( TEXT( "Original length was " ), data.GetSize() );
      WFCTRACEVAL( TEXT( "Decoded length was " ), decoded_data.GetSize() );
      return;
   }

   index = 0;

   while( index < decoded_data.GetSize() )
   {
      if ( data.GetAt( index ) != decoded_data.GetAt( index ) )
      {
         WFCTRACEVAL( TEXT( "Comparison failed at byte " ), index );
      }

      index++;
   }
}

