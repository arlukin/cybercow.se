#include <afx.h>
#include <wfc.h>

/*
** Author: Samuel R. Blackburn
** CI$: 76300,326
** Internet: sblackbu@erols.com
**
** You can use it any way you like.
*/

BOOL create_server_pipe( LPCTSTR pipe_name );


