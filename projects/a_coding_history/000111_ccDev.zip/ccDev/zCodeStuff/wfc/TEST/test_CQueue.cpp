#include "test.h"
#pragma hdrstop

/*
** Author: Samuel R. Blackburn
** Internet: wfc@pobox.com
**
** You can use it any way you like as long as you don't try to sell it.
**
** Any attempt to sell WFC in source code form must have the permission
** of the original author. You can produce commercial executables with
** WFC but you can't sell WFC.
**
** Copyright, 1997, Samuel R. Blackburn
**
** $Workfile: test_CQueue.cpp $
** $Revision: 3 $
** $Modtime: 9/19/98 11:19a $
*/

void test_CQueue( void )
{
   WFCTRACEINIT( TEXT( "test_CQueue()" ) );

   CQueue queue( 4 ); // A really small queue

   queue.Add( 1 );
   queue.Add( 2 );
   queue.Add( 3 );

   WFCTRACE( TEXT( "Next addition should cause growth" ) );

   queue.Add( 4 );
   queue.Add( 5 );

   DWORD item = 0;

   ASSERT( queue.Get( item ) != FALSE ); // item should be 1
   WFCTRACEVAL( TEXT( "Got " ), item );
   ASSERT( item == 1 );

   ASSERT( queue.Get( item ) != FALSE ); // item should be 1
   WFCTRACEVAL( TEXT( "Got " ), item );
   ASSERT( item == 2 );

   ASSERT( queue.Get( item ) != FALSE ); // item should be 1
   WFCTRACEVAL( TEXT( "Got " ), item );
   ASSERT( item == 3 );

   ASSERT( queue.Get( item ) != FALSE ); // item should be 1
   WFCTRACEVAL( TEXT( "Got " ), item );
   ASSERT( item == 4 );

   ASSERT( queue.Get( item ) != FALSE ); // item should be 1
   WFCTRACEVAL( TEXT( "Got " ), item );
   ASSERT( item == 5 );

   ASSERT( queue.Get( item ) == FALSE ); // Queue should be empty

   queue.Add( 6 );
   queue.Add( 7 );
   queue.Add( 8 );

   ASSERT( queue.Get( item ) != FALSE );
   WFCTRACEVAL( TEXT( "Got " ), item );
   ASSERT( item == 6 );

   queue.Add( 9 );
   queue.Add( 10 );

   ASSERT( queue.Get( item ) != FALSE );
   WFCTRACEVAL( TEXT( "Got " ), item );
   ASSERT( item == 7 );

   ASSERT( queue.Get( item ) != FALSE );
   WFCTRACEVAL( TEXT( "Got " ), item );
   ASSERT( item == 8 );

   ASSERT( queue.Get( item ) != FALSE );
   WFCTRACEVAL( TEXT( "Got " ), item );
   ASSERT( item == 9 );

   ASSERT( queue.Get( item ) != FALSE );
   WFCTRACEVAL( TEXT( "Got " ), item );
   ASSERT( item == 10 );

   ASSERT( queue.Get( item ) == FALSE ); // Queue should be empty
}
