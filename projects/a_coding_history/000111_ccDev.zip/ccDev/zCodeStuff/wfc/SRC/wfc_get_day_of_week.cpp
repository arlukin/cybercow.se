#include <wfc.h>
#pragma hdrstop

/*
** Author: Samuel R. Blackburn
** Internet: wfc@pobox.com
**
** You can use it any way you like as long as you don't try to sell it.
**
** Any attempt to sell WFC in source code form must have the permission
** of the original author. You can produce commercial executables with
** WFC but you can't sell WFC.
**
** Copyright, 1998, Samuel R. Blackburn
**
** $Workfile: wfc_get_day_of_week.cpp $
** $Revision: 2 $
** $Modtime: 8/17/98 7:54a $
*/

#if defined( _DEBUG )
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif // _DEBUG

BOOL PASCAL wfc_get_day_of_week( int year_with_century, int month, int day, int& day_of_week )
{
   WFCLTRACEINIT( TEXT( "wfc_get_day_of_week()" ) );

   day_of_week = 0;

   // This function is good only for Gregorian dates (until I find
   // source code that will handle ANY date). For now, all dates since
   // 1582 should suffice. The Gregorian calendar bagan on October 15, 1582.

   if ( year_with_century < 1582 )
   {
      WFCTRACE( TEXT( "Can't handle dates prior to 1582." ) );
      return( FALSE );
   }

   if ( year_with_century == 1582 )
   {
      if ( month < 10 )
      {
         WFCTRACE( TEXT( "Can't handle dates prior to October, 1582." ) );
         return( FALSE );
      }

      if ( month == 10 && day < 15 )
      {
         WFCTRACE( TEXT( "Can't handle dates prior to October 15, 1582." ) );
         return( FALSE );
      }
   }

   // Now, there's another little quirk, September 3rd through 13th did not
   // exist in 1752.

   if ( year_with_century == 1752 && month == 9 )
   {
      if ( day >= 3 && day <= 13 )
      {
         WFCTRACE( TEXT( "September 3rd-13th did not exist in 1752." ) );
         return( FALSE );
      }
   }

   if ( month <= 2 )
   {
      year_with_century++;
      month += 12;
   }

   DWORD temporary_day_of_week = 0;

   double term_1 = 0.0;

   term_1 = static_cast< double >( month + 1 ) * 3.0;
   term_1 /= 5.0;

   temporary_day_of_week  = ( day + ( month * 2 ) + static_cast< int >( term_1 ) + year_with_century + ( year_with_century / 4 ) );
   temporary_day_of_week -= ( year_with_century / 100 );
   temporary_day_of_week += ( year_with_century / 400 );
   temporary_day_of_week++;

   // Let's fix things for the Sept 3-13th that don't exist in 1752
   if ( year_with_century == 1752 )
   {
      if ( month < 9 )
      {
         temporary_day_of_week -= 10;
      }
      else if ( month == 9 )
      {
         if ( day <= 2 )
         {
            temporary_day_of_week -= 10;
         }
      }
   }
   else if ( year_with_century < 1752 )
   {
      temporary_day_of_week -= 10;
   }

   day_of_week = ( static_cast< int >( temporary_day_of_week % 7 ) );

   return( TRUE );
}

#if 0
<WFC_DOCUMENTATION>
<HTML>
<HEAD>
<TITLE>WFC - wfc_get_day_of_week</TITLE>
<META name="keywords" content="WFC, MFC extension library, freeware class library, Win32">
<META name="description" content="Simple C function that computes the day of the week (taking into account September 3rd through 13th did not exist in 1752).">
</HEAD>
<BODY>
<H1>wfc_get_day_of_week</H1>
$Revision: 2 $<HR>
<H2>Declaration</H2>
<PRE>BOOL <B>wfc_get_day_of_week</B>( int year_with_century, int month, int day, int&amp; day_of_week )</PRE>
<H2>Description</H2>
This function returns TRUE if the day of week was successfully computed.
<H2>Example</H2><PRE><CODE>int _tmain( int number_of_command_line_arguments, LPCTSTR command_line_arguments[] )
{
   WFCTRACEINIT( TEXT( &quot;_tmain()&quot; ) );

   if ( number_of_command_line_arguments &lt; 2 )
   {
      return( EXIT_SUCCESS );
   }

   TCHAR physical_disk[ MAX_PATH ];

   ZeroMemory( physical_disk, sizeof( physical_disk ) );

   _stprintf( physical_disk, TEXT( &quot;\\\\.\\PHYSICALDRIVE%u&quot; ), _ttoi( command_line_arguments[ 1 ] ) );

   HANDLE disk_handle = NULL;

   disk_handle = CreateFile( physical_disk,
                             GENERIC_READ | GENERIC_WRITE,
                             0,
                             0,
                             OPEN_EXISTING,
                             FILE_ATTRIBUTE_NORMAL,
                             NULL );

   if ( disk_handle != INVALID_HANDLE_VALUE )
   {
      DISK_GEOMETRY disk_geometry;

      ZeroMemory( &amp;disk_geometry, sizeof( disk_geometry ) );

      DWORD number_of_bytes_read = 0;

      if ( DeviceIoControl( disk_handle,
                            IOCTL_DISK_GET_DRIVE_GEOMETRY,
                            NULL,
                            0,
                           &amp;disk_geometry,
                            sizeof( disk_geometry ),
                           &amp;number_of_bytes_read,
                            NULL ) != FALSE )
      {
         _tprintf( TEXT( &quot;Number of Cylinders (low)     %lu\n&quot; ), disk_geometry.Cylinders.LowPart  );
         _tprintf( TEXT( &quot;Number of Cylinders (high)    %lu\n&quot; ), disk_geometry.Cylinders.HighPart );
         _tprintf( TEXT( &quot;Number of Tracks per Cylinder %lu\n&quot; ), disk_geometry.TracksPerCylinder  );
         _tprintf( TEXT( &quot;Number of Sectors per Track   %lu\n&quot; ), disk_geometry.SectorsPerTrack    );
         _tprintf( TEXT( &quot;Number of Bytes per Sector    %lu\n&quot; ), disl_geometry.BytesPerSector     );
      }

      <B>wfc_close_handle</B>( disk_handle );
   }

   return( EXIT_SUCCESS );
}</CODE></PRE>
<H2>API's Used</H2>
<B>wfc_close_handle</B>() uses the following API's:
<UL>
<LI>CloseHandle
</UL>
<I>Copyright, 1998, Samuel R. Blackburn</I><BR>
$Workfile: wfc_get_day_of_week.cpp $<BR>
$Modtime: 8/17/98 7:54a $
</BODY>
</HTML>
</WFC_DOCUMENTATION>
#endif
