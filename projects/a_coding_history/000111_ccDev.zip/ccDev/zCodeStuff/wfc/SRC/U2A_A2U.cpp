#include <wfc.h>
#pragma hdrstop

/*
** Author: Samuel R. Blackburn
** Internet: wfc@pobox.com
**
** You can use it any way you like as long as you don't try to sell it.
**
** Any attempt to sell WFC in source code form must have the permission
** of the original author. You can produce commercial executables with
** WFC but you can't sell WFC.
**
** Copyright, 1998, Samuel R. Blackburn
**
** $Workfile: u2a_a2u.cpp $
** $Revision: 9 $
** $Modtime: 3/08/98 2:28p $
*/

#if defined( _DEBUG )
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif // _DEBUG

void ASCII_to_UNICODE( LPCSTR ansi_string, LPWSTR unicode_string )
{
   if ( ansi_string == NULL || unicode_string == NULL )
   {
      return;
   }

   if ( ansi_string == (LPCSTR) unicode_string )
   {
      ASSERT( FALSE );
      return;
   }

   // We were passed a pointer, don't trust it

   try
   {
      int index = 0;

      while( ansi_string[ index ] != 0x00 )
      {
         unicode_string[ index ] = ansi_string[ index ];
         index++;
      }

      unicode_string[ index ] = 0;
   }
   catch( ... )
   {
      return;
   }
}

void UNICODE_to_ASCII( LPCWSTR unicode_string, LPSTR ansi_string )
{
   if ( unicode_string == (LPCWSTR) NULL || ansi_string == (LPSTR) NULL )
   {
      return;
   }

   // We were passed a pointer, don't trust it

   try
   {
      int index = 0;

      while( unicode_string[ index ] != 0 )
      {
         if ( unicode_string[ index ] < 256 )
         {
            ansi_string[ index ] = (char) unicode_string[ index ];
         }
         else
         {
            ansi_string[ index ] = ' ';
         }

         index++;
      }

      ansi_string[ index ] = 0x00;
   }
   catch( ... )
   {
      return;
   }
}
