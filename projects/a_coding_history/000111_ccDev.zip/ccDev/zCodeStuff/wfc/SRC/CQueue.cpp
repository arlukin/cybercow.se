#include <wfc.h>
#pragma hdrstop

/*
** Author: Samuel R. Blackburn
** Internet: wfc@pobox.com
**
** You can use it any way you like as long as you don't try to sell it.
**
** Any attempt to sell WFC in source code form must have the permission
** of the original author. You can produce commercial executables with
** WFC but you can't sell WFC.
**
** Copyright, 1998, Samuel R. Blackburn
**
** $Workfile: CQueue.cpp $
** $Revision: 19 $
** $Modtime: 9/23/98 12:00a $
*/

#if defined( _DEBUG )
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif // _DEBUG

#if defined( _DEBUG )

void CQueue::Dump( CDumpContext& dump_context ) const
{
   dump_context << TEXT( "a CQueue at " ) << (VOID *) this << TEXT( "\n{\n" );
   dump_context << TEXT( "   m_AddIndex is    " ) << m_AddIndex    << TEXT( "\n" );
   dump_context << TEXT( "   m_GetIndex is    " ) << m_GetIndex    << TEXT( "\n" );
   dump_context << TEXT( "   m_Size is        " ) << m_Size        << TEXT( "\n" );
   dump_context << TEXT( "}\n" );
}

#endif // _DEBUG

#if 0
<HTML>

<HEAD>
<TITLE>WFC - CQueue</TITLE>
<META name="keywords" content="WFC, MFC extension library, freeware class library, Win32, queue">
<META name="description" content="The C++ class that gives you a high-performance thread-safe queue.">
</HEAD>

<BODY>

<H1>CQueue</H1>
$Revision: 19 $<HR>

<H2>Description</H2>

This class a simple, thread-safe but high-performance queue.
It allows one thread to add to the queue while another
thread can get from the queue <STRONG>without blocking</STRONG>.
Normally, getting something from a queue blocks anyone from
adding to that queue. This is a performance bottleneck.
<B>CQueue</B> was designed for speed.
<P>

<B>CQueue</B> automatically grows the queue when needed.
It is a first-in, first-out queue. In other words, the order in which
things were added to the queue is the order in which they will be
retrieved from the queue.

<H2>Constructors</H2>

<DL COMPACT>

<DT><PRE><B>CQueue</B>( DWORD initial_queue_size = 1024 )</B></PRE><DD>
Constructs the object. You can specify an initial size for the queue.
The larger the queue the fewer the growth periods (which can be
expensive).

</DL>

<H2>Methods</H2>

<DL COMPACT>

<DT><PRE>BOOL <B>Add</B>( DWORD new_item )
BOOL <B>Add</B>( void * item )</PRE><DD>
This is how you add something to the queue. The queue will
automatically grow to accomodate new items.

<DT><PRE>void <B>Dump</B>( CDumpContext&amp; dump_context ) const</PRE><DD>
Present only in debug builds. Dumps interesting information about
<B>CQueue</B> to the <CODE>dump_context</CODE> provided.

<DT><PRE>void <B>Empty</B>( void )</PRE><DD>
Empties the queue. There will be no entries in the queue
when you call this method.

<DT><PRE>BOOL <B>Get</B>( DWORD&amp; item )
BOOL <B>Get</B>( void * &amp; item )</PRE><DD>
This is how you get something from the queue. It will
return TRUE if a value was successfully retrieved from 
the queue. It will return FALSE when there is nothing
in the queue to pull.

<DT><PRE>DWORD <B>GetLength</B>( void ) const</PRE><DD>
Returns the number of items in the queue.

<DT><PRE>DWORD <B>GetMaximumLength</B>( void ) const</PRE><DD>
Returns the maximum size of the current queue. This is <I>not</I>
the maximum number of things the queue can hold. It is the maximum
number of items the queue can hold before it enters a growth
period. Currently, when the queue fills, its size doubles.

</DL>

<H2>Example</H2>

<PRE><CODE>void test_CQueue( void )
{
   WFCLTRACEINIT( TEXT( &quot;test_CQueue()&quot; ) );

   <B>CQueue</B> queue( 4 );

   queue.Add( 1 );
   queue.Add( 2 );
   queue.Add( 3 );

   WFCTRACE( TEXT( &quot;Next addition should cause growth&quot; ) );

   queue.Add( 4 );
   queue.Add( 5 );

   DWORD item = 0;

   while( queue.Get( item ) != FALSE )
   {
      WFCTRACEVAL( TEXT( &quot;Got &quot;, item ) );
   }

   queue.Add( 6 );
   queue.Add( 7 );
   queue.Add( 8 );

   queue.Get( item );

   queue.Add( 9 );
   queue.Add( 10 );

   while( queue.Get( item ) != FALSE )
   {
      WFCTRACEVAL( TEXT( &quot;Got &quot;, item ) );
   }
}</CODE></PRE>

<HR>

<I>Copyright, 1998, <A HREF="mailto:wfc@pobox.com">Samuel R. Blackburn</A></I><BR>
$Workfile: CQueue.cpp $<BR>
$Modtime: 9/23/98 12:00a $
</BODY>

</HTML>
#endif
