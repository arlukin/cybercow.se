#include <wfc.h>
#pragma hdrstop

/*
** Author: Samuel R. Blackburn
** Internet: wfc@pobox.com
**
** You can use it any way you like as long as you don't try to sell it.
**
** Any attempt to sell WFC in source code form must have the permission
** of the original author. You can produce commercial executables with
** WFC but you can't sell WFC.
**
** Copyright, 1998, Samuel R. Blackburn
**
** $Workfile: RemoteAccessServiceUser.cpp $
** $Revision: 12 $
** $Modtime: 3/08/98 2:28p $
*/

#if defined( _DEBUG )
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif // _DEBUG

CRemoteAccessServiceUser::CRemoteAccessServiceUser()
{
   WFCLTRACEINIT( TEXT( "CRemoteAccessServiceUser::CRemoteAccessServiceUser()" ) );
   WFCTRACEVAL( TEXT( "pointer is " ), (VOID *) this );
   Empty();
}

CRemoteAccessServiceUser::CRemoteAccessServiceUser( const CRemoteAccessServiceUser& source )
{
   WFCLTRACEINIT( TEXT( "CRemoteAccessServiceUser::CRemoteAccessServiceUser( CRemoteAccessServiceUser& )" ) );
   WFCTRACEVAL( TEXT( "pointer is " ), (VOID *) this );
   Copy( source );
}

CRemoteAccessServiceUser::CRemoteAccessServiceUser( const RAS_USER_0 * source )
{
   WFCLTRACEINIT( TEXT( "CRemoteAccessServiceUser::CRemoteAccessServiceUser( RAS_USER_0 * )" ) );
   WFCTRACEVAL( TEXT( "pointer is " ), (VOID *) this );
   Copy( source );
}

CRemoteAccessServiceUser::~CRemoteAccessServiceUser()
{
   WFCLTRACEINIT( TEXT( "CRemoteAccessServiceUser::~CRemoteAccessServiceUser()" ) );
   WFCTRACEVAL( TEXT( "pointer is " ), (VOID *) this );
   Empty();
}

void CRemoteAccessServiceUser::Copy( const RAS_USER_0 * source )
{
   WFCLTRACEINIT( TEXT( "CRemoteAccessServiceUser::Copy( const RAS_USER_0 * )" ) );
   ASSERT( source != NULL );

   // Choose to live
   if ( source == NULL )
   {
      Empty();
      return;
   }

   // We were passed a pointer, do not trust it

   try
   {
      Privileges = source->bfPrivilege;
      ::wfc_convert_lpcwstr_to_cstring( source->szPhoneNumber, PhoneNumber );
   }
   catch( ... )
   {
      Empty();
   }
}

void CRemoteAccessServiceUser::Copy( const CRemoteAccessServiceUser& source )
{
   WFCLTRACEINIT( TEXT( "CRemoteAccessServiceUser::Copy( const CRemoteAccessServiceUser& )" ) );

   // Copying ourself is a silly thing to do

   if ( &source == this )
   {
      WFCTRACE( TEXT( "Attempt to make a copy of ourself (such silliness)." ) );
      return;
   }

   Privileges  = source.Privileges;
   PhoneNumber = source.PhoneNumber;
}

void CRemoteAccessServiceUser::Empty( void )
{
   WFCLTRACEINIT( TEXT( "CRemoteAccessServiceUser::Empty()" ) );
   Privileges = 0;
   PhoneNumber.Empty();
}

#if 0
<WFC_DOCUMENTATION>
<HTML>
<HEAD>
<TITLE>WFC - CRemoteAccessServiceUser</TITLE>
<META name="keywords" content="WFC, MFC extension library, freeware class library, Win32, RAS, Remote Access Service, Dialup networking">
</HEAD>
<BODY>
<H1>CRemoteAccessServiceUser : CObject</H1>
$Revision: 12 $
<HR><H2>Description</H2>
This class is based on the RAS_USER_0 structure.
<H2>Data Members</H2>
<B>None.</B>
<H2>Methods</H2>
<DL COMPACT>
<DT><B>Copy</B><DD>Copies another CRemoteAccessServiceUser or a RAS_USER_0 structure.
</DL>
<H2>Example</H2><PRE><CODE>Sorry.</CODE></PRE>
<I>Copyright, 1998, Samuel R. Blackburn</I><BR>
$Workfile: RemoteAccessServiceUser.cpp $<BR>
$Modtime: 3/08/98 2:28p $
</BODY>
</HTML>
</WFC_DOCUMENTATION>
#endif
