#include <wfc.h>
#pragma hdrstop

/*
** Author: Samuel R. Blackburn
** Internet: wfc@pobox.com
**
** You can use it any way you like as long as you don't try to sell it.
**
** Any attempt to sell WFC in source code form must have the permission
** of the original author. You can produce commercial executables with
** WFC but you can't sell WFC.
**
** Copyright, 1998, Samuel R. Blackburn
**
** $Workfile: CExtensibleMarkupLanguageDocument.cpp $
** $Revision: 27 $
** $Modtime: 1/05/99 4:56p $
*/

#if defined( _DEBUG )
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif // _DEBUG

typedef struct _xml_element_callback_entry
{
   CString              name;
   XML_ELEMENT_CALLBACK callback;
   void *               parameter;
}
XML_ELEMENT_CALLBACK_ENTRY, *XML_ELEMENT_CALLBACK_ENTRY_P;

CExtensibleMarkupLanguageDocument::CExtensibleMarkupLanguageDocument()
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageDocument::CExtensibleMarkupLanguageDocument()" ) );
   WFCTRACEVAL( TEXT( "pointer is " ), (VOID *) this );

   m_IgnoreWhiteSpace     = FALSE;
   m_AutomaticIndentation = FALSE;
   m_IndentationLevel     = 0;
   m_IndentBy             = 0;
   m_ParseOptions         = WFC_XML_IGNORE_MISSING_XML_DECLARATION;
   m_WriteOptions         = 0;

   // 1998-08-27 Thanks go to Christopher Remington (chrisr@silversoft.net)
   // for finding where I wasn't intializing m_ParseErrorEncountered.

   m_ParseErrorEncountered = FALSE;

   // Add the internal entities listed in section 4.6 of REC-xml-19980210
   m_Entities.Add( TEXT( "&amp;"  ), TEXT( "&"  ) );
   m_Entities.Add( TEXT( "&apos;" ), TEXT( "'"  ) );
   m_Entities.Add( TEXT( "&gt;"   ), TEXT( ">"  ) );
   m_Entities.Add( TEXT( "&lt;"   ), TEXT( "<"  ) );
   m_Entities.Add( TEXT( "&quot;" ), TEXT( "\"" ) );

   try
   {
      m_XML = CExtensibleMarkupLanguageElement::NewElement( NULL, CExtensibleMarkupLanguageElement::typeProcessingInstruction, this );
      m_XML->SetTag( TEXT( "xml" ) );
      m_XML->AddAttribute( TEXT( "version"    ), TEXT( "1.0" ) );
      m_XML->AddAttribute( TEXT( "standalone" ), TEXT( "yes" ) );
   }
   catch( ... )
   {
      m_XML = reinterpret_cast< CExtensibleMarkupLanguageElement * >( NULL );
   }
}

CExtensibleMarkupLanguageDocument::CExtensibleMarkupLanguageDocument( const CExtensibleMarkupLanguageDocument& source )
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageDocument::CExtensibleMarkupLanguageDocument( CExtensibleMarkupLanguageDocument )" ) );
   WFCTRACEVAL( TEXT( "pointer is " ), (VOID *) this );

   m_IgnoreWhiteSpace     = FALSE;
   m_AutomaticIndentation = FALSE;
   m_IndentationLevel     = 0;
   m_IndentBy             = 0;
   m_ParseOptions         = WFC_XML_IGNORE_MISSING_XML_DECLARATION;
   m_WriteOptions         = 0;

   // 1998-08-27 Thanks go to Christopher Remington (chrisr@silversoft.net)
   // for finding where I wasn't intializing m_ParseErrorEncountered.

   m_ParseErrorEncountered = FALSE;

   // Add the internal entities listed in section 4.6 of REC-xml-19980210
   m_Entities.Add( TEXT( "&amp;"  ), TEXT( "&"  ) );
   m_Entities.Add( TEXT( "&apos;" ), TEXT( "'"  ) );
   m_Entities.Add( TEXT( "&gt;"   ), TEXT( ">"  ) );
   m_Entities.Add( TEXT( "&lt;"   ), TEXT( "<"  ) );
   m_Entities.Add( TEXT( "&quot;" ), TEXT( "\"" ) );

   try
   {
      m_XML = CExtensibleMarkupLanguageElement::NewElement( NULL, CExtensibleMarkupLanguageElement::typeProcessingInstruction, this );
      m_XML->SetTag( TEXT( "xml" ) );
      m_XML->AddAttribute( TEXT( "version"    ), TEXT( "1.0" ) );
      m_XML->AddAttribute( TEXT( "standalone" ), TEXT( "yes" ) );
   }
   catch( ... )
   {
      m_XML = reinterpret_cast< CExtensibleMarkupLanguageElement * >( NULL );
   }

   Copy( source );
}

CExtensibleMarkupLanguageDocument::~CExtensibleMarkupLanguageDocument()
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageDocument::~CExtensibleMarkupLanguageDocument()" ) );
   WFCTRACEVAL( TEXT( "pointer is " ), (VOID *) this );

   Empty();

   m_IgnoreWhiteSpace      = FALSE;
   m_AutomaticIndentation  = FALSE;
   m_IndentationLevel      = 0;
   m_IndentBy              = 0;
   m_ParseErrorEncountered = FALSE;
   m_ParseOptions          = 0;
   m_WriteOptions          = 0;
}

BOOL CExtensibleMarkupLanguageDocument::AddCallback( LPCTSTR element_name, XML_ELEMENT_CALLBACK callback, void * callback_parameter )
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageDocument::AddCallback()" ) );

   if ( element_name == NULL )
   {
      WFCTRACE( TEXT( "Nameless element callbacks not supported" ) );
      return( FALSE );
   }

   if ( element_name[ 0 ] == 0x00 )
   {
      WFCTRACE( TEXT( "Empty element name not supported" ) );
      return( FALSE );
   }

   if ( callback == NULL )
   {
      WFCTRACE( TEXT( "NULL Callback not added" ) );
      return( FALSE );
   }

   // Now go find this entry (to make sure we don't call it twice)

   int index             = 0;
   int number_of_entries = m_Callbacks.GetSize();

   CString name( element_name );

   XML_ELEMENT_CALLBACK_ENTRY_P entry_p = reinterpret_cast< XML_ELEMENT_CALLBACK_ENTRY_P >( NULL );

   while( index < number_of_entries )
   {
      entry_p = reinterpret_cast< XML_ELEMENT_CALLBACK_ENTRY_P >( m_Callbacks.GetAt( index ) );

      if ( entry_p != NULL )
      {
         if ( entry_p->callback  == callback &&
              entry_p->parameter == callback_parameter &&
              name.Compare( entry_p->name ) == 0 )
         {
            return( FALSE );
         }
      }

      index++;
   }

   // If we get here, it means we have a new entry for the list

   try
   {
      entry_p = new XML_ELEMENT_CALLBACK_ENTRY;
   }
   catch( ... )
   {
      entry_p = reinterpret_cast< XML_ELEMENT_CALLBACK_ENTRY_P >( NULL );
   }

   if ( entry_p == NULL )
   {
      return( FALSE );
   }

   entry_p->callback  = callback;
   entry_p->parameter = callback_parameter;
   entry_p->name      = name;

   m_Callbacks.Add( entry_p );

   return( TRUE );
}

BOOL CExtensibleMarkupLanguageDocument::AddEntity( const CString& entity, const CString& value )
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageDocument::AddEntity()" ) );

   // First, we must check to see if we allow default entities to be replaced...
   // The default entities are:
   // &amp;
   // &apos;
   // &gt;
   // &lt;
   // &quot;

   if ( m_ParseOptions & WFC_XML_ALLOW_REPLACEMENT_OF_DEFAULT_ENTITIES )
   {
      // We don't care if default entities are replaced 
      m_Entities.Add( entity, value );
      return( TRUE );
   }
   else
   {
      // We must check to make sure the default entities aren't replaced

      if ( entity.Compare( TEXT( "&amp;"  ) ) == 0 ||
           entity.Compare( TEXT( "&apos;" ) ) == 0 ||
           entity.Compare( TEXT( "&gt;"   ) ) == 0 ||
           entity.Compare( TEXT( "&lt;"   ) ) == 0 ||
           entity.Compare( TEXT( "&quot;" ) ) == 0 )
      {
         // The user tried to replace a default entity
         return( FALSE );
      }
      else
      {
         m_Entities.Add( entity, value );
         return( TRUE );
      }
   }
}

void CExtensibleMarkupLanguageDocument::Append( const CExtensibleMarkupLanguageDocument& source )
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageDocument::Append()" ) );

   if ( m_XML == NULL || source.m_XML == NULL )
   {
      WFCTRACE( TEXT( "an m_XML is NULL!" ) );
      return;
   }

   CExtensibleMarkupLanguageElement * element_to_copy_p = reinterpret_cast< CExtensibleMarkupLanguageElement * >( NULL );
   CExtensibleMarkupLanguageElement * element_to_add_p  = reinterpret_cast< CExtensibleMarkupLanguageElement * >( NULL );

   DWORD enumerator = 0;

   if ( source.m_XML->EnumerateChildren( enumerator ) != FALSE )
   {
      while( source.m_XML->GetNextChild( enumerator, element_to_copy_p ) != FALSE )
      {
         if ( element_to_copy_p != NULL )
         {
            element_to_add_p = CExtensibleMarkupLanguageElement::NewElement( m_XML );

            if ( element_to_add_p == NULL )
            {
               WFCTRACE( TEXT( "Can't create element!" ) );
               return;
            }

            element_to_add_p->Copy( *element_to_copy_p );

            m_XML->AddChild( element_to_add_p );
            element_to_add_p = reinterpret_cast< CExtensibleMarkupLanguageElement * >( NULL );
         }
      }
   }
}

void CExtensibleMarkupLanguageDocument::Copy( const CExtensibleMarkupLanguageDocument& source )
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageDocument::Copy()" ) );

   Empty();

   if ( m_XML == NULL )
   {
      m_XML = CExtensibleMarkupLanguageElement::NewElement( NULL, CExtensibleMarkupLanguageElement::typeProcessingInstruction, this );

      if ( m_XML == NULL )
      {
         WFCTRACE( TEXT( "Can't allocate memory for the document node" ) );
         return;
      }
   }

   if ( source.m_XML != NULL )
   {
      m_XML->Copy( *source.m_XML );
   }
}

void CExtensibleMarkupLanguageDocument::CopyCallbacks( const CExtensibleMarkupLanguageDocument& source )
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageDocument::CopyCallbacks()" ) );

   m_RemoveAllCallbacks();

   XML_ELEMENT_CALLBACK_ENTRY_P entry_p = reinterpret_cast< XML_ELEMENT_CALLBACK_ENTRY_P >( NULL );

   int index             = 0;
   int number_of_entries = source.m_Callbacks.GetSize();

   while( index < number_of_entries )
   {
      entry_p = reinterpret_cast< XML_ELEMENT_CALLBACK_ENTRY_P >( m_Callbacks.GetAt( index ) );

      if ( entry_p != NULL )
      {
         AddCallback( entry_p->name, entry_p->callback, entry_p->parameter );
      }

      index++;
   }
}

DWORD CExtensibleMarkupLanguageDocument::CountElements( const CString& name ) const
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageDocument::CopyCallbacks()" ) );

   if ( m_XML != NULL )
   {
      return( m_XML->CountChildren( name ) );
   }

   return( 0 );
}

#if defined( _DEBUG )

void CExtensibleMarkupLanguageDocument::Dump( CDumpContext& dump_context ) const
{
   dump_context << TEXT( " a CExtensibleMarkupLanguageDocument at " ) << (VOID *) this << TEXT( "\n{\n" );

   dump_context << TEXT( "      m_IgnoreWhiteSpace is " );

   if ( m_IgnoreWhiteSpace == FALSE )
   {
      dump_context << TEXT( "FALSE\n" );
   }
   else
   {
      dump_context << TEXT( "TRUE\n" );
   }

   dump_context << TEXT( "      m_AutomaticIndentation is " );

   if ( m_AutomaticIndentation == FALSE )
   {
      dump_context << TEXT( "FALSE\n" );
   }
   else
   {
      dump_context << TEXT( "TRUE\n" );
   }

   dump_context << TEXT( "   m_IndentationLevel is " ) << m_IndentationLevel << TEXT( "\n" );
   dump_context << TEXT( "   m_IndentBy         is " ) << m_IndentBy         << TEXT( "\n" );

   dump_context << TEXT( "   m_XML" );

   if ( m_XML == NULL )
   {
      dump_context << TEXT( " is NULL\n" );
   }
   else
   {
      m_XML->Dump( dump_context );
   }

   dump_context << TEXT( "   m_ParseErrorEncountered is " );

   if ( m_ParseErrorEncountered == FALSE )
   {
      dump_context << TEXT( "FALSE\n" );
   }
   else
   {
      dump_context << TEXT( "TRUE\n" );
   }

   dump_context << TEXT( "   m_ParseOptions is " ) << m_ParseOptions << TEXT( "\n" );

   if ( m_ParseOptions > 0 )
   {
      // Some parsing options have been set. Let's break out the bit fields

      dump_context << TEXT( "   {\n" );

      if ( m_ParseOptions & WFC_XML_IGNORE_CASE_IN_XML_DECLARATION )
      {
         dump_context << TEXT( "      WFC_XML_IGNORE_CASE_IN_XML_DECLARATION\n" );
      }

      if ( m_ParseOptions & WFC_XML_ALLOW_REPLACEMENT_OF_DEFAULT_ENTITIES )
      {
         dump_context << TEXT( "      WFC_XML_ALLOW_REPLACEMENT_OF_DEFAULT_ENTITIES\n" );
      }

      if ( m_ParseOptions & WFC_XML_FAIL_ON_ILL_FORMED_ENTITIES )
      {
         dump_context << TEXT( "      WFC_XML_FAIL_ON_ILL_FORMED_ENTITIES\n" );
      }

      dump_context << TEXT( "   }\n" );
   }

   dump_context << TEXT( "   m_WriteOptions is " ) << m_WriteOptions << TEXT( "\n" );

   if ( m_WriteOptions > 0 )
   {
      // Some parsing options have been set. Let's break out the bit fields

      dump_context << TEXT( "   {\n" );

      if ( m_ParseOptions & WFC_XML_INCLUDE_TYPE_INFORMATION )
      {
         dump_context << TEXT( "      WFC_XML_INCLUDE_TYPE_INFORMATION\n" );
      }

      if ( m_ParseOptions & WFC_XML_DONT_OUTPUT_XML_DECLARATION )
      {
         dump_context << TEXT( "      WFC_XML_DONT_OUTPUT_XML_DECLARATION\n" );
      }

      dump_context << TEXT( "   }\n" );
   }

   dump_context << TEXT( "   m_ErrorTagName is " ) << m_ErrorTagName << TEXT( "\n" );

   dump_context << TEXT( "   m_ErrorElementBeganAt is " );
   //m_ErrorElementBeganAt.Dump( dump_context );

   dump_context << TEXT( "   m_ErrorOccuredAt is " );
   //m_ErrorOccuredAt.Dump( dump_context );

   dump_context << TEXT( "   m_ErrorMessage is " ) << m_ErrorMessage << TEXT( "\n" );

   dump_context << TEXT( "}\n" );
}

#endif // _DEBUG

void CExtensibleMarkupLanguageDocument::Empty( void )
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageDocument::Empty()" ) );

   m_RemoveAllCallbacks();
   m_Entities.Empty();

   m_ParseErrorEncountered = FALSE;
   m_ErrorElementBeganAt.Empty();
   m_ErrorOccuredAt.Empty();
   m_ErrorTagName.Empty();
   m_ErrorMessage.Empty();

   if ( m_XML != NULL )
   {
      CExtensibleMarkupLanguageElement::DeleteElement( m_XML );
      m_XML = reinterpret_cast< CExtensibleMarkupLanguageElement * >( NULL );
   }

   m_IgnoreWhiteSpace = FALSE;
   m_ParseOptions     = WFC_XML_IGNORE_MISSING_XML_DECLARATION;
   m_WriteOptions     = 0;
}

void CExtensibleMarkupLanguageDocument::ExecuteCallbacks( CExtensibleMarkupLanguageElement * element_p ) const
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageDocument::ExecuteCallbacks()" ) );

   if ( element_p == NULL )
   {
      WFCTRACE( TEXT( "Can't pass NULL!" ) );
      return;
   }

   int index               = 0;
   int number_of_callbacks = m_Callbacks.GetSize();

   CString tag;

   try
   {
      element_p->GetTag( tag );
   }
   catch( ... )
   {
      return;
   }

   XML_ELEMENT_CALLBACK_ENTRY_P entry_p = NULL;

   while( index < number_of_callbacks )
   {
      try
      {
         entry_p = reinterpret_cast< XML_ELEMENT_CALLBACK_ENTRY_P >( m_Callbacks.GetAt( index ) );

         if ( entry_p != NULL )
         {
            if ( tag.Compare( entry_p->name ) == 0 )
            {
               // We found a callback

               entry_p->callback( entry_p->parameter, element_p );
            }
         }
      }
      catch( ... )
      {
         // Do Nothing
      }

      index++;
   }
}

void CExtensibleMarkupLanguageDocument::GetAutomaticIndentation( BOOL& automatically_indent, DWORD& indentation_level, DWORD& indent_by )
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageDocument::GetAutomaticIndentation()" ) );

   automatically_indent = m_AutomaticIndentation;
   indentation_level    = m_IndentationLevel;
   indent_by            = m_IndentBy;
}

CExtensibleMarkupLanguageElement * CExtensibleMarkupLanguageDocument::GetElement( const CString& element_name ) const
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageDocument::GetElement()" ) );

   if ( m_XML == NULL )
   {
      return( NULL );
   }

   // The element_name is in the form of "Parent(0).Child(1)"

   return( m_XML->GetChild( element_name ) );
}

BOOL CExtensibleMarkupLanguageDocument::GetIgnoreWhiteSpace( void ) const
{
   return( ( m_IgnoreWhiteSpace == FALSE ) ? FALSE : TRUE );
}

DWORD CExtensibleMarkupLanguageDocument::GetNumberOfElements( void ) const
{
   if ( m_XML == NULL )
   {
      return( 0 );
   }

   return( m_XML->GetTotalNumberOfChildren() );
}

DWORD CExtensibleMarkupLanguageDocument::GetParseOptions( void ) const
{
   return( m_ParseOptions );
}

void CExtensibleMarkupLanguageDocument::GetParsingErrorInformation( CString& tag_name, CParsePoint& beginning, CParsePoint& error_location, CString * error_message_p ) const
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageDocument::GetParsingErrorInformation()" ) );

   tag_name = m_ErrorTagName;
   beginning.Copy( m_ErrorElementBeganAt );
   error_location.Copy( m_ErrorOccuredAt );

   if ( error_message_p != NULL )
   {
      // We were passed a pointer by the user, don't trust it

      try
      {
         *error_message_p = m_ErrorMessage;
      }
      catch( ... )
      {
         // Do Nothing
      }
   }
}

CExtensibleMarkupLanguageElement * CExtensibleMarkupLanguageDocument::GetRootElement( void ) const
{
   return( m_XML );
}

DWORD CExtensibleMarkupLanguageDocument::GetWriteOptions( void ) const
{
   return( m_WriteOptions );
}

void CExtensibleMarkupLanguageDocument::m_RemoveAllCallbacks( void )
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageDocument::m_RemoveAllCallbacks()" ) );

   int index             = 0;
   int number_of_entries = m_Callbacks.GetSize();

   XML_ELEMENT_CALLBACK_ENTRY_P entry_p = reinterpret_cast< XML_ELEMENT_CALLBACK_ENTRY_P >( NULL );

   while( index < number_of_entries )
   {
      entry_p = reinterpret_cast< XML_ELEMENT_CALLBACK_ENTRY_P >( m_Callbacks.GetAt( index ) );
      m_Callbacks.SetAt( index, NULL );

      if ( entry_p != NULL )
      {
         WFCTRACEVAL( TEXT( "Removing callback for " ), entry_p->name );
         delete entry_p;
         entry_p = NULL;
      }

      index++;
   }

   m_Callbacks.RemoveAll();
}

BOOL CExtensibleMarkupLanguageDocument::Parse( const CDataParser& source )
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageDocument::Parse( CDataParser )" ) );

   m_ParseErrorEncountered = FALSE;
   m_ErrorElementBeganAt.Empty();
   m_ErrorOccuredAt.Empty();
   m_ErrorTagName.Empty();
   m_ErrorMessage.Empty();

   if ( m_XML == NULL )
   {
      m_XML = CExtensibleMarkupLanguageElement::NewElement( NULL, CExtensibleMarkupLanguageElement::typeProcessingInstruction, this );

      if ( m_XML == NULL )
      {
         WFCTRACE( TEXT( "Can't allocate memory for the document node" ) );
         m_ParseErrorEncountered = TRUE;
         m_ErrorMessage = TEXT( "Can't allocate memory." );
         return( FALSE );
      }
   }

   // Here's where we look for the <?xml tag

   CParsePoint parse_point;
   CParsePoint beginning_of_tag;
   CParsePoint end_of_tag;

   // According to REC-xml-19980210 Rule 23, the beginning of an XML document
   // is at the "<?xml" tag. Notice this is lower case!

   if ( source.Find( parse_point, TEXT( "<?xml" ), beginning_of_tag ) == FALSE )
   {
      WFCTRACE( TEXT( "Can't find \"<?xml\" tag" ) );

      // Let's see if one of the parsing options is to ignore the case of the XML declaration

      if ( m_ParseOptions & WFC_XML_IGNORE_CASE_IN_XML_DECLARATION )
      {
         // Yup, the user wishes to ignore case

         if ( source.FindNoCase( parse_point, TEXT( "<?xml" ), beginning_of_tag ) == FALSE )
         {
            if ( m_ParseOptions & WFC_XML_IGNORE_MISSING_XML_DECLARATION )
            {
               WFCTRACE( TEXT( "Skipping the missing XML declaration" ) );

               // OK, the XML declaration is missing, this is bad but allowable under
               // the specification. Let's just use the default set in the constructors.

               CExtensibleMarkupLanguageElement * child_element_p = (CExtensibleMarkupLanguageElement *) NULL;

               beginning_of_tag.Empty();

               BYTE character = 0;

               while( beginning_of_tag.GetIndex() < source.GetSize() )
               {
                  character = source.GetAt( beginning_of_tag.GetIndex() );

                  if ( character != '<' )
                  {
                     // The element will be a text segment

                     child_element_p = CExtensibleMarkupLanguageElement::NewElement( m_XML, CExtensibleMarkupLanguageElement::typeTextSegment, this );
                  }
                  else
                  {
                     // The element will be a regular element
                     child_element_p = CExtensibleMarkupLanguageElement::NewElement( m_XML, CExtensibleMarkupLanguageElement::typeElement, this );
                  }

                  if ( child_element_p == NULL )
                  {
                     WFCTRACE( TEXT( "Can't allocate memory for another element" ) );
                     m_XML->DestroyChildren();
                     return( FALSE );
                  }

                  if ( child_element_p->Parse( beginning_of_tag, source ) == FALSE )
                  {
                     WFCTRACE( TEXT( "Parse failed." ) );
                     m_XML->DestroyChildren();
                     return( FALSE );
                  }

                  child_element_p->GetEnding( beginning_of_tag );
               }

               return( TRUE );
            }
            else
            {
               // We still failed

               m_ParseErrorEncountered = TRUE;
               m_ErrorMessage = TEXT( "Can't find beginning-of-XML tag (<?xml) regardless of case." );

               return( FALSE );
            }
         }
      }
      else
      {
         if ( m_ParseOptions & WFC_XML_IGNORE_MISSING_XML_DECLARATION )
         {
            WFCTRACE( TEXT( "Skipping XML declaration" ) );

            // OK, the XML declaration is missing, this is bad but allowable under
            // the specification. Let's just use the default set in the constructors.

            CExtensibleMarkupLanguageElement * child_element_p = (CExtensibleMarkupLanguageElement *) NULL;

            beginning_of_tag.Empty();

            BYTE character = 0;

            while( beginning_of_tag.GetIndex() < source.GetSize() )
            {
               character = source.GetAt( beginning_of_tag.GetIndex() );

               if ( character != '<' )
               {
                  // The element will be a text segment

                  child_element_p = CExtensibleMarkupLanguageElement::NewElement( m_XML, CExtensibleMarkupLanguageElement::typeTextSegment, this );
               }
               else
               {
                  // The element will be a regular element
                  child_element_p = CExtensibleMarkupLanguageElement::NewElement( m_XML, CExtensibleMarkupLanguageElement::typeElement, this );
               }

               if ( child_element_p == NULL )
               {
                  WFCTRACE( TEXT( "Can't allocate memory for another element" ) );
                  m_XML->DestroyChildren();
                  return( FALSE );
               }

               if ( child_element_p->Parse( beginning_of_tag, source ) == FALSE )
               {
                  WFCTRACE( TEXT( "Parse failed." ) );
                  m_XML->DestroyChildren();
                  return( FALSE );
               }

               child_element_p->GetEnding( beginning_of_tag );
            }

            return( TRUE );
         }
         else
         {
            m_ParseErrorEncountered = TRUE;
            m_ErrorMessage = TEXT( "Can't find beginning-of-XML tag (<?xml)." );

            return( FALSE );
         }
      }
   }

   WFCTRACEVAL( TEXT( "Found beginning at byte index " ), beginning_of_tag.GetIndex() );
   WFCTRACEVAL( TEXT( "Line " ), beginning_of_tag.GetLineNumber() );
   WFCTRACEVAL( TEXT( "Line Index " ), beginning_of_tag.GetLineIndex() );

   if ( source.Find( beginning_of_tag, TEXT( "?>" ), end_of_tag ) == FALSE )
   {
      WFCTRACE( TEXT( "Can't find ?>" ) );
      m_ParseErrorEncountered = TRUE;
      m_ErrorMessage = TEXT( "Can't find the end of the end of the beginning-of-XML tag (?>)." );
      return( FALSE );
   }

   if ( m_XML == NULL )
   {
      WFCTRACE( TEXT( "m_XML is NULL!" ) );
      m_ParseErrorEncountered = TRUE;
      m_ErrorMessage = TEXT( "Internal error : m_XML is NULL." );
      return( FALSE );
   }

   if ( m_XML->Parse( beginning_of_tag, source ) == FALSE )
   {
      WFCTRACE( TEXT( "m_XML - Can't parse" ) );

      // m_ParseErrorEncountered and m_ErrorMessag are set by the m_XML->Parse() call
      // so we don't need to fill them in here.

      m_XML->DestroyAttributes();
      m_XML->SetTag( TEXT( "xml" ) );
      m_XML->AddAttribute( TEXT( "version"    ), TEXT( "1.0" ) );
      m_XML->AddAttribute( TEXT( "standalone" ), TEXT( "yes" ) );

      return( FALSE );
   }

   WFCTRACEVAL( TEXT( "?xml began at line " ), beginning_of_tag.GetLineNumber() );
   WFCTRACEVAL( TEXT( "Column " ), beginning_of_tag.GetLineIndex() );
   WFCTRACEVAL( TEXT( "And ended at line " ), end_of_tag.GetLineNumber() );
   WFCTRACEVAL( TEXT( "Column " ), end_of_tag.GetLineIndex() );

   return( TRUE );
}

BOOL CExtensibleMarkupLanguageDocument::RemoveCallback( const char * element_name, XML_ELEMENT_CALLBACK callback, void * callback_parameter )
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageDocument::RemoveCallback()" ) );
   // Now go find this entry (to make sure we don't call it twice)

   int index             = 0;
   int number_of_entries = m_Callbacks.GetSize();

   CString name( element_name );

   XML_ELEMENT_CALLBACK_ENTRY_P entry_p = reinterpret_cast< XML_ELEMENT_CALLBACK_ENTRY_P >( NULL );

   while( index < number_of_entries )
   {
      entry_p = reinterpret_cast< XML_ELEMENT_CALLBACK_ENTRY_P >( m_Callbacks.GetAt( index ) );

      if ( entry_p != NULL )
      {
         if ( entry_p->callback  == callback &&
              entry_p->parameter == callback_parameter &&
              name.Compare( entry_p->name ) == 0 )
         {
            m_Callbacks.SetAt( index, NULL );
            delete entry_p;
            entry_p = reinterpret_cast< XML_ELEMENT_CALLBACK_ENTRY_P >( NULL );
            number_of_entries--;
            index--;
         }
      }

      index++;
   }

   return( TRUE );
}

BOOL CExtensibleMarkupLanguageDocument::ResolveEntity( const CString& entity, CString& resolved_to ) const
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageDocument::ResolveEntity()" ) );

   if ( m_Entities.Resolve( entity, resolved_to ) == FALSE )
   {
      return( FALSE );
   }

   return( TRUE );
}

void CExtensibleMarkupLanguageDocument::SetAutomaticIndentation( BOOL automatically_indent, DWORD indentation_level, DWORD indent_by )
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageDocument::SetAutomaticIndentation()" ) );

   m_AutomaticIndentation = automatically_indent;
   m_IndentationLevel     = indentation_level;
   m_IndentBy             = indent_by;
}

BOOL CExtensibleMarkupLanguageDocument::SetIgnoreWhiteSpace( BOOL new_setting )
{
   BOOL return_value = ( m_IgnoreWhiteSpace == FALSE ) ? FALSE : TRUE;

   if ( new_setting == FALSE )
   {
      m_IgnoreWhiteSpace = FALSE;
   }
   else
   {
      m_IgnoreWhiteSpace = TRUE;
   }

   return( return_value );
}

DWORD CExtensibleMarkupLanguageDocument::SetParseOptions( DWORD new_options )
{
   DWORD return_value = m_ParseOptions;

   m_ParseOptions = new_options;

   return( return_value );
}

void CExtensibleMarkupLanguageDocument::SetParsingErrorInformation( const CString& tag_name, const CParsePoint& beginning, const CParsePoint& error_location, LPCTSTR error_message )
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageDocument::SetParsingErrorInformation()" ) );

   if ( m_ParseErrorEncountered == FALSE )
   {
      m_ParseErrorEncountered = TRUE;
      m_ErrorTagName          = tag_name;
      m_ErrorElementBeganAt.Copy( beginning );
      m_ErrorOccuredAt.Copy( error_location );

      if ( error_message == NULL )
      {
         m_ErrorMessage.Empty();
      }
      else
      {
         m_ErrorMessage = error_message;
      }
   }
}

DWORD CExtensibleMarkupLanguageDocument::SetWriteOptions( DWORD new_options )
{
   DWORD return_value = m_WriteOptions;

   m_WriteOptions = new_options;

   return( return_value );
}

void CExtensibleMarkupLanguageDocument::WriteTo( CByteArray& destination ) const
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageDocument::WriteTo( CByteArray )" ) );

   if ( m_XML == NULL )
   {
      WFCTRACE( TEXT( "Root element is NULL." ) );
      return;
   }

   if ( m_WriteOptions & WFC_XML_DONT_OUTPUT_XML_DECLARATION )
   {
      // The user doesn't want to write the XML declaration. Just write
      // the children.

      DWORD enumerator = 0;

      if ( m_XML->EnumerateChildren( enumerator ) != FALSE )
      {
         CExtensibleMarkupLanguageElement * child_p = (CExtensibleMarkupLanguageElement *) NULL;

         while( m_XML->GetNextChild( enumerator, child_p ) != FALSE )
         {
            if ( child_p != NULL )
            {
               child_p->WriteTo( destination );
            }
         }
      }
      else
      {
         WFCTRACE( TEXT( "No children to enumerate and thusly write." ) );
      }
   }
   else
   {
      m_XML->WriteTo( destination );
   }
}

CExtensibleMarkupLanguageDocument& CExtensibleMarkupLanguageDocument::operator=( const CExtensibleMarkupLanguageDocument& source )
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageDocument::operator=()" ) );
   Copy( source );
   return( *this );
}

CExtensibleMarkupLanguageDocument& CExtensibleMarkupLanguageDocument::operator+=( const CExtensibleMarkupLanguageDocument& source )
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageDocument::operator+=()" ) );
   Append( source );
   return( *this );
}

#if 0
<WFC_DOCUMENTATION>

<HTML>
<HEAD>
<TITLE>WFC - CExtensibleMarkupLanguageDocument</TITLE>
<META name="keywords" content="WFC, MFC extension library, freeware class library, Win32, push technology, source code">
<META name="description" content="The C++ class that parses and constructs XML documents.">
</HEAD>

<BODY>

<H1>CExtensibleMarkupLanguageDocument</H1>
$Revision: 27 $
<HR>

<H2>Description</H2>

This class is the mother of all
<A HREF="http://www.w3.org/TR/" TARGET="_parent">XML</A>
classes. It holds the
things like the element tree and settings that apply to
the entire document.

<H2>Construction</H2>

<DL COMPACT>

<DT><PRE><B>CExtensibleMarkupLanguageDocument</B>()
<B>CExtensibleMarkupLanguageDocument</B>( const CExtensibleMarkupLanguageDocument&amp; source )</PRE><DD>
Creates another <B>CExtensibleMarkupLanguageDocument</B>.
</DL>

<H2>Methods</H2>

<DL COMPACT>

<DT><PRE>BOOL <B>AddCallback</B>( const char * element_name, XML_ELEMENT_CALLBACK callback, void * callback_parameter )</PRE><DD>
Allows you to specify a function (and a parameter for that function) that
will be called when an element with a tag matching <CODE>element_name</CODE>
has been successfully parsed. The <CODE>element_name</CODE> comparison
is not case sensitive.

<DT><PRE>void <B>Append</B>( const CExtensibleMarkupLanguageDocument&amp; source )</PRE><DD>
Appends the elements of <CODE>source</CODE> to this document.

<DT><PRE>void <B>Copy</B>( const CExtensibleMarkupLanguageDocument&amp; source )</PRE><DD>
Copies the contents of <CODE>source</CODE> to this object. It will not
copy the callback functions as this may cause unintentional results.

<DT><PRE>void <B>CopyCallbacks</B>( const CExtensibleMarkupLanguageDocument&amp; source )</PRE><DD>
Copies the callback functions from <CODE>source</CODE> to this object.
If you are a careful programmer, this is perfectly safe to do. Generally
speaking, you shouldn't have to copy the callbacks of <CODE>source</CODE>
because parsing should have already taken place.

<DT><PRE>DWORD <B>CountElements</B>( const CString&amp; element_name ) const</PRE><DD>
Counts the number of elements. <CODE>element_name</CODE> takes much the
same form as used in the <B>GetElement</B>() function.
Consider the following
<A HREF="http://www.w3.org/TR/" TARGET="_parent">XML</A>
snippet:
<PRE><CODE>&lt;Southpark&gt;
   &lt;Characters&gt;
      &lt;Boy&gt;Cartman&lt;/Boy&gt;
      &lt;Boy&gt;Kenny&lt;/Boy&gt;
      &lt;Boy&gt;Kyle&lt;/Boy&gt;
      &lt;Boy&gt;Stan&lt;/Boy&gt;
   &lt;/Characters&gt;
   &lt;Characters&gt;
      &lt;Girl&gt;Wendy&lt;/Girl&gt;
      &lt;Boy&gt;Chef&lt;/Boy&gt;
      &lt;Girl&gt;Ms. Ellen&lt;/Girl&gt;
   &lt;/Characters&gt;
&lt;/Southpark&gt;</CODE></PRE>
If you wanted to know how many &quot;Boy&quot; elements there
are in the first set of characters, you would use an element name
of <CODE>&quot;SouthPark.Characters&quot;</CODE> If you wanted to
know how many &quot;Girl&quot; elements there are in the second
set of characters, you would use this for <CODE>element_name</CODE>:
&quot;Southpark.Characters(1).Girl&quot;

<DT><PRE>void <B>Empty</B>( void )</PRE><DD>
Empties the contents of the document. The object is reset to an
intial state. All elements are deleted.

<DT><PRE>void <B>ExecuteCallbacks</B>( <A HREF="CExtensibleMarkupLanguageElement.htm">CExtensibleMarkupLanguageElement</A> * element_p )</PRE><DD>
This is generally called during the parsing of a document by the
<A HREF="CExtensibleMarkupLanguageElement.htm">CExtensibleMarkupLanguageElement</A>
that just parsed itself. However, you can pull an element out of the
document and call <B>ExecuteCallbacks</B>() yourself.

<DT><PRE><A HREF="CExtensibleMarkupLanguageElement.htm">CExtensibleMarkupLanguageElement</A> * <B>GetElement</B>( const CString&amp; element_name ) const</PRE><DD>
Searches and finds the specified element in the document. The
<CODE>element_name</CODE> is in the form of &quot;Parent(0).Child(0)&quot;
Consider the following
<A HREF="http://www.w3.org/TR/" TARGET="_parent">XML</A> snippet:
<PRE><CODE>&lt;Southpark&gt;
   &lt;Characters&gt;
      &lt;Boy&gt;Cartman&lt;/Boy&gt;
      &lt;Boy&gt;Kenny&lt;/Boy&gt;
      &lt;Boy&gt;Kyle&lt;/Boy&gt;
      &lt;Boy&gt;Stan&lt;/Boy&gt;
   &lt;/Characters&gt;
   &lt;Characters&gt;
      &lt;Girl&gt;Wendy&lt;/Girl&gt;
      &lt;Boy&gt;Chef&lt;/Boy&gt;
      &lt;Girl&gt;Ms. Ellen&lt;/Girl&gt;
   &lt;/Characters&gt;
&lt;/Southpark&gt;</CODE></PRE>
To retrieve the element for Cartman, <CODE>element_name</CODE> should
be &quot;Southpark.Characters.Boy&quot; If you want Ms. Ellen (even
though she doesn't play for the home team) you would use
&quot;Southpark.Characters(1).Girl(1)&quot;

<DT><PRE>BOOL <B>GetIgnoreWhiteSpace</B>( void ) const</PRE><DD>
Returns whether or not the document will suppress the output
of elements that contain only space characters. This output
occurs when you call <B>WriteTo</B>().

<DT><PRE>DWORD <B>GetNumberOfElements</B>( void ) const</PRE><DD>
Returns the number of elements in this document.

<DT><PRE>DWORD <B>GetParseOptions</B>( void ) const</PRE><DD>
Returns the parse options. This is a bit field (32 wide) that
controls the sloppiness of the parser.

<DT><PRE>void <B>GetParsingErrorInformation</B>( CString&amp; tag_name, <A HREF="CParsePoint.htm">CParsePoint</A>&amp; beginning, <A HREF="CParsePoint.htm">CParsePoint</A>&amp; error_location, CString * error_message = NULL ) const</PRE><DD>
If <B>Parse</B>() returns FALSE, you can call this method to find out
interesting information as to where the parse failed. This will help you
correct the XML. If <CODE>error_message</CODE> is not NULL, it will be filled
with a human readable error message.

<DT><PRE><A HREF="CExtensibleMarkupLanguageElement.htm">CExtensibleMarkupLanguageElement</A> * <B>GetRootElement</B>( void ) const</PRE><DD>
Returns the pointer to the ultimate parent element. This will be the element
that contains the data from the <CODE>&lt;?xml ... ?&gt;</CODE> line.

<DT><PRE>DWORD <B>GetWriteOptions</B>( void ) const</PRE><DD>
Returns the writing options. This is a bit field (32 wide) that
controls how the XML documents are written.

<DT><PRE>BOOL <B>Parse</B>( const <A HREF="CDataParser.htm">CDataParser</A>&amp; source )</PRE><DD>
Parses the data from <CODE>source</CODE>. This will construct
the document tree.

<DT><PRE>BOOL <B>RemoveCallback</B>( const char * element_name, XML_ELEMENT_CALLBACK callback, void * callback_parameter )</PRE><DD>
This will remove the specified callback from the list. All parameters
must match for the callback to be removed.

<DT><PRE>BOOL <B>SetIgnoreWhiteSpace</B>( BOOL ignore_whitespace )</PRE><DD>
Tells the document whether or not to ignore text segments that contain
only space characters. It returns what the previous setting was.

<DT><PRE>DWORD <B>SetParseOptions</B>( DWORD new_options )</PRE><DD>
Sets the parsing options. This allows you to customize the parser to
be as loose or as strict as you want. The default is to be as strict
as possible when parsing. <B>SetParseOptions</B>() returns the previous
options. Here are the current parse options that can be set:

<UL>

<LI><B><CODE>WFC_XML_IGNORE_CASE_IN_XML_DECLARATION</CODE></B> - When set, this option
will allow uppercase letters in the XML declaration. For example:
<CODE>&lt;?XmL ?&gt;</CODE> will be allowed even though it does not
conform to the
<A HREF="http://www.w3.org/TR/" TARGET="_parent">specification</A>.

<LI><B><CODE>WFC_XML_ALLOW_REPLACEMENT_OF_DEFAULT_ENTITIES</CODE></B> - Though the
<A HREF="http://www.w3.org/TR/" TARGET="_parent">XML specification</A>
doesn&#39;t talk about it, what should a parser do if default entities
are replaced? If you set this option, the parser will allow replacement
of the default entities. Here is a list of the default entities:

<UL>
<LI><B><CODE>&#38;amp;</CODE></B>
<LI><B><CODE>&#38;apos;</CODE></B>
<LI><B><CODE>&#38;gt;</CODE></B>
<LI><B><CODE>&#38;lt;</CODE></B>
<LI><B><CODE>&#38;quot;</CODE></B>
</UL>

<LI><B><CODE>WFC_XML_FAIL_ON_ILL_FORMED_ENTITIES</CODE></B> - Not yet implemented.
It will allow the parser to ignore ill formed entities such as <BR>
<CODE>&lt;!ENTITY amp &quot;&#38;#38;&quot;&gt;</CODE>

<LI><B><CODE>WFC_XML_IGNORE_ALL_WHITE_SPACE_ELEMENTS</CODE></B> - Tells the parser
to ignore elements (of type <B><CODE>typeTextSegment</CODE></B>) that contain
nothing but white space characters. WARNING! If you use this option, it will
not be possible to reproduce that input file exactly. Elements that contain
nothing but white spaces will be deleted from the document.

</UL>

<DT><PRE>void <B>SetParsingErrorInformation</B>( const CString&amp; tag_name, const <A HREF="CParsePoint.htm">CParsePoint</A>&amp; beginning, const <A HREF="CParsePoint.htm">CParsePoint</A>&amp; error_location, LPCTSTR error_message = NULL )</PRE><DD>
This method is usually called by the element that cannot parse
itself. There is logic that prevents the information from being
overwritten by subsequent calls to <B>SetParsingErrorInformation</B>().
This means you can call <B>SetParsingErrorInformation</B>() as
many times as you want but only information from the first call
will be recorded (and reported via <B>GetParsingErrorInformation</B>())
for each call to <B>Parse</B>().

<DT><PRE>DWORD <B>SetWriteOptions</B>( DWORD new_options )</PRE><DD>
Sets the writing options. This allows you to customize how the XML
is written.
The default is to be as strict as possible when writing.
<B>SetWriteOptions</B>() returns the previous
options. Here are the current options that can be set:

<UL>

<LI><B><CODE>WFC_XML_INCLUDE_TYPE_INFORMATION</CODE></B> - <I><B>Not Yet Implemented.</B></I>
XML is woefully inept at handling data. They use things called DTD&#39;s but
they have a &quot;the world is flat&quot; outlook on life.
DTD&#39;s lack the ability to scope.
It would be like programming where all variables have to have unique names
no matter what function they exist in.
DTD&#39;s are used to give HTML browsers the ability to correctly
display XML. They also give you the ability to do some lame data validation.
In the future, I will include the
ability to write type information in WFC in a programmer friendly fashion.
This type information is intended to be a programmer-to-programmer
communication medium.

<LI><B><CODE>WFC_XML_DONT_OUTPUT_XML_DECLARATION</CODE></B> - This allows
you to skip writing the XML declaration when you output. For example, this
XML document:
<PRE><CODE>&lt;?xml version=&quot;1.0&quot; ?&gt;
&lt;TRUTH&gt;Sam loves Laura.&lt;/TRUTH&gt;</CODE></PRE>
Would look like this when <CODE>WFC_XML_DONT_OUTPUT_XML_DECLARATION</CODE>
is set:
<PRE><CODE>&lt;TRUTH&gt;Sam loves Laura.&lt;/TRUTH&gt;</CODE></PRE>

</UL>

<DT><PRE>void <B>WriteTo</B>( CByteArray&amp; destination )</PRE><DD>
Write the data to <CODE>destination</CODE> in
<A HREF="http://www.w3.org/TR/" TARGET="_parent">XML</A> form.

</DL>

<H2>Operators</H2>

<DL COMPACT>

<DT><PRE>CExtensibleMarkupLanguageDocument&amp; operator <B>=</B> ( const CExtensibleMarkupLanguageDocument&amp; source )</PRE><DD>
Calls <B>Copy</B>().

<DT><PRE>CExtensibleMarkupLanguageDocument&amp; operator <B>+=</B> ( const CExtensibleMarkupLanguageDocument&amp; source )</PRE><DD>
Calls <B>Append</B>().
</DL>

<H2>Example</H2><PRE><CODE>#include &lt;wfc.h&gt;
#pragma hdrstop

BOOL get_bytes( const CString&amp; filename, CByteArray&amp; bytes )
{
   bytes.RemoveAll();

   CFile file;

   if ( file.Open( filename, CFile::modeRead ) == FALSE )
   {
      return( FALSE );
   }

   bytes.SetSize( file.GetLength() );

   file.Read( bytes.GetData(), bytes.GetSize() );

   file.Close();

   return( TRUE );
}

BOOL parse_document( const CString&amp; filename, CExtensibleMarkupLanguageDocument&amp; document )
{
   CByteArray bytes;

   if ( get_bytes( filename, bytes ) != TRUE )
   {
      return( FALSE );
   }

   <A HREF="CDataParser.htm">CDataParser</A> parser;

   parser.Initialize( &amp;bytes, FALSE );

   if ( document.Parse( parser ) == TRUE )
   {
      _tprintf( TEXT( &quot;Parsed OK\n&quot; ) );
   }
   else
   {
      _tprintf( TEXT( &quot;Can't parse document\n&quot; ) );
   }

   return( TRUE );
}

void stanza_callback( void * parameter, <A HREF="CExtensibleMarkupLanguageElement.htm">CExtensibleMarkupLanguageElement</A> * element_p )
{
   _tprintf( TEXT( &quot;Got a stanza with %lu children\n&quot; ), (DWORD) element_p->GetNumberOfChildren() );
}

int _tmain( int number_of_command_line_arguments, LPCTSTR command_line_arguments[] )
{
   <B>CExtensibleMarkupLanguageDocument</B> document;

   document.AddCallback( TEXT( &quot;stanza&quot; ), stanza_callback, NULL );

   if ( parse_document( TEXT( &quot;poem.xml&quot; ), document ) == TRUE )
   {
      CByteArray bytes;

      document.SetWriteOptions( WFC_XML_DONT_OUTPUT_XML_DECLARATION );

      document.WriteTo( bytes );

      _tprintf( TEXT( &quot;Wrote %d bytes\n&quot; ), bytes.GetSize() );

      CFile file;

      if ( file.Open( TEXT( &quot;xml.out&quot; ), CFile::modeCreate | CFile::modeWrite ) != FALSE )
      {
         file.Write( bytes.GetData(), bytes.GetSize() );
         file.Close();
      }
   }

   return( EXIT_SUCCESS );
}</CODE></PRE>
<HR><I>Copyright, 1998, <A HREF="mailto:wfc@pobox.com">Samuel R. Blackburn</A></I><BR>
$Workfile: CExtensibleMarkupLanguageDocument.cpp $<BR>
$Modtime: 1/05/99 4:56p $
</BODY>
</HTML>
</WFC_DOCUMENTATION>
The following line should go in AUTOEXP.DAT so the debugging tooltips will format properly
ToolTipFormatLine=
#endif
