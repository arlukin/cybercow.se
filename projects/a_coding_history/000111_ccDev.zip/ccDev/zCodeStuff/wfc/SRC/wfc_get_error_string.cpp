#include <wfc.h>
#pragma hdrstop

/*
** Author: Samuel R. Blackburn
** Internet: wfc@pobox.com
**
** You can use it any way you like as long as you don't try to sell it.
**
** Any attempt to sell WFC in source code form must have the permission
** of the original author. You can produce commercial executables with
** WFC but you can't sell WFC.
**
** Copyright, 1998, Samuel R. Blackburn
**
** $Workfile: wfc_get_error_string.cpp $
** $Revision: 8 $
** $Modtime: 9/07/98 6:59a $
*/

#if defined( _DEBUG )
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif // _DEBUG

void PASCAL wfc_get_error_string( DWORD error_code, CString& error_string )
{
   error_string.Empty();

   LPVOID message_buffer = NULL;

   ::FormatMessage( FORMAT_MESSAGE_ALLOCATE_BUFFER |
                    FORMAT_MESSAGE_FROM_SYSTEM |
                    FORMAT_MESSAGE_IGNORE_INSERTS,
                    NULL,
                    error_code,
                    MAKELANGID( LANG_NEUTRAL, SUBLANG_SYS_DEFAULT ),
          (LPTSTR) &message_buffer,
                    0,
                    NULL );

   error_string = (LPCTSTR) message_buffer;

   ::LocalFree( message_buffer );
   message_buffer = NULL;

   if ( error_string.GetLength() == 0 )
   {
      error_string.Format( TEXT( "Unknown System Error %lu" ), error_code );
   }
}

#if 0
<WFC_DOCUMENTATION>
<HTML>
<HEAD>
<TITLE>WFC - wfc_get_error_string</TITLE>
<META name="keywords" content="WFC, MFC extension library, freeware class library, Win32">
<META name="description" content="Simple C function that converts error codes to something humanly readable.">
</HEAD>
<BODY>
<H1>wfc_get_error_string</H1>
$Revision: 8 $<HR>
<H2>Declaration</H2>
<PRE>void <B>wfc_get_error_string</B>( DWORD error_code, CString&amp; error_string )</PRE>
<H2>Description</H2>
This function takes a value returned from GetLastError() and formats 
it into something humanly readable.
<H2>Example</H2><PRE><CODE>void print_error( void )
{
   DWORD error_code = GetLastError();

   CString something_a_human_can_understand;

   <B>wfc_get_error_string</B>( error_code, something_a_human_can_understand );

   _tprintf( TEXT( &quot;%s\n&quot; ), (LPCTSTR) something_a_human_can_understand );
}</CODE></PRE>
<H2>API's Used</H2>
<B>wfc_get_error_string</B>() uses the following API's:
<UL>
<LI>FormatMessage
<LI>LocalFree
</UL>
<I>Copyright, 1998, Samuel R. Blackburn</I><BR>
$Workfile: wfc_get_error_string.cpp $<BR>
$Modtime: 9/07/98 6:59a $
</BODY>
</HTML>
</WFC_DOCUMENTATION>
#endif
