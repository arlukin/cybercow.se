#include <wfc.h>
#pragma hdrstop

/*
** Author: Samuel R. Blackburn
** Internet: wfc@pobox.com
**
** You can use it any way you like as long as you don't try to sell it.
**
** Any attempt to sell WFC in source code form must have the permission
** of the original author. You can produce commercial executables with
** WFC but you can't sell WFC.
**
** Copyright, 1998, Samuel R. Blackburn
**
** $Workfile: sockfile.cpp $
** $Revision: 11 $
** $Modtime: 3/08/98 2:28p $
*/

#if defined( _DEBUG )
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif // _DEBUG

CSimpleSocketFile::CSimpleSocketFile( SOCKET client_id, const char * name, const char *dotted_ip_address )
{
   m_SocketID = client_id;
   m_hFile    = client_id;

   if ( name == NULL )
   {
      Name.Empty();
   }
   else
   {
      Name = name;
   }

   if ( dotted_ip_address == NULL )
   {
      Address.Empty();
   }
   else
   {
      Address = dotted_ip_address;
   }

   // The filename should be the host name followed by IP address then port number.
   // Example: "Sammy (195.99.72.1)"

   m_strFileName.Format( TEXT( "%s (%s)" ), (LPCTSTR) Name, (LPCTSTR) Address );
}

CSimpleSocketFile::~CSimpleSocketFile()
{
   Close();
}

BOOL CSimpleSocketFile::Open( void )
{
   ASSERT_VALID( this );
   return( TRUE );
}

#pragma warning( disable : 4100 )

BOOL CSimpleSocketFile::Open( const char *name, UINT port, CFileException *perror )
{
   ASSERT_VALID( this );
   return( TRUE );
}

#pragma warning( default : 4100 )
