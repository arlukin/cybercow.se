#include <wfc.h>
#pragma hdrstop

/*
** Author: Samuel R. Blackburn
** Internet: wfc@pobox.com
**
** You can use it any way you like as long as you don't try to sell it.
**
** Any attempt to sell WFC in source code form must have the permission
** of the original author. You can produce commercial executables with
** WFC but you can't sell WFC.
**
** Copyright, 1998, Samuel R. Blackburn
**
** $Workfile: wfc_UNICODE_floating_point_routines.cpp $
** $Revision: 1 $
** $Modtime: 3/27/98 3:27p $
*/

#if defined( _DEBUG )
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif // _DEBUG

double wfc_unicode_atof( LPCWSTR unicode_string )
{
   char ascii_string[ 4096 ];

   ascii_string[ 0 ] = 0x00;
   ascii_string[ 1 ] = 0x00;

   UNICODE_to_ASCII( unicode_string, ascii_string );

   return( atof( ascii_string ) );
}
