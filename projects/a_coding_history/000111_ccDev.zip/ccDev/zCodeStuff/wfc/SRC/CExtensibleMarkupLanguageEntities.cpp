#include <wfc.h>
#pragma hdrstop

/*
** Author: Samuel R. Blackburn
** Internet: wfc@pobox.com
**
** You can use it any way you like as long as you don't try to sell it.
**
** Any attempt to sell WFC in source code form must have the permission
** of the original author. You can produce commercial executables with
** WFC but you can't sell WFC.
**
** Copyright, 1998, Samuel R. Blackburn
**
** $Workfile: CExtensibleMarkupLanguageEntities.cpp $
** $Revision: 13 $
** $Modtime: 1/08/99 1:59p $
*/

#if defined( _DEBUG )
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif // _DEBUG

CExtensibleMarkupLanguageEntities::CExtensibleMarkupLanguageEntities()
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageEntities::CExtensibleMarkupLanguageEntities()" ) );
   WFCTRACEVAL( TEXT( "pointer is " ), (VOID *) this );
}

CExtensibleMarkupLanguageEntities::CExtensibleMarkupLanguageEntities( const CExtensibleMarkupLanguageEntities& source )
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageEntities::CExtensibleMarkupLanguageEntities( CExtensibleMarkupLanguageEntities )" ) );
   WFCTRACEVAL( TEXT( "pointer is " ), (VOID *) this );
   Copy( source );
}

CExtensibleMarkupLanguageEntities::~CExtensibleMarkupLanguageEntities()
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageEntities::~CExtensibleMarkupLanguageEntities()" ) );
   WFCTRACEVAL( TEXT( "pointer is " ), (VOID *) this );
}

void CExtensibleMarkupLanguageEntities::Add( const CString& entity, const CString& text )
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageEntities::Add()" ) );

   // The list is sorted for quick searching using a binary search

   long lower_limit = 0;
   long upper_limit = m_Entities.GetUpperBound();

   if ( upper_limit == (-1) )
   {
      m_Entities.Add( entity );
      m_Values.Add( text );
      return;
   }

   long here = upper_limit / 2;

   CString entity_in_list;

   int comparison_result = 0;

   do
   {
      entity_in_list = m_Entities.GetAt( here );

      comparison_result = entity.Compare( entity_in_list );

      if ( comparison_result < 0 )
      {
         upper_limit = here - 1;
      }
      else if ( comparison_result > 0 )
      {
         lower_limit = here + 1;
      }
      else
      {
         // WE FOUND IT!
         // This means we must be reading an existing entity

         CString text_already_defined;

         text_already_defined = m_Values.GetAt( here );

         if ( text.Compare( text_already_defined ) != 0 )
         {
            WFCTRACE( TEXT( "WARNING! Redefining an existing entity!" ) );

            m_Values.SetAt( here, text );
         }

         return;
      }

      here = ( lower_limit + upper_limit ) / 2;
   }
   while( lower_limit <= upper_limit );

   // If we get here, the entity wasn't in the list, we need to add it

   if ( here > 0 )
   {
      here--;
   }

   upper_limit = m_Entities.GetUpperBound();

   comparison_result = entity.Compare( m_Entities.GetAt( here ) );

   while( here < upper_limit && comparison_result > 0 )
   {
      here++;
      comparison_result = entity.Compare( m_Entities.GetAt( here ) );
   }

   if ( here >= upper_limit && comparison_result > 0 )
   {
      m_Entities.Add( entity );
      m_Values.Add( text );
   }
   else
   {
      m_Entities.InsertAt( here, entity );
      m_Values.InsertAt( here, text );
   }
}

void CExtensibleMarkupLanguageEntities::Copy( const CExtensibleMarkupLanguageEntities& source )
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageEntities::Copy()" ) );
   m_Entities.Copy( source.m_Entities );
   m_Values.Copy( source.m_Values );
}

#if defined( _DEBUG )

void CExtensibleMarkupLanguageEntities::Dump( CDumpContext& dump_context ) const
{
   dump_context << TEXT( " a CExtensibleMarkupLanguageEntities at " ) << (VOID *) this << TEXT( "\n{\n" );
   dump_context << TEXT( "   m_Entities has " ) << m_Entities.GetSize() << TEXT( " elements.\n   {\n" );

   long loop_index         = 0;
   long number_of_elements = m_Entities.GetSize();

   while( loop_index < number_of_elements )
   {
      dump_context << TEXT( "      " ) << loop_index << TEXT( " - \"" ) << m_Entities.GetAt( loop_index ) << TEXT( "\"\n" );
      loop_index++;
   }

   dump_context << TEXT( "   }\n" );

   dump_context << TEXT( "   m_Values has " ) << m_Values.GetSize() << TEXT( " elements.\n   {\n" );

   loop_index         = 0;
   number_of_elements = m_Values.GetSize();

   while( loop_index < number_of_elements )
   {
      dump_context << TEXT( "      " ) << loop_index << TEXT( " - \"" ) << m_Values.GetAt( loop_index ) << TEXT( "\"\n" );
      loop_index++;
   }

   dump_context << TEXT( "   }\n" );
   dump_context << TEXT( "}\n" );
}

#endif // _DEBUGDump


void CExtensibleMarkupLanguageEntities::Empty( void )
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageEntities::Empty()" ) );
   m_Entities.RemoveAll();
   m_Values.RemoveAll();
}

BOOL CExtensibleMarkupLanguageEntities::Resolve( const CString& entity, CString& text ) const
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageEntities::Resolve()" ) );

   // First, check to see if this is a mathematical entity.

   int entity_length = entity.GetLength();
   int index         = 0;

   if ( entity_length < 3 )
   {
      // We must have a leading & and trailing ; and at least one character in the middle

      WFCTRACE( TEXT( "Entity too short (less than three characters)" ) );
      text.Empty();
      return( FALSE );
   }

   if ( entity.GetAt( 0 ) != TEXT( '&' ) )
   {
      WFCTRACE( TEXT( "First character isn't &" ) );
      return( FALSE );
   }

   if ( entity.GetAt( entity.GetLength() - 1 ) != TEXT( ';' ) )
   {
      WFCTRACE( TEXT( "Last character isn't ;" ) );
      return( FALSE );
   }

   if ( entity.GetAt( 1 ) == TEXT( '#' ) )
   {
      // Check to see if mathematical entity is possible

      if ( entity_length == 3 )
      {
         WFCTRACE( TEXT( "No body for the mathematical entity." ) );
         text.Empty();
         return( FALSE );
      }

      // Let's see if it is hexadecimal or decimal

      if ( entity.GetAt( 2 ) == TEXT( 'X' ) )
      {
         WFCTRACE( TEXT( "Ill-formed entity, it uses a capital X instead of x." ) );
         text.Empty();
         return( FALSE );
      }

      TCHAR number_string[ 1024 ]; // insanely large buffer

      long translated_character = 0;

      if ( entity.GetAt( 2 ) == TEXT( 'x' ) )
      {
         // Yup, we be hexadecimal

         index = 0;

         // loop through the digits but skip the trailing ;

         // We use entity_length - 4 because we need to skip the &#x at the beginning and ; at the end

         while( index < ( entity_length - 4 ) && index < 1023 )
         {
            if ( _istxdigit( entity.GetAt( index + 3 ) ) == 0 ) // + 3 skips &#x
            {
               WFCTRACEVAL( TEXT( "Ill-formed hexadecimal entity. Character is not a hexadecimal digit at index " ), index + 3 );
               text.Empty();
               return( FALSE );
            }

            number_string[ index ] = entity.GetAt( index + 3 );
            index++;
            number_string[ index ] = 0; // NULL terminate the string
         }

         // number_string now contains the hex number of the character

         TCHAR * stopped_at_address = NULL;

         translated_character = _tcstol( number_string, &stopped_at_address, 16 );

         text = CString( (TCHAR) translated_character );

         return( TRUE );
      }
      else
      {
         // Nope, we must be decimal

         index = 0;

         // We use entity_length - 3 because we need to skip the &# at the beginning and ; at the end
         while( index < ( entity_length - 3 ) && index < 1023 )
         {
            if ( _istdigit( entity.GetAt( index + 2 ) ) == 0 ) // + 2 skips &#
            {
               WFCTRACEVAL( TEXT( "Ill-formed decimal entity. Character is not a digit at index " ), index + 2 );
               text.Empty();
               return( FALSE );
            }

            number_string[ index ] = entity.GetAt( index + 2 );
            index++;
            number_string[ index ] = 0; // NULL terminate the string
         }

         // number_string now contains the decimal number of the character

         translated_character = _ttol( number_string );

         text = CString( (TCHAR) translated_character );

         return( TRUE );
      }
   }

   // Welp, it weren't no mathematical entity

   // The entity list is sorted so we can use a binary search

   long lower_limit = 0;
   long upper_limit = m_Entities.GetUpperBound();

   if ( upper_limit == (-1) )
   {
      text.Empty();
      return( FALSE );
   }

   long here = upper_limit / 2;

   CString entity_in_list;

   int comparison_result = 0;

   do
   {
      entity_in_list = m_Entities.GetAt( here );

      comparison_result = entity.Compare( entity_in_list );

      if ( comparison_result < 0 )
      {
         upper_limit = here - 1;
      }
      else if ( comparison_result > 0 )
      {
         lower_limit = here + 1;
      }
      else
      {
         // YIPPEE!! We found that sucker!

         text = m_Values.GetAt( here );

         return( TRUE );
      }

      // Thanks go to Darin Greaham (greaham@cyberramp.net) for finding
      // where I wasn't calculating a new value for "here". That meant
      // I went into an endless loop.
      // 1998-08-10

      here = ( lower_limit + upper_limit ) / 2;
   }
   while( lower_limit <= upper_limit );

   // Entity was not found

   WFCTRACEVAL( TEXT( "Cannot resolve " ), entity );

   text.Empty();

   return( FALSE );
}

CExtensibleMarkupLanguageEntities& CExtensibleMarkupLanguageEntities::operator=( const CExtensibleMarkupLanguageEntities& source )
{
   WFCLTRACEINIT( TEXT( "CExtensibleMarkupLanguageEntities::operator=()" ) );
   Copy( source );
   return( *this );
}

#if 0
<WFC_DOCUMENTATION>
<HTML>
<HEAD>
<TITLE>WFC - CExtensibleMarkupLanguageEntities</TITLE>
<META name="keywords" content="WFC, MFC extension library, freeware class library, Win32, push technology, source code">
<META name="description" content="The C++ class that handles XML entities.">
</HEAD>
<BODY>
<H1>CExtensibleMarkupLanguageEntities</H1>
$Revision: 13 $
<HR><H2>Description</H2>
This class holds the name and value of an XML entity. It is a very
trivial class.
<H2>Methods</H2>
<DL COMPACT>
<DT><B>Copy</B><DD>Copies another <B>CExtensibleMarkupLanguageEntities</B>.
<DT><B>Empty</B><DD>Clears all data members.
</DL>
<H2>Example</H2><PRE><CODE>Sorry.</CODE></PRE>
<HR><I>Copyright, 1998, <A HREF="mailto:wfc@pobox.com">Samuel R. Blackburn</A></I><BR>
$Workfile: CExtensibleMarkupLanguageEntities.cpp $<BR>
$Modtime: 1/08/99 1:59p $
</BODY>
</HTML>
</WFC_DOCUMENTATION>
#endif
