#include <wfc.h>
#pragma hdrstop

/*
** Author: Samuel R. Blackburn
** Internet: wfc@pobox.com
**
** You can use it any way you like as long as you don't try to sell it.
**
** Any attempt to sell WFC in source code form must have the permission
** of the original author. You can produce commercial executables with
** WFC but you can't sell WFC.
**
** Copyright, 1998, Samuel R. Blackburn
**
** $Workfile: CDataParser.cpp $
** $Revision: 12 $
** $Modtime: 11/22/98 9:38a $
*/

#if defined( _DEBUG )
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif // _DEBUG

CDataParser::CDataParser()
{
   WFCLTRACEINIT( TEXT( "CDataParser::CDataParser()" ) );

   m_AutomaticallyDelete = FALSE;
   m_Data                = NULL;

#if defined( _DEBUG )
   m_LastIndex                                   = 0;
   m_NumberOfTimesWeHaveBeenAskedForTheSameIndex = 0;
#endif // _DEBUG
}

CDataParser::~CDataParser()
{
   WFCLTRACEINIT( TEXT( "CDataParser::~CDataParser()" ) );
   Empty();
}

#if defined( _DEBUG )

void CDataParser::Dump( CDumpContext& dump_context ) const
{
   dump_context << TEXT( " is a CDataParser at " ) << (VOID *) this << TEXT( "\n{\n" );
   dump_context << TEXT( "   m_AutomaticallyDelete is " );

   if ( m_AutomaticallyDelete == FALSE )
   {
      dump_context << TEXT( "FALSE\n" );
   }
   else
   {
      dump_context << TEXT( "TRUE\n" );
   }

   dump_context << TEXT( "   m_Data is " );

   if ( m_Data == NULL )
   {
      dump_context << TEXT( "NULL\n" );
   }
   else
   {
      m_Data->Dump( dump_context );
   }

   dump_context << TEXT( "}\n" );

}

#endif // _DEBUG

void CDataParser::Empty( void )
{
   WFCLTRACEINIT( TEXT( "CDataParser::Empty()" ) );

   try
   {
      if ( m_AutomaticallyDelete != FALSE )
      {
         if ( m_Data != NULL )
         {
            delete m_Data;
            m_Data = NULL;
         }
      }

      m_AutomaticallyDelete = FALSE;
      m_Data                = NULL;
#if defined( _DEBUG )
      m_LastIndex                                   = 0;
      m_NumberOfTimesWeHaveBeenAskedForTheSameIndex = 0;
#endif // _DEBUG
   }
   catch( ... )
   {
      // We can't do anything in here because this may be NULL!
      return;
   }
}

BOOL CDataParser::Find( const CParsePoint& parse_point, BYTE byte_to_find, CParsePoint& found_at ) const
{
   WFCLTRACEINIT( TEXT( "CDataParser::Find( BYTE )" ) );

   try
   {
      found_at.Copy( parse_point );

      if ( m_Data == NULL )
      {
         found_at.Empty();
         ::SetLastError( ERROR_INVALID_ADDRESS );
         ASSERT( FALSE );
         return( FALSE );
      }

      DWORD number_of_data_bytes = m_Data->GetSize();

      if ( found_at.GetIndex() >= number_of_data_bytes )
      {
         found_at.Empty();
         ::SetLastError( ERROR_ALLOTTED_SPACE_EXCEEDED );
         return( FALSE );
      }

      const BYTE * buffer = m_Data->GetData();

      while( found_at.GetIndex() < number_of_data_bytes )
      {
         if ( buffer[ found_at.GetIndex() ] == byte_to_find )
         {
            return( TRUE );
         }

         found_at.AutoIncrement( buffer[ found_at.GetIndex() ] );
      }

      found_at.Empty();

      ::SetLastError( NO_ERROR );
      return( FALSE );
   }
   catch( ... )
   {
      return( FALSE );
   }
}

BOOL CDataParser::Find( const CParsePoint& parse_point, const CString& string_to_find, CParsePoint& found_at ) const
{
   WFCLTRACEINIT( TEXT( "CDataParser::Find( CString )" ) );

   try
   {
      found_at.Copy( parse_point );

      if ( m_Data == NULL )
      {
         found_at.Empty();
         ::SetLastError( ERROR_INVALID_ADDRESS );
         ASSERT( FALSE );
         return( FALSE );
      }

      DWORD number_of_data_bytes = m_Data->GetSize();

      if ( found_at.GetIndex() >= number_of_data_bytes )
      {
         found_at.Empty();
         ::SetLastError( ERROR_ALLOTTED_SPACE_EXCEEDED );
         return( FALSE );
      }

      size_t string_length = string_to_find.GetLength();

      const BYTE * buffer = m_Data->GetData();

      while( ( found_at.GetIndex() + string_length ) < number_of_data_bytes )
      {
         if ( ::memcmp( &buffer[ found_at.GetIndex() ], static_cast< LPCTSTR > ( string_to_find ), string_length ) == 0 )
         {
            return( TRUE );
         }

         found_at.AutoIncrement( buffer[ found_at.GetIndex() ] );
      }

      found_at.Empty();

      ::SetLastError( NO_ERROR );
      return( FALSE );
   }
   catch( ... )
   {
      return( FALSE );
   }
}

BOOL CDataParser::Find( const CParsePoint& parse_point, const CByteArray& bytes_to_find, CParsePoint& found_at ) const
{
   WFCLTRACEINIT( TEXT( "CDataParser::Find( CByteArray )" ) );

   try
   {
      found_at.Copy( parse_point );

      if ( m_Data == NULL )
      {
         found_at.Empty();
         ::SetLastError( ERROR_INVALID_ADDRESS );
         ASSERT( FALSE );
         return( FALSE );
      }

      DWORD number_of_data_bytes = m_Data->GetSize();

      if ( found_at.GetIndex() >= number_of_data_bytes )
      {
         found_at.Empty();
         ::SetLastError( ERROR_ALLOTTED_SPACE_EXCEEDED );
         return( FALSE );
      }

      size_t pattern_length = bytes_to_find.GetSize();

      const BYTE * buffer         = m_Data->GetData();
      const BYTE * pattern_buffer = bytes_to_find.GetData();

      while( ( found_at.GetIndex() + pattern_length ) < number_of_data_bytes )
      {
         if ( ::memcmp( &buffer[ found_at.GetIndex() ], pattern_buffer, pattern_length ) == 0 )
         {
            return( TRUE );
         }

         found_at.AutoIncrement( buffer[ found_at.GetIndex() ] );
      }

      found_at.Empty();

      ::SetLastError( NO_ERROR );
      return( FALSE );
   }
   catch( ... )
   {
      return( FALSE );
   }
}

BOOL CDataParser::FindNoCase( const CParsePoint& parse_point, const CString& string_to_find, CParsePoint& found_at ) const
{
   WFCLTRACEINIT( TEXT( "CDataParser::Find( CString )" ) );

   try
   {
      found_at.Copy( parse_point );

      if ( m_Data == NULL )
      {
         found_at.Empty();
         ::SetLastError( ERROR_INVALID_ADDRESS );
         ASSERT( FALSE );
         return( FALSE );
      }

      DWORD number_of_data_bytes = m_Data->GetSize();

      if ( found_at.GetIndex() >= number_of_data_bytes )
      {
         found_at.Empty();
         ::SetLastError( ERROR_ALLOTTED_SPACE_EXCEEDED );
         return( FALSE );
      }

      size_t string_length = string_to_find.GetLength();

      const BYTE * buffer = m_Data->GetData();

      while( ( found_at.GetIndex() + string_length ) < number_of_data_bytes )
      {
         if ( ::_memicmp( &buffer[ found_at.GetIndex() ], static_cast< LPCTSTR > ( string_to_find ), string_length ) == 0 )
         {
            return( TRUE );
         }

         found_at.AutoIncrement( buffer[ found_at.GetIndex() ] );
      }

      found_at.Empty();

      ::SetLastError( NO_ERROR );
      return( FALSE );
   }
   catch( ... )
   {
      return( FALSE );
   }
}

BOOL CDataParser::FindNoCase( const CParsePoint& parse_point, const CByteArray& bytes_to_find, CParsePoint& found_at ) const
{
   WFCLTRACEINIT( TEXT( "CDataParser::Find( CByteArray )" ) );

   try
   {
      found_at.Copy( parse_point );

      if ( m_Data == NULL )
      {
         found_at.Empty();
         ::SetLastError( ERROR_INVALID_ADDRESS );
         ASSERT( FALSE );
         return( FALSE );
      }

      DWORD number_of_data_bytes = m_Data->GetSize();

      if ( found_at.GetIndex() >= number_of_data_bytes )
      {
         found_at.Empty();
         ::SetLastError( ERROR_ALLOTTED_SPACE_EXCEEDED );
         return( FALSE );
      }

      size_t pattern_length = bytes_to_find.GetSize();

      const BYTE * buffer         = m_Data->GetData();
      const BYTE * pattern_buffer = bytes_to_find.GetData();

      while( ( found_at.GetIndex() + pattern_length ) < number_of_data_bytes )
      {
         if ( ::_memicmp( &buffer[ found_at.GetIndex() ], pattern_buffer, pattern_length ) == 0 )
         {
            return( TRUE );
         }

         found_at.AutoIncrement( buffer[ found_at.GetIndex() ] );
      }

      found_at.Empty();

      ::SetLastError( NO_ERROR );
      return( FALSE );
   }
   catch( ... )
   {
      return( FALSE );
   }
}

BOOL CDataParser::Get( CParsePoint& parse_point, DWORD length, CByteArray& bytes_to_get ) const
{
   WFCLTRACEINIT( TEXT( "CDataParser::Get( CByteArray )" ) );

   try
   {
      bytes_to_get.RemoveAll();

      if ( m_Data == NULL )
      {
         ::SetLastError( ERROR_INVALID_ADDRESS );
         ASSERT( FALSE );
         return( FALSE );
      }

      if ( ( parse_point.GetIndex() + length ) >= static_cast< DWORD > ( m_Data->GetSize() ) )
      {
         ::SetLastError( ERROR_ALLOTTED_SPACE_EXCEEDED );
         return( FALSE );
      }

      DWORD index = 0;

      while( index < length )
      {
         bytes_to_get.Add( m_Data->GetAt( parse_point.GetIndex() ) );
         parse_point.AutoIncrement( m_Data->GetAt( parse_point.GetIndex() ) );
         index++;
      }

      ::SetLastError( NO_ERROR );
      return( TRUE );
   }
   catch( ... )
   {
      return( FALSE );
   }
}

BOOL CDataParser::Get( CParsePoint& parse_point, DWORD length, CString& string_to_get ) const
{
   WFCLTRACEINIT( TEXT( "CDataParser::Get( CString )" ) );

   try
   {
      string_to_get.Empty();

      if ( m_Data == NULL )
      {
         ::SetLastError( ERROR_INVALID_ADDRESS );
         ASSERT( FALSE );
         return( FALSE );
      }

      if ( ( parse_point.GetIndex() + length ) >= static_cast< DWORD > ( m_Data->GetSize() ) )
      {
         ::SetLastError( ERROR_ALLOTTED_SPACE_EXCEEDED );
         return( FALSE );
      }

      DWORD index = 0;

      while( index < length )
      {
         string_to_get += static_cast< TCHAR > ( m_Data->GetAt( parse_point.GetIndex() ) );
         parse_point.AutoIncrement( m_Data->GetAt( parse_point.GetIndex() ) );
         index++;
      }

      ::SetLastError( NO_ERROR );
      return( TRUE );
   }
   catch( ... )
   {
      return( FALSE );
   }
}

BYTE CDataParser::GetAt( DWORD index ) const
{
  // WFCLTRACEINIT( TEXT( "CDataParser::GetAt()" ) );

   try
   {

#if defined( _DEBUG )

      if ( index == m_LastIndex )
      {
         const_cast< DWORD& > ( m_NumberOfTimesWeHaveBeenAskedForTheSameIndex )++;

         if ( m_NumberOfTimesWeHaveBeenAskedForTheSameIndex > 25 )
         {
            // We've asked for this same stinking character 25 times already!
            // Looks like our caller is stuck in an endless loop

            ASSERT( FALSE );
         }
      }
      else
      {
         const_cast< DWORD& > ( m_LastIndex                                   ) = index;
         const_cast< DWORD& > ( m_NumberOfTimesWeHaveBeenAskedForTheSameIndex ) = 0;
      }

#endif // _DEBUG

      if ( m_Data == NULL )
      {
         ::SetLastError( ERROR_INVALID_ADDRESS );
         ASSERT( FALSE );
         return( 0 );
      }

      if ( index >= static_cast< DWORD > ( m_Data->GetSize() ) )
      {
         return( 0 );
      }

      return( m_Data->GetAt( index ) );
   }
   catch( ... )
   {
      return( 0 );
   }
}

DWORD CDataParser::GetSize( void ) const
{
   try
   {
      if ( m_Data == NULL )
      {
         ::SetLastError( ERROR_INVALID_ADDRESS );
         return( 0 );
      }

      int the_size = m_Data->GetSize();

      return( ( the_size < 0 ) ? 0 : the_size );
   }
   catch( ... )
   {
      return( 0 );
   }
}

BOOL CDataParser::GetUntilAndIncluding( CParsePoint& parse_point, BYTE termination_byte, CByteArray& bytes_to_get ) const
{
   WFCLTRACEINIT( TEXT( "CDataParser::GetUntilAndIncluding( CByteArray )" ) );

   try
   {
      bytes_to_get.RemoveAll();

      if ( m_Data == NULL )
      {
         ::SetLastError( ERROR_INVALID_ADDRESS );
         ASSERT( FALSE );
         return( FALSE );
      }

      if ( parse_point.GetIndex() >= static_cast< DWORD > ( m_Data->GetSize() ) )
      {
         ::SetLastError( ERROR_ALLOTTED_SPACE_EXCEEDED );
         return( FALSE );
      }

      BYTE byte_to_test = 0;

      do
      {
         if ( parse_point.GetIndex() < static_cast< DWORD > ( m_Data->GetSize() ) )
         {
            byte_to_test = m_Data->GetAt( parse_point.GetIndex() );
            bytes_to_get.Add( byte_to_test );
            parse_point.AutoIncrement( byte_to_test );
         }
         else
         {
            ::SetLastError( ERROR_ALLOTTED_SPACE_EXCEEDED );
            return( FALSE );
         }
      }
      while( byte_to_test != termination_byte );

      ::SetLastError( NO_ERROR );
      return( TRUE );
   }
   catch( ... )
   {
      return( FALSE );
   }
}

BOOL CDataParser::GetUntilAndIncluding( CParsePoint& parse_point, BYTE termination_byte, CString& string_to_get ) const
{
   WFCLTRACEINIT( TEXT( "CDataParser::GetUntilAndIncluding( CString )" ) );

   try
   {
      string_to_get.Empty();

      if ( m_Data == NULL )
      {
         ::SetLastError( ERROR_INVALID_ADDRESS );
         ASSERT( FALSE );
         return( FALSE );
      }

      if ( parse_point.GetIndex() >= static_cast< DWORD > ( m_Data->GetSize() ) )
      {
         ::SetLastError( ERROR_ALLOTTED_SPACE_EXCEEDED );
         return( FALSE );
      }

      BYTE byte_to_test = 0;

      do
      {
         if ( parse_point.GetIndex() < static_cast< DWORD > ( m_Data->GetSize() ) )
         {
            byte_to_test = m_Data->GetAt( parse_point.GetIndex() );
            string_to_get += static_cast< TCHAR > ( byte_to_test );
            parse_point.AutoIncrement( byte_to_test );
         }
         else
         {
            ::SetLastError( ERROR_ALLOTTED_SPACE_EXCEEDED );
            return( FALSE );
         }
      }
      while( byte_to_test != termination_byte );

      ::SetLastError( NO_ERROR );
      return( TRUE );
   }
   catch( ... )
   {
      return( FALSE );
   }
}

// 1998-11-21, New for Release 38
// The following method was added by Jeff Barczewski (jb@snowflight.com)
// He added to fix a bun in the parsing of comment sections in XML

BOOL CDataParser::GetUntilAndIncluding( CParsePoint& parse_point, const CString& termination_characters, CString& string_to_get ) const
{
   WFCLTRACEINIT( TEXT( "CDataParser::GetUntilAndIncluding( CString )" ) );

   try
   {
      string_to_get.Empty();

      if ( m_Data == NULL )
      {
         ::SetLastError( ERROR_INVALID_ADDRESS );
         ASSERT( FALSE );
         return( FALSE );
      }

      if ( parse_point.GetIndex() >= static_cast< DWORD > ( m_Data->GetSize() ) )
      {
         ::SetLastError( ERROR_ALLOTTED_SPACE_EXCEEDED );
         return( FALSE );
      }

      TCHAR character_to_test = 0;

      const BYTE * data_p = m_Data->GetData();

      DWORD termination_characters_length = termination_characters.GetLength();

      do
      {
         if ( parse_point.GetIndex() + termination_characters_length - 1 < static_cast< DWORD > ( m_Data->GetSize() ) )
         {
            character_to_test = m_Data->GetAt( parse_point.GetIndex() );
            string_to_get += static_cast< TCHAR > ( character_to_test );
            parse_point.AutoIncrement( character_to_test );
         }
         else
         {
            ::SetLastError( ERROR_ALLOTTED_SPACE_EXCEEDED );
            return( FALSE );
         }
      }
      while( 0 != memcmp( data_p + parse_point.GetIndex(), (LPCTSTR) termination_characters, termination_characters_length ) );

      for( DWORD loop_index = 0; loop_index < termination_characters_length; loop_index++ )
      {
         //move to the end of the string
         character_to_test = m_Data->GetAt( parse_point.GetIndex() );
         string_to_get += static_cast< TCHAR > ( character_to_test );
         parse_point.AutoIncrement( character_to_test );
      }

      ::SetLastError( NO_ERROR );

      return( TRUE );
   }
   catch( ... )
   {
      return( FALSE );
   }
}

BOOL CDataParser::GetUntilAndIncluding( CParsePoint& parse_point, const CByteArray& termination_bytes, CString& string_to_get ) const
{
   WFCLTRACEINIT( TEXT( "CDataParser::GetUntilAndIncluding( CString )" ) );

   try
   {
      string_to_get.Empty();

      if ( m_Data == NULL )
      {
         ::SetLastError( ERROR_INVALID_ADDRESS );
         ASSERT( FALSE );
         return( FALSE );
      }

      if ( parse_point.GetIndex() >= static_cast< DWORD > ( m_Data->GetSize() ) )
      {
         ::SetLastError( ERROR_ALLOTTED_SPACE_EXCEEDED );
         return( FALSE );
      }

      TCHAR character_to_test = 0;

      const BYTE * data_p = m_Data->GetData();
      const BYTE * termination_bytes_p = termination_bytes.GetData();

      DWORD termination_bytes_length = termination_bytes.GetSize();

      do
      {
         if ( parse_point.GetIndex() + termination_bytes_length - 1 < static_cast< DWORD > ( m_Data->GetSize() ) )
         {
            character_to_test = m_Data->GetAt( parse_point.GetIndex() );
            string_to_get += character_to_test;
            parse_point.AutoIncrement( character_to_test );
         }
         else
         {
            ::SetLastError( ERROR_ALLOTTED_SPACE_EXCEEDED );
            return( FALSE );
         }
      }
      while( 0 != memcmp( data_p + parse_point.GetIndex(), termination_bytes_p, termination_bytes_length ) );

      for( DWORD loop_index = 0; loop_index < termination_bytes_length; loop_index++ )
      {
         //move to the end of the string
         character_to_test = m_Data->GetAt( parse_point.GetIndex() );
         string_to_get += static_cast< TCHAR > ( character_to_test );
         parse_point.AutoIncrement( character_to_test );
      }

      ::SetLastError( NO_ERROR );

      return( TRUE );
   }
   catch( ... )
   {
      return( FALSE );
   }
}

BOOL CDataParser::Initialize( CByteArray * data, BOOL automatically_delete )
{
   WFCLTRACEINIT( TEXT( "CDataParser::Initialize( CByteArray )" ) );

   try
   {
      Empty();

      m_AutomaticallyDelete = automatically_delete;
      m_Data                = data;

      ::SetLastError( NO_ERROR );

      if ( m_Data == NULL )
      {
         ::SetLastError( ERROR_INVALID_ADDRESS );
         return( FALSE );
      }

      return( TRUE );
   }
   catch( ... )
   {
      return( FALSE );
   }
}

BOOL CDataParser::Initialize( const CStringArray& strings )
{
   WFCLTRACEINIT( TEXT( "CDataParser::Initialize( CStringArray )" ) );

   try
   {
      // Let's create our own CByteArray

      CByteArray * bytes_p = NULL;

      try
      {
         bytes_p = new CByteArray;
      }
      catch( ... )
      {
         bytes_p = NULL;
      }

      if ( bytes_p == NULL )
      {
         WFCTRACE( TEXT( "Can't allocate memory for a new CByteArray" ) );
         return( FALSE );
      }

      CString a_string;

      DWORD index             = 0;
      DWORD number_of_strings = strings.GetSize();
      DWORD string_index      = 0;
      DWORD string_length     = 0;

      while( index < number_of_strings )
      {
         a_string = strings.GetAt( index );

         // CByteArray doesn't have a method where you can append a lot bytes at once
         // so we have to hack around it

         string_index = 0;
         string_length = a_string.GetLength();

         while( string_index < string_length )
         {
            bytes_p->Add( static_cast< BYTE > ( a_string.GetAt( string_index ) ) );
            string_index++;
         }

         index++;
      }

      Initialize( bytes_p, TRUE );

      return( TRUE );
   }
   catch( ... )
   {
      return( FALSE );
   }
}

void CDataParser::m_Initialize( void )
{
   m_AutomaticallyDelete = FALSE;
   m_Data                = NULL;
}

#if 0
<WFC_DOCUMENTATION>
<HTML>

<HEAD>
<TITLE>WFC - CDataParser</TITLE>
<META name="keywords" content="WFC, MFC extension library, freeware class library, Win32, push technology, source code">
<META name="description" content="The C++ class that parses anything.">
</HEAD>

<BODY>

<H1>CDataParser</H1>

$Revision: 12 $
<HR>

<H2>Description</H2>

This class is a generic class to assist in parsing data.
It provides some basic searching capability as well as
idiot proofed retrieval.

<H2>Construction</H2>

<DL COMPACT>

<DT><PRE><B>CDataParser</B>()</PRE><DD>
Constructs the object.
</DL>

<H2>Methods</H2>

<DL COMPACT>

<DT><PRE>void <B>Empty</B>( void )</PRE><DD>
Re-initializes the object. If a CByteArray was attached
(and set to automatically delete) it will be deleted.

<DT><PRE>BOOL <B>Find</B>( const <A HREF="CParsePoint.htm">CParsePoint</A>&amp; parse_point, BYTE byte_to_find, <A HREF="CParsePoint.htm">CParsePoint</A>&amp; found_at ) const
BOOL <B>Find</B>( const <A HREF="CParsePoint.htm">CParsePoint</A>&amp; parse_point, const CString&amp; string_to_find, <A HREF="CParsePoint.htm">CParsePoint</A>&amp; found_at ) const
BOOL <B>Find</B>( const <A HREF="CParsePoint.htm">CParsePoint</A>&amp; parse_point, const CByteArray&amp; bytes_to_find, <A HREF="CParsePoint.htm">CParsePoint</A>&amp; found_at ) const</PRE><DD>
Searches for <CODE>byte_to_find</CODE>, <CODE>string_to_find</CODE> or
<CODE>bytes_to_find</CODE> beginning at <CODE>parse_point</CODE>.
If what you're looking for is found, the location will be put into
<CODE>found_at</CODE> and the return value will be TRUE. If <B>Find</B>()
cannot find what you're looking for, it will return FALSE.

<DT><PRE>BOOL <B>FindNoCase</B>( const <A HREF="CParsePoint.htm">CParsePoint</A>&amp; parse_point, const CString&amp; string_to_find, <A HREF="CParsePoint.htm">CParsePoint</A>&amp; found_at ) const
BOOL <B>FindNoCase</B>( const <A HREF="CParsePoint.htm">CParsePoint</A>&amp; parse_point, const CByteArray&amp; bytes_to_find, <A HREF="CParsePoint.htm">CParsePoint</A>&amp; found_at ) const</PRE><DD>
Will search for <CODE>string_to_find</CODE> or <CODE>bytes_to_find</CODE> without
regard to case. It will match 'a' with 'A'.
If what you're looking for is found, the location will be put into
<CODE>found_at</CODE> and the return value will be TRUE. If <B>FindNoCase</B>()
cannot find what you're looking for, it will return FALSE.

<DT><PRE>BOOL <B>Get</B>( <A HREF="CParsePoint.htm">CParsePoint</A>&amp; parse_point, DWORD length, CByteArray&amp; bytes_to_get ) const
BOOL <B>Get</B>( <A HREF="CParsePoint.htm">CParsePoint</A>&amp; parse_point, DWORD length, CString&amp; string_to_get ) const</PRE><DD>
Retrieves the <CODE>length</CODE> number of bytes beginning at <CODE>parse_point</CODE>.

<DT><PRE>BYTE <B>GetAt</B>( DWORD index ) const</PRE><DD>
Retrieves the byte at the given <CODE>index</CODE>.

<DT><PRE>DWORD <B>GetSize</B>( void ) const</PRE><DD>
Returns the number of bytes in the data area.

<DT><PRE>BOOL <B>GetUntilAndIncluding</B>( <A HREF="CParsePoint.htm">CParsePoint</A>&amp; parse_point, BYTE termination_byte, CString&amp; string_to_get ) const
BOOL <B>GetUntilAndIncluding</B>( <A HREF="CParsePoint.htm">CParsePoint</A>&amp; parse_point, BYTE termination_byte, CByteArray&amp; bytes_to_get ) const</PRE><DD>
This method retrieves data (filling <CODE>string_to_get</CODE> or <CODE>bytes_to_get</CODE>)
until and including the <CODE>termination_byte</CODE>. The <CODE>parse_point</CODE>
is advanced in the process.

<DT><PRE>BOOL <B>Initialize</B>( CByteArray * data, BOOL automatically_delete = FALSE )
BOOL <B>Initialize</B>( const CStringArray&amp; strings )</PRE><DD>
Tells the parser where to go for data.

</DL>

<H2>Example</H2>
<PRE><CODE>#include &lt;wfc.h&gt;

BOOL parse_document( const CString&amp; filename, <A HREF="CExtensibleMarkupLanguageDocument.htm">CExtensibleMarkupLanguageDocument</A>&amp; document )
{
   <A HREF="WfcTrace.htm">WFCTRACEINIT</A>( TEXT( &quot;parse_document()&quot; ) );

   CByteArray bytes;

   if ( get_bytes( filename, bytes ) != TRUE )
   {
      return( FALSE );
   }

   <B>CDataParser</B> parser;

   parser.Initialize( &amp;bytes, FALSE );

   if ( document.Parse( parser ) == TRUE )
   {
      WFCTRACE( TEXT( &quot;Parsed OK&quot; ) );
      return( TRUE );
   }
   else
   {
      WFCTRACE( TEXT( &quot;Can't parse document&quot; ) );
      return( FALSE );
   }
}</CODE></PRE>
<I>Copyright, 1998, <A HREF="mailto:wfc@pobox.com">Samuel R. Blackburn</A></I><BR>
$Workfile: CDataParser.cpp $<BR>
$Modtime: 11/22/98 9:38a $
</BODY>
</HTML>
</WFC_DOCUMENTATION>
#endif // 0