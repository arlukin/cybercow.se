#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
#define STRICT
#define _WIN32_WINNT 0x0400
#define _ATL_APARTMENT_THREADED
#include <atlbase.h>

class CExeModule : public CComModule
{
public:
	LONG CExeModule::Unlock()
	{	LONG l = CComModule::Unlock();
		if (l == 0)
			PostThreadMessage(dwThreadID, WM_QUIT, 0, 0);
		return l;
	}
	DWORD dwThreadID;
} _Module;

#include <atlimpl.cpp>

/*
//#define new DEBUG_NEW
#include "MemoryTracking.h"
#pragma warning(disable:4073)
#pragma init_seg(lib)
//USE_MEMORYTRACKING("allocs.txt", true)
USE_MEMORYTRACKING("", false)

*/



	// type of function in DLL
typedef int(*TFunction)(char**);


void cow()
{
	int * asdf;
	asdf = new int;
	for (int i=0;i<10;i++)
	{
		char * moo2;
		moo2 = new char[2333];
		strcpy(moo2, "sf");
		delete moo2;
	}
}
void moo()
{	
	cow();
	new char[20];		// leak, that is not detected if memory tracking 
}
/////////////////////////////////////////////////////////////////////////////
//
extern "C" int WINAPI _tWinMain(HINSTANCE hInstance, 
	HINSTANCE /*hPrevInstance*/, LPTSTR lpCmdLine, int /*nShowCmd*/)
{

	//LOGGING_ON 
		new char[20];		// leak, that is not detected if memory tracking 
		new char[20];		// leak, that is not detected if memory tracking 
							// is not enabled for this module
	//LOGGING_OFF
		moo();



//	_CrtSetBreakAlloc(43);
	_Module.Init(NULL,hInstance);

	HMODULE hMod = (HMODULE)::LoadLibrary("dll.dll");
	if(hMod)
	{	TFunction func = (TFunction)::GetProcAddress(hMod,"Function");

		char *buffer = NULL;

		if( func!=NULL )
			func(&buffer);

		::FreeLibrary(hMod);
	}
	_CrtDumpMemoryLeaks();
	return 1;
}
