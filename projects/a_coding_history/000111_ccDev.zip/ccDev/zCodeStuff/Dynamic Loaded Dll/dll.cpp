#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
#define STRICT
#define _WIN32_WINNT 0x0400
#define _ATL_APARTMENT_THREADED
#include <atlbase.h>
extern CComModule _Module;
#include <atlimpl.cpp>

CComModule _Module;

/*
#include "MemoryTracking.h"
#pragma warning(disable:4073)
#pragma init_seg(lib)
USE_MEMORYTRACKING("allocs.txt", true)
*/

// DLL Entry Point
extern "C" BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID /*lpReserved*/)
{
	if (dwReason == DLL_PROCESS_ATTACH)
	{	_Module.Init(NULL, hInstance);
		DisableThreadLibraryCalls(hInstance);
	}
	else if (dwReason == DLL_PROCESS_DETACH)
		_Module.Term();
	return TRUE;    // ok
}

	// Thread function
DWORD WINAPI ThreadProc(LPVOID lpParameter)
{
	char *leak = new char[50];	// just allocate a leak in the thread, then terminate
	return 0;
}
 
	// exported function
extern "C" int Function(char **buffer)
{
	*buffer = new char[100];				// leak that is detected
	*buffer = (char*)::CoTaskMemAlloc(100);	// leak that is not detected

	DWORD	ID;
	HANDLE	hThread = ::CreateThread(NULL, 0, ThreadProc, NULL, 0, &ID);

	::WaitForSingleObject(hThread, INFINITE);	// wait until thread has terminated
	return 0;
}



