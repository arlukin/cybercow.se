#include "stdafx.h"
#include "ProcessList.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

// Fills the Processlist using PSAPI
BOOL 
CProcessList::
FillProcessList()
{
	DWORD dwRetSizeList, *pdwList, dwSize, i;
	BOOL b;

	// Collect list into DWORD*.  
	// Later we add it to an STL vector.
	pdwList = NULL;
	dwSize = 0;

	m_vecID.clear();
	m_vecPath.clear();

    // Collect a list of processes into pdwList
	// Keep trying until the buffer we passed is large enough.
	while( true )
    {
        dwSize += 16;
        pdwList = new DWORD[dwSize];
        if( !pdwList )
		{
            TRACE( "FillProcessList: Out of memory.\n" );
			return FALSE;
		}

        b = EnumProcesses( pdwList, dwSize*sizeof(DWORD), &dwRetSizeList );

		// Got all entries?
		if( b && dwRetSizeList != dwSize*sizeof(DWORD) )
			break; // Success.

        delete pdwList;
		pdwList = NULL;

        if( !b )
		{
			TRACE( "FillProcessList: EnumProcess: %s\n", ErrorMessage() );
			return FALSE;
        }

    }
	// Calculate true size of returned array.
	dwSize = dwRetSizeList/sizeof(DWORD);

	// Copy it to m_vecID and retrieve pathnames
	for( i=0; i<dwSize; i++ )
	{
		m_vecID.push_back(pdwList[i]);
		m_vecPath.push_back( GetProcessPath( pdwList[i] ) );
	}

	// Free pdwList
	delete pdwList;

	return TRUE;
}

char *
CProcessList::
GetProcessPath( 
	DWORD dwProcess )
{
	BOOL b;
	HANDLE hProcess;
	HMODULE hModule;
	DWORD iRetSizeModule;
	char szBaseName[1024];
	static char szShortPath[1024];

	// Set standard return value to nothing
	*szShortPath = '\0';

	// Open process for information
    hProcess = OpenProcess( 
		PROCESS_QUERY_INFORMATION | PROCESS_VM_READ | SYNCHRONIZE,
        FALSE, dwProcess );
    if( hProcess != NULL )
    {
		// Open first module (the .EXE) of the process
        b = EnumProcessModules( hProcess, &hModule, 
            sizeof(hModule), &iRetSizeModule );
        if( b )
        {
			// Get the filename of the first module
            szBaseName[0] = '\0';
            b = GetModuleFileNameEx( hProcess, hModule,
                szBaseName, 1023 );
            if( b )
            {
				b = ConvertToShortPath( szShortPath, szBaseName );
				if( b )
					; // Success
				else
				{
					// Failure, reset return value
					*szShortPath = '\0';
					TRACE("GetProcessPath: ConvertToShortPath(%s): %s\n",
						szBaseName, ErrorMessage());
				}
            }
            else
                TRACE( "GetProcessPath: GetModuleFileNameEx(%ld): %s\n", 
                    dwProcess,  ErrorMessage() );
        }
        else
            TRACE( "GetProcessPath: EnumProcessModules(%ld): %s\n", 
                dwProcess, ErrorMessage() );

		CloseHandle(hProcess);
    }
	return szShortPath;
}

DWORD 
CProcessList::
FindProcess( 
	string sTarget )
{
	DWORD i, sz;

	sz = m_vecPath.size();
	for( i=0; i<sz; i++ )
	{
		if( m_vecPath[i] == sTarget )
			break;
	}
	if( i == sz )
		return -1;
	return m_vecID[i];
}

BOOL 
CProcessList::
ConvertToShortPath( 
	char* szShortPath, 
	char *szPath )
{
	char **szIndex, *szLoc, szSystem[256], szBackup[1024];
	char *szSystemDir[] = {
		"SystemRoot\\System32",
		NULL
	};
	char *szSkip[] = {
		"\\??\\",
		NULL
	};

	szLoc = NULL;
	szIndex = szSystemDir;
	while( *szIndex )
	{
		szLoc = strstr( szPath, *szIndex );
		if( szLoc )
		{
			GetSystemDirectory( szSystem, 256 );
			strcpy( szBackup, szSystem );
			strcat( szBackup, szLoc + strlen(*szIndex) );
			strcpy( szPath, szBackup );
			break;
		}
		szIndex++;
	}

	szLoc = NULL;
	szIndex = szSkip;
	while( *szIndex )
	{
		szLoc = strstr( szPath, *szIndex );
		if( szLoc )
		{
			szBackup[0] = '\0';
			strncpy( szBackup, szPath, szPath-szLoc );
			strcat( szBackup, szLoc + strlen(*szIndex) );
			strcpy( szPath, szBackup );
			break;
		}
		szIndex++;
	}

	if( GetShortPathName( szPath, szShortPath, 1023 ) )
	{
		strlwr(szShortPath);
		return TRUE;
	}
	return FALSE;
}