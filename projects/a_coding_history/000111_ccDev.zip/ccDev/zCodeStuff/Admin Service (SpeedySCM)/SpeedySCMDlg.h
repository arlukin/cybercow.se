#pragma once

#include "SpeedySCM.h"
#include "FormatError.h"
#include "ProcessList.h"
#include "ServiceList.h"
#include "ThreadPool.h"
#include "Privilege.h"

struct Info;

class CSpeedySCMDlg : public CDialog
{
// Construction
public:
	CSpeedySCMDlg(CWnd* pParent = NULL);	// standard constructor
	virtual ~CSpeedySCMDlg();

// Dialog Data
	//{{AFX_DATA(CSpeedySCMDlg)
	enum { IDD = IDD_SPEEDYSCM_DIALOG };
	CButton	m_ctrlTerminate;
	CListBox	m_ctrlErrors;
	CButton	m_ctrlPause;
	CButton	m_ctrlContinue;
	CButton	m_ctrlStop;
	CButton	m_ctrlStart;
	CEdit	m_ctrlComputer;
	CListBox	m_ctrlList;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSpeedySCMDlg)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	afx_msg void OnThreadFinished(WPARAM,LPARAM);
	afx_msg void OnError(WPARAM,LPARAM);
	virtual void OnSysCommand(UINT nID,LPARAM lParam);
	virtual void OnAbout();
	virtual void OnHelp();
	//{{AFX_MSG(CSpeedySCMDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnStart();
	afx_msg void OnStop();
	afx_msg void OnUpdate();
	afx_msg void OnChangeComputer();
	afx_msg void OnTerminate();
	afx_msg void OnPause();
	afx_msg void OnContinue();
	afx_msg void OnForget();
	afx_msg void OnSelchangeList();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	// ----- Constant helpers
	const static TCHAR *StatusMessage(
		DWORD dwState );
	const static TCHAR *ControlMessage(
		DWORD dwState );
	static DWORD TargetCode(
		DWORD dwState );
	static bool IsPending(
		DWORD dwState );

	// ----- Thread functions
	static void UpdateThread( 
		LPVOID par );
	static void ClearThread( 
		LPVOID par );
	static void ControlThread( 
		LPVOID par );
	static void ClearServicesThread( 
		LPVOID par ); 

	// ----- Thread helpers
	void SpawnControlThread( 
		const char *szServiceName, 
		const char *szServiceDisplay, 
		DWORD dwControlCode );
	BOOL SpawnUpdateThread( 
		Info* pInfo );
	void ClearInfo( 
		Info *pInfo );

	// ----- Error handling
	static CString *NewError( 
		const char *szAction, 
		const char *szService,
		const char *szComputer, 
		const char *szMsg = NULL );
	static void SendError( 
		Info *pInfo, 
		const char *szAction = NULL, 
		const char *szMsg = NULL );
	void SendError( 
		const char *szAction, 
		const char *szService, 
		const char *szMsg = NULL );
	void UpdateError( CString strWhat );

	// ----- Security
	BOOL EnableTerminate();

	// ----- Error handling
	void ToggleButtons();
	BOOL TermProcess( DWORD dwTargetID );
	void UpdateSingle( int i, const char *szState );
	void ServiceAction(
		DWORD dwOperation);
	HRESULT UpdateDisplay();

	// ----- Variables
	CPrivilege m_Privilege;
	CThreadPool *m_pThreadPool;
	CServiceList *m_pServices;
	char m_szComputer[256];
	int m_iCurrentComputer;
	bool m_bComputerChanged;
	bool m_bTerminateAvailable;

	// Synchronizing and cleaning up
	#ifdef _DEBUG
		DWORD m_dwMainThread;
	#endif

	vector<Info *> m_vecInfo;

public:
	HANDLE m_hThreadStop;
	CRITICAL_SECTION m_critErrors;
	vector<CString*> m_vecErrors;
};

//{{AFX_INSERT_LOCATION}}
