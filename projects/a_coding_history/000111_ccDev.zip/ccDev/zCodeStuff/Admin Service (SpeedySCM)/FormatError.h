#pragma once

TCHAR *ErrorMessage( DWORD dwError = GetLastError() );
