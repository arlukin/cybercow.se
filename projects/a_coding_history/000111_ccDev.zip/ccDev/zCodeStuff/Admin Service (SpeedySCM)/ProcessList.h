#pragma once

#include "FormatError.h"

// Process API
#pragma comment(lib, "psapi.lib")
#include "psapi.h"

// Standard Template Library
#pragma warning( disable : 4786 ) // Identifier truncated in debug info
#include <vector>
#include <string>
using namespace std;

class CProcessList  
{
public:
	BOOL FillProcessList();
	DWORD FindProcess( string sShortPath );
private:
	char *GetProcessPath( DWORD wdProcessID );
	BOOL ConvertToShortPath( char* szShortPath, char *szPath );

	vector<DWORD> m_vecID;	
	vector<string> m_vecPath;
};
