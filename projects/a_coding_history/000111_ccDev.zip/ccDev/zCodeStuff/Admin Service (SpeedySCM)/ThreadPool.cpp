#include "stdafx.h"
#include "ThreadPool.h"

// Extra debug messages
#ifdef _DEBUG
#define THREAD_POOL_DEBUG
#endif _DEBUG

struct ThreadInfo
{
	HANDLE hThread;				// Handle to the thread
	UINT ulThread;				// Thread ID
	HANDLE hWorking;			// Event to set when we're free and wait for until we run the next pFunc
	HANDLE hExit;               // Event to tell us to exit
	HANDLE hDone;				// Event to set when we're done (can be NULL)
								// Not used by ThreadPool but provided as a service.
	void (*pFunc)( void * );	// Function to run
	void *pArg;					// Argument to pass to pFunc
};

CThreadPool::
CThreadPool()
{
	#ifdef THREAD_POOL_DEBUG
		TCHAR msg[128];
		wsprintf( msg, "ThreadPool(%lx): Constructed.\n", this );
		OutputDebugString(msg);
	#endif

	InitializeCriticalSection(&m_hCrit);
	m_dwMaxThreads = 0;
}

CThreadPool::
~CThreadPool()
{
	vector<ThreadInfo*>::iterator i;

	EnterCriticalSection(&m_hCrit);

	for( i=m_vecThreads.begin(); i<m_vecThreads.end(); i++ )
		SetEvent( (*i)->hExit );

	for( i=m_vecThreads.begin(); i<m_vecThreads.end(); i++ )
	{
		#ifdef THREAD_POOL_DEBUG
			TCHAR msg[128];
			wsprintf( msg, "ThreadPool(%lx): Waiting for thread %lx.\n", 
				this, (*i)->ulThread );
			OutputDebugString(msg);
		#endif

		WaitForSingleObject( (*i)->hThread, INFINITE );
		CloseHandle( (*i)->hThread );
		delete *i;
	}
	#ifdef THREAD_POOL_DEBUG
		TCHAR msg[128];
		wsprintf( msg, "ThreadPool(%lx): All %ld threads are done.\n", 
			this, m_vecThreads.size() );
		OutputDebugString(msg);
	#endif

	LeaveCriticalSection(&m_hCrit);
	DeleteCriticalSection(&m_hCrit);
}

void 
CThreadPool::
SetMaxThreads(
	DWORD dwMaxThreads )
{
	EnterCriticalSection(&m_hCrit);
	m_dwMaxThreads = dwMaxThreads;
	LeaveCriticalSection(&m_hCrit);
}

unsigned __stdcall
CThreadPool::
TheThread( 
	void *pArg )
{
	ThreadInfo *pInfo = (ThreadInfo *) pArg;
	HANDLE pObs[] = { pInfo->hExit, pInfo->hWorking };
	DWORD dwWaitResult;

	while( true )
	{
		pInfo->pFunc( pInfo->pArg );

		if( pInfo->hDone )
			SetEvent( pInfo->hDone );

		pInfo->pFunc = NULL;

		// Tell threadpool we're free
		::ResetEvent(pInfo->hWorking);

		// Wait for next job, or exit command
		dwWaitResult = ::WaitForMultipleObjects( 2, pObs, FALSE, INFINITE );

		// If we got woken up to exit, call it a day.
		if( dwWaitResult == WAIT_OBJECT_0 )
			break;
	}
	CloseHandle( pInfo->hWorking );
	CloseHandle( pInfo->hExit );
	return 0;
}

BOOL 
CThreadPool::
ActivateThread( 
	ThreadInfo &Info, 
	void (*pFunc)( void * ), 
	void *pArg, 
	HANDLE hDone )
{
	#ifdef THREAD_POOL_DEBUG
		TCHAR msg[128];
		wsprintf( msg, "ThreadPool(%lx): Activating thread %lx.\n",
			this, Info.ulThread );
		OutputDebugString(msg);
	#endif

	Info.pFunc = pFunc;
	Info.pArg = pArg;
	Info.hDone = hDone;
	
	return SetEvent(Info.hWorking);
}

BOOL 
CThreadPool::
SpawnThread( 
	void (*pFunc)( void * ), 
	void *pArg, 
	HANDLE hDone )
{
	ThreadInfo *pInfo = new ThreadInfo;

	pInfo->hWorking = CreateEvent( NULL, TRUE, TRUE, NULL );
	pInfo->hExit =  CreateEvent( NULL, TRUE, FALSE, NULL );

	pInfo->pFunc = pFunc;
	pInfo->pArg = pArg;
	pInfo->hDone = hDone;

	pInfo->hThread = (HANDLE)_beginthreadex( NULL, NULL, TheThread, 
		pInfo, NULL, &( pInfo->ulThread ) );

	if( !pInfo->hThread )
	{
		// Failure
		#ifdef THREAD_POOL_DEBUG
			TCHAR msg[128];
			wsprintf( msg, "ThreadPool(%lx): Could not create new thread.\n",
				this);
			OutputDebugString(msg);
		#endif
		CloseHandle(pInfo->hWorking);
		CloseHandle(pInfo->hExit);
		delete pInfo;
		return FALSE;
	}

	// Success
	m_vecThreads.push_back(pInfo);
	#ifdef THREAD_POOL_DEBUG
		TCHAR msg[128];
		wsprintf( msg, "ThreadPool(%lx): Spawned thread %lx.\n",
			this, pInfo->ulThread );
		OutputDebugString(msg);
	#endif
	return TRUE;
}

BOOL 
CThreadPool::
Run( 
	void (*pFunc)( void * ), 
	void *pArg, 
	HANDLE hDone )
{	
	vector<ThreadInfo*>::iterator i;
	BOOL b;

	EnterCriticalSection(&m_hCrit);

	// Look for a free thread
	// A thread that isn't working has a reset working event.
	for( i=m_vecThreads.begin(); i<m_vecThreads.end(); i++ )
		if( WaitForSingleObject( (*i)->hWorking, 0 ) == WAIT_TIMEOUT )
			break;

	if( i!=m_vecThreads.end() )
		// Found thread, activate it
		b = ActivateThread( **i, pFunc, pArg, hDone );
	else
	{
		// No free thread, can we create one?
		if( m_dwMaxThreads && m_vecThreads.size() >= m_dwMaxThreads )
		{
			#ifdef THREAD_POOL_DEBUG
				TCHAR msg[128];
				wsprintf( msg, "ThreadPool(%lx): Run denied, max threads (%ld) reached.\n",
					this, m_dwMaxThreads );
				OutputDebugString(msg);
			#endif
			b = FALSE;
		}
		else
			b = SpawnThread( pFunc, pArg, hDone );
	}

	LeaveCriticalSection(&m_hCrit);
	return b;
}
