#pragma once

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers
#define WIN32_LEAN_AND_MEAN

#include <afxwin.h>         // MFC core and standard components
#include <afxdisp.h> // COleDateTime
#include "comdef.h" // COM support
#include "winsvc.h" // service control manager

// Standard Template Library
#pragma warning( disable : 4786 ) // Identifier truncated in debug info
#include <vector>
#include <algorithm>
#include <string>
using namespace std;

#define VOTE_WIM_KOK

//{{AFX_INSERT_LOCATION}}
