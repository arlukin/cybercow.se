#include "stdafx.h"
#include "speedyscm.h"
#include "ServiceList.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

CServiceList::
CServiceList()
{
	m_hSCM = NULL;
}

CServiceList::
~CServiceList()
{
	if( m_hSCM )
		CloseServiceHandle(m_hSCM);
}

BOOL 
CServiceList::
OpenSCM(
	char *szComputer )
{
	if( m_hSCM )
		CloseServiceHandle(m_hSCM);

	m_hSCM = OpenSCManager( szComputer, SERVICES_ACTIVE_DATABASE, SC_MANAGER_ALL_ACCESS );
	if( !m_hSCM )
	{
		TRACE( "OpenSCM: %s\n", ErrorMessage() );
		return FALSE;
	}
	return TRUE;
}

BOOL 
CServiceList::
Fill(
	char *szComputer )
{
	SC_HANDLE hService = NULL;
	unsigned char Data[8192];
	ENUM_SERVICE_STATUS *pStatus = (ENUM_SERVICE_STATUS*)Data, *pIndex;
	unsigned long i, ulBytesToGo, ulServicesReturned;
	DWORD dwResumeHandle;
	BOOL b;
	QUERY_SERVICE_CONFIG *pConfig = (QUERY_SERVICE_CONFIG*)Data;

	m_vecBinary.clear();
	m_vecName.clear();
	m_vecDisplay.clear();
	m_vecStatus.clear();

	// If we get an emptry string, replace it with
	// a NULL pointer
	if( szComputer && *szComputer == '\0' )
		szComputer = NULL;

	b = OpenSCM(szComputer);
	if( !b )
		return FALSE;

	// ===== Get list of services
	dwResumeHandle = NULL;
	ulBytesToGo = 1;
	while( ulBytesToGo )
	{
		b = EnumServicesStatus( m_hSCM, SERVICE_WIN32, SERVICE_STATE_ALL,
			pStatus, sizeof(Data), &ulBytesToGo, &ulServicesReturned,
			&dwResumeHandle );
		if( !b )
		{
			// Check for the "success-error" ERROR_MORE_DATA.
			// This is returned when the buffer is to small.
			DWORD dwErr = GetLastError();
			if( dwErr != ERROR_MORE_DATA )
			{
				TRACE("FillServiceList: EnumServicesStatus: %s\n",ErrorMessage(dwErr));
				break;
			}
		}

		pIndex = pStatus;
		for( i=0; i<ulServicesReturned; i++ )
		{
			m_vecName.push_back( pIndex->lpServiceName );
			m_vecDisplay.push_back( pIndex->lpDisplayName );
			m_vecStatus.push_back( pIndex->ServiceStatus.dwCurrentState );
			pIndex++;
		}
	}
	return TRUE;
}

const char *
CServiceList::
Name(
	int i )
{
	ASSERT( i >= 0 && i < m_vecName.size() );

	return m_vecName[i].c_str();
}

const char *
CServiceList::
DisplayName(
	int i )
{
	ASSERT( i >= 0 && i < m_vecDisplay.size() );

	return m_vecDisplay[i].c_str();
}

const char *
CServiceList::
Binary(
	int i )
{
	if( !m_vecBinary.size() && !GetBinary() )
		return NULL;

	ASSERT( i >= 0 && i < m_vecBinary.size() );

	return m_vecBinary[i].c_str();
}

DWORD 
CServiceList::
Status(
	int i )
{
	ASSERT( i >= 0 && i < m_vecStatus.size() );

	return m_vecStatus[i];
}

DWORD 
CServiceList::
Size()
{
	return m_vecName.size();
}

BOOL
CServiceList::
GetBinary()
{
	/// ===== Variables
	SC_HANDLE hService = NULL;
	unsigned char Data[8192];
	unsigned long i, ulBytesToGo;
	BOOL b;
	char szShortPath[256];
	QUERY_SERVICE_CONFIG *pConfig = (QUERY_SERVICE_CONFIG*)Data;

	for( i=0; i<m_vecName.size(); i++ )
	{
		hService = OpenService( m_hSCM, m_vecName[i].c_str(), SERVICE_QUERY_CONFIG );
		if( hService )
		{
			b = QueryServiceConfig( hService, pConfig, sizeof(Data), &ulBytesToGo );
			if( b )
			{
				// Convert to short pathname
				b = ConvertToShortPath( szShortPath, pConfig->lpBinaryPathName );
				if( b )
					m_vecBinary.push_back( szShortPath );
				else
				{
					m_vecBinary.push_back( "" );
					TRACE("GetServiceBinaries: ConvertToShortPath(%s): %s\n",
						pConfig->lpBinaryPathName, ErrorMessage());
				}
			}
			else
			{
				m_vecBinary.push_back("");
				TRACE("GetBinary: QueryServiceConfig(%s) %s\n",
					m_vecName[i].c_str(), ErrorMessage() );
			}

			CloseServiceHandle(hService);
		}
		else
		{
			m_vecBinary.push_back("");
			TRACE("GetBinary: OpenService(%s): %s\n",
				m_vecName[i].c_str(), ErrorMessage() );
		}
	}

	return TRUE;
}


BOOL
CServiceList::
ConvertToShortPath( 
	char *szShortPath, 
	char *szPath )
{
	BOOL b;
	int i, sz;

	strlwr(szPath);
	sz = strlen( szPath );
	while( true )
	{
		b = GetShortPathName( szPath, szShortPath, 256 );
		if( b )
			break;

		// Try to append .exe
		if( strcmp( szPath+sz-4, ".exe" ) )
		{
			strcat( szPath, ".exe" );
			b = GetShortPathName( szPath, szShortPath, 256 );
			if( b )
				break;
			szPath[sz] = '\0';
		}

		// Try to remove parameters
		for( i=sz; i--; )
		{
			if( szPath[i] == ' ' )
			{
				szPath[sz = i] = '\0';
				break;
			}
		}
		if(  i== -1 )
		{
			b = FALSE;
			break;
		}
	}
	if( b )
		strlwr(szShortPath);
	return b;
}
