#pragma once

class CPrivilege  
{
public:
	BOOL GodMode();
	BOOL Enable(LPCTSTR szPrivilege);
	BOOL Disable(LPCTSTR szPrivilege);
private:
	BOOL Start();
	BOOL Set( LPCTSTR Privilege, BOOL bEnablePrivilege );
	BOOL SetGroup( LPCTSTR *pszList, BOOL bEnable );
	void End();
	HANDLE m_hToken;
};
