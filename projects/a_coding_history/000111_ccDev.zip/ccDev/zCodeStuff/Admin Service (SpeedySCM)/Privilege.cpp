#include "stdafx.h"
#include "Privilege.h"
#include "FormatError.h"

// Taken from Knowledge Base article Q131065
BOOL 
CPrivilege::
Set( 
	LPCTSTR szPrivilege, 
	BOOL bEnablePrivilege )
{ 
    BOOL b;
	TOKEN_PRIVILEGES tp;
    LUID luid;
    TOKEN_PRIVILEGES tpPrevious;
    DWORD cbPrevious=sizeof(TOKEN_PRIVILEGES);

    b = LookupPrivilegeValue( NULL, szPrivilege, &luid );
	if( b )
	{
		// first pass.  get current privilege setting
		tp.PrivilegeCount           = 1;
		tp.Privileges[0].Luid       = luid;
		tp.Privileges[0].Attributes = 0;

		b = AdjustTokenPrivileges( m_hToken, FALSE, &tp, sizeof(TOKEN_PRIVILEGES),
				&tpPrevious, &cbPrevious );
		if( b )
		{
			// second pass.  set privilege based on previous setting
			tpPrevious.PrivilegeCount       = 1;
			tpPrevious.Privileges[0].Luid   = luid;

			if(bEnablePrivilege)
				tpPrevious.Privileges[0].Attributes |= (SE_PRIVILEGE_ENABLED);
			else
				tpPrevious.Privileges[0].Attributes ^= (SE_PRIVILEGE_ENABLED &
					tpPrevious.Privileges[0].Attributes);

			b = AdjustTokenPrivileges( m_hToken, FALSE, &tpPrevious, 
				cbPrevious, NULL, NULL );
			if( !b )
				TRACE("Privilege.Set: Error setting %s: %s.\n",szPrivilege,ErrorMessage());
		}
		else
			TRACE("Privilege.Set: Reading setting for %s: %s.\n",
				szPrivilege, ErrorMessage() );
	}
	else
		TRACE("Privilege.Set: LookupPrivilegeValue(%s): %s\n",
			szPrivilege, ErrorMessage() );

	return b;
} 

BOOL 
CPrivilege::
Start()
{
	BOOL b;

    b = OpenProcessToken( GetCurrentProcess(), 
		TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &m_hToken );
	if( !b )
	{
		m_hToken = NULL;
		TRACE("Privilege.Start: Error getting security token: %s.\n",ErrorMessage());
	}

	return b;
}

void
CPrivilege::
End()
{
	if( m_hToken )
		CloseHandle(m_hToken);
}

BOOL
CPrivilege::
SetGroup( LPCTSTR *pszList, BOOL bEnable )
{
	BOOL b;
	LPCTSTR *pIndex = pszList;

	b = TRUE;
	if( Start() )
	{
		while( *pIndex )
			if( ! Set( *(pIndex++), bEnable ) )
				b = FALSE;

		End();
	}
	return b;
}

BOOL 
CPrivilege::
GodMode()
{
	LPCTSTR strToDo[] =
	{
		SE_ASSIGNPRIMARYTOKEN_NAME,
		SE_AUDIT_NAME,
		SE_BACKUP_NAME,
		SE_CHANGE_NOTIFY_NAME,
		SE_CREATE_PAGEFILE_NAME,
		SE_CREATE_PERMANENT_NAME,
		SE_CREATE_TOKEN_NAME,
		SE_DEBUG_NAME,
		SE_INC_BASE_PRIORITY_NAME,
		SE_INCREASE_QUOTA_NAME, 
		SE_LOAD_DRIVER_NAME, 
		SE_LOCK_MEMORY_NAME, 
		SE_MACHINE_ACCOUNT_NAME,
		SE_PROF_SINGLE_PROCESS_NAME,
		SE_REMOTE_SHUTDOWN_NAME,
		SE_RESTORE_NAME,
		SE_SECURITY_NAME,
		SE_SHUTDOWN_NAME,
		SE_SYSTEM_ENVIRONMENT_NAME,
		SE_SYSTEM_PROFILE_NAME,
		SE_SYSTEMTIME_NAME,
		SE_TAKE_OWNERSHIP_NAME,
		SE_TCB_NAME,
		SE_UNSOLICITED_INPUT_NAME,
		NULL
	};

	return SetGroup( strToDo, true );
}

BOOL 
CPrivilege::
Enable(
	LPCTSTR szPrivilege )
{
	LPCTSTR pszTodo[] = { szPrivilege, NULL };
	return SetGroup( pszTodo, TRUE );
}

BOOL 
CPrivilege::
Disable(
	LPCTSTR szPrivilege )
{
	LPCTSTR pszTodo[] = { szPrivilege, NULL };
	return SetGroup( pszTodo, FALSE );
}
