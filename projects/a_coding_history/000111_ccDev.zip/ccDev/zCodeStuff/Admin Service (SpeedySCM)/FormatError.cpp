#include "stdafx.h"
#include "FormatError.h"

// Remove traling '.' '\n' '\r' characters.
void 
BeautifyString(
	TCHAR* data )
{
	int sz;
	while( (sz = _tcslen(data)) && (
		data[sz-1]==_T('\n') || data[sz-1]==_T('\r') || data[sz-1]==_T('.') ) )
	{
		data[sz-1] = '\0';
	}
}

// Translate a GetLastError() style code into
// an error string.  Ought to be thread safe
// thanks to TLS (thread local storage.)
TCHAR *
ErrorMessage(
	DWORD dwError )
{
	__declspec(thread) static TCHAR data[256];
	
    ::FormatMessage( 
        FORMAT_MESSAGE_FROM_SYSTEM | 
        FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL,
        dwError,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
        data,
        256,
        NULL 
    );
	BeautifyString(data);
    return data;;
}
