#pragma once

#include "FormatError.h"

class CServiceList
{
public:
	CServiceList();
	virtual ~CServiceList();

	BOOL Fill(char *szComputer = NULL);
	const char *Name(int i);
	const char *DisplayName(int i);
	const char *Binary(int i);
	DWORD Status(int i);
	DWORD Size();

private:
	BOOL OpenSCM(char *szComputer);
	BOOL GetBinary();
	BOOL ConvertToShortPath( char *szShortPath, char *szPath );

	vector<string> m_vecBinary;
	vector<string> m_vecName;
	vector<DWORD> m_vecStatus;
	vector<string> m_vecDisplay;
	SC_HANDLE m_hSCM;
};
