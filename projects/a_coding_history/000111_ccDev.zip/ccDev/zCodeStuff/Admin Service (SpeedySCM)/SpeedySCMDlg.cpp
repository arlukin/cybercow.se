#include "stdafx.h"
#include "SpeedySCMDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Enable extra debug mesages
#ifdef _DEBUG
#define SPEEDYSCMDLG_DEBUG
#endif

// To check if we're in the thread we think we are in
#define ENSURE_MAIN_THREAD() ASSERT(GetCurrentThreadId() == m_dwMainThread)

// User messages send to dialog window.
// This is used to ensure the window is only
// updated by the main thread.
#define WM_USER_THREAD_FINISHED		WM_USER + 3
#define WM_USER_ERROR				WM_USER + 4

#define SYSCMD_ABOUT 0xDAF0  // System range

// Not an API constant (starting a service and
// controlling a service are different calls.)
#define SERVICE_CONTROL_START 0

// Error updating service
#define SERVICE_FUBAR -1

// This structure contains the data for the Control and Update threads
struct Info
{
	// For performing action
	char *szServiceName;
	char *szServiceDisplay;
	DWORD dwControlCode;
	char *szComputer;
	SC_HANDLE hSCM;
	SC_HANDLE hService;

	// For performing callback
	bool bError;
	bool bBeenPending;
	int iComputer;
	DWORD dwStatus;
	int iUpdateCount;
	CSpeedySCMDlg *pDlg;
};

// [Threadsafe]
// Helper functions
const TCHAR *
CSpeedySCMDlg::
StatusMessage(
	DWORD dwState )
{
	switch( dwState )
	{
		case SERVICE_FUBAR: return _T("*Error*");
		case SERVICE_STOPPED: return _T("Stopped");
		case SERVICE_START_PENDING: return _T("StartPending");
		case SERVICE_STOP_PENDING: return _T("StopPending");
		case SERVICE_RUNNING: return _T("Running");
		case SERVICE_CONTINUE_PENDING: return _T("ContinuePending");
		case SERVICE_PAUSE_PENDING: return _T("PausePending");
		case SERVICE_PAUSED : return _T("Paused");
		default : ASSERT(true); return _T("*Unknown*");
	}
}

const TCHAR *
CSpeedySCMDlg::
ControlMessage(
	DWORD dwState )
{
	switch( dwState )
	{
		case SERVICE_CONTROL_START: return _T("Starting");
		case SERVICE_CONTROL_STOP: return _T("Stopping");
		case SERVICE_CONTROL_CONTINUE: return _T("Continuing");
		case SERVICE_CONTROL_PAUSE: return _T("Pausing");
		default : ASSERT(true); return _T("?Controlling?");
	}
}

DWORD CSpeedySCMDlg::
TargetCode(
	DWORD dwState )
{
	switch( dwState )
	{
		case SERVICE_CONTROL_STOP: return SERVICE_STOPPED;
		case SERVICE_CONTROL_CONTINUE: return SERVICE_RUNNING;
		case SERVICE_CONTROL_PAUSE: return SERVICE_PAUSED;
		case SERVICE_CONTROL_START: return SERVICE_RUNNING;
		default: ASSERT(true); return -1;
	}
}

bool 
CSpeedySCMDlg::
IsPending(
	DWORD dwState )
{
	switch( dwState )
	{
		case SERVICE_START_PENDING:
		case SERVICE_STOP_PENDING:
		case SERVICE_CONTINUE_PENDING: 
		case SERVICE_PAUSE_PENDING:
			return true;
		default: 
			return false;
	}
}

CSpeedySCMDlg::
CSpeedySCMDlg(
	CWnd* pParent /*=NULL*/)
	: CDialog(CSpeedySCMDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSpeedySCMDlg)
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

CSpeedySCMDlg::
~CSpeedySCMDlg()
{
}

void 
CSpeedySCMDlg::
DoDataExchange(
	CDataExchange* pDX )
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSpeedySCMDlg)
	DDX_Control(pDX, IDTERMINATE, m_ctrlTerminate);
	DDX_Control(pDX, IDC_ERRORS, m_ctrlErrors);
	DDX_Control(pDX, IDPAUSE, m_ctrlPause);
	DDX_Control(pDX, IDCONTINUE, m_ctrlContinue);
	DDX_Control(pDX, IDSTART, m_ctrlStop);
	DDX_Control(pDX, IDSTOP, m_ctrlStart);
	DDX_Control(pDX, IDC_COMPUTER, m_ctrlComputer);
	DDX_Control(pDX, IDC_LIST, m_ctrlList);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSpeedySCMDlg, CDialog)
    ON_MESSAGE(WM_USER_THREAD_FINISHED, OnThreadFinished)
    ON_MESSAGE(WM_USER_ERROR, OnError)
	ON_WM_SYSCOMMAND() 
	ON_BN_CLICKED(IDABOUT, OnAbout)
	ON_BN_CLICKED(IDHELP, OnHelp)
	//{{AFX_MSG_MAP(CSpeedySCMDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDSTART, 
	)
	ON_BN_CLICKED(IDSTOP, OnStop)
	ON_BN_CLICKED(IDUPDATE, OnUpdate)
	ON_EN_CHANGE(IDC_COMPUTER, OnChangeComputer)
	ON_BN_CLICKED(IDTERMINATE, OnTerminate)
	ON_BN_CLICKED(IDPAUSE, OnPause)
	ON_BN_CLICKED(IDCONTINUE, OnContinue)
	ON_BN_CLICKED(IDFORGET, OnForget)
	ON_LBN_SELCHANGE(IDC_LIST, OnSelchangeList)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL 
CSpeedySCMDlg::
OnInitDialog()
{
	RECT r;
	int w;
	CMenu *pMenu;

	// Disable the "Maximize" and "Resize" options,
	// and add an About box.
	pMenu = GetSystemMenu(FALSE);
	pMenu->EnableMenuItem( SC_MAXIMIZE, MF_BYCOMMAND | MF_GRAYED );
	pMenu->EnableMenuItem( SC_SIZE, MF_BYCOMMAND | MF_GRAYED );
	pMenu->AppendMenu( NULL, SYSCMD_ABOUT, "&About" );

	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// Grab a threadpool
	m_pThreadPool = new CThreadPool;
	
	// Initialize the listbox
	m_ctrlList.SetTabStops(48);
	m_ctrlList.GetWindowRect(&r);
	w = r.right-r.left-4;  // -4 for the borders
	m_ctrlList.SetColumnWidth(w/2);

	// Enable this for horizontal scrolling in the error list.
	// Personally, I think the scrolbar takes up too much space.
	// m_ctrlErrors.SetHorizontalExtent(2*w);

	// First computer
	m_iCurrentComputer = 0;
	m_bComputerChanged = true;

	// Check if we can get SE_DEBUG_NAME.
	m_bTerminateAvailable = m_Privilege.Enable(SE_DEBUG_NAME) ? true : false;
	if( m_bTerminateAvailable )
		m_Privilege.Disable(SE_DEBUG_NAME);

	// For debugging
	#if _DEBUG
		m_dwMainThread = GetCurrentThreadId();
	#endif
	#ifdef SPEEDYSCMDLG_DEBUG
		TRACE("Main thread is %lx.\n",GetCurrentThreadId());
	#endif

	// To make all threads exit when we quit
	m_hThreadStop = CreateEvent( NULL, TRUE, FALSE, NULL );

	// Critical section used to protect m_vecErrors
	InitializeCriticalSection(&m_critErrors);

	// Fill the listbox
	m_pServices = NULL;
	OnUpdate();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// Message handler
void 
CSpeedySCMDlg::
OnSysCommand(
	UINT nID,
	LPARAM lParam )
{
	if( (nID & 0xFFF0) == SYSCMD_ABOUT )
		OnAbout();
	else
		CWnd::OnSysCommand(nID,lParam);
}

// Message handler
void 
CSpeedySCMDlg::
OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// Message handler
HCURSOR 
CSpeedySCMDlg::
OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

// [Threadsafe]
// Allocate and format error message
CString *
CSpeedySCMDlg::
NewError( 
	const char *szAction, 
	const char *szService,
	const char *szComputer, 
	const char *szMsg )
{
	CString *psError;

	if( szMsg == NULL )
		szMsg = ErrorMessage();

	psError = new CString;

	if( szComputer && strlen(szComputer) )
		psError->Format( "%s \"%s\" on \"%s\": %s.", 
			szAction, szService, szComputer, szMsg );
	else
		psError->Format( "%s \"%s\": %s.", 
			szAction, szService, szMsg );

	return psError;
}

// [Threadsafe]
// Allocate, format, and post WM_USER_ERROR
void 
CSpeedySCMDlg::
SendError( 
	Info *pInfo, 
	const char *szAction, 
	const char *szMsg )
{
	CSpeedySCMDlg *pDlg = pInfo->pDlg;

	if( !szAction )
		szAction = ControlMessage(pInfo->dwControlCode);

	CString *psError = NewError( szAction, pInfo->szServiceDisplay,
		pInfo->szComputer, szMsg );

	// Just need to guard m_vecErrors integrity;
	// deleting will be done when all threads
	// are finished.
	EnterCriticalSection(&pDlg->m_critErrors);
	pDlg->m_vecErrors.push_back(psError);
	LeaveCriticalSection(&pDlg->m_critErrors);

	pInfo->bError = true;
	pDlg->PostMessage( WM_USER_ERROR, (LPARAM)psError, NULL );
}

// Allocate, format, and immediately display a message
void 
CSpeedySCMDlg::
SendError( 
	const char *szAction, 
	const char *szService, 
	const char *szMsg )
{
	ENSURE_MAIN_THREAD();

	CString *psError = NewError( szAction, szService, m_szComputer, szMsg );

	UpdateError(*psError);

	delete psError;
}

// Add error message to the listbox
void
CSpeedySCMDlg::
UpdateError( CString strWhat )
{
	int sz;
	COleDateTime d;
	CString sPrefix, sMessage;

	ENSURE_MAIN_THREAD();
	m_ctrlErrors.SendMessage( WM_SETREDRAW, FALSE, 0 );

	while(true)
	{
		sz = m_ctrlErrors.GetCount();
		if( sz <= 15 )
			break;
		m_ctrlErrors.DeleteString(0);
	}

	d = COleDateTime::GetCurrentTime();
	sPrefix = d.Format("%H:%M:%S");
	sMessage.Format("%s %s",(LPCTSTR)sPrefix,(LPCTSTR)strWhat);

	m_ctrlErrors.AddString((LPCTSTR)sMessage);
	m_ctrlErrors.SetCurSel(sz);
	m_ctrlErrors.SetCaretIndex(sz,FALSE);

	m_ctrlErrors.SendMessage( WM_SETREDRAW, TRUE, 0 );
}

// WM_USER_ERROR message handler
void 
CSpeedySCMDlg::
OnError(
	WPARAM p1, 
	LPARAM p2 )
{
	CString *psWhat = (CString *)p1;

	UpdateError(*psWhat);

	vector<CString*>::iterator i;
	EnterCriticalSection(&m_critErrors);
	i = find( m_vecErrors.begin(), m_vecErrors.end(), psWhat );
	if( i != m_vecErrors.end() )
		m_vecErrors.erase(i);
	else
		TRACE("OnError: Coulndn't find %p.\n", psWhat );

	LeaveCriticalSection(&m_critErrors);

	delete psWhat;
}

// Message handler
void 
CSpeedySCMDlg::
OnForget() 
{
	m_ctrlErrors.SendMessage( WM_SETREDRAW, FALSE, 0 );
	m_ctrlErrors.ResetContent();
	m_ctrlErrors.SendMessage( WM_SETREDRAW, TRUE, 0 );
}

// Open and terminate a process
BOOL 
CSpeedySCMDlg::
TermProcess( 
	DWORD dwProcess )
{
	CString msg;
	BOOL b;
	HANDLE hProcess;

	ENSURE_MAIN_THREAD();

	b = m_Privilege.Enable(SE_DEBUG_NAME);
	if( b )
	{
		hProcess = OpenProcess( PROCESS_TERMINATE, FALSE, dwProcess );
		if( hProcess != NULL )
		{
			// Terminate the process.
			b = ::TerminateProcess(hProcess,1);
			if( !b )
				TRACE("TermProcess: TerminatingProcess(%ld): %s.\n", 
					dwProcess, ErrorMessage() );

			CloseHandle( hProcess );
		}
		else
		{
			b = FALSE;
			TRACE("TermProcess: OpenProcess(%ld): %s.\n", 
				dwProcess, ErrorMessage() );
		}
	}
	else
		TRACE("TermProcess: Enable debug privilege: %s.\n", 
			ErrorMessage() );

	m_Privilege.Disable(SE_DEBUG_NAME);
	return b;
}

// [Thread Function]
// Clear a servicelist.  This does a CloseServiceHandle which
// might easily block over a network.
void
CSpeedySCMDlg::
ClearServicesThread( 
	LPVOID par )
{
	CServiceList *pList = (CServiceList *) par;
	delete pList;
}

// [Thead Function]
// Clear an info block.  This again might block on the
// CloseServiceHandle call.
void 
CSpeedySCMDlg::
ClearThread( 
	LPVOID par )
{
	Info *pInfo = (Info*) par;

	#ifdef SPEEDYSCMDLG_DEBUG
		CString msg;
		msg.Format("ClearThread: Now clearing %p.\n",pInfo);		
		OutputDebugString(msg);
	#endif

	if( pInfo->hSCM )
	{
		CloseServiceHandle(pInfo->hSCM);
		pInfo->hSCM = NULL;
	}
	if( pInfo->hService )
	{
		CloseServiceHandle(pInfo->hService);
		pInfo->hService = NULL;
	}
	delete pInfo->szServiceName;
	pInfo->szServiceName = NULL;
	delete pInfo->szServiceDisplay;
	pInfo->szServiceDisplay = NULL;
	delete pInfo->szComputer;
	pInfo->szComputer = NULL;

	delete pInfo;
	pInfo = NULL;
}

// Clear an info block. Synchronous needed to ensure
// all threads are done before our window is destroyed
// (threads might report back with a WM_USER_...)
void 
CSpeedySCMDlg::
ClearInfo( 
	Info *pInfo )
{
	BOOL b;

	ENSURE_MAIN_THREAD();

	// Remove from the list
	vector<Info*>::iterator i;
	i = find( m_vecInfo.begin(), m_vecInfo.end(), pInfo );
	if( i == m_vecInfo.end() )
		TRACE("Clearinfo: Couldn't find pInfo\n");
	else
	{
		m_vecInfo.erase(i);

		// Spawn a thread to clear it
		b = m_pThreadPool->Run( ClearThread, pInfo );
		if( !b )
			TRACE("Couldn't run ClearThread\n");
	}
}

// [Thread Function]
// Wait for a number of seconds, then query service status
// and report back with a WM_USER_THREADFINISHED
void 
CSpeedySCMDlg::
UpdateThread( 
	LPVOID par )
{
	Info *pInfo = (Info *)par;
	BOOL b = false;;
	SERVICE_STATUS ServiceStatus = { 0, 0, 0, 0, 0, 0 };
	DWORD dwWaitTime = 0, dwWaitResult;	

	if( pInfo->iUpdateCount < 2 )
		dwWaitTime = 500;
	else if( pInfo->iUpdateCount < 4 )
		dwWaitTime = 1000;
	else if( pInfo->iUpdateCount < 8 )
		dwWaitTime = 2000;
	else if( pInfo->iUpdateCount < 16 )
		dwWaitTime = 4000;
	else if( pInfo->iUpdateCount < 32 )
		dwWaitTime = 8000;
	else
		dwWaitTime = 16000;
	
	dwWaitResult = WaitForSingleObject( pInfo->pDlg->m_hThreadStop, dwWaitTime );
	if( dwWaitResult != WAIT_TIMEOUT )
	{
		CString msg;
		msg.Format("UpdateThread: Thread %lx abandoned wait.\n",GetCurrentThreadId());		
		OutputDebugString(msg);
	}
	
	// Query status for callback
	b = QueryServiceStatus( pInfo->hService, &ServiceStatus );
	if( !b )
	{
		pInfo->dwStatus = SERVICE_FUBAR;
		SendError( pInfo, "Updating status for" );
		pInfo->pDlg->PostMessage( WM_USER_THREAD_FINISHED, (LPARAM)pInfo, 3 );
	}
	else
	{
		pInfo->dwStatus = ServiceStatus.dwCurrentState;
		pInfo->pDlg->PostMessage( WM_USER_THREAD_FINISHED, (LPARAM)pInfo, 0 );
	}
}

// [Thread Function]
// Open and send call a control function for a specific
// service. Report back with a WM_USER_THREADFINISHED.
void 
CSpeedySCMDlg::
ControlThread( 
	LPVOID par )
{
	Info *pInfo = (Info *)par;
	BOOL b = false;
	SERVICE_STATUS ServiceStatus = { 0, 0, 0, 0, 0, 0 };
	
	pInfo->hSCM = OpenSCManager( pInfo->szComputer, 
		SERVICES_ACTIVE_DATABASE, SC_MANAGER_ALL_ACCESS );
	if( !pInfo->hSCM )
	{
		SendError( pInfo, "Opening SCM for" );
		pInfo->pDlg->PostMessage( WM_USER_THREAD_FINISHED, (LPARAM)pInfo, -2 );
	}
	else
	{
		pInfo->hService = OpenService( pInfo->hSCM, 
			pInfo->szServiceName, SERVICE_ALL_ACCESS );
		if( !pInfo->hService )
		{
			SendError(pInfo,"Opening SCM for");
			pInfo->pDlg->PostMessage( WM_USER_THREAD_FINISHED, (LPARAM)pInfo, -1 );
		}
		else
		{
			if( pInfo->dwControlCode )
			{
				b = ControlService( pInfo->hService, 
					pInfo->dwControlCode, &ServiceStatus );
				if( !b )
					SendError(pInfo);
			}
			else
			{
				b = StartService( pInfo->hService, 0, NULL );
				if( !b )
					SendError(pInfo);
			}

			// Query status for callback
			b = QueryServiceStatus( pInfo->hService, &ServiceStatus );
			if( !b )
			{
				pInfo->dwStatus = SERVICE_FUBAR;
				SendError( pInfo, "Querying" );
			}
			else
				pInfo->dwStatus = ServiceStatus.dwCurrentState;

			pInfo->pDlg->PostMessage( WM_USER_THREAD_FINISHED, (LPARAM)pInfo, 0 );
		}
	}
}

// Helper function to decide wether to handle requests
// for update threads.
BOOL 
CSpeedySCMDlg::
SpawnUpdateThread( 
	Info* pInfo )
{
	int i, sz;
	BOOL b;

	ENSURE_MAIN_THREAD();

	// Check if this is the most recent update thread for
	// this service
	sz = m_vecInfo.size();
	for( i=sz; i--; )
	{
		if( pInfo == m_vecInfo[i] )
			break;
		else if( !strcmp( pInfo->szServiceName, m_vecInfo[i]->szServiceName ) )
		{
			TRACE("SpawnUpdateThread: Disbanded old thread for %s\n",pInfo->szServiceDisplay);
			return FALSE;
		}
	}

	// Continuous update needed?
	pInfo->iUpdateCount++;
	if( pInfo->bError )
		TRACE("OnThreadFinished: Stopping refresh for %s because of error.\n",
			pInfo->szServiceDisplay );
	else if( pInfo->iUpdateCount > 32 )
		SendError( pInfo, NULL, "Timed out, automatic refresh stopped" );
	else
	{
		if( pInfo->dwStatus == TargetCode(pInfo->dwControlCode) )
			#ifdef SPEEDYSCMDLG_DEBUG
				TRACE("SpawnUpdateThread: Target reached, count %ld for %s\n",
					pInfo->iUpdateCount, pInfo->szServiceName );
			#else
				;
			#endif
		else if( pInfo->bBeenPending && !IsPending(pInfo->dwStatus) )
		{
			CString msg;
			msg.Format( "Final service status is %s instead of %s",
				StatusMessage(pInfo->dwStatus),
				StatusMessage(TargetCode(pInfo->dwControlCode)) );
			SendError( pInfo, NULL, msg );
		}
		else
		{
			#ifdef SPEEDYSCMDLG_DEBUG
				TRACE("Continuing update %ld for %s\n", pInfo->iUpdateCount,
					pInfo->szServiceDisplay );
			#endif
			if( IsPending(pInfo->dwStatus) )
				pInfo->bBeenPending = true;
			if( pInfo->iUpdateCount == 6 )
				SendError( ControlMessage(pInfo->dwControlCode),
					pInfo->szServiceDisplay,
					"Service takes very long to respond" );

			// Spawn new thread
			b = m_pThreadPool->Run( UpdateThread, pInfo );

			if( b )
				return TRUE;
			else
				SendError( pInfo, "Creatng update thread for" );
		}
	}
	return FALSE;
}

// Message handler: WM_USER_THREADFINISHED
void 
CSpeedySCMDlg::
OnThreadFinished( 
	WPARAM p1, 
	LPARAM p2 )
{
	Info *pInfo = (Info *)p1;
	long code = p2;
	int i, sz;
	BOOL bDontFree = FALSE;

	ENSURE_MAIN_THREAD();

	// Are we in the same computer
	if( pInfo->iComputer != m_iCurrentComputer )
	{
		TRACE("OnThreadFinished: Obsolete update for %s\n",pInfo->szServiceDisplay);
	}
	else
	{
		sz = m_pServices->Size();
		for( i=0; i<sz; i++ )
		{
			if( !strcmp( m_pServices->Name(i), pInfo->szServiceName ) )
			{
				UpdateSingle( i, StatusMessage( pInfo->dwStatus ) );
				bDontFree = SpawnUpdateThread(pInfo);
				break;
			}
		}

		if( i==sz )
			TRACE("OnThreadFinished: Couldn't find %s\n",pInfo->szServiceDisplay);
	}
	if( !bDontFree )
		ClearInfo(pInfo);
}

// Helper function to create a new Info structure
// and pass it to a control thread
void 
CSpeedySCMDlg::
SpawnControlThread( 
	const char *szServiceName, 
	const char *szServiceDisplay, 
	DWORD dwControlCode )
{
	Info *pInfo;
	BOOL b;
	int iCount;
	vector<Info*>::iterator i;
	
	ENSURE_MAIN_THREAD();

	// Count current control threads.
	// This counts update threads too, but since they are discared
	// if there's more than one, that doesn't really matter.
	iCount = 0;
	for( i=m_vecInfo.begin(); i<m_vecInfo.end(); i++ )
		if( !strcmp( (*i)->szServiceName, szServiceName )  )
			iCount++;

	if( iCount > 2 )
	{
		CString msg;
		msg.Format( "Already %i operations queued; this one cancelled",
			iCount );
		SendError( ControlMessage(dwControlCode), szServiceDisplay, msg );
		return;
	}

	pInfo = new Info;
	pInfo->szServiceName = new char[strlen(szServiceName)+1];
	strcpy(pInfo->szServiceName,szServiceName);
	pInfo->szServiceDisplay = new char[strlen(szServiceDisplay)+1];
	strcpy(pInfo->szServiceDisplay,szServiceDisplay);
	pInfo->dwControlCode = dwControlCode;
	pInfo->szComputer = new char[strlen(m_szComputer)+1];
	strcpy(pInfo->szComputer,m_szComputer);
	pInfo->iComputer = m_iCurrentComputer;
	pInfo->pDlg = this;
	pInfo->iUpdateCount = 0;
	pInfo->hSCM = NULL;
	pInfo->hService = NULL;
	pInfo->bError = false;
	pInfo->bBeenPending = false;
	m_vecInfo.push_back(pInfo);

	b = m_pThreadPool->Run( ControlThread, pInfo, NULL );
	if( !b )
	{
		SendError( pInfo, "Creatng control thread for" );
		ClearInfo(pInfo);
	}
}

// Update a single entry in the list of services
void 
CSpeedySCMDlg::
UpdateSingle( 
	int i, 
	const char *szState )
{
	BOOL bSel;
	int iCar;
	CString msg, old;

	ENSURE_MAIN_THREAD();

	msg.Format( _T("%s\t%s"), szState, m_pServices->DisplayName(i) );
	m_ctrlList.GetText( i, old );
	if( old == msg )
		return;

	m_ctrlList.SendMessage( WM_SETREDRAW, FALSE, 0 );

	// Store selected attribute
	bSel = m_ctrlList.GetSel(i) ? true : false;
	// Remember caret in case we fark up
	if( bSel )
		iCar = m_ctrlList.GetCaretIndex();

	m_ctrlList.DeleteString(i);
	m_ctrlList.InsertString(i,msg);
	if( bSel )
	{
		// This also sets the caret
		m_ctrlList.SetSel(i,TRUE);
		// So we reset the caret
		if( i != iCar && iCar >=0 && iCar < m_ctrlList.GetCount() )
			m_ctrlList.SetCaretIndex(iCar,FALSE);
	}

	m_ctrlList.SendMessage( WM_SETREDRAW, TRUE, 0 );
}

// Message handler for the Refresh button
// Update all entries in the list of services
HRESULT 
CSpeedySCMDlg::
UpdateDisplay()
{
	unsigned long i, sz, j, sz2;
	vector<string> vecSelection;
	string strCaret;
	BOOL b;
	int *selected, car;

	ENSURE_MAIN_THREAD();
	m_ctrlComputer.GetLine( 0, m_szComputer, 256 );

	CWaitCursor w;
	m_ctrlList.SendMessage( WM_SETREDRAW, FALSE, 0 );
	
	// Try to preserve selection
	if( !m_bComputerChanged )
	{
		sz = m_ctrlList.GetSelCount();
		if( sz )
		{
			selected = new int[sz];
			m_ctrlList.GetSelItems( sz, selected );
			for( i=0; i<sz; i++ )
				vecSelection.push_back( m_pServices->DisplayName(selected[i]) );

			delete selected;
		}
		car = m_ctrlList.GetCaretIndex();
		if( car >= 0 && car < m_ctrlList.GetCount() )
			strCaret = m_pServices->DisplayName(car);

		sz2 = vecSelection.size();
		ASSERT( sz == sz2 );
	}
	else
		sz2 = 0;

	// Async refresh, because CloseSCMHandle can cause
	// long delays
	if( m_pServices )
		m_pThreadPool->Run( ClearServicesThread, m_pServices );
	m_pServices = new CServiceList;

	b = m_pServices->Fill(m_szComputer);
	if( !b )
	{
		CString msg;
		if( m_szComputer && *m_szComputer )
			msg.Format( "Could not contact the Service Control Manager on \"%s\": %s.",
				m_szComputer, ErrorMessage() );
		else
			msg.Format( "Could not contact the Service Control Manager: %s.", 
				ErrorMessage() );

		AfxMessageBox( msg.GetBuffer(0), MB_ICONEXCLAMATION );
	}

	if( m_bComputerChanged )
		m_bComputerChanged = false;

	m_ctrlList.ResetContent();
	sz = m_pServices->Size();
	for( i=0; i < sz; i++ )
	{
		CString msg;
		msg.Format( _T("%s\t%s"), 
			StatusMessage( m_pServices->Status(i) ),
			m_pServices->DisplayName(i) );
		m_ctrlList.AddString(msg);

		for( j=0; j<sz2; j++ )
			if( string(m_pServices->DisplayName(i)) == vecSelection[j] )
				break;

		if( j!=sz2 )
			m_ctrlList.SetSel(i,TRUE);

		if( strCaret == string(m_pServices->DisplayName(i)) )
			car = i;
	}
	m_ctrlList.SetCaretIndex(car,TRUE);
	m_ctrlList.SendMessage( WM_SETREDRAW, TRUE, 0 );
	ToggleButtons();

	return S_OK;
}

// Helper functions for the start/stop/pause/continue buttons
void 
CSpeedySCMDlg::
ServiceAction(
	DWORD dwOperation) 
{
	/// ===== Variables
	int i, sz, *selected;

	ENSURE_MAIN_THREAD();

	// ===== Cycle selected entries
	sz = m_ctrlList.GetSelCount();
	ASSERT(sz);

	selected = new int[sz];
	m_ctrlList.GetSelItems( sz, selected );
	for( i=0; i<sz; i++ )
		SpawnControlThread( m_pServices->Name(selected[i]),
			m_pServices->DisplayName(selected[i]), dwOperation );

	delete selected;
}

// Message handlers for start/stop/pause/continue
void 
CSpeedySCMDlg::
OnStart() 
{
	ServiceAction(SERVICE_CONTROL_START);
}

void 
CSpeedySCMDlg::
OnStop() 
{
	ServiceAction(SERVICE_CONTROL_STOP);
}

void 
CSpeedySCMDlg::
OnPause() 
{
	ServiceAction(SERVICE_CONTROL_PAUSE);
}


void 
CSpeedySCMDlg::
OnContinue() 
{
	ServiceAction(SERVICE_CONTROL_CONTINUE);
}

void 
CSpeedySCMDlg::
OnUpdate() 
{
	UpdateDisplay();
}

// Enable/disable buttons depending on selection
// and the availability of SE_DEBUG_NAME.
void 
CSpeedySCMDlg::
ToggleButtons()
{
	BOOL bAction, bTerminate;
	if( m_bComputerChanged || !m_ctrlList.GetSelCount() )
		bAction = bTerminate = FALSE;
	else
	{
		bAction = TRUE;
		bTerminate = m_bTerminateAvailable && !strlen(m_szComputer);
	}
	m_ctrlStart.EnableWindow(bAction);
	m_ctrlStop.EnableWindow(bAction);
	m_ctrlPause.EnableWindow(bAction);
	m_ctrlContinue.EnableWindow(bAction);
	m_ctrlTerminate.EnableWindow(bTerminate);
}

// Terminate message handler
void 
CSpeedySCMDlg::
OnTerminate() 
{
	/// ===== Variables
	int i, sz, *selected, iAsk;
	BOOL b;
	DWORD dwID;
	CProcessList Procs;;
	char szSystem[256], szSCM[256];
	CString msg;

	ENSURE_MAIN_THREAD();

	// ===== Terminate API availble on local PC only
	ASSERT( !m_szComputer || !*m_szComputer );

	// ===== Cycle selected entries
	sz = m_ctrlList.GetSelCount();
	ASSERT( sz );

	b = Procs.FillProcessList();
	if( b )
	{
		selected = new int[sz];
		m_ctrlList.GetSelItems( sz, selected );

		GetSystemDirectory(szSystem,256);
		strcpy(szSCM,szSystem);
		strcat(szSCM,"\\services.exe");

		for( i=0; i<sz; i++ )
		{
			dwID = Procs.FindProcess( m_pServices->Binary(selected[i]) );
			if( dwID != -1 )
			{
				if( !stricmp( m_pServices->Binary(selected[i]), szSCM  ) )
				{
					msg.Format( "Service \"%s\" has filename:\n\n"
						"\"%s\"\n\n"
						"This indicates the NT Service Controller.\n"
						"Terminating it will currupt the system.",
						m_pServices->DisplayName(selected[i]),
						m_pServices->Binary(selected[i]) );
					iAsk = AfxMessageBox( msg.GetBuffer(0), MB_ICONSTOP | MB_YESNO );
				}
				else if( !strnicmp( m_pServices->Binary(selected[i]), szSystem, strlen(szSystem) ) )
				{
					msg.Format( "Service \"%s\" has filename:\n\n"
						"\"%s\"\n\n"
						"This indicates an NT System Service.\n"
						"Terminating it might currupt the system.",
						m_pServices->DisplayName(selected[i]),
						m_pServices->Binary(selected[i]) );
					iAsk = AfxMessageBox( msg.GetBuffer(0), MB_ICONEXCLAMATION | MB_YESNO );
				}
				else 
					iAsk = IDYES;

				if( iAsk == IDYES )
				{
					b = TermProcess( dwID );

					if( b )
						UpdateSingle( selected[i], "Killed" );
					else
						SendError( "Terminating", m_pServices->DisplayName(selected[i]) );
				}
			}
			else
			{
				CString err;
				err.Format("No process found with filename \"%s\"",
					m_pServices->Binary(selected[i]) );
				SendError( "Terminating", m_pServices->DisplayName(selected[i]), err );
			}
		}

		delete selected;
	}
	else
	{
		CString msg;
		msg.Format( "Couldn't read process information: %s",
			ErrorMessage() );
		AfxMessageBox( msg.GetBuffer(0), MB_ICONEXCLAMATION );
	}
}

// User typed in the computer box.
// Don't update untill he presses "refresh"
// but take note that the computer is no longer
// accurate.
void 
CSpeedySCMDlg::
OnChangeComputer() 
{
	m_iCurrentComputer++;
	m_bComputerChanged = true;
}

void 
CSpeedySCMDlg::
OnSelchangeList() 
{
	ToggleButtons();
}

// This is were we clear up the remaining threads,
// error messages, info blocks, and member variables.
// The window will still exist so rampant threads
// can send messages.  However, they won't be
// processed because from now on we take the single
// GUI thread to its end,
BOOL 
CSpeedySCMDlg::
DestroyWindow() 
{
	vector<Info*>::iterator i;
	vector<CString*>::iterator j;

	#ifdef SPEEDYSCMDLG_DEBUG
		TRACE("DestroyWindow.\n");
	#endif

	// ===== Ask threads to return to the pool
	SetEvent( m_hThreadStop );
	
	// ===== Delete pool 
	// (won't return until all threads are done.)
	delete m_pThreadPool;
	m_pThreadPool = NULL;

	// ===== Tidy up memory

	// ----- WM_USER_THREAD_FINISHED Info pointers
	#ifdef SPEEDYSCMDLG_DEBUG
		TRACE("Clearing %ld info blocks.\n",m_vecInfo.size());
	#endif
	// Reverse order required -- vector is shrinking!
	// If needed, end()-1 is invalid on an empty vector
	if( m_vecInfo.size() )
		for( i=m_vecInfo.end()-1; i>=m_vecInfo.begin(); i-- )
		{
			ClearThread(*i);
			m_vecInfo.erase(i);
		}

	// ----- WM_USER_ERROR CString pointers
	#ifdef SPEEDYSCMDLG_DEBUG
		TRACE("Clearing %ld errors.\n",m_vecErrors.size());
	#endif
	// Reverse order required -- vector is shrinking!
	// If needed, end()-1 is invalid on an empty vector
	if( m_vecErrors.size() )
		for( j=m_vecErrors.end()-1; j>=m_vecErrors.begin(); j-- )
		{
			delete *j;
			m_vecErrors.erase(j);
		}

	// ----- Own allocated memory blocks
	delete m_pServices;
	CloseHandle(m_hThreadStop);
	DeleteCriticalSection(&m_critErrors);

	// Close the thread pool for ClearInfo
	delete m_pThreadPool;

	return CDialog::DestroyWindow();
}

void 
CSpeedySCMDlg::
OnAbout() 
{
	AfxMessageBox(
"SpeedySCM -- Fast, Easy & Remote Service Control for Windows NT.\n"
"Copyright (C)1999 by Wessel Troost <wtroost@dds.nl>.\n"
"\n"
"This program is free software; you can redistribute it and/or\n"
"modify it under the terms of the GNU General Public License\n"
"as published by the Free Software Foundation; either version 2\n"
"of the License, or (at your option) any later version.\n"
"\n"
"This program is distributed in the hope that it will be useful,\n"
"but WITHOUT ANY WARRANTY; without even the implied warranty of\n"
"MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n"
"GNU General Public License for more details.\n"
"\n"
"You should have received a copy of the GNU General Public License\n"
"along with this program; if not, write to the Free Software\n"
"Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.\n"
"Or visit http://www.gnu.org/copyleft/gpl.html.\n",
	MB_ICONINFORMATION );
}

void 
CSpeedySCMDlg::
OnHelp() 
{
	AfxMessageBox(
"SpeedySCM is a hacked up clone of the Windows NT Service Control\n"
"Manager (SCM).  SpeedySCM allows you start and stop multiple services\n"
"at once.\n"
"\n"
"The box right above allows you to connect to another computer and\n"
"toggle services remotely.  Of course, the other computer must be\n"
"running Windows NT and you must have administrator access to it.\n"
"\n"
"Stopping a crashed service used to require the Visual Studio debugger\n"
"(taskmanager -> processes tab -> rightclick process -> debug.)  This is\n"
"painfully slow, especially for groups of services.\n"
"\n"
"Enter SpeedySCM's \"Terminate\" button.  This allows you to kill groups\n"
"of services in a matter of seconds!  This only works on the local machine,\n"
"but it's a big step forward.\n"
"\n"
"A word of warning: both SpeedySCM and the Visual Studio debugger use the\n"
"dreaded TerminateProcess API, which is kindof effective but may cause system\n"
"instability.  (I haven't seen it happen, but the documentation says so.)\n"
"\n"
"The lower box on the screen will list error messages (if any.)  You can reset\n"
"the list by clicking \"Forget Errors\".\n",
	MB_ICONINFORMATION );
}
