#pragma once

#include <vector>
using namespace std;

#include "process.h"

struct ThreadInfo;

class CThreadPool  
{
public:
	CThreadPool();
	virtual ~CThreadPool();
	static unsigned __stdcall TheThread( void *pArg );
	BOOL Run( void (*pFunc )(void *), 
		void *pArg, HANDLE hDone = NULL );
	void SetMaxThreads(DWORD dwMaxThreads);

private:
	BOOL ActivateThread( ThreadInfo &Info, void (*pFunc )(void *), 
		void *pArg, HANDLE hDone );
	BOOL SpawnThread( void (*pFunc )(void *), 
		void *pArg, HANDLE hDone );

	CRITICAL_SECTION m_hCrit;
	DWORD m_dwMaxThreads;
	vector<ThreadInfo*> m_vecThreads;
};
