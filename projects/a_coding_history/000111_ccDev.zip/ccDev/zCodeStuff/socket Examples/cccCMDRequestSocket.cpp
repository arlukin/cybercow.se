//////////////////////////////////////////////////////////////////////
// $File name   : cccCMDRequestSocket.cpp: 
//
// $Author      : Daniel Lindh (Daniel.Lindh@home.se)
// Notice       : Copyright (c) CyberCow AB 2000
//
//////////////////////////////////////////////////////////////////////

#include "ccVOServer.h"
#include "cccCMDRequestSocket.h"
#include "ccsSocketData.h"

#include "cccServer.h"
#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(cccCMDRequestSocket, CAsyncSocket)
	//{{AFX_MSG_MAP(cccCMDRequestSocket)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0


/////////////////////////////////////////////////////////////////////////////
// *** Construction/Destruction 
/////////////////////////////////////////////////////////////////////////////
	
cccCMDRequestSocket::cccCMDRequestSocket()
{
}

//

cccCMDRequestSocket::cccCMDRequestSocket( cccServer * m_accServer )
{
	m_dataBase = NULL;

	m_ccServer = m_accServer;

	m_nBufLength = 0;	

	m_reqStatus = REQ_LOGIN;	

	// Clean command and argument string
	m_nCommandParsing = -1;

	m_bLogedIn = FALSE;
}

//

cccCMDRequestSocket::~cccCMDRequestSocket()
{	
	if (m_dataBase)		
		delete m_dataBase;
}

/////////////////////////////////////////////////////////////////////////////
// *** Socket incoming processing.
/////////////////////////////////////////////////////////////////////////////

void cccCMDRequestSocket::processData()
{	
	while( 1)
	{
		switch ( m_reqStatus )
		{		
		default:
		case REQ_LOGIN:
		case REQ_ADMIN_COMMAND:
		case REQ_COMMAND:
			// Separate command and argument			
			if ( (parseLine()) && !m_commandLine[0].IsEmpty() )				
			{				
				switch( m_reqStatus )
				{					
					// First socket has to be loged in, and set to some kind of "mode"
					default:
					case REQ_LOGIN:						
						processReqLogin();						
						break;

					// Administrator has logedin, and here is admin specific commands.
					case REQ_ADMIN_COMMAND:						
						if ( processReqAdminCommand() )
							break;

					// User specific (Also admin) commands.
					case REQ_COMMAND:
						processReqCommand();
						break;
				}					
			}
			else 
				return;
	
			break;			

		case REQ_CCVO_STUCT:
			// ****** Have we at least gotten enough to read the base?
			if( m_nBufLength < sizeof( ccsSDBase ) )
				return;
														
			const ccsSDBase *lpSDBase = (const ccsSDBase *)m_pBuf;	

			// ****** Have we got the whole request
			if( (int)lpSDBase->wSize > m_nBufLength )
				return;			

			// ****** We have gotten a complete request
			// ****** process it!
			processReqCCVOStruct( lpSDBase->ucID );

			// ****** Move past the old request.
			if( m_nBufLength > lpSDBase->wSize )
			{
				m_nBufLength -= lpSDBase->wSize;
				memcpy( m_pBuf, &m_pBuf[ lpSDBase->wSize ], m_nBufLength );
			}
			else
				m_nBufLength = 0;							
			break;
		} //switch			
	} // while
}

//

BOOL cccCMDRequestSocket::parseLine()
{
	// Clean command and argument string
	if (m_nCommandParsing == -1)
	{
		m_nCommandParsing = 0;
		m_bLongCommandLine = FALSE;

		for (int i=0;i<COMMAND_LINE_ARG;i++)
			m_commandLine[i].Empty();			
	}

	int ndx = 0;	
	BOOL bLine = FALSE;
	while ( bLine == FALSE && ndx < m_nBufLength )
	{
		char ch = (char)(m_pBuf[ndx]);
		switch( ch )
		{
		case '\r': // ignore
			break;

		case '\n': // end-of-line
			{
				bLine = TRUE;

				//m_commandLine[m_nCommandParsing].MakeLower();

				// Tell program to reset command and argument string, next time parsing.
				m_nCommandParsing = -1;				
				break;
			}
			break;

		case '"':
		case '\'':
			m_bLongCommandLine = !m_bLongCommandLine;
			break;
		case ' ':
			// If " has been entered add a space to the string.
			if ( m_bLongCommandLine == FALSE )
			{
				m_commandLine[m_nCommandParsing].MakeLower();

				m_nCommandParsing++;
				break;
			}			

		default:   // other....
			m_commandLine[m_nCommandParsing] += ch;			
			break;
		}
		++ndx;
	}	
	
	// Delete parsed data from m_pBuf. Keep data not parsed.
	if( m_nBufLength > ndx )
	{
		m_nBufLength -= ndx;
		memcpy( m_pBuf, &m_pBuf[ ndx ], m_nBufLength );
	}
	else
		m_nBufLength = 0;			

	return bLine;
}

//

void cccCMDRequestSocket::processReqLogin()
{
	if ( (m_commandLine[0] == "login") )
	{		
		if ( gcLoginUser(m_commandLine[1], m_commandLine[2]) )
			if ( m_user == "admin")
				m_reqStatus = REQ_ADMIN_COMMAND;
			else
				m_reqStatus = REQ_COMMAND;						
	}
}

//

BOOL cccCMDRequestSocket::processReqAdminCommand()
{
			// Send a msg to all active user. 
			// msg2all "15 minutes to close"
		 if ( (m_commandLine[0] == "msg2all") )
			{
			 m_ccServer->sendMessageToAll( m_commandLine[1] );
			 return TRUE;
			}

			// Show all active user. 
			// acListUsr
	else if (m_commandLine[0] == "listusr")
			{ 
				acListUsr(); 
				return TRUE;
			}					

			// Close all sockets
			// shutdown yes
	else if (m_commandLine[0] == "shutdown")
			{ 
				if ( m_commandLine[1] == "yes")
					PostQuitMessage(5);
					//m_ccServer->shutdownServer();
				return TRUE;
			}					
			 
			// Can only log in with admin account
			// disablelogin yes
			// disablelogin no
	else if (m_commandLine[0] == "disablelogin")
			{ 
				if ( m_commandLine[1] == "yes")
					m_ccServer->diableLogin( TRUE );
				else
					m_ccServer->diableLogin( FALSE );
				return TRUE;
			}					
	else if ( (m_commandLine[0] == "info") )
		{ acSessionInfo(); m_ccServer->serverInfo(this); return TRUE;}

	return false;
}

//

void cccCMDRequestSocket::processReqCommand()
{					
		 if ( (m_commandLine[0] == "quit") )
			m_ccServer->logout( this  );
		 
	else if ( (m_commandLine[0] == "info") )
			acSessionInfo();

	else if ( (m_commandLine[0] == "moo") )						
			acSendTxtMessage("moo p� dig.");

	else if ( (m_commandLine[0] == "CCVO2KMODE") )	
			m_reqStatus = REQ_CCVO_STUCT;

	else
			acSendTxtMessage("Unknown command.");
}

//

void cccCMDRequestSocket::processReqCCVOStruct( UCHAR aucID)
{				
	switch ( aucID )
	{
	case CCSD_NEW_USER:
		stNewUser( );
		break;
	default:
		break;
	}	
}

/////////////////////////////////////////////////////////////////////////////
// *** Socket Struct prossesing.
/////////////////////////////////////////////////////////////////////////////

void cccCMDRequestSocket::stNewUser()
{
	const ccsSDNewUser *poNewUser = (const ccsSDNewUser *)m_pBuf;
	// TODO..		
}

/////////////////////////////////////////////////////////////////////////////
// *** Socket admin Commands
/////////////////////////////////////////////////////////////////////////////

void cccCMDRequestSocket::acSessionInfo()
{
	CString lsInfo;
	lsInfo += "****************** Session info ***********************\r\n";	
	lsInfo += "Username: "; lsInfo += m_user;		lsInfo += "\r\n";
	lsInfo += "Password: "; lsInfo += m_password;	lsInfo += "\r\n";
	acSendTxtMessage( lsInfo );
}

//

void cccCMDRequestSocket::acSendTxtMessage(CString lsMessage)
{
	// Tell the client that a message is comming.
	lsMessage = "msg::" + lsMessage;
	lsMessage += "\r\n";
 
	try
	{
		Send( lsMessage, lsMessage.GetLength() );
	}
	catch (CException e)
	{
		char sErrorBuf[100];
		e.GetErrorMessage( sErrorBuf, 100);
		CString sPrefix;
		sPrefix.LoadString( IDS_SOCKET_ERROR );
		ccErr( CString(sErrorBuf), sPrefix); 				
	}
	catch(...)
	{
		ccErrEM( IDS_SENDERROR, IDS_SOCKET_ERROR);
	}
}

//

void cccCMDRequestSocket::acListUsr()
{
	CString lsActiveUsers = m_ccServer->getActiveUsers();
	
	acSendTxtMessage( lsActiveUsers );
}

/////////////////////////////////////////////////////////////////////////////
// *** Socket Commands
/////////////////////////////////////////////////////////////////////////////

BOOL cccCMDRequestSocket::gcLoginUser(CString &asUser, CString &asPassword)
{
	try 
	{		
		if ( m_ccServer->isLoginDisabled( asUser ) )
		{
			acSendTxtMessage("Login is disabled, probely because of system maintance");
		}
		else
		{			
			// Create a connection to the database
			if ( m_dataBase == NULL )
				m_dataBase = new ccDataBase;
						
			if ( m_dataBase->isOpen() )
				m_dataBase->close();
			
			m_dataBase->openADOMSSQLServer( getSQLServerName(), getDataBaseName(), NULL, NULL);

			
			if ( m_ccServer->isUserActive( asUser ) )
			{
				acSendTxtMessage("User already active!");			
			}
			else
			{
				// Login user if existing in sql database
				VARIANT vPassword;
				CString lsSQL;
				lsSQL.Format("SELECT password FROM dtUser where username = '%s'", asUser);
				if ( m_dataBase->getRSVariant(lsSQL, &vPassword) )
				{
					CString lsRealPassword = (char*)(_bstr_t)vPassword;
					lsRealPassword.TrimLeft();lsRealPassword.TrimRight();
					if (  lsRealPassword == asPassword )
					{
						// Login succeded
						m_user	   = asUser;
						m_password = asPassword;
						m_bLogedIn = TRUE;
						acSendTxtMessage("Login succeded.");
						return TRUE;
					}			
					else
					{
						acSendTxtMessage("Invalid password!");					
					}
				}
				else
				{
					acSendTxtMessage("Invalid username!");	
				}
			}
		}
	}
	catch(_com_error &e)
	{		
		CString strComErrorPrefix; strComErrorPrefix.LoadString( IDS_COM_ERROR );
		CString strComError; strComError = getComError( e );
		ccErr( strComError, strComErrorPrefix );
	}
	catch(...)
	{
		CString strComErrorPrefix; strComErrorPrefix.LoadString( IDS_COM_ERROR );
		ccErr("Unknown error", strComErrorPrefix);
	}

	return FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// *** Overrides	
/////////////////////////////////////////////////////////////////////////////

void cccCMDRequestSocket::OnReceive(int nErrorCode) 
{
	// Declare local variables up here because they are also used for debugging
	// and error detection.
	int nBytesRead; // Also used for error detection.
	DWORD dwBytes;
	
	try
	{
		while (1)
		{			
			// ****** Read chunks of data from the socket			
			if ( IOCtl( FIONREAD, &dwBytes ) == 0)
				return;

			if( dwBytes == 0 )
				return;	

			// Append data from the socket to the end of buffert.
			nBytesRead = Receive( &m_pBuf[ m_nBufLength ], dwBytes );			
			m_nBufLength += nBytesRead;		

			if ( m_nBufLength > BUFSIZE )
			{
				ccErrEM( IDS_SOCKERT_BUFFER_OVERFLOW, IDS_CRITICAL_SOCKET_ERROR);
				m_nBufLength = 0;
				return;
			}

			if( nBytesRead == 0 || nBytesRead == SOCKET_ERROR )
				return;
			
			processData();
		}
	}
	catch (CException e)
	{
		char sErrorBuf[100];
		e.GetErrorMessage( sErrorBuf, 100);
		CString sPrefix;
		sPrefix.LoadString( IDS_CRITICAL_SOCKET_ERROR );
		ccErr( CString(sErrorBuf), sPrefix); 				
	}
	catch(...)
	{
		ccErrEM( IDS_UNKNOWN_SOCKET_ERROR, IDS_CRITICAL_SOCKET_ERROR);

		if (nBytesRead == 0)
			ccErrEM( IDS_SOCKET_CLOSED, IDS_SOCKET_ERROR);
		else if (nBytesRead == SOCKET_ERROR )
			ccErrEN( GetLastError(), IDS_SOCKET_ERROR);
		else
		{
			ccString strDump;			
			strDump << "dwBytes "		<< dwBytes		<< "\n";
			strDump << "nBytesRead "	<< nBytesRead	<< "\n";
			strDump << "m_nBufLength "	<< m_nBufLength	<< "\n";
			
			ccErr(strDump, "cccCMDRequestSocketDump");
		}
	}	
}

//

void cccCMDRequestSocket::OnClose(int nErrorCode) 
{
	m_ccServer->logout( this  );
	
	CAsyncSocket::OnClose(nErrorCode);
}
