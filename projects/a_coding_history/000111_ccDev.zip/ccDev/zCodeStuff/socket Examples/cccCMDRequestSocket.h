// ==========================================================================
//                    Class Specification : cccCMDRequestSocket
// ==========================================================================
//////////////////////////////////////////////////////////////////////
// $File name   : /ccVO2k/dev/ccVOServer/cccCMDRequestSocket.h: 
//
// $Author      : Daniel Lindh (Daniel.Lindh@home.se)
// $HomePage    : home.bip.net/CyberCow
// $ICQ         : 7983755
//
// Notice       : Copyright (c) CyberCow AB 2000
//                Ekbacksv�gen 28
//                168 69  BROMMA
//                SWEDEN  
//                tel int + 46 (8) 555 362 95
//                
//                The copyright to the computer program(s) herein is the 
//				  property of CyberCow.The program(s) may be used and/or 
//				  copied only with the written permission of CyberCow or 
//				  in accordance with the terms and conditions stipulated 
//				  in the agreement/contract under which the program(s) 
//				  have been supplied. 
//
/////////////////////////////////////////////////////////////////////////////
///** $History$ *************************************************************
// *
// * $Date: 2/03/2000 10:00 $
// * $Revision: 1 $
// * 
// * *****************  Version 1  *****************
// * User: Daniel Date: 2/03/2000 10:00
// * Source-Code Traced [ ]; Reviewd [ ] 
// * Created in $/ccVO2k/dev/ccVOServer/
// * Initial release.
// * 
// **************************************************************************
/////////////////////////////////////////////////////////////////////////////
// ** $Properties$ **********************************************************
// * [ ] Abstract class (does not have any objects)
// * [ ] Uses exceptions
// **************************************************************************
/////////////////////////////////////////////////////////////////////////////
/*
$Description : 
	The socket connected to the client.
	This socket takes care of all "telnet" commands and all structs send
	to the server, and also sends information back to the client.
*/
/////////////////////////////////////////////////////////////////////////////
#if !defined(AFX_cccCMDRequestSocket_H__92F09FC7_E49E_11D3_8996_00609708DCFE__INCLUDED_)
#define AFX_cccCMDRequestSocket_H__92F09FC7_E49E_11D3_8996_00609708DCFE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "ccsSocketData.h"

/////////////////////////////////////////////////////////////////////////////
// cccCMDRequestSocket command target
class cccServer;
class ccsUser;

class cccCMDRequestSocket : public CAsyncSocket
{
// *** Construction/Destruction 
public:
	// Default constructor
	//
	cccCMDRequestSocket();

	// Constructor used by the ccServer
	//
	cccCMDRequestSocket(cccServer * m_pServer);

	// Default Destructor
	//
	virtual ~cccCMDRequestSocket();


// *** Socket incoming processing.
private:
	//  Handle data comming in from the OnRecive(...)
	//
	void processData();

	// Parse the command line comming from the socket.
	// Separate the command and arguments from each other.
	//
	BOOL parseLine();

	// Handle command line in ReqLogin mode
	//
	void processReqLogin();

	// Handle command line in ReqAdminCommand mode
	//
	BOOL processReqAdminCommand();

	// Handle command line in ReqCommand mode
	//
	void processReqCommand();	

	// Handle incomming binary data in ReqCCVOStruct mode
	// The data is comming in a ccsSDBase derivide
	// struct.
	//
	void processReqCCVOStruct( UCHAR aucID );


// *** Socket Struct prossesing.
// st = struct
public:

	// create a new user in the database
	// depending on data coming from a struct.
	//	
	void stNewUser();

	
// *** Socket admin Commands
// ac = adminCommand
public:
	// Gives some information about the server.
	//
	void acSessionInfo( );

	// Send a "msg::" to the user connected 
	// to this socket.
	//
	void acSendTxtMessage(CString lsMessage);

	// Send a list of all connected users to the user
	// connected to this socket	
	//
	void acListUsr();


// *** Socket General Commands
// gc = generalCommand
public:
	// Login user 
	//
	BOOL gcLoginUser(CString & asUser, CString & asPassword);	

	
// *** SQL Server commands
public:
	// Get the name of the SQL server.
	//
	char * getSQLServerName()		{ return "CYBERCOW";			};

	// Get the name of the Database in the SQL server.
	//
	char * getDataBaseName()		{ return "CCVO2K";				};

private:
	ccDataBase * m_dataBase;						// The connection to the database.

// Attributes - Socket information
private:
	cccServer * m_ccServer;							// pointer to the ccServer object.

	// Socket (telnet) command attributes
	int	 m_nCommandParsing;
	BOOL m_bLongCommandLine;
	CString m_commandLine[COMMAND_LINE_ARG];	
	
	BYTE			m_pBuf[ BUFSIZE ];				// Data recived from the socket.

	int				m_nBufLength;					// Length of currently recived data in m_pBuf.

	// Tell what kind of data expected to recive.	
	enum REQSTATUS
	{
		REQ_LOGIN=0, REQ_ADMIN_COMMAND, REQ_COMMAND, REQ_CCVO_STUCT
	};	
	REQSTATUS   m_reqStatus;		

// *** Attributes - User information
public:
	CString m_user;
	CString m_password;	
	BOOL	m_bLogedIn;


// *** Overrides	
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(cccCMDRequestSocket)
	public:
	virtual void OnReceive(int nErrorCode);
	virtual void OnClose(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(cccCMDRequestSocket)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_cccCMDRequestSocket_H__92F09FC7_E49E_11D3_8996_00609708DCFE__INCLUDED_)
