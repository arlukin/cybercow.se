//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by chatsrvr.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define ID_MESSAGES                     129
#define IDD_DISCUSSION                  130
#define ID_CONNECTIONS                  130
#define IDS_MESSAGESFMT                 131
#define IDS_CONNECTIONSFMT              132
#define IDC_EDIT1                       1000
#define IDS_SERVERSHUTDOWN              61204
#define IDS_READERROR                   61205
#define IDS_SENDERROR                   61206

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
