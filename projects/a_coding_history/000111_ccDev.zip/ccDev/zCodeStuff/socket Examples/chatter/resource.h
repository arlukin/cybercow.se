//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by chatter.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDD_SETUP                       130
#define IDC_HANDLE                      1000
#define IDC_CHANNEL                     1001
#define IDC_SERVER                      1002
#define IDS_CHANGEADDRESS               32100
#define IDS_DISCONNECT                  32101
#define IDS_CREATEFAILED                32102
#define IDS_RETRYCONNECT                32103
#define IDS_CONNECT                     32104
#define IDS_SERVERRESET                 32105
#define IDS_CONNECTIONCLOSED            32106
#define IDS_STATEMENT01                 32107
#define IDS_STATEMENT02                 32108
#define IDS_STATEMENT03                 32109
#define IDS_STATEMENT04                 32110
#define IDS_STATEMENT05                 32111
#define IDS_STATEMENT06                 32112
#define IDS_STATEMENT07                 32113
#define IDS_STATEMENT08                 32114
#define IDS_STATEMENT09                 32115
#define IDS_STATEMENT10                 32116
#define IDS_STATEMENT11                 32117
#define IDS_STATEMENT12                 32118
#define IDS_STATEMENT13                 32119
#define IDS_STATEMENT14                 32120
#define IDS_STATEMENT15                 32121
#define IDS_STATEMENT16                 32122
#define IDS_STATEMENT17                 32123
#define IDS_STATEMENT18                 32124
#define IDS_STATEMENT19                 32125
#define IDS_STATEMENT20                 32126
#define IDS_STATEMENT21                 32127
#define IDS_STATEMENT22                 32128
#define IDS_STATEMENT23                 32129
#define IDS_STATEMENT24                 32130
#define IDS_STATEMENT25                 32131
#define IDS_STATEMENT26                 32132
#define IDS_STATEMENT27                 32133
#define IDS_STATEMENT28                 32134
#define IDS_STATEMENT29                 32135
#define IDS_STATEMENT30                 32136
#define IDS_STATEMENT31                 32137
#define IDS_STATEMENT32                 32138
#define IDS_STATEMENT33                 32139
#define IDS_STATEMENT34                 32140
#define IDS_STATEMENT35                 32141
#define IDS_STATEMENT36                 32142
#define IDS_ADJECTIVE01                 32143
#define IDS_ADJECTIVE02                 32144
#define IDS_ADJECTIVE03                 32145
#define IDS_ADJECTIVE04                 32146
#define IDS_ADJECTIVE05                 32147
#define IDS_ADJECTIVE06                 32148
#define IDS_FORMAT                      32149
#define ID_AUTOCHATTER                  32775

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
