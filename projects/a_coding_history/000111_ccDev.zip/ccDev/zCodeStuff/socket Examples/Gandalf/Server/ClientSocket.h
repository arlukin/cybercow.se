#if !defined(AFX_CLIENTSOCKET_H__A6A02F47_5D1C_11D2_847A_0000F8774739__INCLUDED_)
#define AFX_CLIENTSOCKET_H__A6A02F47_5D1C_11D2_847A_0000F8774739__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ClientSocket.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CClientSocket command target

#define BUFSIZE	16384

class CLucienDlg;

class CClientSocket : public CAsyncSocket
{
// Attributes
public:

// Operations
public:
	CClientSocket( CLucienDlg *pDlg );
	virtual ~CClientSocket();

// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClientSocket)
	public:
	virtual void OnReceive(int nErrorCode);
	virtual void OnClose(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CClientSocket)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation

	CString			GetIP( void ) const				{ return( m_strIP ); };
	DWORD			GetIPAsDword( void ) const		{ return( m_dwIP ); };
	DWORD			GetInfotizerID( void ) const	{ return( m_dwInfotizerID ); };
	CString			GetFriendlyName( void ) const; 

	BOOL			SendMsg( CString strMsg, BOOL bPrompt ) const;
	BOOL			SendAcute( BOOL bImmediate );
	BOOL			SendURL( int nMode, CString strURL );

	int				GetPingAliveTime( void )	{ return( m_nPingAliveTime ); };

	BOOL			CheckISendMessages( void );

	BOOL			GetBit( int n, const BYTE *ucCategory );

protected:

	//***** New by Bj�rn
	BOOL			SendTelephoneNumbers( void );
	//***** End 

	BOOL			ProcessLogin( void *p );
	BOOL			ProcessProfile( void *p );
	BOOL			ProcessTickAd( void *p );
	BOOL			ProcessPingAlive( void *p );

	BOOL			FailAuthentication( void ) const;

	BOOL			UpdateProfile( BOOL bLogin );

	// ****** Match functions
	BOOL			Match( void );
	BOOL			MatchZIP( CString ZIP, CString UserZIP );
	CString			FindInterval( CString WorkZip, CString *From, CString *To );
	BOOL			CheckInterval( CString From, CString To, CString UserZIP );


	BYTE			m_pBuf[ BUFSIZE ];
	int				m_nBufLength;

	WORD			m_wVersion;
	BYTE			m_pucMsgVersion[ COMM_LOGIN1_MSG_COUNT ];

	CString			m_strIP;
	DWORD			m_dwIP;

	CTime			m_timeLogin;

	int				m_nTotalPointsAwarded;
	int				m_pnPointsAwarded[ TICK_CATEGORIES ];


	// ****** Profile data
	DWORD			m_dwInfotizerID;
	CString			m_strInfotizerPassword;
	CString			m_strName;
	int				m_nProfileNo;
	CString			m_strEmail;
	int				m_nLoginTimes;
	int				m_nCountry;
	int				m_nAge;
	BOOL			m_bMale;
	CString			m_strZIP;
	CString			m_strAreaCode;
	CString			m_strLanguageCode;
	CString			m_strState;

	BYTE			m_pucCategory[ COMM_PROFILE1_CATEGORY_BYTES ];

	BOOL			m_bAuthenticated;

	int				m_nPingAliveTime;	// ****** Time of last alive ping

	CLucienDlg		*m_pDlg;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLIENTSOCKET_H__A6A02F47_5D1C_11D2_847A_0000F8774739__INCLUDED_)
