// ClientSocket.cpp : implementation file
//

#include "stdafx.h"
#include "Lucien.h"
#include "ClientSocket.h"

#include "LucienDlg.h"

#include "Bridge.h"
#include "AdSet.h"
#include "BitGroupSet.h"
#include "BitSet.h"
#include "InfotizerIdSet.h"
#include "InfotizerTransactionSet.h"
#include "IPGroupSet.h"
#include "ISendQueueSet.h"

#include "TelephoneSet.h"

#include <time.h>
//***** End

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CClientSocket

CClientSocket::CClientSocket( CLucienDlg *pDlg ) : m_pDlg( pDlg )
{
	m_nBufLength = 0;

	m_strIP = "xxx.xxx.xxx.xxx";
	m_dwIP = 0;
	m_strName = "<anonymous>";
	m_timeLogin = CTime::GetCurrentTime();

	m_dwInfotizerID = 0;

	m_bAuthenticated = FALSE;

	m_nTotalPointsAwarded = 0;

	m_nPingAliveTime = time( NULL );

	for( int i = 0; i < TICK_CATEGORIES; i++ )
		m_pnPointsAwarded[ i ] = 0;
}

CClientSocket::~CClientSocket()
{
	m_pDlg->m_pBridge->AddMsg( 3, GetFriendlyName() + ": logoff." );
	m_pDlg->SetClientMsg( this, "" );

	// ****** Only save anything if we are authenticated.
	if( !m_bAuthenticated )
		return;

	for( int i = 0; i < TICK_CATEGORIES; i++ )
	{
		if( m_pnPointsAwarded[ i ] == 0 )
			continue;

		// ****** Only save rows when we have gained some points
		TRY
			m_pDlg->m_pInfotizerTransactionSet->AddNew(); 
		CATCH( CDBException, e )
			CString str;
			str.Format( "Could not extend table - InfotizerPointsTransactions: %s",
				(LPCTSTR)e->m_strError );
			m_pDlg->m_pBridge->AddMsg( 1, str );
			m_pDlg->ReportDBError();
			break;
		END_CATCH

		m_pDlg->m_pInfotizerTransactionSet->m_i_infotizer_id = m_dwInfotizerID;
		m_pDlg->m_pInfotizerTransactionSet->m_i_cardinality = m_pnPointsAwarded[ i ];
		m_pDlg->m_pInfotizerTransactionSet->m_i_point_from_id = i;
		m_pDlg->m_pInfotizerTransactionSet->m_dt_time = time( NULL );
		m_pDlg->m_pInfotizerTransactionSet->m_i_extended_info = 0;

		TRY
			m_pDlg->m_pInfotizerTransactionSet->Update();
		CATCH( CDBException, e )
			CString str;
			str.Format( "Could not write to table - InfotizerPointsTransactions: %s",
				(LPCTSTR)e->m_strError );
			m_pDlg->m_pBridge->AddMsg( 1, str );
			m_pDlg->ReportDBError();
			break;
		END_CATCH
	}

	UpdateProfile( FALSE );
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CClientSocket, CAsyncSocket)
	//{{AFX_MSG_MAP(CClientSocket)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CClientSocket member functions

// ************************************************************
// ***
// *** BOOL ProcessLogin( void *p )
// ***
// *** Process a login request. Send the user a COMMServerInfo1
// *** packet.
// *** Modifies:
// ***		m_wVersion, m_strIP, m_dwIP
// ************************************************************
BOOL CClientSocket::ProcessLogin( void *p )
{

	// ****** Get the IP adress of the user
	UINT nPort;
	GetPeerName( m_strIP, nPort );
	m_dwIP = ::IPAddrStrToInt( m_strIP );


	// ****** Open up proxy ******
	m_pDlg->SendSingleOpen( m_dwIP, TICKET_LENGTH );

	// ****** Get the base
	const COMMBase *pCOMMBase = (const COMMBase *)p;

	// ****** Get the whole points
	const COMMLogin1 *pCOMMLogin = (const COMMLogin1 *)p;

	m_wVersion = pCOMMLogin->wVersion;

	for( int i = 0; i < COMM_LOGIN1_MSG_COUNT; i++ )
		m_pucMsgVersion[ i ] = pCOMMLogin->pucMsgVersion[ i ];

	m_pDlg->SetClientMsg( this, "Received version info" );

	// ****** Send the user a COMMServerInfo1 command
	COMMServerInfo1 info;
	info.base.wSize = sizeof( COMMServerInfo1 );
	info.base.ucID = COMM_SERVER_INFO;
	info.base.ucVersion = COMM_SERVER_INFO_VERSION;

	strcpy( info.pstrtServerDescription, "Lucien Ad Server" );

	Send( &info, info.base.wSize );

	// ****** Send the user the list of sites with can/cannot access profile info
	COMMProfileSecurity1 security;
	security.base.wSize = sizeof( COMMProfileSecurity1 );
	security.base.ucID = COMM_PROFILE_SECURITY;
	security.base.ucVersion = COMM_PROFILE_SECURITY_VERSION;

	security.wDefaultAccess = theApp.GetProfileDefaultAccess();

	CString str = theApp.GetProfileURLs();

	// ****** Break the string up into pieces and send it
	BOOL bAtEnd;
	for( i = 0; str != ""; i++ )
	{
		CString strHead = str.Left( COMM_PROFILE_SECURITY_LENGTH - 1 );

		bAtEnd = FALSE;

		if( str.GetLength() >= COMM_PROFILE_SECURITY_LENGTH - 1 )
			str = str.Mid( COMM_PROFILE_SECURITY_LENGTH - 1 );
		else
		{
			bAtEnd = TRUE;
			str = "";
		}

		if( i == 0 && bAtEnd )
			security.wListPosition = COMM_PROFILE_SECURITY_ALL;
		else if( i == 0 && !bAtEnd )
			security.wListPosition = COMM_PROFILE_SECURITY_HEAD;
		else if( i > 0 && !bAtEnd )
			security.wListPosition = COMM_PROFILE_SECURITY_BODY;
		else if( i > 0 && bAtEnd )
			security.wListPosition = COMM_PROFILE_SECURITY_TAIL;
		else
		{
			ASSERT( FALSE );
		}

		strcpy( security.pUrls, strHead );
		Send( &security, security.base.wSize );
	}

	return( TRUE );
}

// ************************************************************
// ***
// *** CString GetFriendlyName( void ) const;
// ***
// *** Returns a friendly name for the user (display name that is).
// *** Modifies:
// ***		NONE
// ************************************************************
CString CClientSocket::GetFriendlyName( void ) const
{
	CString str;
	str.Format( "%08d - %s", m_dwInfotizerID, (LPCTSTR)m_strName );
	return( str );
}

// ************************************************************
// ***
// *** BOOL ProcessProfile( void *p )
// ***
// *** Process a profile msg. Match all ads for the user.
// *** Modifies:
// ***		ALL
// ************************************************************
BOOL CClientSocket::ProcessProfile( void *p )
{
	// ****** Get the base
	const COMMBase *pCOMMBase = (const COMMBase *)p;

	// ****** Get the whole msg
	const COMMProfile1 *pCOMMProfile = (const COMMProfile1 *)p;

	m_dwInfotizerID = pCOMMProfile->dwInfotizerID;
	m_strInfotizerPassword = pCOMMProfile->pstrtInfotizerPassword;
	m_strName = pCOMMProfile->pstrsName;
	m_nProfileNo = pCOMMProfile->ucProfileNo;
	m_strEmail = pCOMMProfile->pstrsEmail;
	m_nLoginTimes = pCOMMProfile->wLoginTimes;
	m_nCountry = pCOMMProfile->wCountry;
	m_nAge = pCOMMProfile->ucAge;
	m_bMale = pCOMMProfile->bMale;
	m_strZIP = pCOMMProfile->pstrtZIP;
	m_strAreaCode = pCOMMProfile->pstrtAreaCode;
	m_strLanguageCode = pCOMMProfile->pstrLanguageCode;
	m_strState = pCOMMProfile->pstrState;

	for( int i = 0; i < COMM_PROFILE1_CATEGORY_BYTES; i++ )
		m_pucCategory[ i ] = pCOMMProfile->pucCategory[ i ];

	m_pDlg->SetClientMsg( this, "Received profile info" );

	// **************************************************************
	// ****** Validate the user and get his points
	// **************************************************************
	m_bAuthenticated = TRUE;

	m_pDlg->m_pInfotizerIdSet->m_strFilter.Format( "i_infotizer_id = %d", m_dwInfotizerID );

	if( !m_pDlg->m_pInfotizerIdSet->IsOpen() )
	{
		m_pDlg->m_pBridge->AddMsg( 1, "Table not open - InfotizerIds" );
		return( FALSE );
	}
	TRY
		m_pDlg->m_pInfotizerIdSet->Requery();
	CATCH( CDBException, e )
		CString str;
		str.Format( "Could not query table - InfotizerIdSet: %s",
			(LPCTSTR)e->m_strError );
		m_pDlg->m_pBridge->AddMsg( 1, str );
		m_pDlg->ReportDBError();
		return( FALSE );
	END_CATCH


	if( m_pDlg->m_pInfotizerIdSet->IsBOF() == 0 && m_pDlg->m_pInfotizerIdSet->IsEOF() == 0 )
		m_pDlg->m_pInfotizerIdSet->MoveFirst();
	else
	{
		m_dwInfotizerID = 0;
		m_bAuthenticated = FALSE;
		FailAuthentication();
		m_pDlg->m_pBridge->AddMsg( 1, GetFriendlyName() + " has an invalid InfotizerId!" );

		m_pDlg->SetClientMsg( this, "No InfotizerID" );

		return( FALSE );
	}

	if( m_pDlg->m_pInfotizerIdSet->m_vc_password != m_strInfotizerPassword )
	{
		m_dwInfotizerID = 0;
		m_bAuthenticated = FALSE;
		FailAuthentication();
		m_pDlg->m_pBridge->AddMsg( 1, "User: " + GetFriendlyName() + " entered the wrong password!" );

		m_pDlg->SetClientMsg( this, "Invalid password" );

		return( FALSE );
	}

	// ****** Everything checked up.
	// ****** Send an ok msg, with the point count.

	UpdateProfile( TRUE );			// ****** Update the InfotizerIds table

	COMMInfotizerInfo1 info;

	info.base.wSize = sizeof( COMMInfotizerInfo1 );
	info.base.ucID = COMM_INFOTIZER_INFO;
	info.base.ucVersion = COMM_INFOTIZER_INFO_VERSION;

	info.bAuthenticated = TRUE;
	info.wErrorCode = 0;				// ****** Not used atm

	// ****** Check for null value, then return 0.
	if( !m_pDlg->m_pInfotizerIdSet->IsFieldNull( &m_pDlg->m_pInfotizerIdSet->m_i_points ) )
		info.dwPoints = m_pDlg->m_pInfotizerIdSet->m_i_points;
	else
		info.dwPoints = 0;

	info.dwMinLoadWait = 10*10;		// *** Wait 10 seconds before loading new
	info.dwMaxLoadWait = 5*60*10;	// *** Wait at most 5 minutes, then force load
	info.dwMinShowWait = 30*10;		// *** Don't show more often than 30 seconds
	info.dwMaxShowWait = 10*60*10;	// *** Force an ad if haven't seen one for 10 minutes

	strcpy( info.pstrlServers, theApp.m_strAdServers );
	strcpy( info.pstrsAdRoot, theApp.m_strHTTPAddRoot );
	strcpy( info.pstrsGoto, theApp.m_strReferTo );

	// ****** Send the license info
	info.wLicenseVersion = theApp.GetLicenseVersion();
	strcpy( info.pstrsLicenseURL, theApp.GetLicenseURL() );

	// ****** Send the showing mode info.
	if( (theApp.GetShowMode() == SHOW_MODE_NORMAL && !theApp.IsShowException( m_nCountry ) ) ||
		(theApp.GetShowMode() == SHOW_MODE_INTERVAL && theApp.IsShowException( m_nCountry ) ) )
	{
		// ****** This user should go in normal mode
		info.wShowMode = SHOW_MODE_NORMAL;
		info.wShowModeIntervalLength = 0;
		info.wShowModeIntervalStayOnTime = 0;
		m_pDlg->m_pBridge->AddMsg( 1, "User: " + GetFriendlyName() + " goes in normal mode." );
	}
	else
	{
		// ****** This user should go in interval mode.
		// ****** Times from db is in seconds,
		// ****** time in client is in 10ths if a second.
		info.wShowMode = SHOW_MODE_INTERVAL;
		info.wShowModeIntervalLength = theApp.GetShowModeIntervalLength() * 10;
		info.wShowModeIntervalStayOnTime = theApp.GetShowModeIntervalShowTime() * 10;
		m_pDlg->m_pBridge->AddMsg( 1, "User: " + GetFriendlyName() + " goes in interval mode." );
	}

	Send( &info, info.base.wSize );

	// ****** Now send all matching adds ******
	if( !m_pDlg->m_pAdSet->IsOpen() )
	{
		m_pDlg->m_pBridge->AddMsg( 1, "Table not open - Ads" );
		return( FALSE );
	}
	TRY
		m_pDlg->m_pAdSet->Requery();
	CATCH( CDBException, e )
		CString str;
		str.Format( "Could not query table - Ads: %s",
			(LPCTSTR)e->m_strError );
		m_pDlg->m_pBridge->AddMsg( 1, str );
		m_pDlg->ReportDBError();
		return( FALSE );
	END_CATCH

	if( m_pDlg->m_pAdSet->IsBOF() )
		m_pDlg->m_pBridge->AddMsg( 1, "There are no active Ads!!!" );

	int nAddsSent = 0;

	time_t Time = time( NULL );

	m_pDlg->SetClientMsg( this, "Matching ads..." );

	// ****** Now match user with all ads
	while ( !m_pDlg->m_pAdSet->IsEOF( ) )
	{
		if( !m_pDlg->m_pAdSet->IsDeleted() )
		{
			if( Match() && !m_pDlg->m_pAdSet->m_IsAcute )
			{
				COMMAd1 ad;
				ad.base.wSize = sizeof( COMMAd1 );
				ad.base.ucID = COMM_AD;
				ad.base.ucVersion = COMM_AD_VERSION;

				ad.wAdCode = AD_CODE_NORMAL;
				ad.dwAdID = m_pDlg->m_pAdSet->m_ID;
				ad.wPriority = (WORD)m_pDlg->m_pAdSet->m_Priority;
				ad.dwExpires = m_pDlg->m_pAdSet->m_Expires;
				ad.bStoppedByDefault = m_pDlg->m_pAdSet->m_StoppedByDefault;
				ad.dwSessionMaxShow = m_pDlg->m_pAdSet->m_MaxShow;
				ad.dwSessionMaxInteract = m_pDlg->m_pAdSet->m_MaxInteract;
				ad.dwLifetimeShow = m_pDlg->m_pAdSet->m_LifetimeShow;
				ad.dwLifetimeInteract = m_pDlg->m_pAdSet->m_LifetimeInteract;

				ad.dwStayOnTime = 25;
				ad.dwMinShowTime = 5*10;
				ad.dwMaxShowTime = 12*10;

				// ****** Just in case somebody left a NULL in the db...
				if( m_pDlg->m_pAdSet->IsFieldNull( &m_pDlg->m_pAdSet->m_MinInterval ) )
					ad.dwMinInterval = 0;
				else
					ad.dwMinInterval = m_pDlg->m_pAdSet->m_MinInterval;

				// ****** Send the chaining info.
				ad.dwChainTo = m_pDlg->m_pAdSet->m_ChainTo;
				ad.bInChain = m_pDlg->m_pAdSet->m_InChain;

				strcpy( ad.pstrtName, m_pDlg->m_pAdSet->m_Name );
				strcpy( ad.pstrsWWW, m_pDlg->m_pAdSet->m_WWW );

				for( int i = 0; i < COMM_AD1_ENABLED_HOURS_BYTES; i++ )
					ad.pucEnabledHours[ i ] = m_pDlg->m_pAdSet->m_EnabledHours[ i ];

				ad.dwPointsAdShow = m_pDlg->m_pAdSet->m_PointsAdShow;
				ad.dwPointsAdInteract = m_pDlg->m_pAdSet->m_PointsAdInteract;
				ad.dwPointsAdGoneTo = m_pDlg->m_pAdSet->m_PointsAdGoneTo;
				ad.dwPointsAdShowFirstTime = m_pDlg->m_pAdSet->m_PointsAdShowFirstTime;
				ad.dwPointsAdInteractFirstTime = m_pDlg->m_pAdSet->m_PointsAdInteractFirstTime;
				ad.dwPointsAdPrinted = m_pDlg->m_pAdSet->m_PointsAdPrinted;


				Send( &ad, ad.base.wSize );

				nAddsSent++;
			}
		}
		m_pDlg->m_pAdSet->MoveNext();
	}

	// ****** See if we have a new telephone list.
	if( pCOMMProfile->wTelephoneVersion != theApp.GetTelephoneVersion() )
		SendTelephoneNumbers();

	// ****** Add notification msg
	CString str;
	str.Format( "Logon: %s -> matched %d adds, Language: %s",
		(LPCTSTR)GetFriendlyName(), nAddsSent, (LPCTSTR)m_strLanguageCode );
	m_pDlg->m_pBridge->AddMsg( 3, str );

	// ****** Add to user list, with time stamp
	str.Format( "%02d:%02d - %d",
		m_timeLogin.GetHour(), m_timeLogin.GetMinute(), m_nTotalPointsAwarded );
	m_pDlg->SetClientMsg( this, str );

	// ****** Check for ISend messages
	CheckISendMessages();

	return( TRUE );
}

BOOL CClientSocket::Match( void )
{
	time_t Time = time( NULL );

	// ****** Is a BIP user and bit 0 is off => no match.
//	if( m_bBIPUser && !(m_pDlg->m_pAdSet->m_RASGroup & 1) )
//		return( FALSE );

	// ****** Is not a BIP user and bit 1 is off => no match.
//	if( !m_bBIPUser && !(m_pDlg->m_pAdSet->m_RASGroup & 2) )
//		return( FALSE );

	// ****** Check the login counts.
	if( m_nLoginTimes < m_pDlg->m_pAdSet->m_LoginTimesFrom || m_nLoginTimes > m_pDlg->m_pAdSet->m_LoginTimesTo )
		return( FALSE );

	if( m_pDlg->m_pAdSet->m_Begins > Time )
		return( FALSE );
	if( m_pDlg->m_pAdSet->m_Expires < Time )
		return( FALSE );
	if( m_pDlg->m_pAdSet->m_AgeFrom > m_nAge )
		return( FALSE );
	if( m_pDlg->m_pAdSet->m_AgeTo < m_nAge )
		return( FALSE );
	if( !m_pDlg->m_pAdSet->m_Male && m_bMale )
		return( FALSE );
	if( !m_pDlg->m_pAdSet->m_Female && !m_bMale )
		return( FALSE );

	if( !MatchZIP( m_pDlg->m_pAdSet->m_ZIP, m_strZIP ) )
		return( FALSE );

	// ****** Now try to match any category
	BOOL bSuccess = FALSE;
	for( int i = 0; i < COMM_PROFILE1_CATEGORY_BYTES; i++ )
		if( m_pDlg->m_pAdSet->m_CategoryOr[ i ] & m_pucCategory[ i ] )
		{
			bSuccess = TRUE;
			break;
		}
	if( !bSuccess )
	{
//		CString str;
//		str.Format( "Failed OR match on ad: %d",
//			m_pDlg->m_pAdSet->m_ID );
//		m_pDlg->m_pBridge->AddMsg( 3, str );
		return( FALSE );
	}

	// ****** Now try an AND match.
	for( i = 0; i < COMM_PROFILE1_CATEGORY_BYTES; i++ )
		if( (m_pDlg->m_pAdSet->m_CategoryAnd[ i ] & m_pucCategory[ i ]) != 
			m_pDlg->m_pAdSet->m_CategoryAnd[ i ] )
		{
//			CString str;
//			str.Format( "Failed AND match on ad: %d",
//				m_pDlg->m_pAdSet->m_ID );
//			m_pDlg->m_pBridge->AddMsg( 3, str );
			return( FALSE );
		}

	// ****** Now try a NOT match.
	for( i = 0; i < COMM_PROFILE1_CATEGORY_BYTES; i++ )
	{
		BYTE uchData = m_pDlg->m_pAdSet->m_CategoryNot[ i ];
		if( ( uchData & m_pucCategory[ i ] ) != 0 )
		{
//			CString str;
//			str.Format( "Failed NOT match on ad: %d",
//				m_pDlg->m_pAdSet->m_ID );
//			m_pDlg->m_pBridge->AddMsg( 3, str );
			return( FALSE );
		}
	}

//	CString str;
//	str.Format( "Success in match on ad: %d",
//		m_pDlg->m_pAdSet->m_ID );
//	m_pDlg->m_pBridge->AddMsg( 3, str );


	// ****** Do the IP group match
	// ****** If the field is NULL, that means some butthead
	// ****** has been using an old version of Morpheus
	if( !m_pDlg->m_pAdSet->IsFieldNull( &m_pDlg->m_pAdSet->m_IPGroups ) )
	{
		BOOL bMatch = FALSE;
		int iIPGroup;
		for( int i = 0; i < 254; i += 2 )
		{
			iIPGroup = MAKEWORD( m_pDlg->m_pAdSet->m_IPGroups.GetAt( i + 1 ), m_pDlg->m_pAdSet->m_IPGroups.GetAt( i ) );

			// ****** First pos = 0 then no groups are specified, i.e. all can pass
			if( iIPGroup == 0 )
			{
				if( i == 0 )
					bMatch = TRUE;
				break;
			}

			// ****** Find the group in the table.
			m_pDlg->m_pIPGroupSet->m_strFilter.Format( "i_id = %d", iIPGroup );

			if( !m_pDlg->m_pIPGroupSet->IsOpen() )
			{
				m_pDlg->m_pBridge->AddMsg( 1, "Table not open - IPGroups" );
				return( TRUE );			// ****** Just let the match go through.
			}
			TRY	
				m_pDlg->m_pIPGroupSet->Requery();
			CATCH( CDBException, e )
				CString str;
				str.Format( "Could not query table - IPGroups: %s",
					(LPCTSTR)e->m_strError );
				m_pDlg->m_pBridge->AddMsg( 1, str );
				m_pDlg->ReportDBError();
				return( TRUE );			// ****** Just let the match go through.
			END_CATCH


			// ****** Did we find the group, if not then I really don't care, go on.
			if( !m_pDlg->m_pIPGroupSet->IsBOF() )
			{
				if( GetIPAsDword() >= (DWORD)m_pDlg->m_pIPGroupSet->m_i_ip_from &&
					GetIPAsDword() <= (DWORD)m_pDlg->m_pIPGroupSet->m_i_ip_to )
				{
					bMatch = TRUE;
				}
				else
				{
					CString str;
					str.Format( "Failed ip group match for ad %d in group: %d",
						m_pDlg->m_pAdSet->m_ID, iIPGroup );
					m_pDlg->m_pBridge->AddMsg( 3, str );
				}
				
			}
		}
		// ****** If we didn't find a group we're part of then fail.
		if( !bMatch )
		{
			CString str;
			str.Format( "Failed ip group match for ad %d!",
				m_pDlg->m_pAdSet->m_ID );
			m_pDlg->m_pBridge->AddMsg( 3, str );
			return( FALSE );
		}
		else
		{
			CString str;
			str.Format( "Success in ip group match on ad %d!",
				m_pDlg->m_pAdSet->m_ID );
			m_pDlg->m_pBridge->AddMsg( 3, str );
			return( TRUE );
		}
	}


	return( TRUE );
}

BOOL CClientSocket::MatchZIP( CString ZIP, CString UserZIP )
{
	CString WorkZIP = ZIP;
	CString From;
	CString To;

	int i = 0;		// *** In case somebody has entered a horrible zip-code in the Ad

	// *** Means that we don't care about ZIP code
	if( WorkZIP.GetLength() == 0 )
		return( TRUE );

	while( WorkZIP.GetLength() > 0 && i < 255 )
	{
		WorkZIP = FindInterval( WorkZIP, &From, &To );
		if( CheckInterval( From, To, UserZIP ) )
			return( TRUE );
		i++;
	}

	return( FALSE );
}


CString CClientSocket::FindInterval( CString WorkZip, CString *From, CString *To )
{

	int nFirstMinus = WorkZip.Find( '-' );
	int nFirstComma = WorkZip.Find( ',' );

	// ****** Did we find something like 16446 (without anything after it)
	if( nFirstMinus == -1 && nFirstComma == -1 )
	{
		*From = WorkZip;	
		*To = WorkZip;
		return( "" );
	}

	// ****** Here I just wan't to not bother with cases when a token is missing
	if( nFirstMinus == -1 )
		nFirstMinus = 666;
	if( nFirstComma == -1 )
		nFirstComma = 666;


	// ****** Did we find something like 16446,943.....
	if( nFirstComma < nFirstMinus )
	{
		*From = WorkZip.Left( nFirstComma );
		*To = WorkZip.Left( nFirstComma );
		WorkZip = WorkZip.Right( WorkZip.GetLength() - nFirstComma );
		if( WorkZip.GetLength() > 0 )
			if( WorkZip[ 0 ] == ',' )
				WorkZip = WorkZip.Right( WorkZip.GetLength() - 1 );
		return( WorkZip );
	}

	// ****** Did we find something like 164-168,943.....
	if( nFirstMinus < nFirstComma )
	{
		*From = WorkZip.Left( nFirstMinus );
		WorkZip = WorkZip.Right( WorkZip.GetLength() - nFirstMinus - 1 );
		int nNextToken = WorkZip.FindOneOf( "-," );
		if( nNextToken == -1 )
			nNextToken = WorkZip.GetLength();
		*To = WorkZip.Left( nNextToken );
		WorkZip = WorkZip.Right( WorkZip.GetLength() - nNextToken );
		if( WorkZip.GetLength() > 0 )
			if( WorkZip[ 0 ] == ',' )
				WorkZip = WorkZip.Right( WorkZip.GetLength() - 1 );
		return( WorkZip );
	}

	assert( FALSE );
	return( "" );
}


BOOL CClientSocket::CheckInterval( CString From, CString To, CString UserZIP )
{
	int nLengthFrom = From.GetLength();
	int nLengthTo = To.GetLength();
	int nLengthUserZIP = UserZIP.GetLength();

	for( int i = 0; i < nLengthUserZIP; i++ )
	{
		if( i < nLengthFrom )
		{
			if( UserZIP[ i ] < From[ i ] )		// *** If digit is less -> no match
				return( FALSE );
			else if( UserZIP[ i ] > From[ i ] ) // *** Sure match, no need to check rest
				nLengthFrom = i;
		}
		if( i < nLengthTo )
		{
			if( UserZIP[ i ] > To[ i ] )		// *** If digit is bigger -> no match
				return( FALSE );
			else if( UserZIP[ i ] < To[ i ] )	// *** Sure match, no need to check rest
				nLengthTo = i;
		}
	}
	return( TRUE );
}

// ************************************************************
// ***
// *** BOOL SendMsg( CString strMsg, BOOL bPrompt ) const
// ***
// *** Send a message to the client
// *** Modifies:
// ***		NONE
// ************************************************************
BOOL CClientSocket::SendMsg( CString strMsg, BOOL bPrompt ) const
{
	if( bPrompt )
		if( AfxMessageBox( "Are you sure you want to send: \n" + strMsg + "\nTo: " +
				GetFriendlyName(), MB_YESNO ) != IDYES )
			return( FALSE );

	COMMMsg1 msg;
	msg.base.wSize = sizeof( COMMMsg1 );
	msg.base.ucID = COMM_MSG;
	msg.base.ucVersion = COMM_MSG_VERSION;

	strcpy( msg.pstrlMsg, strMsg );

	// ****** I don't think that send isn't a const function...
	((CClientSocket *)this)->Send( &msg, sizeof( COMMMsg1 ) );

	return( TRUE );
}

// ************************************************************
// ***
// *** BOOL ProcessTickAd( void *p );
// ***
// *** Process a tick ad msg.
// *** Modifies:
// ***		NONE
// ************************************************************
BOOL CClientSocket::ProcessTickAd( void *p )
{
	// ****** Get the base
	const COMMBase *pCOMMBase = (const COMMBase *)p;

	// ****** Get the whole msg
	const COMMTickAd1 *pCOMMTickAd = (const COMMTickAd1 *)p;

	// ****** Update screen and stats
	CString str;
	str.Format( "Ping %d, #%d on %d for %d points from %s", 
		pCOMMTickAd->wCode, pCOMMTickAd->wPingCount, pCOMMTickAd->dwAdID, 
		pCOMMTickAd->dwPointsAwarded, (LPCTSTR)GetFriendlyName() );
	m_pDlg->m_pBridge->AddMsg( 3, str );

	// ****** Add to user list, with time stamp
	str.Format( "%02d:%02d - %d",
		m_timeLogin.GetHour(), m_timeLogin.GetMinute(), m_nTotalPointsAwarded );
	m_pDlg->SetClientMsg( this, str );

	// ****** Update screen stats
	if( pCOMMTickAd->wCode < NO_STATS )
		m_pDlg->m_nTickStat[ pCOMMTickAd->wCode ]++;

	if( pCOMMTickAd->wCode < TICK_CATEGORIES )
	{
		m_pnPointsAwarded[ pCOMMTickAd->wCode ] += pCOMMTickAd->dwPointsAwarded;
		m_nTotalPointsAwarded += pCOMMTickAd->dwPointsAwarded;
	}

	// ****** Give the tick to the bridge, for the other thread to store
	m_pDlg->m_pBridge->AddTick( GetFriendlyName(), pCOMMTickAd->dwAdID,
		pCOMMTickAd->wCode, time( NULL ), m_nAge, m_bMale, m_nProfileNo,
		m_dwIP, m_dwInfotizerID, pCOMMTickAd->wPingCount );

	return( TRUE );
}

// ************************************************************
// ***
// *** BOOL ProcessPingAlive( void *p );
// ***
// *** Process a ping ad msg.
// *** Modifies:
// ***		m_nPingAliveTime
// ************************************************************
BOOL CClientSocket::ProcessPingAlive( void *p )
{
	// ****** Get the base
	const COMMBase *pCOMMBase = (const COMMBase *)p;

	// ****** Get the whole msg
	const COMMPingAlive1 *pCOMMPingAlive = (const COMMPingAlive1 *)p;

	// ****** Update screen and stats
//	m_pDlg->m_pBridge->AddMsg( 3, "Alive ping - " + GetFriendlyName() );

	m_nPingAliveTime = time( NULL );

	return( TRUE );
}


// ************************************************************
// ***
// *** BOOL FailAuthentication( void ) const
// ***
// *** Fail a users authentication. Send a bad COMMInfotizerInfo1 msg.
// *** Modifies:
// ***		NONE
// ************************************************************
BOOL CClientSocket::FailAuthentication( void ) const
{
	COMMInfotizerInfo1 info;

	info.base.wSize = sizeof( COMMInfotizerInfo1 );
	info.base.ucID = COMM_INFOTIZER_INFO;
	info.base.ucVersion = COMM_INFOTIZER_INFO_VERSION;

	info.bAuthenticated = FALSE;
	info.wErrorCode = 0;				// ****** Not used atm
	info.dwPoints = 0;

	info.dwMinLoadWait = 10*10;		// *** Wait 10 seconds before loading new
	info.dwMaxLoadWait = 5*60*10;	// *** Wait at most 5 minutes, then force load
	info.dwMinShowWait = 30*10;		// *** Don't show more often than 30 seconds
	info.dwMaxShowWait = 10*60*10;	// *** Force an ad if haven't seen one for 10 minutes

	strcpy( info.pstrlServers, theApp.m_strAdServers );
	strcpy( info.pstrsAdRoot, theApp.m_strHTTPAddRoot );
	strcpy( info.pstrsGoto, theApp.m_strReferTo );

	info.wLicenseVersion = theApp.GetLicenseVersion();
	strcpy( info.pstrsLicenseURL, theApp.GetLicenseURL() );

	info.wShowMode = SHOW_MODE_NORMAL;
	info.wShowModeIntervalLength = 0;
	info.wShowModeIntervalStayOnTime = 0;

	// ****** I still consider this a constant function, dammit.
	((CClientSocket *)this)->Send( &info, info.base.wSize );

	return( TRUE );
}


// ************************************************************
// ***
// *** BOOL UpdateProfile( BOOL bLogin )
// ***
// *** Updates the users profile. If bLogin = FALSE then
// *** update then update the login count.
// *** Modifies:
// ***		NONE
// ************************************************************
BOOL CClientSocket::UpdateProfile( BOOL bLogin )
{
	m_pDlg->m_pInfotizerIdSet->m_strFilter.Format( "i_infotizer_id = %d", m_dwInfotizerID );

	if( !m_pDlg->m_pInfotizerIdSet->IsOpen() )
	{
		m_pDlg->m_pBridge->AddMsg( 1, "Table not open - InfotizerIds" );
		return( FALSE );
	}
	TRY
		m_pDlg->m_pInfotizerIdSet->Requery();
	CATCH( CDBException, e )
		CString str;
		str.Format( "Could not query table - InfotizerIds: %s",
			(LPCTSTR)e->m_strError );
		m_pDlg->m_pBridge->AddMsg( 1, str );
		m_pDlg->ReportDBError();
		return( FALSE );
	END_CATCH

	// ****** What? Not found
	if( m_pDlg->m_pInfotizerIdSet->IsBOF() )
	{
		m_pDlg->m_pBridge->AddMsg( 2, GetFriendlyName() + ": Infotizer ID missing in InfotizerIds table!" );
		return( FALSE );
	}

	TRY
		m_pDlg->m_pInfotizerIdSet->Edit(); 
	CATCH( CDBException, e )
		CString str;
		str.Format( "Could not edit table - InfotizerIds: %s",
			(LPCTSTR)e->m_strError );
		m_pDlg->m_pBridge->AddMsg( 1, str );
		m_pDlg->ReportDBError();
		return( FALSE );
	END_CATCH

	m_pDlg->m_pInfotizerIdSet->m_vc_name = m_strName;
	m_pDlg->m_pInfotizerIdSet->m_i_age = m_nAge;
	m_pDlg->m_pInfotizerIdSet->m_i_male = m_bMale;
	m_pDlg->m_pInfotizerIdSet->m_vc_zip = m_strZIP;
	m_pDlg->m_pInfotizerIdSet->m_i_online = bLogin;
	m_pDlg->m_pInfotizerIdSet->m_vc_language_code = m_strLanguageCode;
	m_pDlg->m_pInfotizerIdSet->m_vc_state = m_strState;
	m_pDlg->m_pInfotizerIdSet->m_vc_area_code = m_strAreaCode;

	for( int i = 0; i < COMM_PROFILE1_CATEGORY_BYTES; i++ )
		m_pDlg->m_pInfotizerIdSet->m_b_category.SetAtGrow( i, m_pucCategory[ i ] );

	// ****** Just in case we have a NULL value in there...
	if( m_pDlg->m_pInfotizerIdSet->IsFieldNull( &m_pDlg->m_pInfotizerIdSet->m_i_login_times ) )
		m_pDlg->m_pInfotizerIdSet->m_i_login_times = 0;

	if( bLogin )
		m_pDlg->m_pInfotizerIdSet->m_i_login_times++;

	m_pDlg->m_pInfotizerIdSet->m_i_ip = GetIPAsDword();
	m_pDlg->m_pInfotizerIdSet->m_i_country = m_nCountry;

	// ****** Get the random chat status.
	if( GetBit( 20, m_pucCategory ) )
	{
		m_pDlg->m_pInfotizerIdSet->m_i_random_chat_status = 0;
		m_pDlg->m_pBridge->AddMsg( 3, GetFriendlyName() + " - not available for random chat." );
	}
	else
	{
		m_pDlg->m_pInfotizerIdSet->m_i_random_chat_status = 1;
		m_pDlg->m_pBridge->AddMsg( 3, GetFriendlyName() + " - available for random chat." );
	}


	TRY
		m_pDlg->m_pInfotizerIdSet->Update();
	CATCH( CDBException, e )
		CString str;
		str.Format( "Could not write to table - InfotizerIds: %s",
			(LPCTSTR)e->m_strError );
		m_pDlg->m_pBridge->AddMsg( 1, str );
		m_pDlg->ReportDBError();
		return( FALSE );
	END_CATCH


	m_pDlg->m_pBridge->AddMsg( 3, "PROFILE UPDATED!" );

	// ****** If we are logging out then update the logins table
	if( !bLogin )
		m_pDlg->m_pBridge->AddLogin( m_dwInfotizerID, GetFriendlyName(),
			m_nProfileNo, m_strName, m_strEmail, m_nAge, m_bMale, m_strZIP,
			m_timeLogin.GetTime(), time( NULL ), m_nTotalPointsAwarded, m_pucCategory );

	return( TRUE );
}

// ************************************************************
// ***
// *** BOOL SendTelephoneNumbers( void ) 
// ***
// *** Send phonenumbers to the client
// *** packet.
// *** Modifies:
// ***		NONE
// ************************************************************
BOOL CClientSocket::SendTelephoneNumbers( void )
{

	// ****** Start by querying the database, to make
	// ****** sure we have a connection.
	if( !m_pDlg->m_pTelephoneSet->IsOpen() )
	{
		m_pDlg->m_pBridge->AddMsg( 1, "Table not open - Telephony" );
		return( FALSE );
	}
	TRY
		m_pDlg->m_pTelephoneSet->Requery();
	CATCH( CDBException, e )
		CString str;
		str.Format( "Could not query table - Telephony: %s",
			(LPCTSTR)e->m_strError );
		m_pDlg->m_pBridge->AddMsg( 1, str );
		m_pDlg->ReportDBError();
		return( FALSE );
	END_CATCH

	// ****** Send startmessage
	COMMPhoneTag1 tag;

	m_pDlg->m_pBridge->AddMsg( 3, "Sending telephonelist to: " + GetFriendlyName() );
	m_pDlg->SetClientMsg( this, "Phonelist update..." );

	tag.base.wSize		= sizeof( COMMPhoneTag1 );
	tag.base.ucID		= COMM_PHONE_TAG;
	tag.base.ucVersion  = COMM_PHONE_TAG_VERSION;
	tag.wVersion		= theApp.GetTelephoneVersion();
	tag.bStart			= TRUE;

	Send( &tag, tag.base.wSize );

	// ****************** Send all the telephone numbers ********************

	// ****** Get random-number to use for Stockholm.
	int		n08, nCount08 = 0;
	double	nRand08;

	srand( ( unsigned )time( NULL ) );
	nRand08  = ( double )rand() / ( double )RAND_MAX;

	n08  = (int)(10.0 * nRand08);

	// ****** Send all phonenumbers
	while ( !m_pDlg->m_pTelephoneSet->IsEOF( ) )
	{
		if( !m_pDlg->m_pTelephoneSet->IsDeleted() )
		{
			COMMPhoneEntry1 num;
			num.base.wSize = sizeof( COMMPhoneEntry1 );
			num.base.ucID = COMM_PHONE_ENTRY;
			num.base.ucVersion = COMM_PHONE_ENTRY_VERSION;

			m_pDlg->m_pTelephoneSet->m_phonenumber.TrimLeft();
			m_pDlg->m_pTelephoneSet->m_phonenumber.TrimRight();
			
			strcpy( num.pstrtNumber, m_pDlg->m_pTelephoneSet->m_phonenumber );
			
			if( CString( num.pstrtNumber ).Left( 2 ) == "08" )
			{
				if( nCount08 == n08 )
					Send( &num, num.base.wSize );
				else
					++nCount08;
			}
			else
			{
				Send( &num,  num.base.wSize );
			}
		}
		m_pDlg->m_pTelephoneSet->MoveNext();
	}
	

	// ***************** Send the end message **********************
	tag.bStart = FALSE;
	Send( &tag, tag.base.wSize );

	m_pDlg->SetClientMsg( this, "Phonelist done..." );

	return( TRUE );

}


// ************************************************************
// ***
// *** BOOL SendAcute( BOOL bImmediate )
// ***
// *** If the user matches the ad. then send it.
// *** m_pDlg->m_pAdSet points to the ad to be sent.
// *** Modifies:
// ***		NONE
// ************************************************************
BOOL CClientSocket::SendAcute( BOOL bImmediate )
{
	if( !Match() )
		return( FALSE );

	COMMAd1 ad;
	ad.base.wSize = sizeof( COMMAd1 );
	ad.base.ucID = COMM_AD;
	ad.base.ucVersion = COMM_AD_VERSION;

	if( bImmediate )
		ad.wAdCode = AD_CODE_IMMEDIATE;
	else
		ad.wAdCode = AD_CODE_ACUTE;

	ad.dwAdID = m_pDlg->m_pAdSet->m_ID;
	ad.wPriority = (WORD)m_pDlg->m_pAdSet->m_Priority;
	ad.dwExpires = m_pDlg->m_pAdSet->m_Expires;
	ad.bStoppedByDefault = m_pDlg->m_pAdSet->m_StoppedByDefault;
	ad.dwSessionMaxShow = m_pDlg->m_pAdSet->m_MaxShow;
	ad.dwSessionMaxInteract = m_pDlg->m_pAdSet->m_MaxInteract;
	ad.dwLifetimeShow = m_pDlg->m_pAdSet->m_LifetimeShow;
	ad.dwLifetimeInteract = m_pDlg->m_pAdSet->m_LifetimeInteract;

	ad.dwStayOnTime = 25;
	ad.dwMinShowTime = 5*10;
	ad.dwMaxShowTime = 12*10;

	// ****** Just in case somebody left a NULL in the db...
	if( m_pDlg->m_pAdSet->IsFieldNull( &m_pDlg->m_pAdSet->m_MinInterval ) )
		ad.dwMinInterval = 0;
	else
		ad.dwMinInterval = m_pDlg->m_pAdSet->m_MinInterval;

	ad.dwChainTo = 0;

	strcpy( ad.pstrtName, m_pDlg->m_pAdSet->m_Name );
	strcpy( ad.pstrsWWW, m_pDlg->m_pAdSet->m_WWW );

	for( int i = 0; i < COMM_AD1_ENABLED_HOURS_BYTES; i++ )
		ad.pucEnabledHours[ i ] = m_pDlg->m_pAdSet->m_EnabledHours[ i ];

	ad.dwPointsAdShow = m_pDlg->m_pAdSet->m_PointsAdShow;
	ad.dwPointsAdInteract = m_pDlg->m_pAdSet->m_PointsAdInteract;
	ad.dwPointsAdGoneTo = m_pDlg->m_pAdSet->m_PointsAdGoneTo;
	ad.dwPointsAdShowFirstTime = m_pDlg->m_pAdSet->m_PointsAdShowFirstTime;
	ad.dwPointsAdInteractFirstTime = m_pDlg->m_pAdSet->m_PointsAdInteractFirstTime;
	ad.dwPointsAdPrinted = m_pDlg->m_pAdSet->m_PointsAdPrinted;

	Send( &ad, ad.base.wSize );

	return( TRUE );
}

// ************************************************************
// ***
// *** BOOL SendURL( int nMode, CString strURL )
// ***
// *** Sends the given URL to the client.
// *** Modifies:
// ***		NONE
// ************************************************************
BOOL CClientSocket::SendURL( int nMode, CString strURL )
{
	COMMUrl1 url;

	url.base.wSize = sizeof( COMMUrl1 );
	url.base.ucID = COMM_URL;
	url.base.ucVersion = COMM_URL_VERSION;

	url.wMode = nMode;
	strcpy( url.pstrlUrl, strURL );

	Send( &url, url.base.wSize );

	CString str;
	str.Format( "%d: sent url: %d - %s", m_dwInfotizerID, nMode, (LPCTSTR)strURL );
	m_pDlg->m_pBridge->AddMsg( 3, str );

	return( TRUE );
}

// ************************************************************
// ***
// *** BOOL CheckISendMessages( void );
// ***
// *** Check if the user has any ISend messages queued up.
// *** Modifies:
// ***		NONE
// ************************************************************
BOOL CClientSocket::CheckISendMessages( void )
{
	m_pDlg->m_pISendQueueSet->m_strFilter.Format( "i_infotizer_id = %d AND i_viewed = 0", GetInfotizerID() );

	if( !m_pDlg->m_pISendQueueSet->IsOpen() )
	{
		m_pDlg->m_pBridge->AddMsg( 1, "Table not open - ISendQueue" );
		return( FALSE );
	}
	TRY
		m_pDlg->m_pISendQueueSet->Requery();
	CATCH( CDBException, e )
		CString str;
		str.Format( "Could not query table - ISendQueue: %s", (LPCTSTR)e->m_strError );
		m_pDlg->m_pBridge->AddMsg( 1, str );
		m_pDlg->ReportDBError();
		return( FALSE );
	END_CATCH

	// ****** No records matched?
	if( m_pDlg->m_pISendQueueSet->IsBOF() )
		return( FALSE );

	// ****** Send a start page to the user.
	SendURL( COMM_URL_IMMEDIATE, "http://www.infotizer.com/newisend/" );

	while ( !m_pDlg->m_pISendQueueSet->IsEOF( ) )
	{
		if( !m_pDlg->m_pISendQueueSet->IsDeleted() )
		{
			SendURL( COMM_URL_IMMEDIATE, m_pDlg->m_pISendQueueSet->m_vc_url );

			TRY
				m_pDlg->m_pISendQueueSet->Edit(); 
			CATCH( CDBException, e )
				CString str;
				str.Format( "Could not edit table - ISendQueue: %s", (LPCTSTR)e->m_strError );
				m_pDlg->m_pBridge->AddMsg( 1, str );
				m_pDlg->ReportDBError();
				break;
			END_CATCH

			m_pDlg->m_pISendQueueSet->m_i_viewed = TRUE;
			m_pDlg->m_pISendQueueSet->m_dt_viewed = CTime::GetCurrentTime();

			TRY
				m_pDlg->m_pISendQueueSet->Update();
			CATCH( CDBException, e )
				CString str;
				str.Format( "Could not write to table - ISendQueue: %s", (LPCTSTR)e->m_strError );
				m_pDlg->m_pBridge->AddMsg( 1, str );
				m_pDlg->ReportDBError();
				break;
			END_CATCH
		}
		m_pDlg->m_pISendQueueSet->MoveNext();
	}


	return( TRUE );
}

// ************************************************************
// ***
// *** BOOL GetBit( int n, const BYTE *ucCategory );

// ***
// *** Check if the user has any ISend messages queued up.
// *** Modifies:
// ***		NONE
// ************************************************************
BOOL CClientSocket::GetBit( int n, const BYTE *ucCategory )
{
	int nByte = n / 8;
	int nBit = n % 8;
	int nMask = 1 << nBit;

	if( (ucCategory[ nByte ] & nMask) != 0 )
		return( TRUE );

	return( FALSE );
}
