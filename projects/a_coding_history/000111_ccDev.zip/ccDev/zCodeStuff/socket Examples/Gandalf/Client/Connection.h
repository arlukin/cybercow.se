// Connection.h: interface for the CConnection class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CONNECTION_H__6C7FE7E7_5D2B_11D2_85B5_00609708DE08__INCLUDED_)
#define AFX_CONNECTION_H__6C7FE7E7_5D2B_11D2_85B5_00609708DE08__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "MySocket.h"

typedef CList<CMySocket *, CMySocket *&>CSocketList;

// ****** New by Bj�rn
class CPhoneList;
// ****** End

#define CONNECTION_TIMEOUT	10		// ****** Time out after 10 seconds
#define PING_ALIVE_INTERVAL	30		// ****** Send an alive ping every 30 seconds

class CConnection
{
public:
	CConnection();
	virtual ~CConnection();

	BOOL		Connect( void );

	BOOL		OnConnect( CMySocket *pConnectedSocket, int nErrorCode );

	BOOL		ProcessServerInfo( const void *p );
	BOOL		ProcessInfotizerInfo( const void *p );
	BOOL		ProcessMsg( const void *p );
	BOOL		ProcessAd( const void *p );
	BOOL		ProcessPhoneTag( const void *p );
	BOOL		ProcessPhoneEntry( const void *p );
	BOOL		ProcessUrl( const void *p );
	BOOL		ProcessProfileSecurity( const void *p );

	BOOL		Disconnect( void );

	BOOL		OnTimer();

	BOOL		GetConnected( void ) const { return( m_bConnected ); };
	BOOL		GetConnectedChanged( void ) { BOOL b = m_bConnectionChanged; m_bConnectionChanged = FALSE; return( b ); };

	BOOL		SendTick( int nAdID, int nCode, int nTickCount, int nPointsAwarded );

	CString		GetConnectedName( void ) const;

private:

	CPhoneList		*m_pTelephoneList;

	CMySocket	*m_pSocket;

	UINT		m_nTimer;

	BOOL		m_bConnected;
	BOOL		m_bConnectionChanged;

	BOOL		m_bTryingToConnect;
	int			m_nTryingToConnectTime;

	int			m_nSendPingAliveAt;

	CSocketList	m_listCandidateSockets;

	BOOL		m_bTryBackupServer;			// *** Used to alternate connections between 
											// *** regular server and the backup.


	static VOID CALLBACK OnTimer( HWND hWnd, UINT uMsg, UINT idEvent, DWORD dwTime );

};

#endif // !defined(AFX_CONNECTION_H__6C7FE7E7_5D2B_11D2_85B5_00609708DE08__INCLUDED_)
