// MySocket.cpp : implementation file
//

#include "stdafx.h"
#include "BIP.h"
#include "MySocket.h"

#include "Connection.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMySocket

CMySocket::CMySocket( CConnection *pCon ) : m_pConnection( pCon )
{
	m_nBufLength = 0;
}

CMySocket::~CMySocket()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CMySocket, CAsyncSocket)
	//{{AFX_MSG_MAP(CMySocket)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CMySocket member functions

// ************************************************************
// ***
// *** void OnConnect(int nErrorCode) 
// ***
// *** Called when we have established a connection with the server.
// *** Modifies:
// ***		NONE
// ************************************************************
void CMySocket::OnConnect(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class

	if( nErrorCode != 0 )
	{
		DEBUG_MSG( "Connection failure!!!" );
	}
	else
		m_pConnection->OnConnect( this, nErrorCode );
	CAsyncSocket::OnConnect(nErrorCode);
}

void CMySocket::OnReceive(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class

	// ****** Process all messages.

	while( 1 )
	{
		// ****** Read chunks of data from the socket
		DWORD dwBytes;
		IOCtl( FIONREAD, &dwBytes );
		if( dwBytes == 0 )
			break;

		int nBytesRead = Receive( &m_pBuf[ m_nBufLength ], dwBytes );
		m_nBufLength += nBytesRead;

		if( nBytesRead == 0 || nBytesRead == SOCKET_ERROR )
			break;

		// ****** Process the data
		while( 1 )
		{
			// ****** Have we at least gotten enough to read the base?
			if( m_nBufLength < sizeof( COMMBase ) )
				break;

			const COMMBase *pCOMMBase = (const COMMBase *)m_pBuf;

			// ****** Have we got the whole request
			if( (int)pCOMMBase->wSize > m_nBufLength )
				break;

			// ****** We have gotten a complete request
			// ****** process it!
			if( pCOMMBase->ucID == COMM_SERVER_INFO )
				m_pConnection->ProcessServerInfo( (void *)m_pBuf );
			if( pCOMMBase->ucID == COMM_INFOTIZER_INFO )
				m_pConnection->ProcessInfotizerInfo( (void *)m_pBuf );
			if( pCOMMBase->ucID == COMM_MSG )
				m_pConnection->ProcessMsg( (void *)m_pBuf );
			if( pCOMMBase->ucID == COMM_AD )
				m_pConnection->ProcessAd( (void *)m_pBuf );
			if( pCOMMBase->ucID == COMM_PHONE_TAG )
				m_pConnection->ProcessPhoneTag( (void *)m_pBuf );
			if( pCOMMBase->ucID == COMM_PHONE_ENTRY )
				m_pConnection->ProcessPhoneEntry( (void *)m_pBuf );
			if( pCOMMBase->ucID == COMM_URL )
				m_pConnection->ProcessUrl( (void *)m_pBuf );
			if( pCOMMBase->ucID == COMM_PROFILE_SECURITY )
				m_pConnection->ProcessProfileSecurity( (void *)m_pBuf );

			// ****** Move past the old request.
			if( m_nBufLength > pCOMMBase->wSize )
			{
				m_nBufLength -= pCOMMBase->wSize;
				memcpy( m_pBuf, &m_pBuf[ pCOMMBase->wSize ], m_nBufLength );
			}
			else
				m_nBufLength = 0;
		}
	}
	
	CAsyncSocket::OnReceive(nErrorCode);
}

// ************************************************************
// ***
// *** void OnClose(int nErrorCode) 
// ***
// *** What? The server shouldn't close our connection.
// *** Maybe it went down our Urban pulled the plug.
// *** Find a new server to connect to.
// *** Modifies:
// ***		NONE
// ************************************************************
void CMySocket::OnClose(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class
	DEBUG_MSG( "RECONNECTING TO SERVER!!!" );
	CAsyncSocket::OnClose(nErrorCode);
	m_pConnection->Connect();
}
