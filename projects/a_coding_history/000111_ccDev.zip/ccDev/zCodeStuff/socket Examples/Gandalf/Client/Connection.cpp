// Connection.cpp: implementation of the CConnection class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "BIP.h"
#include "Connection.h"

#include "Adds.h"
#include "Profiles.h"

#include "MySocket.h"

// ****** New by Bj�rn
#include "../../Sawgrass/Registry.h"
#include "PhoneList.h"
// ****** End

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CConnection::CConnection() : m_pSocket( NULL )
{

	m_nTimer = SetTimer( NULL, 0, 1000L, OnTimer );
	m_bConnected = FALSE;
	m_bTryingToConnect = FALSE;
	m_bConnectionChanged = TRUE;

	m_pSocket = NULL;

	m_bTryBackupServer = FALSE;
}

CConnection::~CConnection()
{
	KillTimer( NULL, m_nTimer );

	if( m_pSocket != NULL )
	{
		delete m_pSocket;
		m_pSocket = NULL;
	}

	while( !m_listCandidateSockets.IsEmpty() )
	{
		CMySocket *pSocket = m_listCandidateSockets.RemoveHead();
	}
}

// ************************************************************
// ***
// *** BOOL Connect( void )
// ***
// *** Try to connect with any ad server.
// *** Modifies:
// ***		m_bTryingToConnect, m_nTryingToConnectTime
// ************************************************************
BOOL CConnection::Connect( void )
{
	theApp.SetAuthentication( CBIPApp::UNKNOWN );

	m_bTryingToConnect = TRUE;
	m_nTryingToConnectTime = time( NULL );
	m_bConnected = FALSE;
	m_bConnectionChanged = TRUE;

	// ****** Check for an internet connection,
	// ****** must be called after m_bTryingToConnect
	// ****** is set, so we get the retries going.
	if( !theApp.HaveInternetConnection() )
	{
		DEBUG_MSG( "No Internet connection available!" );
		return( FALSE );
	}

	CString str;

	// ****** See if we should go for the regular server or the backup.
	if( !m_bTryBackupServer )
	{
		DEBUG_MSG( "CONNECTING..." );
		str = theApp.GetServers();
	}
	else
	{
		DEBUG_MSG( "CONNECTING BACKUP..." );
		str = "backup.infotizer.com";
	}

#ifdef _DEBUG
	str = "127.0.0.1";
#endif

	// ****** Next connection try should be "reversed"
	m_bTryBackupServer = !m_bTryBackupServer;

	CString strServer;

	// ****** Delete any old socket

	if( m_pSocket != NULL )
	{
		delete m_pSocket;
		m_pSocket = NULL;
	}

	// ****** Delete any old candidate sockets
	while( !m_listCandidateSockets.IsEmpty() )
	{
		CMySocket *pSocket = m_listCandidateSockets.RemoveHead();
		delete pSocket;
	}

	while( str.GetLength() > 0 )
	{
		int n = str.Find( ';' );
		if( n != -1 )
		{
			strServer = str.Left( n );
			str = str.Mid( n + 1 );
		}
		else
		{
			strServer = str;
			str = "";
		}

		CMySocket *pSocket = new CMySocket( this );

		if( pSocket->Create() )
		{

			DEBUG_MSG( "--- Connecting to: " + strServer );
			pSocket->Connect( strServer, PORT );
			DEBUG_MSG( "--- Left connect." );


			m_listCandidateSockets.AddTail( pSocket );
		}
		else
			delete pSocket;
	}
	return( TRUE );
}

// ************************************************************
// ***
// *** BOOL OnConnect( int nErrorCode )
// ***
// *** We have gotten a connection (or an error msg).
// *** Modifies:
// ***		m_pSocket, m_bConnected, m_bTryingToConnect, m_nSendPingAliveAt
// ************************************************************
BOOL CConnection::OnConnect( CMySocket *pConnectedSocket, int nErrorCode )
{

	// ****** Successfully connected

	DWORD dwSize = 16*1024;
	int nOptLen = sizeof( DWORD );
	if( !pConnectedSocket->SetSockOpt( SO_RCVBUF, &dwSize, nOptLen ) )
		DEBUG_MSG( "**************** OPT ERROR ****************" );


	// ****** Are we already connected?
	if( GetConnected() )
		return( FALSE );

	// ****** We are the first good connection,
	// ****** cancel all other connection candidates.
	m_bTryingToConnect = FALSE;
	m_bConnected = TRUE;
	m_pSocket = pConnectedSocket;
	m_bConnectionChanged = TRUE;

	m_bTryBackupServer = FALSE;

	m_nSendPingAliveAt = time( NULL ) + PING_ALIVE_INTERVAL;

	while( !m_listCandidateSockets.IsEmpty() )
	{
		CMySocket *pSocket = m_listCandidateSockets.RemoveHead();
		if( pSocket != pConnectedSocket )
			delete pSocket;
	}

	DEBUG_MSG( "CONNECTED!!!" );

	// ****** Then send of a login msg

	if( nErrorCode == 0 )
	{
		COMMLogin1 login;
		login.base.wSize = sizeof( COMMLogin1 );
		login.base.ucID = COMM_LOGIN;
		login.base.ucVersion = COMM_LOGIN_VERSION;

		login.wVersion = BIP_VERSION;
		for( int i = 0; i < COMM_LOGIN1_MSG_COUNT; i++ )
			login.pucMsgVersion[ i ] = 0;

		login.pucMsgVersion[ COMM_LOGIN ] = COMM_LOGIN_VERSION;

		if( m_pSocket->Send( &login, sizeof( COMMLogin1 ) ) == SOCKET_ERROR )
			AfxMessageBox( "Send error!" );
	}

	return( TRUE );
}


// ************************************************************
// ***
// *** BOOL ProcessServerInfo( const void *p )
// ***
// *** The server sent us some initial info.
// *** Modifies:
// ***		NONE
// ************************************************************
BOOL CConnection::ProcessServerInfo( const void *p )
{
	// ****** Get the base
	const COMMBase *pCOMMBase = (const COMMBase *)p;

	// ****** Get the whole thing
	const COMMServerInfo1 *pCOMMServerInfo = (const COMMServerInfo1 *)p;

	// ****** We will receive new ads, delete any old ones.
	theApp.m_pAdds->Clear();

	// ****** Get all profile info and send it.
	COMMProfile1 profile;
	profile.base.wSize = sizeof( COMMProfile1 );
	profile.base.ucID = COMM_PROFILE;
	profile.base.ucVersion = COMM_PROFILE_VERSION;

#ifdef _DEBUG
	CString str;
	str.Format( "ID: %d, pwd: %s", theApp.m_pProfiles->GetID(),
		(LPCTSTR)theApp.m_pProfiles->GetPassword() );
	DEBUG_MSG( str );
#endif
	profile.dwInfotizerID = theApp.m_pProfiles->GetID();
	strcpy( profile.pstrtInfotizerPassword, theApp.m_pProfiles->GetPassword() );


	strcpy( profile.pstrsName, theApp.m_pProfiles->GetName() );
	profile.ucProfileNo = theApp.m_pProfiles->GetCurProfileNo();

	strcpy( profile.pstrsEmail, "<e-mail>" );

	profile.wLoginTimes = theApp.m_pProfiles->GetLoginCount();

	profile.wCountry = theApp.m_pProfiles->GetCountry();

	profile.ucAge = theApp.m_pProfiles->GetAge();
	profile.bMale = theApp.m_pProfiles->IsMale();

	strcpy( profile.pstrtZIP, theApp.m_pProfiles->GetZip() );

	strcpy( profile.pstrtAreaCode, theApp.m_pProfiles->GetAreaCode() );

	strcpy( profile.pstrLanguageCode, theApp.m_pProfiles->GetLanguage() );
	strcpy( profile.pstrState, theApp.m_pProfiles->GetState() );

	theApp.m_pProfiles->GetAllCategories( profile.pucCategory );

//	profile.wTelephoneVersion = theApp.GetTelephoneVersion();

	profile.wTelephoneVersion = -1;

	m_pSocket->Send( &profile, profile.base.wSize );

	return( TRUE );
}

// ************************************************************
// ***
// *** BOOL ProcessInfotizerInfo( const void *p )
// ***
// *** The server sent us infotizer info.
// *** Modifies:
// ***		NONE
// ************************************************************
BOOL CConnection::ProcessInfotizerInfo( const void *p )
{
	// ****** Get the base
	const COMMBase *pCOMMBase = (const COMMBase *)p;

	// ****** Get the whole thing
	const COMMInfotizerInfo1 *pCOMMInfotizerInfo = (const COMMInfotizerInfo1 *)p;

	theApp.SetPoints( pCOMMInfotizerInfo->dwPoints );

	theApp.m_pAdds->SetMinLoadWait( pCOMMInfotizerInfo->dwMinLoadWait );
	theApp.m_pAdds->SetMaxLoadWait( pCOMMInfotizerInfo->dwMaxLoadWait );
	theApp.m_pAdds->SetMinShowWait( pCOMMInfotizerInfo->dwMinShowWait );
	theApp.m_pAdds->SetMaxShowWait( pCOMMInfotizerInfo->dwMaxShowWait );

	theApp.m_pAdds->SetAdRoot( pCOMMInfotizerInfo->pstrsAdRoot );
	theApp.m_pAdds->SetGoto( pCOMMInfotizerInfo->pstrsGoto );
	theApp.SetServers( pCOMMInfotizerInfo->pstrlServers );

	DEBUG_MSG_ARG( "InfoPointz: %d", pCOMMInfotizerInfo->dwPoints );

	if( pCOMMInfotizerInfo->bAuthenticated )
		theApp.SetAuthentication( CBIPApp::AUTHENTICATED );
	else
	{
		if( theApp.m_pProfiles->GetID() == 0 )
			theApp.SetAuthentication( CBIPApp::NO_INFOTIZERID );
		else
			theApp.SetAuthentication( CBIPApp::NOT_AUTHENTICATED );
		DEBUG_MSG( "AUTHENTICATION FAILED!" );
	}

	// ****** Check if it's time for a new license.
	if( pCOMMInfotizerInfo->wLicenseVersion > theApp.m_pProfiles->GetLastLicenseVersion() )
	{
		theApp.SetShowLicense( TRUE, pCOMMInfotizerInfo->wLicenseVersion, pCOMMInfotizerInfo->pstrsLicenseURL );
		DEBUG_MSG( CString( "Time for a new license at: " ) + pCOMMInfotizerInfo->pstrsLicenseURL );
	}
	else
	{
		DEBUG_MSG( "No new license needed." );
	}

	// ****** Get the mode were in
	theApp.SetShowMode( pCOMMInfotizerInfo->wShowMode );
	theApp.SetShowModeIntervalLength( pCOMMInfotizerInfo->wShowModeIntervalLength );
	theApp.SetSHowModeIntervalStayOnTime( pCOMMInfotizerInfo->wShowModeIntervalStayOnTime );

#ifdef _DEBUG
	CString str;
	str.Format( "Mode: %d, length: %d, stay on: %d", 
		pCOMMInfotizerInfo->wShowMode,
		pCOMMInfotizerInfo->wShowModeIntervalLength,
		pCOMMInfotizerInfo->wShowModeIntervalStayOnTime );
	DEBUG_MSG( str );
#endif

	return( TRUE );
}

// ************************************************************
// ***
// *** BOOL OnTimer( void )
// ***
// *** Check to see if we are trying to connect and have timed
// *** out. Also check if we should send an alive ping
// *** Modifies:
// ***		NONE
// ************************************************************
BOOL CConnection::OnTimer( void )
{

	int nTime = time( NULL );

	// ****** If we are connected the see if it's time to send a ping
	if( GetConnected() )
	{
		if( nTime >= m_nSendPingAliveAt )
		{
			DEBUG_MSG( "Sending alive ping." );
			
			COMMPingAlive1 ping;
			ping.base.wSize = sizeof( COMMPingAlive1 );
			ping.base.ucID = COMM_PING_ALIVE;
			ping.base.ucVersion = COMM_PING_ALIVE;

			m_pSocket->Send( &ping, ping.base.wSize );

			DEBUG_MSG( "Ping alive sent." );
	
			m_nSendPingAliveAt = nTime + PING_ALIVE_INTERVAL;
		}

	}

	// ****** Are we trying to connect?
	if( !m_bTryingToConnect )
		return( FALSE );

	if( nTime < m_nTryingToConnectTime + CONNECTION_TIMEOUT )
		return( FALSE );

	// ****** It is time to reconnect
	Connect();

	return( TRUE );
}

VOID CALLBACK CConnection::OnTimer( HWND hWnd, UINT uMsg, UINT idEvent, DWORD dwTime )
{
	if( theApp.m_pConnection != NULL )
		theApp.m_pConnection->OnTimer();

}


// ************************************************************
// ***
// *** BOOL ProcessMsg( const void *p )
// ***
// *** We have been sent a msg. Show it.
// *** Modifies:
// ***		NONE
// ************************************************************
BOOL CConnection::ProcessMsg( const void *p )
{
	// ****** Get the base
	const COMMBase *pCOMMBase = (const COMMBase *)p;
	// ****** Get the whole thing
	const COMMMsg1 *pCOMMMsg = (const COMMMsg1 *)p;
	::MessageBox( NULL, pCOMMMsg->pstrlMsg, "Infotizer", MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST );
	return( TRUE );
}

// ************************************************************
// ***
// *** BOOL ProcessAd( const void *p )
// ***
// *** We have been sent a new ad. Add it to the rest.
// *** Modifies:
// ***		NONE
// ************************************************************
BOOL CConnection::ProcessAd( const void *p )
{
	// ****** Get the base
	const COMMBase *pCOMMBase = (const COMMBase *)p;

	// ****** Get the whole thing
	const COMMAd1 *pCOMMAd = (const COMMAd1 *)p;

	theApp.m_pAdds->CreateAd( pCOMMAd );
	return( TRUE );
}

// ************************************************************
// ***
// *** BOOL SendTick( int nAdID, int nCode, int nTickCount, int nPointsAwarded );
// ***
// *** Returns TRUE if everything go sent ok.
// *** Modifies:
// ***		NONE
// ************************************************************
BOOL CConnection::SendTick( int nAdID, int nCode, int nTickCount, int nPointsAwarded )
{
	COMMTickAd1 tick;
	tick.base.wSize = sizeof( COMMTickAd1 );
	tick.base.ucID = COMM_TICK_AD;
	tick.base.ucVersion = COMM_TICK_AD_VERSION;

	tick.dwAdID = nAdID;
	tick.wCode = nCode;
	tick.wPingCount = nTickCount;
	tick.dwPointsAwarded = nPointsAwarded;

	// ******Got here once with a null pointer on shutdown...
	if( m_pSocket != NULL )
		if( m_pSocket->Send( &tick, tick.base.wSize ) == SOCKET_ERROR )
			return( FALSE );

	return( TRUE );
}


// ************************************************************
// ***
// *** CString CConnection::GetConnectedName( void ) const;
// ***
// *** Gets the name of the server where connected to.
// *** Return "<NOT CONNECTED>" if we're not.
// *** Modifies:
// ***		NONE
// ************************************************************
CString CConnection::GetConnectedName( void ) const
{
	if( !GetConnected() )
		return( "<NOT CONNECTED>" );

	CString str;
	UINT nPort;

	// ***** DAMN CRAP! GetPeerName should be a const function!!!!
	if( !((CConnection *)this)->m_pSocket->GetPeerName( str, nPort ) )
		return( "<UNKNOWN>" );
	return( str );
}

// ************************************************************
// ***
// *** BOOL Disconnect( void )
// ***
// *** Disconnect from the server.
// *** 
// *** Modifies:
// ***		m_bConnected, m_pSocket, m_listCandidateSockets
// ************************************************************
BOOL CConnection::Disconnect( void )
{
	if( m_pSocket != NULL )
	{
		delete m_pSocket;
		m_pSocket = NULL;
	}

	while( !m_listCandidateSockets.IsEmpty() )
	{
		CMySocket *pSocket = m_listCandidateSockets.RemoveHead();
		delete pSocket;
	}

	m_bConnected = FALSE;

	DEBUG_MSG( "DISCONNECTED." );

	Connect();

	return( TRUE );
}

// ****** New from Bj�rn 

// ************************************************************
// ***
// *** BOOL ProcessPhoneTag( const void *p )
// ***
// *** New phone list from server. FTP it down if needed.
// *** Modifies:
// ***		NONE
// ************************************************************
BOOL CConnection::ProcessPhoneTag( const void *p )
{
	
	const COMMPhoneTag1* pPhoneTag = ( COMMPhoneTag1 *)p;
	
	if( pPhoneTag->bStart )
	{
		DEBUG_MSG( "--- PHONELIST START ---" );
		m_pTelephoneList	= new CPhoneList( _T("tel.cow") );
	}
	else if( !pPhoneTag->bStart ) 
	{
		DEBUG_MSG( "--- PHONELIST END ---" );
		if( m_pTelephoneList != NULL ) 
		{
			m_pTelephoneList->Save();
			delete m_pTelephoneList;
		} 
		else
			return( FALSE );

		// ****** Since we are done, update the telephone list version.
		theApp.SetTelephoneVersion( pPhoneTag->wVersion );
	}
	else
		ASSERT( FALSE );

 	return( TRUE );
}

// ************************************************************
// ***
// *** BOOL ProcessPhoneEntry( const void *p )
// ***
// *** New phonenumber from server. Put it in the appropriate list
// *** Modifies:
// ***		NONE
// ************************************************************
BOOL CConnection::ProcessPhoneEntry( const void *p )
{
	const COMMPhoneEntry1* pPhoneEntry = ( COMMPhoneEntry1 *)p;

#ifdef _DEBUG
	CString str;
	str.Format( "%s", pPhoneEntry->pstrtNumber );
	DEBUG_MSG( str );
#endif
	
	if( m_pTelephoneList == NULL ) 
		return( FALSE );
	m_pTelephoneList->Add( CString(pPhoneEntry->pstrtNumber) );
 	return( TRUE );
}

// ************************************************************
// ***
// *** BOOL ProcessUrl( const void *p );
// ***
// *** We have gotten a URL that we should go to immediately.
// *** Modifies:
// ***		NONE
// ************************************************************
BOOL CConnection::ProcessUrl( const void *p )
{
	// ****** Get the base
	const COMMBase *pCOMMBase = (const COMMBase *)p;

	// ****** Get the whole thing
	const COMMUrl1 *pCOMMUrl = (const COMMUrl1 *)p;

	theApp.m_pAdds->TriggerUrlRequest( pCOMMUrl->wMode, pCOMMUrl->pstrlUrl );

	return( TRUE );
}

// ************************************************************
// ***
// *** BOOL ProcessProfileSecurity( const void *p )
// ***
// *** We have gotten received some URLs for the Profile Security.
// *** Modifies:
// ***		NONE
// ************************************************************
BOOL CConnection::ProcessProfileSecurity( const void *p )
{
	// ****** Get the base
	const COMMBase *pCOMMBase = (const COMMBase *)p;

	// ****** Get the whole thing
	const COMMProfileSecurity1 *pCOMMProfileSecurity = (const COMMProfileSecurity1 *)p;
	
	CString str = pCOMMProfileSecurity->pUrls;

	// ****** If this is the first packet then set the default access type.
	if( pCOMMProfileSecurity->wListPosition == COMM_PROFILE_SECURITY_HEAD ||
		pCOMMProfileSecurity->wListPosition == COMM_PROFILE_SECURITY_ALL )
		theApp.SetProfileSecurityDefault( pCOMMProfileSecurity->wDefaultAccess );

	// ****** If this is the first packet then set the URL's
	// ****** Otherwise append it to the already received URL's
	// ****** If this is the end then append a sentinel end ';'
	if( pCOMMProfileSecurity->wListPosition == COMM_PROFILE_SECURITY_HEAD )
		theApp.SetProfileSecurityUrls( str );
	else if( pCOMMProfileSecurity->wListPosition == COMM_PROFILE_SECURITY_ALL )
		theApp.SetProfileSecurityUrls( str );
	else if( pCOMMProfileSecurity->wListPosition == COMM_PROFILE_SECURITY_BODY )
		theApp.SetProfileSecurityUrls( theApp.GetProfileSecurityUrls() + str );
	else if( pCOMMProfileSecurity->wListPosition == COMM_PROFILE_SECURITY_TAIL )
		theApp.SetProfileSecurityUrls( theApp.GetProfileSecurityUrls() + str );



#ifdef _DEBUG
	if( pCOMMProfileSecurity->wListPosition == COMM_PROFILE_SECURITY_TAIL ||
		pCOMMProfileSecurity->wListPosition == COMM_PROFILE_SECURITY_ALL )
	{
		DEBUG_MSG( "URLs: " + theApp.GetProfileSecurityUrls() );
	}

#endif

	return( TRUE );
}
