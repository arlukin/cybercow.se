#if !defined(AFX_REBARSDIAW_H__EE40D783_90D0_11D3_879B_000000000000__INCLUDED_)
#define AFX_REBARSDIAW_H__EE40D783_90D0_11D3_879B_000000000000__INCLUDED_

// RebarSDIaw.h : header file
//

class CDialogChooser;

// All function calls made by mfcapwz.dll to this custom AppWizard (except for
//  GetCustomAppWizClass-- see RebarSDI.cpp) are through this class.  You may
//  choose to override more of the CCustomAppWiz virtual functions here to
//  further specialize the behavior of this custom AppWizard.
class CRebarSDIAppWiz : public CCustomAppWiz
{
public:
	virtual CAppWizStepDlg* Next(CAppWizStepDlg* pDlg);
		
	virtual void InitCustomAppWiz();
	virtual void ExitCustomAppWiz();
	virtual void CustomizeProject(IBuildProject* pProject);
};

// This declares the one instance of the CRebarSDIAppWiz class.  You can access
//  m_Dictionary and any other public members of this class through the
//  global RebarSDIaw.  (Its definition is in RebarSDIaw.cpp.)
extern CRebarSDIAppWiz RebarSDIaw;

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REBARSDIAW_H__EE40D783_90D0_11D3_879B_000000000000__INCLUDED_)
