// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__88959A7A_9087_11D3_9982_00500487D199__INCLUDED_)
#define AFX_MAINFRM_H__88959A7A_9087_11D3_9982_00500487D199__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CContainerView;
class CMainFrame : public CCJFrameWnd
{
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
public:

// Operations
public:
	CContainerView* GetMainView();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CCJStatusBar		m_wndStatusBar;
	CCJToolBar			m_wndToolBar;
	CCJWindowPlacement	m_state;
	CCJFlatComboBox*	m_pComboBox;
	CGfxSplitterWnd		m_wndSplitter;
	CGfxOutBarCtrl		m_wndOutlookBar;
	CImageList			m_ImageLarge, m_ImageSmall;
	BOOL				m_bPreview;

	enum { FOLDER_0, FOLDER_1 };
	enum { CMD_00, CMD_01, CMD_02, CMD_03, CMD_04, CMD_05, CMD_06, CMD_07 };

// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnClose();
	afx_msg void OnPreviewPane();
	afx_msg void OnUpdatePreviewPane(CCmdUI* pCmdUI);
	//}}AFX_MSG
	afx_msg long OnOutbarNotify(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__88959A7A_9087_11D3_9982_00500487D199__INCLUDED_)
