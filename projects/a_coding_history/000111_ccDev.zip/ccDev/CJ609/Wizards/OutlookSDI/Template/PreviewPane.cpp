// PreviewPane.cpp : implementation file
//

#include "stdafx.h"
#include "$$root$$.h"
#include "PreviewPane.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define CAPT_MAX_HEIGHT	35
#define CAPT_MIN_HEIGHT 5

#define TEXT_BOLD_LEFT	4
#define TEXT_NORM_LEFT	75
#define TEXT_LINE_ONE	4
#define TEXT_LINE_TWO	18

/////////////////////////////////////////////////////////////////////////////
// CPreviewPane

IMPLEMENT_DYNCREATE(CPreviewPane, CView)

CPreviewPane::CPreviewPane()
{
	m_strTitle1 = _T("Message:");
	m_strDescp1 = _T("Some words about this message");
	m_strTitle2 = _T("Content:");
	m_strDescp2 = _T("This message contains nothing special.");
	
	m_strViewMessage = _T("This area can be used for preview info...");
	m_clrViewMessage = RGB(255,255,255);

	m_bMax = TRUE;

	UpdateFont(m_NormFont);
	UpdateFont(m_BoldFont, FW_BOLD);
}

CPreviewPane::~CPreviewPane()
{
	m_NormFont.DeleteObject();
	m_BoldFont.DeleteObject();
}

BEGIN_MESSAGE_MAP(CPreviewPane, CView)
	//{{AFX_MSG_MAP(CPreviewPane)
	ON_WM_LBUTTONDBLCLK()
	ON_WM_ERASEBKGND()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPreviewPane drawing

void CPreviewPane::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
}

/////////////////////////////////////////////////////////////////////////////
// CPreviewPane diagnostics

#ifdef _DEBUG
void CPreviewPane::AssertValid() const
{
	CView::AssertValid();
}

void CPreviewPane::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPreviewPane message handlers

void CPreviewPane::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	// Toggle caption.
	if (m_rcCaption.PtInRect(point)) {
		m_bMax = !m_bMax;
		Invalidate();
	}
	
	CView::OnLButtonDblClk(nFlags, point);
}

BOOL CPreviewPane::OnEraseBkgnd(CDC* pDC) 
{
	// override to eliminate screen flicker.
	UNUSED_ALWAYS(pDC);
	return TRUE;
}

void CPreviewPane::UpdateFont(CFont& font, LONG lfWeight)
{
	font.DeleteObject();
	NONCLIENTMETRICS info;
	info.cbSize = sizeof(info);
	SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(info), &info, 0);
	info.lfMessageFont.lfWeight = lfWeight;
	VERIFY(font.CreateFontIndirect(&info.lfMessageFont));
}

void CPreviewPane::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// Get the client rect.
	CRect rcClient, rcClip;
	dc.GetClipBox( &rcClip );
	GetClientRect( &rcClient );

	// Create a memory device-context. This is done to help reduce
	// screen flicker, since we will paint the entire control to the
	// off screen device context first.
	CDC memDC;
	CBitmap bitmap;
	memDC.CreateCompatibleDC(&dc);
	bitmap.CreateCompatibleBitmap(&dc, rcClient.Width(), rcClient.Height());
	CBitmap* pOldBitmap = memDC.SelectObject(&bitmap);

	// Draw the view.
	DrawView(&memDC);

	// Copy the memory device context back into the original DC via BitBlt().
	dc.BitBlt( rcClip.left, rcClip.top, rcClip.Width(), rcClip.Height(), &memDC, 
		rcClip.left, rcClip.top, SRCCOPY );

	// Cleanup resources.
	memDC.SelectObject(pOldBitmap);
	memDC.DeleteDC();
	bitmap.DeleteObject();
}

void CPreviewPane::DrawView(CDC * pDC)
{
	// TODO: add draw code here
	GetWindowRect(&m_rcCaption);
	ScreenToClient(&m_rcCaption);
	pDC->FillSolidRect(m_rcCaption, ::GetSysColor(COLOR_WINDOW));
	m_rcView.CopyRect(m_rcCaption);

	m_rcCaption.bottom = m_bMax?CAPT_MAX_HEIGHT:CAPT_MIN_HEIGHT;
	m_rcView.top = m_rcCaption.bottom;

	pDC->FillSolidRect(m_rcCaption, ::GetSysColor(COLOR_BTNFACE));
	pDC->Draw3dRect(m_rcCaption, ::GetSysColor(COLOR_BTNHIGHLIGHT),
		::GetSysColor(COLOR_BTNSHADOW));
	pDC->SetBkMode(TRANSPARENT);

	if (m_bMax)
	{
		pDC->SelectObject(&m_BoldFont);

		pDC->TextOut(TEXT_BOLD_LEFT, TEXT_LINE_ONE, m_strTitle1);
		pDC->TextOut(TEXT_BOLD_LEFT, TEXT_LINE_TWO, m_strTitle2);

		pDC->SelectObject(&m_NormFont);
		pDC->TextOut(TEXT_NORM_LEFT, TEXT_LINE_ONE, m_strDescp1);
		pDC->TextOut(TEXT_NORM_LEFT, TEXT_LINE_TWO, m_strDescp2);
	}

	int y = 5+(m_bMax?33:0);
	pDC->SelectObject(&m_NormFont);
	pDC->TextOut(5, y, m_strViewMessage);
}
