#if !defined(AFX_CONTAINERVIEW_H__88959A86_9087_11D3_9982_00500487D199__INCLUDED_)
#define AFX_CONTAINERVIEW_H__88959A86_9087_11D3_9982_00500487D199__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ContainerView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CContainerView view

class CContainerView : public CView
{
protected:
	CContainerView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CContainerView)

// Attributes
public:
	CCJCaption			m_Caption;
	CCJFlatSplitterWnd	m_wndSplitter, m_wndSplitter2;
	CFont				m_CaptionFont;
	HICON				m_hIcon;

// Operations
public:
	CCJTreeCtrl* GetFolderTreeCtrl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CContainerView)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CContainerView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CContainerView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	afx_msg void OnCloseFolderListView(UINT lParam, LONG wParam);
	afx_msg void OnPushPinButton(UINT lParam, LONG wParam);
	afx_msg void OnPushPinCancel(UINT lParam, LONG wParam);
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONTAINERVIEW_H__88959A86_9087_11D3_9982_00500487D199__INCLUDED_)
