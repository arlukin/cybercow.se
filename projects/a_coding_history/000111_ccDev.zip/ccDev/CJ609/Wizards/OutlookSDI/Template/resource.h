//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by $$root$$.rc
//
#define IDD_ABOUTBOX                    100
#define ID_MENUBAR                      101
#define IDC_CAPT_BUTTON                 102
#define IDC_TREE_VIEW                   103
#define IDR_MAINFRAME                   128
#define IDR_$$DOC$$TYPE                  129
#define IDB_PUSHPIN                     130
#define IDI_ICON_OUTLOOK                132
#define IDI_ICON_INBOX                  133
#define IDI_ICON_CALENDAR               134
#define IDI_ICON_CONTACTS               135
#define IDI_ICON_TASKS                  136
#define IDI_ICON_JOURNAL                137
#define IDI_ICON_NOTES                  138
#define IDI_ICON_DELETED                139
#define IDI_ICON_DRAFTS                 140
#define IDI_ICON_OUTBOX                 141
#define IDI_ICON_SENT                   142
#define IDI_ICON_PUBLIC                 143
#define IDC_STATIC_ADDRESS              1000
#define IDC_CJ_LOGO                     1001
#define IDC_STATIC_MAILME               1002
#define ID_PLACEHOLDER                  32771
#define ID_PREVIEW_PANE                 32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
