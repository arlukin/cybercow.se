// ContainerView.cpp : implementation file
//

#include "stdafx.h"
#include "$$root$$.h"
#include "ContainerView.h"
#include "$$root$$View.h"
#include "FolderListView.h"
#include "PreviewPane.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CContainerView

IMPLEMENT_DYNCREATE(CContainerView, CView)

CContainerView::CContainerView()
{
	// define the caption font.
	NONCLIENTMETRICS ncm;
	memset(&ncm, 0, sizeof(NONCLIENTMETRICS));
	ncm.cbSize = sizeof(NONCLIENTMETRICS);

	VERIFY(::SystemParametersInfo(SPI_GETNONCLIENTMETRICS,
		sizeof(NONCLIENTMETRICS), &ncm, 0));
	ncm.lfMessageFont.lfWeight = 700;
	ncm.lfMessageFont.lfHeight = 20;
	_tcscpy(ncm.lfMessageFont.lfFaceName, _T("Arial"));
	m_CaptionFont.CreateFontIndirect(&ncm.lfMessageFont);

	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

CContainerView::~CContainerView()
{
}


BEGIN_MESSAGE_MAP(CContainerView, CView)
	//{{AFX_MSG_MAP(CContainerView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
	ON_MESSAGE(FM_CLOSEFOLDERLISTVIEW, OnCloseFolderListView)
	ON_MESSAGE(CM_ONPUSHPINBUTTON, OnPushPinButton)
	ON_MESSAGE(CM_ONPUSHPINCANCEL, OnPushPinCancel)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CContainerView drawing

void CContainerView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CContainerView diagnostics

#ifdef _DEBUG
void CContainerView::AssertValid() const
{
	CView::AssertValid();
}

void CContainerView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CContainerView message handlers

BOOL CContainerView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if(!CView::PreCreateWindow(cs))
		return FALSE;

	// TODO: Add your specialized code here and/or call the base class
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.dwExStyle |=  WS_EX_STATICEDGE;
	
	return TRUE;
}

int CContainerView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_Caption.Create(this, _T("Inbox")))
	{
		TRACE0( "Failed to caption window.\n" );
		return -1;
	}

	// set the caption colors.
	m_Caption.SetCaptionColors( ::GetSysColor(COLOR_BTNFACE),
		::GetSysColor(COLOR_BTNSHADOW), ::GetSysColor(COLOR_WINDOW));

	// set the caption style.
	m_Caption.ModifyCaptionStyle( 4, &m_CaptionFont, NULL, m_hIcon);

	// The context information is passed on from the framework
	CCreateContext *pContext = (CCreateContext*)lpCreateStruct->lpCreateParams;

	// Create the splitter window with two columns
	if (!m_wndSplitter.CreateStatic(this, 1, 2))
	{
		TRACE0("Failed to create splitter window\n");
		return FALSE;
	}

	if (!m_wndSplitter.CreateView(0,0,RUNTIME_CLASS(CFolderListView),
		CSize(175, 0), pContext))
	{
		m_wndSplitter.DestroyWindow();
		return -1;
	}

	// add the third splitter pane - which is a nested splitter with 2 rows
	if (!m_wndSplitter2.CreateStatic(&m_wndSplitter,	// our parent window is the first splitter
		2, 1,											// the new splitter is 2 rows, 1 column
		WS_CHILD | WS_VISIBLE | WS_BORDER,				// style, WS_BORDER is needed
		m_wndSplitter.IdFromRowCol(0, 1)))				// new splitter is in the first row, 3rd column of first splitter
	{
		TRACE0("Failed to create nested splitter\n");
		return FALSE;
	}

	// now create the two views inside the nested splitter
	if (!m_wndSplitter2.CreateView(0, 0, RUNTIME_CLASS(C$$Safe_root$$View),
		CSize(0, 300), pContext))
	{
		m_wndSplitter2.DestroyWindow();
		return FALSE;
	}

	if (!m_wndSplitter2.CreateView(1, 0, RUNTIME_CLASS(CPreviewPane),
		CSize(0, 0), pContext))
	{
		m_wndSplitter2.DestroyWindow();
		return FALSE;
	}

	// it all worked, we now have two splitter windows which contain
	// four different views
	
	return 0;
}

void CContainerView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	if( m_wndSplitter.GetSafeHwnd())
	{
		int nCX = ::GetSystemMetrics( SM_CXEDGE );
		int nCY = ::GetSystemMetrics( SM_CYEDGE );
		
		// move and grow view to clip border
		m_wndSplitter.MoveWindow(-nCX, 30, cx+(nCX*2), cy+(nCY*2)-34);	
	}

	if( m_Caption.GetSafeHwnd()) {
		m_Caption.MoveWindow(0,0,cx,31);
	}
}

BOOL CContainerView::OnEraseBkgnd(CDC* pDC) 
{
	UNUSED_ALWAYS(pDC);
	return FALSE;
}

void CContainerView::OnCloseFolderListView(UINT lParam, LONG wParam)
{
	m_Caption.SetChildWindow( &CFolderListView::m_TreeCtrl, this );
	m_wndSplitter.HideColumn(0);
}

void CContainerView::OnPushPinButton(UINT lParam, LONG wParam)
{
	m_wndSplitter.ShowColumn();
}

void CContainerView::OnPushPinCancel(UINT lParam, LONG wParam)
{
	// TODO: Add your message handler code here and/or call default
	
}

CCJTreeCtrl* CContainerView::GetFolderTreeCtrl()
{
	return &CFolderListView::m_TreeCtrl;
}
