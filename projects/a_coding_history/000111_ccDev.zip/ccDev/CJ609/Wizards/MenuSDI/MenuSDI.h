#if !defined(AFX_MENUSDI_H__EE40D737_90D0_11D3_879B_000000000000__INCLUDED_)
#define AFX_MENUSDI_H__EE40D737_90D0_11D3_879B_000000000000__INCLUDED_

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

// TODO: You may add any other custom AppWizard-wide declarations here.


//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MENUSDI_H__EE40D737_90D0_11D3_879B_000000000000__INCLUDED_)
