#if !defined(AFX_REBARMDIAW_H__EE40D7A6_90D0_11D3_879B_000000000000__INCLUDED_)
#define AFX_REBARMDIAW_H__EE40D7A6_90D0_11D3_879B_000000000000__INCLUDED_

// RebarMDIaw.h : header file
//

class CDialogChooser;

// All function calls made by mfcapwz.dll to this custom AppWizard (except for
//  GetCustomAppWizClass-- see RebarMDI.cpp) are through this class.  You may
//  choose to override more of the CCustomAppWiz virtual functions here to
//  further specialize the behavior of this custom AppWizard.
class CRebarMDIAppWiz : public CCustomAppWiz
{
public:
	virtual CAppWizStepDlg* Next(CAppWizStepDlg* pDlg);
		
	virtual void InitCustomAppWiz();
	virtual void ExitCustomAppWiz();
	virtual void CustomizeProject(IBuildProject* pProject);
};

// This declares the one instance of the CRebarMDIAppWiz class.  You can access
//  m_Dictionary and any other public members of this class through the
//  global RebarMDIaw.  (Its definition is in RebarMDIaw.cpp.)
extern CRebarMDIAppWiz RebarMDIaw;

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REBARMDIAW_H__EE40D7A6_90D0_11D3_879B_000000000000__INCLUDED_)
