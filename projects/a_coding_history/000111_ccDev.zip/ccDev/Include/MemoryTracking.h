/*	Author:	Stefan Soltsien
	Date:	26.5.99
--------------------------------------------------------------------------------------------------------------------------------------
	Usage:
	to detect memory leaks in you applications, you just have to add the
	following lines anywhere to your application code:

	#include "MemoryTracking.h"
	USE_MEMORYTRACKING(MT,"f:\\cybercow\\bin\\memdump.cpp",true)
	#pragma warning(disable:4073)							
	#pragma warning(disable:4786)
	#pragma init_seg(lib)

	o	the path in the #include-statement has to be adapted to your needs

	o	The Macro 
		USE_MEMORYTRACKING(MT,"c:\\temp\\allocations.log", bLogAtStartup)
		defines the name of the Logfile (if NULL, all output is written 
		to the debug output window) and	specifies, whether logging is on 
		or off on startup

	o	To control the parts of your program where logging is on / off
		use the macros
			LOGGING_ON / LOGGING_OFF
		or 
			BEGIN_NO_LOG_BLOCK / END_NO_LOG_BLOCK 
		to switch off logging for a special part of code.
		

	Then:
	- recompile you program (rebuild is NOT neccessary)
	- start your program, and invoke those parts of it, where the leaks occur
	- terminate the program and you'll get a list of  memory leaks in your 
		debug window of VC++
	- open the log file, that is defined with the macro USE_MEMORYTRACKING 
		(see above) or take a look into the VC++ debug output window, depending
		if you have defined a log file
	- compare the numbers enclosed in curly braces with the 'request'-numbers 
		in the log file (or in the debug output window)
	By looking at the call stack in the logfile, you may figure out which 
	function or method has allocated the leak.
	If MFC is used, you may add the line '#define new DEBUG_NEW' to the cpp
	files. Thus you provide information about where allocations occur. For 
	allocations (leaks) that have been made with DEBUG_NEW defined you can 
	simply double-click the line preceeding the call stack of a leak descrip-
	tion (in the debug output window) to jump to the appropriate position in 
	the source code.

	!!! Please note that this mechanism only works in Debug mode and 
		that it severly affects the execution speed of your program.
--------------------------------------------------------------------------------------------------------------------------------------
*/


#ifndef _INC_MEMORY_TRACKING_H_
#define _INC_MEMORY_TRACKING_H_

#ifndef _DEBUG
#error	Memory tracking does only work in Debug mode
#endif
#ifdef _UNICODE
#error	Memory tracking does not work with unicode
#endif
#if !defined(_WIN32) || !defined(_X86_)
#error	This code only works on Win32 platforms on Intel X86 machines
#endif

#pragma message("Note: memory tracking is enabled, this will slow down the execution speed of you program dramatically")

#include <windows.h>
#include <crtdbg.h>
#include <assert.h>
#include <imagehlp.h>
#pragma warning(disable:4786)
#include <map>
#include <vector>

#define MAXNAMELEN 1024 // max name length for found symbols
#define IMGSYMLEN ( sizeof IMAGEHLP_SYMBOL )


// Macros to start / stop logging;
	// stop loggin within the enclosed block of code
#define BEGIN_NO_LOG_BLOCK						\
	{	bool oldVal = MemoryTracker::m_bLog;	\
		MemoryTracker::m_bLog = false;
#define END_NO_LOG_BLOCK						\
		MemoryTracker::m_bLog = oldVal;			\
	}

//	these macros should be used only once in your program to 
//	start for example the logging at a certain point in your
//	program
#define LOGGING_ON	MemoryTracker::m_bLog = true;
#define LOGGING_OFF	MemoryTracker::m_bLog = false;



// Initialisation of static and global variables
#define USE_MEMORYTRACKING(__LogFile, bInitiallyLogging)			\
	char			MemoryTracker::szMsg[1000+MAX_PATH];			\
	bool			MemoryTracker::m_bLog = bInitiallyLogging;		\
	MemoryTracker	*MemoryTracker::m_Instance		= NULL;			\
	const char		*MemoryTracker::m_LogfileName	= __LogFile;	\
	MemoryTracker	__Instance;

//	link the imagehlp library
#pragma comment( lib, "imagehlp.lib" )
#pragma warning( disable : 4786 )

//	aus ...\DevStudio\vc\crt\dbgint.h
#define nNoMansLandSize 4

//	aus ...\DevStudio\vc\crt\dbgint.h
typedef struct _CrtMemBlockHeader
{
        struct _CrtMemBlockHeader * pBlockHeaderNext;
        struct _CrtMemBlockHeader * pBlockHeaderPrev;
        char *                      szFileName;
        int                         nLine;
        size_t                      nDataSize;
        int                         nBlockUse;
        long                        lRequest;
        unsigned char               gap[nNoMansLandSize];
        /* followed by:
         *  unsigned char           data[nDataSize];
         *  unsigned char           anotherGap[nNoMansLandSize];
         */
} _CrtMemBlockHeader;

// helpers to convert pointer to memory on the heap <--> _CrtMemBlockHeader
#define Block(data) (((_CrtMemBlockHeader *)data)-1)


// from STL to overwrite the allocations of a vector and a map in a way that
//	their "internal" allocations are not logged.
// The code has been copied from the STL source files and then modified to my needs
		// TEMPLATE FUNCTION _Allocate
template<class _Ty> 
inline _Ty _FARQ *_Allocate(_PDFT _N, _Ty _FARQ *)
{	if(_N<0)
		_N = 0;
	return (_Ty _FARQ *)::GlobalAlloc(GMEM_FIXED, (_SIZT)_N *sizeof(_Ty));
//	return ((_Ty _FARQ *)operator new((_SIZT)_N * sizeof (_Ty)));
}

		// TEMPLATE FUNCTION _Construct
template<class _T1, class _T2>
inline void _Construct(_T1 _FARQ *_P, const _T2& _V)
{	
	*_P = _V;
//	new ((void _FARQ *)_P) _T1(_V);
}

// overwrites for TEMPLATE FUNCTION _Destroy
	// pointers themselves must not be destroyed, the memory pointed to
	//	is freed in the destructors of CallStack and MemoryTracker
inline void _Destroy(char*)
{}
inline void _Destroy(char**)
{}
		// TEMPLATE CLASS allocator
template<class _Ty> class MyAllocator
{
public:
	typedef _SIZT size_type;
	typedef _PDFT difference_type;
	typedef _Ty _FARQ *pointer;
	typedef const _Ty _FARQ *const_pointer;
	typedef _Ty _FARQ& reference;
	typedef const _Ty _FARQ& const_reference;
	typedef _Ty value_type;

	pointer address(reference _X) const
		{	return (&_X);
		}
	const_pointer address(const_reference _X) const
		{	return (&_X);
		}
	pointer allocate(size_type _N, const void *)
		{	return (_Allocate((difference_type)_N, (pointer)0));
		}
	char _FARQ *_Charalloc(size_type _N)
		{	return (_Allocate((difference_type)_N, (char _FARQ *)0));
		}
	void deallocate(void _FARQ *_P, size_type)
		{	//operator delete(_P);
			::GlobalFree(_P);
		}
	void construct(pointer _P, const _Ty& _V)
		{	_Construct(_P, _V);
		}
	void destroy(pointer _P)
		{	_Destroy(_P);
		}
	_SIZT max_size() const
		{	_SIZT _N = (_SIZT)(-1) / sizeof (_Ty);
			return (0 < _N ? _N : 1);
		}
	};

//----------------------------------------------------------------------------
// class MemoryTracker
//	this class does not really have a public interface. All neccessary
//	work is done within the _ctor/_dtor. The static methods
class MemoryTracker
{
private:
	// used to find a memory block when a block is deallocted
	struct DeleteHookInfo
	{	void *data;
		bool ignore;
		long request;
	};

	// stores the strings that describe an allocation (contains the callstack)
	struct CallStack	: private std::vector<LPSTR, MyAllocator<LPSTR> >
	{
	private:
		std::vector<LPSTR, MyAllocator<LPSTR> >::iterator iter;
	public:
		~CallStack()
			{	BEGIN_NO_LOG_BLOCK
					for(iter=begin(); iter!=end(); ++iter)
						::GlobalFree(*iter);
				END_NO_LOG_BLOCK
			}

		void Add(LPCSTR str)
			{	BEGIN_NO_LOG_BLOCK
					int		len = strlen(str)+1;
					LPSTR	p = (LPSTR)::GlobalAlloc(GMEM_FIXED,len);
					memcpy(p, str, len);
					push_back(p);
				END_NO_LOG_BLOCK
			}
		void Dump(HANDLE file)
			{	if( file!=NULL && file!=INVALID_HANDLE_VALUE)
				{	DWORD	dw;
					for(iter=begin(); iter!=end(); ++iter)
						::WriteFile(file,*iter, strlen(*iter), &dw, NULL);
				} else
				{	for(iter=begin(); iter!=end(); ++iter)
						::OutputDebugString(*iter);
				}
			}		
	};

public:

		// Constructor
	MemoryTracker()
		:	m_file(INVALID_HANDLE_VALUE), m_hMutex(NULL), m_oldHook(NULL)
		{
			m_hMutex = ::CreateMutex(NULL, false, "MemoryTracker_Mutex");
			if(::GetLastError()==ERROR_ALREADY_EXISTS)
			{	::OutputDebugString("#### WARNING: #####\nDetected more than one instance of MemoryTracker; this instance is disabled.\n");
				assert(0);		// valid only for one component at a time
				::CloseHandle(m_hMutex);
				m_hMutex = NULL;
				return;
			}


			if( m_Instance==NULL )	// singleton
				m_Instance = this;
	
			// create/truncate the logfile if specified
			if( MemoryTracker::m_LogfileName )
			{	m_file = ::CreateFile(m_LogfileName,
									GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
									FILE_ATTRIBUTE_NORMAL, NULL);
				if( m_file!=INVALID_HANDLE_VALUE )
					::SetFilePointer(m_file, 0, NULL, FILE_BEGIN);
			}

			// set the hook that traces all allocations via new, malloc, realloc
			m_oldHook = _CrtSetAllocHook(&MemoryTracker::AllocHook);
			// load the debug info to map an address in a callstack to the symbol 
			//	name of the function or method
			::OutputDebugString( "Initializing Symbol Files ...\n" );
			::SymInitialize( ::GetCurrentProcess(), NULL, true );
			::OutputDebugString( "Initializing Symbol Files ... done\nFound Modules:\n" );
			// show which debug info modules are loaded
			::SymEnumerateModules(::GetCurrentProcess(), &MemoryTracker::SymEnumModulesCallback, NULL);
		}

	// Destructor
	~MemoryTracker()
		{	if( m_file==INVALID_HANDLE_VALUE )
				::OutputDebugString( "======== Memory Allocation Dump ========\n" );
			// dump the callstacks for all memory leaks
			BEGIN_NO_LOG_BLOCK
				for( TCallstackMap::iterator iter=m_BlockMap.begin(); iter!=m_BlockMap.end(); ++iter )
				{	(*iter).second->Dump(m_file);
					::Sleep(10);	// stupid, but neccessary, don't know why
					(*iter).second->~CallStack();
					::GlobalFree((*iter).second);
				}
				char buffer[100];
				::Sleep(1000);	// wait for buffers to be flushed before terminating
				if( m_file==INVALID_HANDLE_VALUE )
					::OutputDebugString( "======== End of Memory Allocation Dump ========\n" );
				// show total number of leaks
				sprintf(buffer, "Number of Memory Leaks in Module: %d\n", m_BlockMap.size() );
				if( m_file!=INVALID_HANDLE_VALUE )
				{	DWORD dw;
					::WriteFile(m_file, buffer, strlen(buffer), &dw, NULL);
				}
				::OutputDebugString( buffer );
				// clean-up
				m_BlockMap.clear();
				if( m_file!=INVALID_HANDLE_VALUE )
				{	::FlushFileBuffers(m_file);
					::CloseHandle(m_file);
				}
			END_NO_LOG_BLOCK

			::SymCleanup( ::GetCurrentProcess() );
			if( m_hMutex )
				::_CrtSetAllocHook(m_oldHook);
			m_Instance = NULL;
			if( m_hMutex )
				::CloseHandle(m_hMutex);
		}

private:
		// callback to enumerate the debug info modules, that are loaded
	static BOOL CALLBACK SymEnumModulesCallback(LPSTR ModuleName, ULONG BaseOfDll, PVOID)
		{	sprintf(szMsg, "\t%s\tBase: %d\n", ModuleName, BaseOfDll);
			::OutputDebugString(szMsg);
			return TRUE;
		}
 
		// hook that is called for each new/delete malloc/realloc/free call
		// not called for Windows API functions like VirtualAlloc, GlobalAlloc etc.
	static int AllocHook(int allocType,	// one of: _HOOK_ALLOC / _HOOK_REALLOC / _HOOK_FREE
					void *userData,		// valid for delete / free
					size_t size, 
					int blockType,
					long request,
					const unsigned char *filename,	// filename and lineNumber is info that comes with 
					int lineNumber)			//	_dbg_malloc, _dbg_free methods (can be 
											//	activated with MFC's '#define new DEBUG_NEW')
		{
			if( m_bLog==false || m_Instance==NULL )		// logging off or not yet initialized
				return TRUE;
														// reporting is switched off
			if( !(_CrtSetDbgFlag(_CRTDBG_REPORT_FLAG) & _CRTDBG_ALLOC_MEM_DF) )
				return TRUE;

			strcpy(szMsg, "<unknown call of AllocHook>");
			const char *const bt = blockType==_FREE_BLOCK ? "_FREE_BLOCK" :
									blockType==_NORMAL_BLOCK ? "_NORMAL_BLOCK" :
									blockType==_CRT_BLOCK ? "_CRT_BLOCK" :
									blockType==_IGNORE_BLOCK ? "_IGNORE_BLOCK" :
									blockType==_CLIENT_BLOCK ? "_CLIENT_BLOCK" :
									blockType==_MAX_BLOCKS ? "_MAX_BLOCKS" : 
															"<Unknown block>";

			if( allocType==_HOOK_ALLOC )
			{	if( filename==NULL && lineNumber==0 )
					sprintf(szMsg, "Alloc: request=%d, size=%d, blocktype=%s, file=%s, line=%d\n",
							request, size, bt, filename, lineNumber);
				else
					sprintf(szMsg, "%s(%d) : request=%d, size=%d, blocktype=%s\n",
							filename, lineNumber, request, size, bt);
			} else if(allocType==_HOOK_REALLOC)
			{	if( filename==NULL && lineNumber==0 )
					sprintf(szMsg, "Realloc: request=%d, size=%d, ptr=%p, blocktype=%s, file=%s, line=%d\n",
							request, size, userData, bt, filename, lineNumber);								
				else
					sprintf(szMsg, "%s(%d) : request=%d, size=%d, blocktype=%s\n",
							filename, lineNumber, request, size, bt);
			} else if(allocType==_HOOK_FREE)
				sprintf(szMsg, "Free: request=%d, size=%d, ptr=%p, blocktype=%s, file=%s, line=%d\n",
							request, size, userData, bt, filename, lineNumber);								
			else
				sprintf(szMsg, "<unknown allocType>: %d\n", allocType);

			// don't trace CRT allocations
			if( blockType==_CRT_BLOCK )
				return TRUE;

			// get the call stack
			CONTEXT ctx;
			memset( &ctx, 0, sizeof(CONTEXT) );
			ctx.ContextFlags = CONTEXT_FULL;

			if( allocType==_HOOK_ALLOC || allocType==_HOOK_REALLOC )
			{	// init CONTEXT record so we know where to start the stackwalk
				if( ::GetThreadContext( ::GetCurrentThread(), &ctx ))
				{	BEGIN_NO_LOG_BLOCK
						CallStack *pCallStack = (CallStack*)::GlobalAlloc(GMEM_FIXED,sizeof(CallStack));
						pCallStack->Add(szMsg);	// 1st line contains reqest number, blocktype etc.
						ShowStack( ::GetCurrentThread(), ctx, pCallStack );	// reads the callstack
						m_Instance->m_BlockMap[request] = pCallStack;	// store
					END_NO_LOG_BLOCK
				}
			} else if( allocType==_HOOK_FREE )
			{	_CrtMemBlockHeader *block = Block(userData);
				TCallstackMap::iterator iter = m_Instance->m_BlockMap.find(block->lRequest);
				if( iter!=m_Instance->m_BlockMap.end() )
				{	BEGIN_NO_LOG_BLOCK
						(*iter).second->~CallStack();
						::GlobalFree((*iter).second);
						m_Instance->m_BlockMap.erase(iter);
					END_NO_LOG_BLOCK
				}
			}
			return TRUE;
		}

		// convert a linear address, locates the module, section, 
		// 	and offset containing that address.
	static bool GetLogicalAddress(void *addr, char *module, DWORD len, DWORD& Section, DWORD& offset)
		{	MEMORY_BASIC_INFORMATION mbi;
			if( !::VirtualQuery(addr, &mbi, sizeof(mbi)) )
				return false;
			DWORD hMod = (DWORD)mbi.AllocationBase;
			if ( !::GetModuleFileName( (HMODULE)hMod, module, len ) )
				return false;
			// Point to the DOS header in memory
			PIMAGE_DOS_HEADER doshdr = (PIMAGE_DOS_HEADER)hMod;
			// From the DOS header, find the NT (PE) header
			PIMAGE_NT_HEADERS nthdr	= (PIMAGE_NT_HEADERS)(hMod +doshdr->e_lfanew);
			PIMAGE_SECTION_HEADER section = IMAGE_FIRST_SECTION(nthdr);
			DWORD Addr = (DWORD)addr -hMod; // offset from module load address
			// iterate through the section table, looking for the one that encompasses
			// the linear address.
			for(unsigned int i=0; i<nthdr->FileHeader.NumberOfSections; i++, section++ )
			{	DWORD start	= section->VirtualAddress;
				DWORD end	= start +max(section->SizeOfRawData, section->Misc.VirtualSize);
				// is the address in this section?
				if( Addr>=start && Addr<=end )
				{	// section and offset,
					Section = i +1;
					offset	= Addr -start;
					return true;
				}
			}
			return false;   // should never get here
		}

		// walks the call stack and logs the methodnames or function names
	static void ShowStack( HANDLE hThread, CONTEXT& ctx, CallStack *pCallStack )
		{	HANDLE			hProcess = ::GetCurrentProcess();
			DWORD			Offset = 0; // tells us how far from the symbol we were
			DWORD			Options;	// symbol handler settings
			STACKFRAME		sf;			// in/out stackframe
			IMAGEHLP_SYMBOL *sym = (IMAGEHLP_SYMBOL*)::GlobalAlloc(
										GMEM_ZEROINIT|GMEM_FIXED,IMGSYMLEN+MAXNAMELEN);
			char Name[MAXNAMELEN];		// undecorated name
			char FullName[MAXNAMELEN];	// undecorated name with all shenanigans

			if( sym==NULL )
				return;

			sym->SizeOfStruct	= IMGSYMLEN;
			sym->MaxNameLength	= MAXNAMELEN;
			
			memset(&sf, 0, sizeof(STACKFRAME));

			sf.AddrPC.Mode		= sf.AddrFrame.Mode	= sf.AddrStack.Mode	= AddrModeFlat;
			sf.AddrPC.Offset	= ctx.Eip;
			sf.AddrFrame.Offset	= ctx.Ebp;
			sf.AddrStack.Offset	= ctx.Esp;

			Options = ::SymGetOptions();
			Options &= ~SYMOPT_UNDNAME;
			::SymSetOptions(Options);
			
			// get next stack frame
			while(::StackWalk(IMAGE_FILE_MACHINE_I386, hProcess, hThread, &sf, &ctx, NULL,
							  &SymFunctionTableAccess, &SymGetModuleBase, NULL))
			{	
				// display its contents
				if ( sf.AddrPC.Offset != 0 )
				{	// we seem to have a valid PC -> show procedure info
					if ( ! ::SymGetSymFromAddr( hProcess, sf.AddrPC.Offset, &Offset, sym ) )
					{	if ( ::GetLastError() != 487 )	// 487 means: address not valid
						{	sprintf(szMsg, "\tSymGetSymFromAddr() failed with errorcode=%lu\n", ::GetLastError() );
							pCallStack->Add(szMsg);
						} else
						{	// if the address does not seem to be valid, we show at least
							// the name of the module, the section and offset
							char module[MAX_PATH] = "";
							DWORD section = 0, offset = 0;

							if( GetLogicalAddress((void*)(sf.AddrPC.Offset), module, MAX_PATH, section, offset))
								sprintf(szMsg, "\t%s\tsection: %d\toffset: %d\n", 
										module, section, offset);
							else	// can't find anything
								sprintf(szMsg,"\t(can't find symbol)\n");
							pCallStack->Add(szMsg);
						}
					} else
					{	// get the symbol's name
						::UnDecorateSymbolName(sym->Name, Name, MAXNAMELEN, UNDNAME_NAME_ONLY);
						::UnDecorateSymbolName(sym->Name, FullName, MAXNAMELEN, UNDNAME_COMPLETE);
						sprintf(szMsg, "\t%s", Name);
						if(Offset!=0)
							sprintf(szMsg, "%s %+ld bytes\tsig: %s\tdecl: %s\n", 
									szMsg, (long)Offset, sym->Name, FullName );
						// hide some internal calls below new operator (not interesting)
						if( !((!strcmp(Name, "NtLockVirtualMemory") && Offset==15 &&
							  !strcmp(sym->Name, "NtLockVirtualMemory") && 
							  !strcmp(FullName, "NtLockVirtualMemory")) ||
							 (!strcmp(Name, "__malloc_dbg") && Offset==30 &&
							  !strcmp(sym->Name, "__malloc_dbg") && 
							  !strcmp(FullName, "__malloc_dbg")) ||
							 (!strcmp(Name, "__heap_alloc_dbg") && Offset==127 &&
							  !strcmp(sym->Name, "__heap_alloc_dbg") && 
							  !strcmp(FullName, "__heap_alloc_dbg")) ||
							 (!strcmp(Name, "__nh_malloc_dbg") && Offset==35 &&
							  !strcmp(sym->Name, "__nh_malloc_dbg") && 
							  !strcmp(FullName, "__nh_malloc_dbg")) ||
							 (!strcmp(Name, "__nh_malloc") && Offset==22 &&
							  !strcmp(sym->Name, "__nh_malloc") && 
							  !strcmp(FullName, "__nh_malloc"))) )
							pCallStack->Add(szMsg);
					}
				} // no valid PC
			} // while(...)

			::ResumeThread(hThread);
			::GlobalFree(sym);
		}


private:
	typedef std::map<long, CallStack*, std::less<long>, MyAllocator<CallStack*> >	TCallstackMap;

	TCallstackMap	m_BlockMap;		// stores the callstack items
	_CRT_ALLOC_HOOK m_oldHook;
	HANDLE			m_file;			// handle to logfile
	HANDLE			m_hMutex;		// ensure that this is used as a singleton
	
	static MemoryTracker	*m_Instance;
	static char				szMsg[1000+MAX_PATH];	// temporary text buffer, should be
													//	large enough
public:
	static bool			m_bLog;				// logging switch
	static const char	*m_LogfileName;
};


#endif // _INC_MEMORY_TRACKING_H_