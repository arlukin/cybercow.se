


-++= B-Original V1.3a =++--
(Freeware edtion)


1.0 What is B-original ?
2.0 What's new in version 1.3a
3.0 How to install
3.1 How to install for dummies
3.2 How to use
3.3 How to uninstall (very unwise!)
3.4 How to get support


1.0 What is B-original ?

Well, I always liked it when people have those little quotes at the end of
their email messages. But when you mail with somebody and his/her email 
message always contain the same quote they are not that special anymore.
So that's why I created this tiny tool which uses a text file with a number
(not limited) of quotes in it and a mask file. The program runs in the system
tray of your Win95/Win98/WinNT4.0 (yes indeed, beside the clock) and picks up
a different quote from the text file every minute. This quote is then used 
with the mask file which creates a signature file. When you configure your
email program (e.g. Outlook, Eudora, Pegasus, Netscape Mail, or any other) to
use the signature file as signature you will get a different quote in your
signature every minute of the day !

2.0 What's new in version 1.3a

* Manual quote update (in case you don't like the quote that's choosen)
* Edit the quotes file from within the program
* Edit the mask file from within the program
* The input into the signature file is line orientated instead of character 
orientated, which means that there are no more problems with quotes containing
comma's or dots.
* Size of the program is reduced to less then 50 kb
* Unlimited quotes can be added to the quotes.txt file
* More quotes distributed with the program		

3.0 How to install.

B-original runs *ONLY* on Windows 95, Windows 98, Windows NT 4.0 workstation or
Windows NT 4.0 server. Because I wanted to keep the program as small as possible
I haven't created a setup program for it. The program only excists out of one
executable, two text files and one DLL file. The DLL file is not included in the
zip file you have downloaded because of it's size and most people already have
this DLL on their system installed by other applications. But in case you need
this file look at http://members.xoom.com/boriginal

To install B-original you just put the files (except the DLL that one belongs
in the windows\system folder) in a folder and create a shortcut in the 'startup'
folder of the start menu. If you don't get it read chapter 3.1 How to install 
for dummies.

3.1 How to install for dummies.

Unzip the files in a directory on your hard drive. Open the directory (folder)
and right click on borigv13.exe, select 'create shortcut'. Right click on the
just created shortcut and select 'cut'. Right click on the task bar and select
'properties'. Select the right tab 'Programs start menu' (or something like that,
I got a dutch version). Click 'advanced' , the explorer shows up and you select
the folder 'startup'. Right click on the startup folder or the left window, select
'paste'. Close the explorer and the properties screen of the taskbar. 

3.2 How to use.

Well, when you start B-original you just have to click on the icon in the system
tray to pop up the main (and only) window of B-original. Click on 'Edit Mask File'
to create your own personal signature mask. You can make this mask file as long 
or as short as you wish. Use %$% if you want a quote to appear in you signature.
(quotes will not been shown in the mask file) 

!!NOTE!! if you want to use the Edit Mask and Edit Quotes option in B-original
you have to have NOTEPAD.EXE installed. Standard Windows installations include
the installation of Notepad so 99% of the windows systems include this program.

Now you've created your mask file start you email program and find the option
which lets you configure the signature. Select the option to use a (text) file
for you signature. Select the signature.txt file in the B-original folder.

Done ! Now you can edit the quotes file to add, alter or remove quotes to the
file.

!!NOTE!! You can alter the quotes.txt file as much as you like but in no way
you should alter the text after the first dashed line. The program will not
run if you do so !

3.3 How to uninstall (very Unwise!)

Just remove the shortcut from the startup folder and delete the folder containing
B-original.

3.4 How to get support.

Visit the official B-original Homepage.
http://members.xoom.com/boriginal

Send mail to the author.
b-original@usa.net

---------------------------------
patrick van Kessel
Heerlen, The Netherlands


