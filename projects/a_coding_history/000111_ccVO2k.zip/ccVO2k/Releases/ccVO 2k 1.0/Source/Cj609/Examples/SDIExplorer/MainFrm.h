// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__0500578A_9090_11D3_9982_00500487D199__INCLUDED_)
#define AFX_MAINFRM_H__0500578A_9090_11D3_9982_00500487D199__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CLeftView;
class CSDIExplorerView;
class CMainFrame : public CCJFrameWnd
{
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
public:

// Operations
public:
	CSDIExplorerView*	GetRightPane();
	CLeftView*			GetLeftPane();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CCJFlatSplitterWnd	m_wndSplitter;
	CCJStatusBar		m_wndStatusBar;
	CCJToolBar  		m_wndToolBar;
	CCJReBar			m_wndReBar;
	CAnimateCtrl		m_wndAnimate;
	CFont				m_Font;
	CComboBox   		m_wndAddress;
	BOOL				m_bHidden;
	CStringArray		m_astrFavoriteURLs;

// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnBack();
	afx_msg void OnForward();
	afx_msg void OnUp();
	afx_msg void OnCut();
	afx_msg void OnCopy();
	afx_msg void OnPaste();
	afx_msg void OnUndo();
	afx_msg void OnDelete();
	afx_msg void OnProperties();
	afx_msg void OnViewToggle();
	afx_msg void OnViewAllfolders();
	afx_msg void OnUpdateViewAllfolders(CCmdUI* pCmdUI);
	//}}AFX_MSG
	afx_msg void OnUpdateViewStyles(CCmdUI* pCmdUI);
	afx_msg void OnViewStyle(UINT nCommandID);
	afx_msg void OnSelendokCombo();
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__0500578A_9090_11D3_9982_00500487D199__INCLUDED_)
