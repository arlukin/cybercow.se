// ClassWizPage2.h : header file
//

#ifndef __CLASSWIZPAGE2_H__
#define __CLASSWIZPAGE2_H__

/////////////////////////////////////////////////////////////////////////////
// CClassWizPage2 dialog

class CClassWizSheet;
class CClassWizPage2 : public CPropertyPage
{
	DECLARE_DYNCREATE(CClassWizPage2)

public:
	CClassWizSheet* GetParentSheet();

// Construction
public:
	void SetEnabled();
	CClassWizPage2();
	~CClassWizPage2();

// Dialog Data
	//{{AFX_DATA(CClassWizPage2)
	enum { IDD = IDD_CLASSWIZ_PAGE2 };
	CStatic	m_staticMicrosoft;
	CComboBox	m_comboSerialize;
	CButton	m_checkUseMFC;
	CButton	m_checkSerialize;
	CEdit	m_editHeader;
	CButton	m_checkHeader;
	BOOL	m_bHeader;
	CString	m_strHeader;
	BOOL	m_bSerialize;
	int		m_nSerialize;
	BOOL	m_bUseMFC;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CClassWizPage2)
	public:
	virtual BOOL OnSetActive();
	virtual BOOL OnWizardFinish();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CClassWizPage2)
	afx_msg void OnHeaderCheck2();
	afx_msg void OnUseMfcCheck();
	afx_msg void OnSerializeCheck();
	afx_msg void OnEditchangeSerializeCombo();
	afx_msg void OnChangeHeaderEdit();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

#endif // __CLASSWIZPAGE2_H__
