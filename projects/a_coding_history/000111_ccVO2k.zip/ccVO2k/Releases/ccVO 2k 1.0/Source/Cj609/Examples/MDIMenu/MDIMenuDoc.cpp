// MDIMenuDoc.cpp : implementation of the CMDIMenuDoc class
//

#include "stdafx.h"
#include "MDIMenu.h"

#include "MDIMenuDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMDIMenuDoc

IMPLEMENT_DYNCREATE(CMDIMenuDoc, CDocument)

BEGIN_MESSAGE_MAP(CMDIMenuDoc, CDocument)
	//{{AFX_MSG_MAP(CMDIMenuDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMDIMenuDoc construction/destruction

CMDIMenuDoc::CMDIMenuDoc()
{
	// TODO: add one-time construction code here

}

CMDIMenuDoc::~CMDIMenuDoc()
{
}

BOOL CMDIMenuDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CMDIMenuDoc serialization

void CMDIMenuDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMDIMenuDoc diagnostics

#ifdef _DEBUG
void CMDIMenuDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMDIMenuDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMDIMenuDoc commands
