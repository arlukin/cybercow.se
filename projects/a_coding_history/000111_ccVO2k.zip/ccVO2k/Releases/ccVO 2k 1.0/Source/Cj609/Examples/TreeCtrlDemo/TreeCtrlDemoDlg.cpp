// TreeCtrlDemoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TreeCtrlDemo.h"
#include "TreeCtrlDemoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	CCJHyperLink	m_staticEmail;
	CCJHyperLink	m_staticAddress;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Control(pDX, IDC_STATIC_MAILME, m_staticEmail);
	DDX_Control(pDX, IDC_STATIC_ADDRESS, m_staticAddress);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// set the hyperlinks and static font.
	m_staticEmail.SetURL(_T("mailto:kstowell@codejock.com"));
	m_staticAddress.SetURL(_T("http://www.codejock.com/"));

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

/////////////////////////////////////////////////////////////////////////////
// CTreeCtrlDemoDlg dialog

CTreeCtrlDemoDlg::CTreeCtrlDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTreeCtrlDemoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTreeCtrlDemoDlg)
	m_nIndex = 0;
	m_nSizeCombo = 0;
	m_bBoldCheck = FALSE;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_clrTreeText = ::GetSysColor(COLOR_WINDOWTEXT);
	m_strFontSize = _T("6");
}

void CTreeCtrlDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTreeCtrlDemoDlg)
	DDX_Control(pDX, IDC_SIZE_COMBO, m_SizeCombo);
	DDX_Control(pDX, IDC_COLOR_PICKER, m_ColorPicker);
	DDX_Control(pDX, IDC_TREE_CTRL, m_TreeCtrl);
	DDX_Control(pDX, IDC_FONT_COMBO, m_FontCombo);
	DDX_CBIndex(pDX, IDC_FONT_COMBO, m_nIndex);
	DDX_CBIndex(pDX, IDC_SIZE_COMBO, m_nSizeCombo);
	DDX_Check(pDX, IDC_BOLD_CHECK, m_bBoldCheck);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTreeCtrlDemoDlg, CDialog)
	//{{AFX_MSG_MAP(CTreeCtrlDemoDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BOLD_CHECK, OnBoldCheck)
	ON_BN_CLICKED(IDC_APPLY_BUTTON, OnApplyButton)
	ON_CBN_SELENDOK(IDC_SIZE_COMBO, OnSelendokSizeCombo)
	ON_CBN_SELENDOK(IDC_FONT_COMBO, OnSelendokFontCombo)
	//}}AFX_MSG_MAP
	ON_MESSAGE( CPN_SELENDOK,  OnSelEndOK )
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTreeCtrlDemoDlg message handlers

BOOL CTreeCtrlDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_ColorPicker.SetColor( m_clrTreeText );
	GetFont()->GetLogFont(&m_LogFont);
	
	m_TreeCtrl.EnableMultiSelect();
	m_ImageList.Create (IDB_TREE_IMAGES, 16, 1, RGB(0,255,0));
	m_TreeCtrl.SetImageList(&m_ImageList, TVSIL_NORMAL);

	HTREEITEM hti = m_TreeCtrl.InsertItem(_T("Root Item"), 0, 1);
	for( int i = 0; i < 10; ++i ) {
		m_TreeCtrl.InsertItem(_T("Child Item"), 0, 1, hti);
	}
	m_TreeCtrl.Expand(hti, TVE_EXPAND);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTreeCtrlDemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTreeCtrlDemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTreeCtrlDemoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CTreeCtrlDemoDlg::OnSelendokFontCombo() 
{
	m_FontCombo.GetSelFont( m_LogFont );
}

void CTreeCtrlDemoDlg::OnSelendokSizeCombo() 
{
	m_SizeCombo.GetWindowText(m_strFontSize);
}

void CTreeCtrlDemoDlg::OnBoldCheck() 
{
	UpdateData();
}

void CTreeCtrlDemoDlg::OnSelEndOK(UINT lParam, LONG wParam)
{
	// a color selection was made, update the 
	// appropriate member data.
	switch( wParam )
	{
	case IDC_COLOR_PICKER:
		m_clrTreeText = m_ColorPicker.GetColor();
		break;
	}
}

void CTreeCtrlDemoDlg::OnApplyButton() 
{
	HTREEITEM hItem = m_TreeCtrl.GetFirstSelectedItem();
	while( hItem != NULL )
	{
		HDC hDC = ::GetDC(m_TreeCtrl.m_hWnd);
		m_LogFont.lfHeight = -MulDiv(_ttoi(m_strFontSize), GetDeviceCaps(hDC, LOGPIXELSY), 72);
		m_TreeCtrl.SetItemFont ( hItem, m_LogFont );
		m_TreeCtrl.SetItemBold ( hItem, m_bBoldCheck );
		m_TreeCtrl.SetItemColor( hItem, m_clrTreeText );
		m_TreeCtrl.SendMessage( WM_ERASEBKGND, (WPARAM)hDC, (LPARAM)0 );
		m_TreeCtrl.Invalidate();
		::ReleaseDC(m_TreeCtrl.m_hWnd, hDC);

		hItem = m_TreeCtrl.GetNextSelectedItem( hItem );
	}
}
