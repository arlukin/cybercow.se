// SDIOutlookDoc.cpp : implementation of the CSDIOutlookDoc class
//

#include "stdafx.h"
#include "SDIOutlook.h"

#include "SDIOutlookDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSDIOutlookDoc

IMPLEMENT_DYNCREATE(CSDIOutlookDoc, CDocument)

BEGIN_MESSAGE_MAP(CSDIOutlookDoc, CDocument)
	//{{AFX_MSG_MAP(CSDIOutlookDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSDIOutlookDoc construction/destruction

CSDIOutlookDoc::CSDIOutlookDoc()
{
	// TODO: add one-time construction code here

}

CSDIOutlookDoc::~CSDIOutlookDoc()
{
}

BOOL CSDIOutlookDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CSDIOutlookDoc serialization

void CSDIOutlookDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CSDIOutlookDoc diagnostics

#ifdef _DEBUG
void CSDIOutlookDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CSDIOutlookDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSDIOutlookDoc commands
