// MDIDevStudioView.cpp : implementation of the CMDIDevStudioView class
//

#include "stdafx.h"
#include "MDIDevStudio.h"

#include "MDIDevStudioDoc.h"
#include "MDIDevStudioView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMDIDevStudioView

IMPLEMENT_DYNCREATE(CMDIDevStudioView, CView)

BEGIN_MESSAGE_MAP(CMDIDevStudioView, CView)
	//{{AFX_MSG_MAP(CMDIDevStudioView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMDIDevStudioView construction/destruction

CMDIDevStudioView::CMDIDevStudioView()
{
	// TODO: add construction code here

}

CMDIDevStudioView::~CMDIDevStudioView()
{
}

BOOL CMDIDevStudioView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMDIDevStudioView drawing

void CMDIDevStudioView::OnDraw(CDC* pDC)
{
	CMDIDevStudioDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CMDIDevStudioView printing

BOOL CMDIDevStudioView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CMDIDevStudioView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CMDIDevStudioView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CMDIDevStudioView diagnostics

#ifdef _DEBUG
void CMDIDevStudioView::AssertValid() const
{
	CView::AssertValid();
}

void CMDIDevStudioView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMDIDevStudioDoc* CMDIDevStudioView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMDIDevStudioDoc)));
	return (CMDIDevStudioDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMDIDevStudioView message handlers
