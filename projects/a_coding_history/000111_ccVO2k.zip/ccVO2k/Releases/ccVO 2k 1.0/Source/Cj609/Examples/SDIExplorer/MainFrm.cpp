// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "SDIExplorer.h"

#include "MainFrm.h"
#include "SDIExplorerView.h"
#include "LeftView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CCJFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CCJFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_BACK, OnBack)
	ON_COMMAND(ID_FORWARD, OnForward)
	ON_COMMAND(ID_UP, OnUp)
	ON_COMMAND(ID_CUT, OnCut)
	ON_COMMAND(ID_COPY, OnCopy)
	ON_COMMAND(ID_PASTE, OnPaste)
	ON_COMMAND(ID_UNDO, OnUndo)
	ON_COMMAND(ID_DELETE, OnDelete)
	ON_COMMAND(ID_PROPERTIES, OnProperties)
	ON_COMMAND(ID_VIEW_TOGGLE, OnViewToggle)
	ON_COMMAND(ID_VIEW_ALLFOLDERS, OnViewAllfolders)
	ON_UPDATE_COMMAND_UI(ID_VIEW_ALLFOLDERS, OnUpdateViewAllfolders)
	//}}AFX_MSG_MAP
	ON_UPDATE_COMMAND_UI_RANGE(IDX_VIEW_SMALLICON, IDX_VIEW_BYNAME, OnUpdateViewStyles)
	ON_COMMAND_RANGE(IDX_VIEW_SMALLICON, IDX_VIEW_BYNAME, OnViewStyle)
	ON_CBN_SELENDOK(AFX_IDW_TOOLBAR+1, OnSelendokCombo)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	NONCLIENTMETRICS ncm;
	memset(&ncm, 0, sizeof(NONCLIENTMETRICS));
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	VERIFY(::SystemParametersInfo(SPI_GETNONCLIENTMETRICS,
		sizeof(NONCLIENTMETRICS), &ncm, 0));
	m_Font.CreateFontIndirect(&ncm.lfMessageFont);

	m_bHidden = FALSE;
}

CMainFrame::~CMainFrame()
{
	m_Font.DeleteObject();
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CCJFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_ALIGN_TOP,
		CRect(0,0,0,0), AFX_IDW_TOOLBAR) ||
		!m_wndToolBar.LoadToolBar(IDR_NAVBAR))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	// set up toolbar properties
//	m_wndToolBar.GetToolBarCtrl().SetButtonWidth(50, 150);

	CString		str;
	CImageList	imageList;
	CBitmap		bitmap;

	// Create and set the normal toolbar image list.
	bitmap.LoadBitmap(IDB_COLDTOOLBAR);
	imageList.Create(22, 20, ILC_COLORDDB|ILC_MASK, 13, 1);
	imageList.Add(&bitmap, RGB(255,0,255));
	m_wndToolBar.GetToolBarCtrl().SetImageList(&imageList);
	imageList.Detach();
	bitmap.Detach();

	// Create and set the hot toolbar image list.
	bitmap.LoadBitmap(IDB_HOTTOOLBAR);
	imageList.Create(22, 20, ILC_COLORDDB|ILC_MASK, 13, 1);
	imageList.Add(&bitmap, RGB(255,0,255));
	m_wndToolBar.GetToolBarCtrl().SetHotImageList(&imageList);
	imageList.Detach();
	bitmap.Detach();
	
	// set text for each toolbar button.
	str.LoadString(IDS_BACK);
	m_wndToolBar.SetButtonText(m_wndToolBar.CommandToIndex(ID_BACK), str);
	str.LoadString(IDS_FORWARD);
	m_wndToolBar.SetButtonText(m_wndToolBar.CommandToIndex(ID_FORWARD), str);
	str.LoadString(IDS_UP);
	m_wndToolBar.SetButtonText(m_wndToolBar.CommandToIndex(ID_UP), str);
	str.LoadString(IDS_CUT);
	m_wndToolBar.SetButtonText(m_wndToolBar.CommandToIndex(ID_CUT), str);
	str.LoadString(IDS_COPY);
	m_wndToolBar.SetButtonText(m_wndToolBar.CommandToIndex(ID_COPY), str);
	str.LoadString(IDS_PASTE);
	m_wndToolBar.SetButtonText(m_wndToolBar.CommandToIndex(ID_PASTE), str);
	str.LoadString(IDS_UNDO);
	m_wndToolBar.SetButtonText(m_wndToolBar.CommandToIndex(ID_UNDO), str);
	str.LoadString(IDS_DELETE);
	m_wndToolBar.SetButtonText(m_wndToolBar.CommandToIndex(ID_DELETE), str);
	str.LoadString(IDS_PROPERTIES);
	m_wndToolBar.SetButtonText(m_wndToolBar.CommandToIndex(ID_PROPERTIES), str);
	str.LoadString(IDS_TOGGLE);
	m_wndToolBar.SetButtonText(m_wndToolBar.CommandToIndex(ID_VIEW_TOGGLE), str);

	CRect rectToolBar;

	// set up toolbar button sizes
	m_wndToolBar.GetItemRect(0, &rectToolBar);
	m_wndToolBar.SetSizes(rectToolBar.Size(), CSize(22,20));

	// add dropdown button.
	m_wndToolBar.AddDropDownButton(ID_BACK,		   IDR_DUMMY,   TRUE);
	m_wndToolBar.AddDropDownButton(ID_FORWARD,	   IDR_DUMMY,   TRUE);
	m_wndToolBar.AddDropDownButton(ID_VIEW_TOGGLE, IDR_POPDOWN, TRUE);

	// m_wndMenuBar is defined in the base class. It is important
	// that you use this member variable for the menu bar.
	if (!m_wndMenuBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_ALIGN_TOP,
		CRect(0,0,0,0), ID_MENUBAR) ||
		!m_wndMenuBar.LoadMenu(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndAddress.Create(CBS_DROPDOWN | WS_CHILD,
		CRect(0, 0, 200, 120), this, ID_ADDRESS))
	{
		TRACE0("Failed to create combobox\n");
		return -1;      // fail to create
	}

	m_wndAddress.SetFont(&m_Font);

	if (!m_wndAnimate.Create(WS_CHILD | WS_VISIBLE | ACS_AUTOPLAY,
		CRect(0,0,100,100), this, ID_ANIMATE) ||
		!m_wndAnimate.Open(IDR_VC))
	{
		TRACE0("Failed to create animation control.\n");
		return -1;      // fail to create
	}

	if (!m_wndReBar.Create(this) ||
		!m_wndReBar.AddBar(&m_wndMenuBar) ||
		!m_wndReBar.AddBar(&m_wndAnimate, NULL, NULL, RBBS_FIXEDBMP | RBBS_FIXEDSIZE) ||
		!m_wndReBar.AddBar(&m_wndToolBar, NULL, NULL, RBBS_FIXEDBMP | RBBS_BREAK) ||
		!m_wndReBar.AddBar(&m_wndAddress, _T("Address:"), NULL, RBBS_FIXEDBMP | RBBS_BREAK))
	{
		TRACE0("Failed to create rebar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Remove this if you don't want tool tips
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY);
	m_wndMenuBar.SetBarStyle(m_wndMenuBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY);
	m_wndReBar.SetBarStyle(m_wndReBar.GetBarStyle() |
		CBRS_BORDER_ANY );

	CCJShellList& listCtrl = GetRightPane()->GetListCtrl();
	CCJShellTree& treeCtrl = GetLeftPane()->GetTreeCtrl();

	listCtrl.AssociateTree(&treeCtrl);
	treeCtrl.AssociateList(&listCtrl);
	treeCtrl.AssociateCombo(&m_wndAddress);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// Call base class overload to eliminate screen flicker.
	if(!CCJFrameWnd::PreCreateWindow(cs, IDR_MAINFRAME)) {
		return FALSE;
	}

	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	cs.style = WS_OVERLAPPED|WS_CAPTION|WS_THICKFRAME|WS_SYSMENU|
		WS_MINIMIZEBOX|WS_MAXIMIZEBOX|WS_MAXIMIZE;

	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CCJFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CCJFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext) 
{
	// create splitter window
	if (!m_wndSplitter.CreateStatic(this, 1, 2))
		return FALSE;

	if (!m_wndSplitter.CreateView(0, 0, RUNTIME_CLASS(CLeftView), CSize(200, 100), pContext) ||
		!m_wndSplitter.CreateView(0, 1, RUNTIME_CLASS(CSDIExplorerView), CSize(100, 100), pContext))
	{
		m_wndSplitter.DestroyWindow();
		return FALSE;
	}

	return TRUE;
}

CSDIExplorerView* CMainFrame::GetRightPane()
{
	CWnd* pWnd = m_wndSplitter.GetPane(0, m_bHidden?0:1);
	CSDIExplorerView* pView = DYNAMIC_DOWNCAST(CSDIExplorerView, pWnd);
	return pView;
}

CLeftView* CMainFrame::GetLeftPane()
{
	CWnd* pWnd = m_wndSplitter.GetPane(0, 0);
	CLeftView* pView = DYNAMIC_DOWNCAST(CLeftView, pWnd);
	return m_bHidden?NULL:pView;
}

void CMainFrame::OnUpdateViewStyles(CCmdUI* pCmdUI)
{
	// TODO: customize or extend this code to handle choices on the
	// View menu.

	CCJShellList* pList = &GetRightPane()->GetListCtrl();

	// if the right-hand pane hasn't been created or isn't a view,
	// disable commands in our range

	if (pList == NULL)
		pCmdUI->Enable(FALSE);
	else
	{
		DWORD dwStyle = pList->GetStyle() & LVS_TYPEMASK;

		// if the command is IDX_VIEW_LINEUP, only enable command
		// when we're in LVS_ICON or LVS_SMALLICON mode

		if (pCmdUI->m_nID == IDX_VIEW_LINEUP)
		{
			if (dwStyle == LVS_ICON || dwStyle == LVS_SMALLICON)
				pCmdUI->Enable();
			else
				pCmdUI->Enable(FALSE);
		}
		else
		{
			// otherwise, use dots to reflect the style of the view
			pCmdUI->Enable();
			BOOL bChecked = FALSE;

			switch (pCmdUI->m_nID)
			{
			case IDX_VIEW_DETAILS:
				bChecked = (dwStyle == LVS_REPORT);
				break;

			case IDX_VIEW_SMALLICON:
				bChecked = (dwStyle == LVS_SMALLICON);
				break;

			case IDX_VIEW_LARGEICON:
				bChecked = (dwStyle == LVS_ICON);
				break;

			case IDX_VIEW_LIST:
				bChecked = (dwStyle == LVS_LIST);
				break;

			default:
				bChecked = FALSE;
				break;
			}

			pCmdUI->SetRadio(bChecked ? 1 : 0);
		}
	}
}


void CMainFrame::OnViewStyle(UINT nCommandID)
{
	// TODO: customize or extend this code to handle choices on the
	// View menu.
	CCJShellList* pList = &GetRightPane()->GetListCtrl();

	// if the right-hand pane has been created and is a CSDIExplorerView,
	// process the menu commands...
	if (pList != NULL)
	{
		DWORD dwStyle = -1;

		switch (nCommandID)
		{
		case IDX_VIEW_LINEUP:
			{
				// ask the list control to snap to grid
				pList->Arrange(LVA_SNAPTOGRID);
			}
			break;

		// other commands change the style on the list control
		case IDX_VIEW_DETAILS:
			dwStyle = LVS_REPORT;
			break;

		case IDX_VIEW_SMALLICON:
			dwStyle = LVS_SMALLICON;
			break;

		case IDX_VIEW_LARGEICON:
			dwStyle = LVS_ICON;
			break;

		case IDX_VIEW_LIST:
			dwStyle = LVS_LIST;
			break;
		}

		// change the style; window will repaint automatically
		if (dwStyle != -1)
			pList->ModifyStyle(LVS_TYPEMASK, dwStyle);
	}
}

void CMainFrame::OnBack() 
{
	// TODO: Add your command handler code here
	
}

void CMainFrame::OnForward() 
{
	// TODO: Add your command handler code here
	
}

void CMainFrame::OnUp() 
{
	// TODO: Add your command handler code here
	
}

void CMainFrame::OnCut() 
{
	// TODO: Add your command handler code here
	
}

void CMainFrame::OnCopy() 
{
	// TODO: Add your command handler code here
	
}

void CMainFrame::OnPaste() 
{
	// TODO: Add your command handler code here

}

void CMainFrame::OnUndo() 
{
	// TODO: Add your command handler code here
	
}

void CMainFrame::OnDelete() 
{
	// TODO: Add your command handler code here
	
}

void CMainFrame::OnProperties() 
{
	// TODO: Add your command handler code here
	
}

void CMainFrame::OnViewToggle() 
{
	// TODO: Add your command handler code here
	
}

void CMainFrame::OnViewAllfolders() 
{
	if( m_bHidden ) {
		m_wndSplitter.ShowColumn();
	}
	else {
		m_wndSplitter.HideColumn(0);
	}
	m_bHidden = !m_bHidden;
}

void CMainFrame::OnUpdateViewAllfolders(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(!m_bHidden);
}

void CMainFrame::OnSelendokCombo() 
{
	CString strText;
	m_wndAddress.GetLBText(m_wndAddress.GetCurSel(), strText);
	CLeftView* pView = GetLeftPane();
	if(pView) {
		GetLeftPane()->GetTreeCtrl().TunnelTree(strText);
	}
}
