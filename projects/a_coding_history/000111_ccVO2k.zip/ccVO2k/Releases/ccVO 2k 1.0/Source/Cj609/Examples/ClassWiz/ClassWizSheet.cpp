// ClassWizSheet.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "ClassWizSheet.h"
#include "ClassWizPage1.h"
#include "ClassWizPage2.h"
#include "CJHyperLink.h"
#include <dos.h>
#include <direct.h>

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	CCJHyperLink	m_staticEmail;
	CCJHyperLink	m_staticAddress;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Control(pDX, IDC_STATIC_MAILME, m_staticEmail);
	DDX_Control(pDX, IDC_STATIC_ADDRESS, m_staticAddress);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// set the hyperlinks and static font.
	m_staticEmail.SetURL(_T("mailto:kstowell@codejock.com"));
	m_staticAddress.SetURL(_T("http://www.codejock.com/"));

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

/////////////////////////////////////////////////////////////////////////////
// CClassWizSheet

CClassWizSheet::CClassWizSheet(CWnd* pWndParent)
	 : CPropertySheet(IDS_PROPSHT_CAPTION, pWndParent)
{
	//{{AFX_DATA_INIT(CClassWizSheet)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	AddPages();

	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

CClassWizSheet::~CClassWizSheet()
{
	RemovePages();
}

void CClassWizSheet::DoDataExchange(CDataExchange* pDX) 
{
	CPropertySheet::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CClassWizSheet)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

IMPLEMENT_DYNAMIC(CClassWizSheet, CPropertySheet)

BEGIN_MESSAGE_MAP(CClassWizSheet, CPropertySheet)
	//{{AFX_MSG_MAP(CClassWizSheet)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDHELP, OnSheetAbout)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CClassWizSheet::AddPages()
{
	m_Page1 = new CClassWizPage1;
	AddPage(m_Page1);

	m_Page2 = new CClassWizPage2;
	AddPage(m_Page2);

	SetWizardMode();
}

void CClassWizSheet::RemovePages()
{
	_delete(m_Page1);
	_delete(m_Page2);
}

/////////////////////////////////////////////////////////////////////////////
// CClassWizSheet message handlers

BOOL CClassWizSheet::OnInitDialog() 
{
	BOOL bResult = CPropertySheet::OnInitDialog();
	
	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	CWnd* pButton = (CWnd*)GetDlgItem(IDHELP);
	ASSERT_KINDOF(CWnd, pButton);

	pButton->SetWindowText(_T("About..."));
	pButton->UpdateWindow();

	// Get the log font.
	NONCLIENTMETRICS ncm;
	memset(&ncm, 0, sizeof(NONCLIENTMETRICS));
	ncm.cbSize = sizeof(NONCLIENTMETRICS);

	VERIFY(::SystemParametersInfo(SPI_GETNONCLIENTMETRICS,
		sizeof(NONCLIENTMETRICS), &ncm, 0));
	
	ncm.lfMessageFont.lfWeight = 700;
	m_BoldFont.CreateFontIndirect(&ncm.lfMessageFont);

	m_Page1->m_staticFile.SetFont(&m_BoldFont);
	m_Page1->m_staticClass.SetFont(&m_BoldFont);
	SetActivePage(1);
	m_Page2->m_staticMicrosoft.SetFont(&m_BoldFont);
	SetActivePage(0);

	return bResult;
}

void CClassWizSheet::OnSysCommand(UINT nID, LPARAM lParam) 
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CPropertySheet::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CClassWizSheet::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CPropertySheet::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.

HCURSOR CClassWizSheet::OnQueryDragIcon() 
{
	return (HCURSOR) m_hIcon;
}

void CClassWizSheet::OnSheetAbout()
{
	CAboutDlg dlgAbout;
	dlgAbout.DoModal();
}

static CString csMacroH[] =
{
	_T("DECLARE_DYNAMIC"),
	_T("DECLARE_DYNCREATE"),
	_T("DECLARE_SERIAL")
};

static CString csMacroCPP[] =
{
	_T("IMPLEMENT_DYNAMIC"),
	_T("IMPLEMENT_DYNCREATE"),
	_T("IMPLEMENT_SERIAL")
};

void CClassWizSheet::OnFinish()
{
	WriteHeaderFile();
	WriteImplementationFile();
}

void CClassWizSheet::WriteHeaderFile()
{
	CString csOutput;
	csOutput.Format(_T("%s\\%s"), m_Page1->m_strLocationH, m_Page1->m_strClassNameH);
	CString cs(m_Page1->m_strClassName.Right(m_Page1->m_strClassName.GetLength()-1));
	cs.MakeUpper();

	fstream fp(csOutput,ios::out,filebuf::sh_write);
	
	fp << "// " << m_Page1->m_strClassNameH << " : header file" << endl;

	WriteHeader(fp);

	fp << "/////////////////////////////////////////////////////////////////////////////" << endl;
	fp << "" << endl;
	fp << "#ifndef __" << cs << "_H__" << endl;
	fp << "#define __" << cs << "_H__" << endl;
	fp << "" << endl;
	
	if (m_Page2->m_bUseMFC)
	{
		fp << "#if _MSC_VER >= 1000" << endl;
		fp << "#pragma once" << endl;
		fp << "#endif // _MSC_VER >= 1000" << endl;
		fp << "" << endl;
	}
	
	if (m_Page1->m_bDerivedFrom)
	{
		if (m_Page1->m_bInclude)
		{
			fp << m_Page1->m_strInclude << endl;
			fp << "" << endl;
		}
	}
	
	fp << "/////////////////////////////////////////////////////////////////////////////" << endl;
	fp << "// " << m_Page1->m_strClassName << " class" << endl;
	fp << "" << endl;
	fp << "class " << m_Page1->m_strClassName;
	
	if(m_Page1->m_bDerivedFrom)
	{
		CString strAs; m_Page1->m_comboAs.GetLBText(m_Page1->m_nAs, strAs);
		fp << " : " << strAs << " " << m_Page1->m_strDerivedFrom;
	}
	
	fp << endl;
	fp << "{" << endl;
	
	if (m_Page2->m_bUseMFC)
	{
		if (m_Page1->m_bDerivedFrom)
		{
			if (m_Page2->m_bSerialize)
			{
				fp << "\t" << csMacroH[m_Page2->m_nSerialize] << "(" << m_Page1->m_strClassName << ")" << endl;
				fp << endl;
			}
		}
	}

	fp << "// Construction" << endl;
	fp << "public:" << endl;
	fp << "\t" << m_Page1->m_strClassName << "();" << endl;
	fp << endl;
	fp << "// Attributes" << endl;
	fp << "public:" << endl;
	fp << "" << endl;
	fp << "// Operations" << endl;
	fp << "public:" << endl;
	fp << endl;
	
	if(m_Page2->m_bUseMFC)
	{
		if(m_Page1->m_bDerivedFrom)
		{
			fp << "// Overrides" << endl;
			fp << "\t// ClassWizard generated virtual function overrides" << endl;
			fp << "\t//{{AFX_VIRTUAL(" << m_Page1->m_strClassName << ")" << endl;
			fp << "\t//}}AFX_VIRTUAL" << endl;
			fp << endl;
		}
	}

	fp << "// Implementation" << endl;
	fp << "public:" << endl;
	fp << "\tvirtual ~" << m_Page1->m_strClassName << "();" << endl;
	
	if(m_Page2->m_bUseMFC)
	{
		if(m_Page1->m_bDerivedFrom)
		{
			fp << "" << endl;
			fp << "// Generated message map functions" << endl;
			fp << "protected:" << endl;
			fp << "\t//{{AFX_MSG(" << m_Page1->m_strClassName << ")" << endl;
			fp << "\t\t// NOTE - the ClassWizard will add and remove member functions here." << endl;
			fp << "\t\t//    DO NOT EDIT what you see in these blocks of generated code !" << endl;
			fp << "\t//}}AFX_MSG" << endl;
			fp << "\tDECLARE_MESSAGE_MAP()" << endl;
		}
	}

	fp << "};" << endl;
	fp << "" << endl;
	fp << "/////////////////////////////////////////////////////////////////////////////" << endl;
	fp << "" << endl;

	if(m_Page2->m_bUseMFC)
	{
		if(m_Page1->m_bDerivedFrom)
		{
			fp << "//{{AFX_INSERT_LOCATION}}" << endl;
			fp << "// Microsoft Developer Studio will insert additional declarations immediately before the previous line." << endl;
			fp << "" << endl;
		}
	}

	fp << "#endif // __" << cs << "_H__" << endl;
	fp << "" << endl;
}

void CClassWizSheet::WriteImplementationFile()
{
	CString csOutput;
	csOutput.Format(_T("%s\\%s"), m_Page1->m_strLocationCPP, m_Page1->m_strClassNameCPP);

	fstream fp(csOutput,ios::out,filebuf::sh_write);

	fp << "// " << m_Page1->m_strClassNameCPP << " : implementation file" << endl;

	WriteHeader(fp);

	fp << "/////////////////////////////////////////////////////////////////////////////" << endl;
	fp << "" << endl;
	
	fp << "#include \"StdAfx.h\"" << endl;
	fp << "#include \"Resource.h\"" << endl;
	fp << "#include \"" << m_Page1->m_strClassNameH << "\"" << endl;
	fp << "" << endl;

	if(m_Page2->m_bUseMFC)
	{
		fp << "#ifdef _DEBUG" << endl;
		fp << "#define new DEBUG_NEW" << endl;
		fp << "#undef THIS_FILE" << endl;
		fp << "static char THIS_FILE[] = __FILE__;" << endl;
		fp << "#endif" << endl;
		fp << "" << endl;
	}

	fp << "/////////////////////////////////////////////////////////////////////////////" << endl;
	fp << "// " << m_Page1->m_strClassName << endl;
	fp << endl;
	fp << m_Page1->m_strClassName << "::" << m_Page1->m_strClassName << "()" << endl;
	fp << "{" << endl;
	fp << "\t// TODO: add construction code here." << endl;
	fp << "}" << endl;
	fp << endl;
	fp << m_Page1->m_strClassName << "::~" << m_Page1->m_strClassName << "()" << endl;
	fp << "{" << endl;
	fp << "\t// TODO: add destruction code here." << endl;
	fp << "}" << endl;
	fp << endl;

	if(m_Page2->m_bUseMFC)
	{
		if(m_Page1->m_bDerivedFrom)
		{
			if(m_Page2->m_bSerialize)
			{
				fp << csMacroCPP[m_Page2->m_nSerialize] << "(" << m_Page1->m_strClassName << ", " << m_Page1->m_strDerivedFrom << ")" << endl;
				fp << endl;
			}

			fp << "BEGIN_MESSAGE_MAP(" << m_Page1->m_strClassName << ", " << m_Page1->m_strDerivedFrom << ")" << endl;
			fp << "\t//{{AFX_MSG_MAP(" << m_Page1->m_strClassName << ")" << endl;
			fp << "\t\t// NOTE - the ClassWizard will add and remove mapping macros here." << endl;
			fp << "\t\t//    DO NOT EDIT what you see in these blocks of generated code!" << endl;
			fp << "\t//}}AFX_MSG_MAP" << endl;
			fp << "END_MESSAGE_MAP()" << endl;
			fp << endl;
		}
	}

	fp << "/////////////////////////////////////////////////////////////////////////////" << endl;

	if(m_Page2->m_bUseMFC)
	{
		fp << "// " << m_Page1->m_strClassName << " message handlers" << endl;
	}

	fp << endl;
}

void CClassWizSheet::WriteHeader(fstream fp)
{
	if (m_Page2->m_bHeader) {
		Remove(m_Page2->m_strHeader);
		fp << m_Page2->m_strHeader;
	}
	
	else {
		fp << "//" <<  endl;
	}
}

void CClassWizSheet::Remove(CString & strHeader)
{
	CString strTemp = _T("");
	char* szHeader = (char*)(LPCTSTR)strHeader;
	int nLen = strHeader.GetLength();

	for (int i = 0; i < nLen; ++i)
	{
		if (szHeader[i] == '\r')
			continue;
		strTemp += szHeader[i];
	}
	strHeader = strTemp;
}

