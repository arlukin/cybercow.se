// ChildFrm.cpp : implementation of the CChildFrame class
//

#include "stdafx.h"
#include "MDIDevStudio.h"

#include "ChildFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildFrame

IMPLEMENT_DYNCREATE(CChildFrame, CCJMDIChildWnd)

BEGIN_MESSAGE_MAP(CChildFrame, CCJMDIChildWnd)
	//{{AFX_MSG_MAP(CChildFrame)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChildFrame construction/destruction

CChildFrame::CChildFrame()
{
	// TODO: add member initialization code here
	
}

CChildFrame::~CChildFrame()
{
}

BOOL CChildFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CCJMDIChildWnd::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CChildFrame diagnostics

#ifdef _DEBUG
void CChildFrame::AssertValid() const
{
	CCJMDIChildWnd::AssertValid();
}

void CChildFrame::Dump(CDumpContext& dc) const
{
	CCJMDIChildWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CChildFrame message handlers

int CChildFrame::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CCJMDIChildWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	{
		m_blankBar1.m_eChildBorder = RAISED;

		if( !m_blankBar1.Create(this, ID_VIEW_BLANK_1,
			_T("Blank One"), CSize(150, 75), CBRS_RIGHT ))
		{
			TRACE0("Failed to create dialog bar m_blankBar1\n");
			return -1;		// fail to create
		}

		m_blankBar1.EnableDockingOnSizeBar( CBRS_ALIGN_ANY );
		EnableDockingSizeBar( CBRS_ALIGN_ANY );
		DockSizeBar( &m_blankBar1 );
	}
	{
		m_blankBar2.m_eChildBorder = RAISED;

		if( !m_blankBar2.Create(this, ID_VIEW_BLANK_1,
			_T("Blank Two"), CSize(150, 75), CBRS_RIGHT ))
		{
			TRACE0("Failed to create dialog bar m_blankBar2\n");
			return -1;		// fail to create
		}

		m_blankBar2.EnableDockingOnSizeBar( CBRS_ALIGN_ANY );
		EnableDockingSizeBar( CBRS_ALIGN_ANY );
		DockSizeBar( &m_blankBar2 );
	}

	return 0;
}
