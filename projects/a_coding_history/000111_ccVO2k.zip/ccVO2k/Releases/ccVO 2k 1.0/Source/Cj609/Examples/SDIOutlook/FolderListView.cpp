// FolderListView.cpp : implementation file
//

#include "stdafx.h"
#include "SDIOutlook.h"
#include "FolderListView.h"
#include "ContainerView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFolderListView

CCJTreeCtrl	CFolderListView::m_TreeCtrl;

IMPLEMENT_DYNCREATE(CFolderListView, CView)

CFolderListView::CFolderListView()
{
	// Create the image list used by frame buttons.
	m_ImageList.Create( IDB_PUSHPIN, 16, 1, RGB( 255, 0, 255 ));

	// Create the image list used by the tree control.
	m_ImageSmall.Create (16, 16, TRUE, 2, 1);

	for( int nIcon = IDI_ICON_OUTLOOK; nIcon <= IDI_ICON_PUBLIC; ++nIcon ) 
	{
		HICON hIcon = AfxGetApp()->LoadIcon(nIcon);
		ASSERT(hIcon);

		m_ImageSmall.Add(hIcon);
	}
}

CFolderListView::~CFolderListView()
{
	m_ImageList.DeleteImageList();
	m_ImageSmall.DeleteImageList();
}

BEGIN_MESSAGE_MAP(CFolderListView, CView)
	//{{AFX_MSG_MAP(CFolderListView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_BN_CLICKED(IDC_CAPT_BUTTON, OnCaptButton)
	ON_NOTIFY(TVN_SELCHANGED, IDC_TREE_VIEW, OnSelchanged)
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFolderListView drawing

void CFolderListView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CFolderListView diagnostics

#ifdef _DEBUG
void CFolderListView::AssertValid() const
{
	CView::AssertValid();
}

void CFolderListView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CFolderListView message handlers

int CFolderListView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// Create the caption.
	if (!m_Caption.Create(this, _T("Folder List")))
	{
		TRACE0( "Unable to create caption.\n" );
		return -1;
	}

	// Create the caption button.
	if (!m_CaptionButton.Create(NULL, WS_VISIBLE|BS_ICON|BS_OWNERDRAW|BS_CENTER|BS_VCENTER,
		CRect(0,0,0,0), this, IDC_CAPT_BUTTON))
	{
		TRACE0( "Unable to create caption button.\n" );
		return -1;
	}
	
	// set the caption buttons icon.
	m_CaptionButton.SetIcon( m_ImageList.ExtractIcon(2), CSize( 16, 15 ));
	
	// create the tree control.
	if (!m_TreeCtrl.Create(WS_VISIBLE, CRect(0,0,0,0), this, IDC_TREE_VIEW))
	{
		TRACE0( "Unable to create tree control.\n" );
		return -1;
	}

	// set the tree controls image list.
	m_TreeCtrl.SetImageList( &m_ImageSmall, TVSIL_NORMAL );

	// add items to the tree control.
	HTREEITEM hti = m_TreeCtrl.InsertItem( _T("Outlook Today"), 0, 0);

	m_TreeCtrl.InsertItem( _T("Calendar"),		 2,  2, hti);
	m_TreeCtrl.InsertItem( _T("Contacts"),		 3,  3, hti);
	m_TreeCtrl.InsertItem( _T("Deleted Items"),  7,  7, hti);
	m_TreeCtrl.InsertItem( _T("Drafts"),		 8,  8, hti);
	m_TreeCtrl.InsertItem( _T("Inbox"),			 1,  1, hti);
	m_TreeCtrl.InsertItem( _T("Journal"),		 5,  5, hti);
	m_TreeCtrl.InsertItem( _T("Notes"),			 6,  6, hti);
	m_TreeCtrl.InsertItem( _T("Outbox"),		 9,  9, hti);
	m_TreeCtrl.InsertItem( _T("Sent Items"),	10, 10, hti);
	m_TreeCtrl.InsertItem( _T("Tasks"),			 4,  4, hti);

	m_TreeCtrl.Expand( hti, TVE_EXPAND );
	m_TreeCtrl.SelectItem( hti );

	return 0;
}

void CFolderListView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	if( m_Caption.GetSafeHwnd()) {
		m_Caption.MoveWindow( 0, 0, cx, 19 );
	}

	if( m_CaptionButton.GetSafeHwnd()) {
		m_CaptionButton.MoveWindow( cx-18, 2, 16, 15 );
	}

	if( m_TreeCtrl.GetSafeHwnd()) {
		m_TreeCtrl.MoveWindow( 0, 19, cx, cy-19 );
	}
}

void CFolderListView::OnCaptButton()
{
	GetParent()->GetParent()->SendMessage( FM_CLOSEFOLDERLISTVIEW, 0, 0 );
}

void CFolderListView::OnSelchanged(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;

	int nImage;
	HTREEITEM htItem = m_TreeCtrl.GetSelectedItem();
	m_TreeCtrl.GetItemImage( htItem, nImage, nImage );

	CContainerView* pView = DYNAMIC_DOWNCAST(CContainerView, GetParent()->GetParent());
	ASSERT_KINDOF(CContainerView, pView);

	pView->m_Caption.UpdateCaption(m_TreeCtrl.GetItemText( htItem ),
		m_ImageSmall.ExtractIcon(nImage));

	*pResult = 0;
}

BOOL CFolderListView::OnEraseBkgnd(CDC* pDC) 
{
	UNUSED_ALWAYS(pDC);
	return TRUE;
}
