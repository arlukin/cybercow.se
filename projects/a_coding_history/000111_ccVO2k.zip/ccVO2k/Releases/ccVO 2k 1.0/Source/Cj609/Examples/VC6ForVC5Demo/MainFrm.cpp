// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "VC6ForVC5Demo.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CCJFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CCJFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CCJFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}
	if (!m_wndDlgBar.Create(this, IDR_MAINFRAME, 
		CBRS_ALIGN_TOP, AFX_IDW_DIALOGBAR))
	{
		TRACE0("Failed to create dialogbar\n");
		return -1;		// fail to create
	}
	
	// m_wndMenuBar is defined in the base class. It is important
	// that you use this member variable for the menu bar.
	if (!m_wndMenuBar.CreateEx(this) ||
		!m_wndMenuBar.LoadMenu(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	// Create the extended combo box
	if (!m_v6ComboBox.Create(CBS_DROPDOWN | WS_CHILD, 
		CRect(0,0,200,200), this, AFX_IDW_TOOLBAR + 1))
	{
		TRACE("Failed to create combobox\n");
		return -1;		// fail to create
	}

	// Create the bitmap associated with image list, this
	// is done so we can use high color while maintaining
	// background transparency...
	m_hBmp = (HBITMAP)::LoadImage(
		AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_IMAGES),
		IMAGE_BITMAP, 112, 16, LR_LOADTRANSPARENT); 

	// Create the image list from the HBITMAP handle we just
	// created...
	CImageList imageList;
	imageList.Create(16, 16, ILC_COLOR32|ILC_MASK, 7, 1);
	imageList.Add(CBitmap::FromHandle(m_hBmp), RGB(255, 0, 255));

	// Associate the image list with the combo box, and then
	// detach it...
	m_v6ComboBox.SetImageList(&imageList);
	imageList.Detach();

	// insert strings into the combo box.
	// arg1 - item index.
	// arg2 - string resource.
	// arg3 - ammount (in pixels) image is to be indented.
	// arg4 - image index.
	// arg5 - selected image index.
	// arg6 - mask (using default).
	m_v6ComboBox.InsertItem(0, IDS_Item0, 0, 0, 0);
	m_v6ComboBox.InsertItem(1, IDS_Item1, 1, 1, 1);
	m_v6ComboBox.InsertItem(2, IDS_Item2, 2, 2, 2);
	m_v6ComboBox.InsertItem(3, IDS_Item3, 2, 3, 3);
	m_v6ComboBox.InsertItem(4, IDS_Item4, 2, 4, 4);
	m_v6ComboBox.InsertItem(5, IDS_Item5, 2, 5, 5);
	m_v6ComboBox.InsertItem(6, IDS_Item6, 2, 6, 6);

	m_v6ComboBox.SetCurSel(0);
	m_v6MonthCal.SubclassDlgItem( IDC_CALENDAR, &m_wndDlgBar );
	m_v6Date.SubclassDlgItem( IDC_DATE, &m_wndDlgBar );
	m_v6Time.SubclassDlgItem( IDC_TIME, &m_wndDlgBar );
	m_v6Time.SetFormat(_T("hh':'mm':'ss tt"));

	if (!m_wndReBar.Create(this) ||
		!m_wndReBar.AddBar(&m_wndMenuBar) ||
		!m_wndReBar.AddBar(&m_wndToolBar, NULL, NULL, RBBS_FIXEDBMP | RBBS_BREAK) ||
		!m_wndReBar.AddBar(&m_wndDlgBar) ||
		!m_wndReBar.AddBar(&m_v6ComboBox, "Address:", NULL, RBBS_BREAK | RBBS_GRIPPERALWAYS | RBBS_FIXEDBMP))
	{
		TRACE0("Failed to create rebar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Remove this if you don't want tool tips or a resizeable toolbar
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY);
	m_wndMenuBar.SetBarStyle(m_wndMenuBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY);
	m_wndReBar.SetBarStyle(m_wndReBar.GetBarStyle() |
		CBRS_BORDER_ANY );

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// Call base class overload to eliminate screen flicker.
	if(!CCJFrameWnd::PreCreateWindow(cs, IDR_MAINFRAME)) {
		return FALSE;
	}

	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CCJFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CCJFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers
