#if !defined(AFX_OUTBARVIEW_H__790EB214_2913_11D3_ABAE_94F400C10000__INCLUDED_)
#define AFX_OUTBARVIEW_H__790EB214_2913_11D3_ABAE_94F400C10000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OutbarView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COutbarView view

class COutbarView : public CView
{
protected:
	COutbarView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(COutbarView)

// Attributes
public:
protected:
	CCJOutlookBar	m_OutlookBar;
	CCJPagerCtrl	m_Pager;
	CRect			m_pRect;
	CImageList		m_ImageList;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COutbarView)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~COutbarView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(COutbarView)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	afx_msg void OnSelEndOK(UINT lParam, LONG wParam);
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OUTBARVIEW_H__790EB214_2913_11D3_ABAE_94F400C10000__INCLUDED_)
