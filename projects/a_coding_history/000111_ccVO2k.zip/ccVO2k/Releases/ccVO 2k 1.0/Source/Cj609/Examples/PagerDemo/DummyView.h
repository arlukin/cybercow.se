#if !defined(AFX_DUMMYVIEW_H__790EB215_2913_11D3_ABAE_94F400C10000__INCLUDED_)
#define AFX_DUMMYVIEW_H__790EB215_2913_11D3_ABAE_94F400C10000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DummyView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDummyView view

class CDummyView : public CView
{
protected:
	CDummyView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CDummyView)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDummyView)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CDummyView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CDummyView)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DUMMYVIEW_H__790EB215_2913_11D3_ABAE_94F400C10000__INCLUDED_)
