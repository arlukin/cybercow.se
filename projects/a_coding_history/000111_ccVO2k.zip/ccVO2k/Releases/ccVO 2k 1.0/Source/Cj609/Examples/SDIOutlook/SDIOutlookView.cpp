// SDIOutlookView.cpp : implementation of the CSDIOutlookView class
//

#include "stdafx.h"
#include "SDIOutlook.h"

#include "SDIOutlookDoc.h"
#include "SDIOutlookView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSDIOutlookView

IMPLEMENT_DYNCREATE(CSDIOutlookView, CView)

BEGIN_MESSAGE_MAP(CSDIOutlookView, CView)
	//{{AFX_MSG_MAP(CSDIOutlookView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSDIOutlookView construction/destruction

CSDIOutlookView::CSDIOutlookView()
{
	// TODO: add construction code here

}

CSDIOutlookView::~CSDIOutlookView()
{
}

BOOL CSDIOutlookView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CSDIOutlookView drawing

void CSDIOutlookView::OnDraw(CDC* pDC)
{
	CSDIOutlookDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CSDIOutlookView printing

BOOL CSDIOutlookView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CSDIOutlookView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CSDIOutlookView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CSDIOutlookView diagnostics

#ifdef _DEBUG
void CSDIOutlookView::AssertValid() const
{
	CView::AssertValid();
}

void CSDIOutlookView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CSDIOutlookDoc* CSDIOutlookView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSDIOutlookDoc)));
	return (CSDIOutlookDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSDIOutlookView message handlers
