// TabResourceView.cpp : implementation of the CTabResourceView class
//

#include "stdafx.h"
#include "SDIDevStudio.h"

#include "TabResourceDoc.h"
#include "TabResourceView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTabResourceView

IMPLEMENT_DYNCREATE(CTabResourceView, CTreeView)

BEGIN_MESSAGE_MAP(CTabResourceView, CTreeView)
	//{{AFX_MSG_MAP(CTabResourceView)
	ON_WM_ERASEBKGND()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CTreeView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CTreeView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CTreeView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTabResourceView construction/destruction

CTabResourceView::CTabResourceView()
{
	// TODO: add construction code here
	m_pTreeCtrl = NULL;
}

CTabResourceView::~CTabResourceView()
{
	m_ImageList.DeleteImageList();
}

BOOL CTabResourceView::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CTreeView::PreCreateWindow( cs ))
		return FALSE;

	// set the style for the tree control.
	cs.style |= TVS_HASBUTTONS|TVS_HASLINES|TVS_LINESATROOT;

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CTabResourceView drawing

void CTabResourceView::OnDraw(CDC* pDC)
{
	CTabResourceDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

void CTabResourceView::OnInitialUpdate()
{
	CTreeView::OnInitialUpdate();

	// Save a pointer to the tree control.
	m_pTreeCtrl = &GetTreeCtrl();

	// Create the image list for the tree control
	m_ImageList.Create (IDB_IL_RSRC, 16, 1, RGB(0,255,0));
	m_pTreeCtrl->SetImageList (&m_ImageList, TVSIL_NORMAL);

	// Initialize the view.
	UpdateView();
}

/////////////////////////////////////////////////////////////////////////////
// CTabResourceView printing

BOOL CTabResourceView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CTabResourceView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CTabResourceView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CTabResourceView diagnostics

#ifdef _DEBUG
void CTabResourceView::AssertValid() const
{
	CTreeView::AssertValid();
}

void CTabResourceView::Dump(CDumpContext& dc) const
{
	CTreeView::Dump(dc);
}

CTabResourceDoc* CTabResourceView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTabResourceDoc)));
	return (CTabResourceDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTabResourceView message handlers

void CTabResourceView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	// TODO: Add your specialized code here and/or call the base class

}

void CTabResourceView::UpdateView()
{
	if( m_pTreeCtrl && m_pTreeCtrl->GetSafeHwnd( ))
	{
		m_pTreeCtrl->LockWindowUpdate();
		
		CString strTreeItems[] = { _T("Tab resources"), _T("Accelerator"), _T("Bitmap"), _T("Dialog"), _T("Icon"), _T("Menu"), _T("String Table"), _T("Toolbar"), _T("Version") };
		
		// add the parent item
		HTREEITEM htItem = m_pTreeCtrl->InsertItem (strTreeItems[0], 1, 1);
		m_pTreeCtrl->SetItemState (htItem, TVIS_BOLD, TVIS_BOLD);
		
		// add children items
		for (int i = 1; i < 9; i++) {
			m_pTreeCtrl->InsertItem (strTreeItems[i], 0, 1, htItem, TVI_LAST);
		}
		
		m_pTreeCtrl->Expand (htItem, TVE_EXPAND);
		
		m_pTreeCtrl->UnlockWindowUpdate();
	}
}

BOOL CTabResourceView::OnEraseBkgnd(CDC* pDC) 
{
	// KStowell - overridden for flicker-free drawing.
	UNUSED_ALWAYS(pDC);
	return TRUE;
}

void CTabResourceView::OnPaint() 
{
    // Use a "Offscreen" DC to fill rect and send to DefWindowProc...  
	CClientDC memDC(this);
	
    CRect rcClip;
    GetClientRect(&rcClip);
    memDC.FillSolidRect(rcClip, ::GetSysColor(COLOR_WINDOW));
    DefWindowProc( WM_PAINT, (WPARAM)memDC.m_hDC, (LPARAM)0 );
	
    // Default is called for cleanup.
    Default();
}
