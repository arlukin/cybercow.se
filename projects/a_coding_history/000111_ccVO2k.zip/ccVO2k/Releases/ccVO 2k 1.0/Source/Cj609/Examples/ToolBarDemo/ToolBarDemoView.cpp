// ToolBarDemoView.cpp : implementation of the CToolBarDemoView class
//

#include "stdafx.h"
#include "ToolBarDemo.h"

#include "ToolBarDemoDoc.h"
#include "ToolBarDemoView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CToolBarDemoView

IMPLEMENT_DYNCREATE(CToolBarDemoView, CView)

BEGIN_MESSAGE_MAP(CToolBarDemoView, CView)
	//{{AFX_MSG_MAP(CToolBarDemoView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CToolBarDemoView construction/destruction

CToolBarDemoView::CToolBarDemoView()
{
	// TODO: add construction code here

}

CToolBarDemoView::~CToolBarDemoView()
{
}

BOOL CToolBarDemoView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CToolBarDemoView drawing

void CToolBarDemoView::OnDraw(CDC* pDC)
{
	CToolBarDemoDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CToolBarDemoView printing

BOOL CToolBarDemoView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CToolBarDemoView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CToolBarDemoView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CToolBarDemoView diagnostics

#ifdef _DEBUG
void CToolBarDemoView::AssertValid() const
{
	CView::AssertValid();
}

void CToolBarDemoView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CToolBarDemoDoc* CToolBarDemoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CToolBarDemoDoc)));
	return (CToolBarDemoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CToolBarDemoView message handlers
