// MDIRebarDoc.cpp : implementation of the CMDIRebarDoc class
//

#include "stdafx.h"
#include "MDIRebar.h"

#include "MDIRebarDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMDIRebarDoc

IMPLEMENT_DYNCREATE(CMDIRebarDoc, CDocument)

BEGIN_MESSAGE_MAP(CMDIRebarDoc, CDocument)
	//{{AFX_MSG_MAP(CMDIRebarDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMDIRebarDoc construction/destruction

CMDIRebarDoc::CMDIRebarDoc()
{
	// TODO: add one-time construction code here

}

CMDIRebarDoc::~CMDIRebarDoc()
{
}

BOOL CMDIRebarDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CMDIRebarDoc serialization

void CMDIRebarDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMDIRebarDoc diagnostics

#ifdef _DEBUG
void CMDIRebarDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMDIRebarDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMDIRebarDoc commands
