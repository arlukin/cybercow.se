// SDIDevStudioDoc.h : interface of the CSDIDevStudioDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SDIDEVSTUDIODOC_H__1340F3FC_9081_11D3_9982_00500487D199__INCLUDED_)
#define AFX_SDIDEVSTUDIODOC_H__1340F3FC_9081_11D3_9982_00500487D199__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


class CSDIDevStudioDoc : public CDocument
{
protected: // create from serialization only
	CSDIDevStudioDoc();
	DECLARE_DYNCREATE(CSDIDevStudioDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSDIDevStudioDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CSDIDevStudioDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CSDIDevStudioDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SDIDEVSTUDIODOC_H__1340F3FC_9081_11D3_9982_00500487D199__INCLUDED_)
