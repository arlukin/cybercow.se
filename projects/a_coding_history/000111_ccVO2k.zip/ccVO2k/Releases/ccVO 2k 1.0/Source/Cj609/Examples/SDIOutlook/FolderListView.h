#if !defined(AFX_FOLDERLISTVIEW_H__33B79F65_355D_11D3_9922_00500487D199__INCLUDED_)
#define AFX_FOLDERLISTVIEW_H__33B79F65_355D_11D3_9922_00500487D199__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FolderListView.h : header file
//

#define FM_CLOSEFOLDERLISTVIEW		(WM_USER + 100)

/////////////////////////////////////////////////////////////////////////////
// CFolderListView view

class CFolderListView : public CView
{
protected:
	CFolderListView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CFolderListView)

// Attributes
public:

// Operations
public:

	CCJCaption		m_Caption;			// frame caption contains 
	CCJFlatButton	m_CaptionButton;	// close button located on frame
	CImageList		m_ImageList, m_ImageSmall;
	
	// static because we need to access control even when
	// the parent view is not visible.
	static CCJTreeCtrl	m_TreeCtrl;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFolderListView)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CFolderListView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CFolderListView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnCaptButton();
	afx_msg void OnSelchanged(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOLDERLISTVIEW_H__33B79F65_355D_11D3_9922_00500487D199__INCLUDED_)
