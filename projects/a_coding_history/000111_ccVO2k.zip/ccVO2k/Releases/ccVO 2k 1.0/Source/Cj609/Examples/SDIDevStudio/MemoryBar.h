// MemoryBar.h : header file
//
/////////////////////////////////////////////////////////////////////////////

#ifndef __MEMORYBAR_H__
#define __MEMORYBAR_H__

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CMemoryBar class

class CMemoryBar : public CCJControlBar
{
	DECLARE_DYNAMIC(CMemoryBar)

// Construction
public:
	CMemoryBar();

// Attributes
public:

	CFont		m_Font;
	CCJHexEdit	m_HexEdit;
	CCJMaskEdit m_MaskedEdit;
	CStatic		m_EditLabel;
	BOOL		m_bAddress;
	BOOL		m_bHex;
	BOOL		m_bAscii;
	BOOL		m_b48;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMemoryBar)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMemoryBar();

// Generated message map functions
protected:
	//{{AFX_MSG(CMemoryBar)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	afx_msg void OnChangeMaskEdit();
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // __MEMORYBAR_H__

