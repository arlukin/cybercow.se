//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PagerDemo.rc
//
#define IDD_ABOUTBOX                    100
#define ID_MENUBAR                      101
#define IDC_OUTBAR                      102
#define IDR_MAINFRAME                   128
#define IDR_PAGERDTYPE                  129
#define IDI_ICON_CALENDAR               130
#define IDI_ICON_CONTACTS               131
#define IDI_ICON_INBOX                  132
#define IDI_ICON_JOURNAL                133
#define IDI_ICON_NOTES                  134
#define IDI_ICON_TASKS                  135
#define IDI_ICON_DELETED                136
#define IDI_ICON_SENT                   137
#define IDI_ICON_OUTBOX                 138
#define IDI_ICON_OUTLOOK                139
#define IDI_ICON_PUBLIC                 140
#define IDI_ICON_DRAFTS                 141
#define IDC_STATIC_ADDRESS              1000
#define IDC_CJ_LOGO                     1001
#define IDC_STATIC_MAILME               1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
