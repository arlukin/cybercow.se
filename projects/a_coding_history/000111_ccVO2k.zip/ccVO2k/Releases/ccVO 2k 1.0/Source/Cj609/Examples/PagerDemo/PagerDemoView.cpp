// PagerDemoView.cpp : implementation of the CPagerDemoView class
//

#include "stdafx.h"
#include "PagerDemo.h"

#include "PagerDemoDoc.h"
#include "PagerDemoView.h"
#include "OutbarView.h"
#include "DummyView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPagerDemoView

IMPLEMENT_DYNCREATE(CPagerDemoView, CView)

BEGIN_MESSAGE_MAP(CPagerDemoView, CView)
	//{{AFX_MSG_MAP(CPagerDemoView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPagerDemoView construction/destruction

CPagerDemoView::CPagerDemoView()
{
	// TODO: add construction code here

}

CPagerDemoView::~CPagerDemoView()
{
}

BOOL CPagerDemoView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CPagerDemoView drawing

void CPagerDemoView::OnDraw(CDC* pDC)
{
	CPagerDemoDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CPagerDemoView printing

BOOL CPagerDemoView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CPagerDemoView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CPagerDemoView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CPagerDemoView diagnostics

#ifdef _DEBUG
void CPagerDemoView::AssertValid() const
{
	CView::AssertValid();
}

void CPagerDemoView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CPagerDemoDoc* CPagerDemoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CPagerDemoDoc)));
	return (CPagerDemoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPagerDemoView message handlers

int CPagerDemoView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// CPaneContainerView is used to control the right pane that CMainFrame
	// sets up. In this case we create a second splitter window.
	m_wndSplitter.CreateStatic(this, 1,2);
	
	// The context information is passed on from the framework
	CCreateContext *pContext = (CCreateContext*)lpCreateStruct->lpCreateParams;
	
	// Create two views
	if (!m_wndSplitter.CreateView(0,0,RUNTIME_CLASS(COutbarView),
		CSize(100,0), pContext))
	{
		TRACE0("Failed to create COutbarView\n");
		return -1;
	}

	if (!m_wndSplitter.CreateView(0,1,RUNTIME_CLASS(CDummyView),
		CSize(0,0), pContext))
	{
		TRACE0("Failed to create CDummyView\n");
		return -1;
	}
	
	return 0;
}

void CPagerDemoView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	if( m_wndSplitter.GetSafeHwnd())
	{
		int nCX = ::GetSystemMetrics( SM_CXEDGE );
		int nCY = ::GetSystemMetrics( SM_CYEDGE );
		
		// move and grow view to clip border
		m_wndSplitter.MoveWindow(-nCX, 0, cx+(nCX*2), cy+(nCY*2));	
	}
}

BOOL CPagerDemoView::OnEraseBkgnd(CDC* pDC) 
{
	// KStowell - overridden for flicker-free drawing.
	UNUSED_ALWAYS(pDC);
	return TRUE;
}
