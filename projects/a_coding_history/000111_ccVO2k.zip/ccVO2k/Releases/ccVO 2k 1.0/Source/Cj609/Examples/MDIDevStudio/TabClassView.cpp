// TabClassView.cpp : implementation of the CTabClassView class
//

#include "stdafx.h"
#include "MDIDevStudio.h"

#include "TabClassDoc.h"
#include "TabClassView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTabClassView

IMPLEMENT_DYNCREATE(CTabClassView, CTreeView)

BEGIN_MESSAGE_MAP(CTabClassView, CTreeView)
	//{{AFX_MSG_MAP(CTabClassView)
	ON_WM_ERASEBKGND()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CTreeView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CTreeView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CTreeView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTabClassView construction/destruction

CTabClassView::CTabClassView()
{
	// TODO: add construction code here
	m_pTreeCtrl = NULL;
}

CTabClassView::~CTabClassView()
{
	m_ImageList.DeleteImageList();
}

BOOL CTabClassView::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CTreeView::PreCreateWindow( cs ))
		return FALSE;

	// set the style for the tree control.
	cs.style |= TVS_HASBUTTONS|TVS_HASLINES|TVS_LINESATROOT;

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CTabClassView drawing

void CTabClassView::OnDraw(CDC* pDC)
{
	CTabClassDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

void CTabClassView::OnInitialUpdate()
{
	CTreeView::OnInitialUpdate();

	// Save a pointer to the tree control.
	m_pTreeCtrl = &GetTreeCtrl();

	// Create the image list for the tree control
	m_ImageList.Create (IDB_IL_CLASS, 16, 1, RGB(0,255,0));
	m_pTreeCtrl->SetImageList (&m_ImageList, TVSIL_NORMAL);

	// Initialize the view.
	UpdateView();
}

/////////////////////////////////////////////////////////////////////////////
// CTabClassView printing

BOOL CTabClassView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CTabClassView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CTabClassView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CTabClassView diagnostics

#ifdef _DEBUG
void CTabClassView::AssertValid() const
{
	CTreeView::AssertValid();
}

void CTabClassView::Dump(CDumpContext& dc) const
{
	CTreeView::Dump(dc);
}

CTabClassDoc* CTabClassView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTabClassDoc)));
	return (CTabClassDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTabClassView message handlers

void CTabClassView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	// TODO: Add your specialized code here and/or call the base class

}

void CTabClassView::UpdateView()
{
	if( m_pTreeCtrl && m_pTreeCtrl->GetSafeHwnd( ))
	{
		m_pTreeCtrl->LockWindowUpdate();
		
		CString strTreeItems[] = { _T("Tab classes"), _T("CClassName"), _T("Globals") };
		
		// Add the parent item
		HTREEITEM htItem = m_pTreeCtrl->InsertItem(strTreeItems[0]);
		m_pTreeCtrl->SetItemState( htItem, TVIS_BOLD, TVIS_BOLD );
		
		// Add children
		for( int i = 1; i < 8; i++ ) {
			m_pTreeCtrl->InsertItem (strTreeItems[1], 1, 1, htItem, TVI_LAST);
		}
		
		// Add children
		m_pTreeCtrl->InsertItem (strTreeItems[2], 2, 3, htItem, TVI_LAST);
		m_pTreeCtrl->Expand(htItem, TVE_EXPAND);
		
		m_pTreeCtrl->UnlockWindowUpdate();
	}
}

BOOL CTabClassView::OnEraseBkgnd(CDC* pDC) 
{
	// KStowell - overridden for flicker-free drawing.
	UNUSED_ALWAYS(pDC);
	return TRUE;
}

void CTabClassView::OnPaint() 
{
    // Use a "Offscreen" DC to fill rect and send to DefWindowProc...  
	CClientDC memDC(this);
	
    CRect rcClip;
    GetClientRect(&rcClip);
    memDC.FillSolidRect(rcClip, ::GetSysColor(COLOR_WINDOW));
    DefWindowProc( WM_PAINT, (WPARAM)memDC.m_hDC, (LPARAM)0 );
	
    // Default is called for cleanup.
    Default();
}
