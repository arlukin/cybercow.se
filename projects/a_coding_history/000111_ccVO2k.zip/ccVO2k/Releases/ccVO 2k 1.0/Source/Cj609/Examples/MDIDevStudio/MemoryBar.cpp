// MemoryBar.cpp : implementation file
//
/////////////////////////////////////////////////////////////////////////////

#include "StdAfx.h"
#include "MDIDevStudio.h"
#include "MemoryBar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMemoryBar

CMemoryBar::CMemoryBar()
{
	NONCLIENTMETRICS ncm;
	memset(&ncm, 0, sizeof(NONCLIENTMETRICS));
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	VERIFY(::SystemParametersInfo(SPI_GETNONCLIENTMETRICS,
		sizeof(NONCLIENTMETRICS), &ncm, 0));
	m_Font.CreateFontIndirect(&ncm.lfMessageFont);

	m_bAddress	= TRUE;
	m_bHex		= TRUE;
	m_bAscii	= TRUE;
	m_b48		= TRUE;
}

CMemoryBar::~CMemoryBar()
{
	// TODO: add destruction code here.
}

IMPLEMENT_DYNAMIC(CMemoryBar, CCJControlBar)

BEGIN_MESSAGE_MAP(CMemoryBar, CCJControlBar)
	//{{AFX_MSG_MAP(CMemoryBar)
	ON_WM_CREATE()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
	ON_EN_CHANGE(IDC_MASKED_EDIT, OnChangeMaskEdit)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMemoryBar message handlers


int CMemoryBar::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CCJControlBar::OnCreate(lpCreateStruct) == -1)
		return -1;

	// define the style used by the controls.
	DWORD dwStyle = WS_CHILD | WS_VISIBLE | ES_MULTILINE | ES_AUTOVSCROLL |
		ES_AUTOHSCROLL | WS_TABSTOP;

	// Create the hex edit control.
	if (!m_HexEdit.CreateEx( WS_EX_CLIENTEDGE,_T("edit"), NULL, 
		dwStyle, CRect(0,0,0,0), this, IDC_HEX_EDIT ))
	{
		TRACE(_T("Failed to create output window.\n"));
		return -1;
	}

	// put some data in the hex edit control.
	m_HexEdit.m_pData = (LPBYTE)malloc(0x04);
	for(int i = 0; i < 0x04; i++)
		m_HexEdit.m_pData[i] = i;
	free(m_HexEdit.m_pData);

	// Create the masked edit control.
	if (!m_MaskedEdit.CreateEx( WS_EX_CLIENTEDGE, _T("edit"), NULL,
		dwStyle, CRect(0,0,0,0), this, IDC_MASKED_EDIT ))
	{
		TRACE(_T("Failed to create edit window.\n"));
		return -1;
	}

	// define the masked used by the control, in this case, we are using 'H'
	// which signifies that this is a Hex edit control.
	m_MaskedEdit.SetEditMask(_T("0xHHHHHHHH"), _T("0x________"), _T("0x00000000"));

	// create the address label.
	if (!m_EditLabel.Create(_T("&Address:"), WS_VISIBLE|SS_CENTERIMAGE,
		CRect(0,0,0,0), this))
	{
		TRACE(_T("Failed to create static text.\n"));
		return -1;
	}

	// set the font used by the controls.
	m_EditLabel.SetFont( &m_Font );

	return 0;
}

void CMemoryBar::OnChangeMaskEdit() 
{

}

void CMemoryBar::OnSize(UINT nType, int cx, int cy) 
{
	CCJControlBar::OnSize(nType, cx, cy);
	
	CRect rc;
	GetChildRect( rc );
	if( IsFloating()) {
		rc.DeflateRect(2,2);
	}
	if( m_EditLabel.GetSafeHwnd( )) {
		m_EditLabel.MoveWindow(rc.left+2, rc.top, 45, 20);
	}
	if( m_MaskedEdit.GetSafeHwnd( )) {
		m_MaskedEdit.MoveWindow(rc.left+47, rc.top, rc.Width()-47, 20);
	}
	if( m_HexEdit.GetSafeHwnd( )) {
		m_HexEdit.MoveWindow(rc.left, rc.top+23, rc.Width(), rc.Height()-23);
	}
}
