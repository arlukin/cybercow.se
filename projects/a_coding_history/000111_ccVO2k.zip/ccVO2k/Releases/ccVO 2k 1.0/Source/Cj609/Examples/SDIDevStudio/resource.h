//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SDIDevStudio.rc
//
#define IDD_ABOUTBOX                    100
#define IDC_MASKED_EDIT                 101
#define IDC_HEX_EDIT                    102
#define ID_VIEW_WORKSPACE               103
#define IDC_FLATTAB                     103
#define ID_VIEW_OUTPUT                  104
#define ID_BUILDLIST                    104
#define IDS_BUILD                       105
#define ID_DEBUGLIST                    105
#define IDS_DEBUG                       106
#define ID_FIND1LIST                    106
#define IDB_IL_TAB                      107
#define IDS_FIND1                       107
#define ID_FIND2LIST                    107
#define IDB_IL_FILE                     108
#define IDS_FIND2                       108
#define ID_MENUBAR                      108
#define IDB_IL_CLASS                    109
#define IDB_IL_RSRC                     110
#define IDR_MAINFRAME                   128
#define IDR_SDIDEVTYPE                  129
#define ID_VIEW_MEMORY                  130
#define IDC_STATIC_ADDRESS              1000
#define IDC_CJ_LOGO                     1001
#define IDC_STATIC_MAILME               1002
#define ID_INIT_TAB_CLASS               32771
#define ID_INIT_TAB_FILE                32772
#define ID_INIT_TAB_RSRC                32773
#define ID_TOGGLEFLAT                   32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           109
#endif
#endif
