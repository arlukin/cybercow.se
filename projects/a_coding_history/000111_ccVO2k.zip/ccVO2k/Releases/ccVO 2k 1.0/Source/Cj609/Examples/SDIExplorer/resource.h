//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SDIExplorer.rc
//
#define IDD_ABOUTBOX                    100
#define ID_MENUBAR                      101
#define ID_ADDRESS                      102
#define ID_ANIMATE                      103
#define IDC_LISTCTRL                    104
#define IDC_CAPT_BUTTON                 105
#define IDC_SHELL_TREE                  106
#define IDR_MAINFRAME                   128
#define IDR_SDIEXPTYPE                  129
#define IDR_NAVBAR                      129
#define IDR_VC                          130
#define IDR_DUMMY                       131
#define IDS_BACK                        131
#define IDS_FORWARD                     132
#define IDS_UP                          133
#define IDS_CUT                         134
#define IDS_COPY                        135
#define IDS_PASTE                       136
#define IDS_UNDO                        137
#define IDS_DELETE                      141
#define IDS_PROPERTIES                  142
#define IDS_TOGGLE                      143
#define IDB_HOTTOOLBAR                  146
#define IDB_COLDTOOLBAR                 147
#define IDR_POPDOWN                     149
#define IDB_PUSHPIN                     150
#define IDC_STATIC_ADDRESS              1000
#define IDC_CJ_LOGO                     1001
#define IDC_STATIC_MAILME               1002
#define ID_CUT                          32771
#define ID_DUMMY                        32772
#define ID_COPY                         32773
#define ID_VIEW_ALLFOLDERS              32774
#define ID_PASTE                        32775
#define ID_UNDO                         32776
#define ID_DELETE                       32777
#define ID_PROPERTIES                   32778
#define ID_VIEW_TOGGLE                  32779
#define ID_UP                           32780
#define ID_FORWARD                      32781
#define ID_BACK                         32782
#define IDX_VIEW_TOOLBAR                0xE800
#define IDX_VIEW_STATUS_BAR             0xE801
#define IDX_VIEW_TOOLBAR2               59394
#define IDX_VIEW_STATUS_BAR2            59395
#define IDX_VIEW_AUTOARRANGE            0xE805
#define IDX_VIEW_SMALLICON              0xE810
#define IDX_VIEW_LARGEICON              0xE811
#define IDX_VIEW_LIST                   0xE812
#define IDX_VIEW_DETAILS                0xE813
#define IDX_VIEW_LINEUP                 0xE814
#define IDX_VIEW_BYNAME                 0xE815

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           107
#endif
#endif
