// VC6ForVC5DemoView.cpp : implementation of the CVC6ForVC5DemoView class
//

#include "stdafx.h"
#include "VC6ForVC5Demo.h"

#include "VC6ForVC5DemoDoc.h"
#include "VC6ForVC5DemoView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CVC6ForVC5DemoView

IMPLEMENT_DYNCREATE(CVC6ForVC5DemoView, CCJHtmlView)

BEGIN_MESSAGE_MAP(CVC6ForVC5DemoView, CCJHtmlView)
	//{{AFX_MSG_MAP(CVC6ForVC5DemoView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CCJHtmlView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CCJHtmlView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CCJHtmlView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVC6ForVC5DemoView construction/destruction

CVC6ForVC5DemoView::CVC6ForVC5DemoView()
{
	// TODO: add construction code here

}

CVC6ForVC5DemoView::~CVC6ForVC5DemoView()
{
}

BOOL CVC6ForVC5DemoView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CCJHtmlView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CVC6ForVC5DemoView drawing

void CVC6ForVC5DemoView::OnDraw(CDC* pDC)
{
	CVC6ForVC5DemoDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CVC6ForVC5DemoView printing

BOOL CVC6ForVC5DemoView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CVC6ForVC5DemoView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CVC6ForVC5DemoView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CVC6ForVC5DemoView diagnostics

#ifdef _DEBUG
void CVC6ForVC5DemoView::AssertValid() const
{
	CCJHtmlView::AssertValid();
}

void CVC6ForVC5DemoView::Dump(CDumpContext& dc) const
{
	CCJHtmlView::Dump(dc);
}

CVC6ForVC5DemoDoc* CVC6ForVC5DemoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CVC6ForVC5DemoDoc)));
	return (CVC6ForVC5DemoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CVC6ForVC5DemoView message handlers

void CVC6ForVC5DemoView::OnInitialUpdate() 
{
	CCJHtmlView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	Navigate2(_T("http://www.codejock.com"));
}
