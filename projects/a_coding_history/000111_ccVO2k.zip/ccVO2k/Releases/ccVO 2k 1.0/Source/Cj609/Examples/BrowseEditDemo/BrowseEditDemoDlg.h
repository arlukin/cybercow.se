// BrowseEditDemoDlg.h : header file
//

#if !defined(AFX_BROWSEEDITDEMODLG_H__D52D2358_9130_11D3_9983_00500487D199__INCLUDED_)
#define AFX_BROWSEEDITDEMODLG_H__D52D2358_9130_11D3_9983_00500487D199__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CBrowseEditDemoDlg dialog

class CBrowseEditDemoDlg : public CDialog
{
// Construction
public:
	CBrowseEditDemoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CBrowseEditDemoDlg)
	enum { IDD = IDD_BROWSEEDITDEMO_DIALOG };
	CCJBrowseEdit	m_Edit3;
	CCJBrowseEdit	m_Edit2;
	CCJBrowseEdit	m_Edit1;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBrowseEditDemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	virtual BOOL OnInitDialog();
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CBrowseEditDemoDlg)
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnPopup1();
	afx_msg void OnPopup2();
	afx_msg void OnPopup3();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BROWSEEDITDEMODLG_H__D52D2358_9130_11D3_9983_00500487D199__INCLUDED_)
