// ClassWizSheet.h : header file
//
// This class defines custom modal property sheet 
// CClassWizSheet.
 
#ifndef __CLASSWIZSHEET_H__
#define __CLASSWIZSHEET_H__

#include <fstream.h>

// class forwards
class CClassWizPage1;
class CClassWizPage2;

/////////////////////////////////////////////////////////////////////////////
// CClassWizSheet

class CClassWizSheet : public CPropertySheet
{
	DECLARE_DYNAMIC(CClassWizSheet)

// Construction
public:
	CClassWizSheet(CWnd* pWndParent = NULL);
	virtual ~CClassWizSheet();

// Attributes
public:
	void Remove(CString& strHeader);
	void WriteHeader(fstream fp);
	void WriteImplementationFile();
	void WriteHeaderFile();
	void OnFinish();
	CClassWizPage1* m_Page1;
	CClassWizPage2* m_Page2;
	CFont m_BoldFont;

// Operations
protected:
	void RemovePages();
	void AddPages();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClassWizSheet)
	public:
	virtual BOOL OnInitDialog();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

// Generated message map functions
protected:
	//{{AFX_MSG(CClassWizSheet)
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSheetAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

#endif	// __CLASSWIZSHEET_H__
