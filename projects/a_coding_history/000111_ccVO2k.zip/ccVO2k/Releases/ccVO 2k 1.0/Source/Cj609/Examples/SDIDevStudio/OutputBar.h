// OutputBar.h : header file
//
/////////////////////////////////////////////////////////////////////////////

#ifndef __OUTPUTBAR_H__
#define __OUTPUTBAR_H__

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// COutputBar class

class COutputBar : public CCJControlBar
{
	DECLARE_DYNAMIC(COutputBar)

// Construction
public:
	COutputBar();

// Attributes
public:
	
	CCJFlatTabCtrl	m_FlatTabCtrl;
	CCJListBox		m_BuildList;
	CCJListBox		m_DebugList;
	CCJListBox		m_Find1List;
	CCJListBox		m_Find2List;
	CFont			m_Font;

// Operations
public:
	LPCTSTR GetString(int nString);
	void UpdateFont();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COutputBar)
	protected:
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
	//}}AFX_VIRTUAL

// Implementation
public:
	void SelectTabView(int nTab);
	virtual ~COutputBar();

// Generated message map functions
protected:
	//{{AFX_MSG(COutputBar)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // __OUTPUTBAR_H__

