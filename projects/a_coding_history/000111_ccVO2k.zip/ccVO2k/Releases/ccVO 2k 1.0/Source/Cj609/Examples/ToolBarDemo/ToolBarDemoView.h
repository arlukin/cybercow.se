// ToolBarDemoView.h : interface of the CToolBarDemoView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TOOLBARDEMOVIEW_H__D11BAFCE_9141_11D3_9983_00500487D199__INCLUDED_)
#define AFX_TOOLBARDEMOVIEW_H__D11BAFCE_9141_11D3_9983_00500487D199__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CToolBarDemoView : public CView
{
protected: // create from serialization only
	CToolBarDemoView();
	DECLARE_DYNCREATE(CToolBarDemoView)

// Attributes
public:
	CToolBarDemoDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CToolBarDemoView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CToolBarDemoView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CToolBarDemoView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ToolBarDemoView.cpp
inline CToolBarDemoDoc* CToolBarDemoView::GetDocument()
   { return (CToolBarDemoDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TOOLBARDEMOVIEW_H__D11BAFCE_9141_11D3_9983_00500487D199__INCLUDED_)
