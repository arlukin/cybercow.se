// PagerDemoDoc.cpp : implementation of the CPagerDemoDoc class
//

#include "stdafx.h"
#include "PagerDemo.h"

#include "PagerDemoDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPagerDemoDoc

IMPLEMENT_DYNCREATE(CPagerDemoDoc, CDocument)

BEGIN_MESSAGE_MAP(CPagerDemoDoc, CDocument)
	//{{AFX_MSG_MAP(CPagerDemoDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPagerDemoDoc construction/destruction

CPagerDemoDoc::CPagerDemoDoc()
{
	// TODO: add one-time construction code here

}

CPagerDemoDoc::~CPagerDemoDoc()
{
}

BOOL CPagerDemoDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CPagerDemoDoc serialization

void CPagerDemoDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CPagerDemoDoc diagnostics

#ifdef _DEBUG
void CPagerDemoDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CPagerDemoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPagerDemoDoc commands
