// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "SDIOutlook.h"

#include "MainFrm.h"
#include "ContainerView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CCJFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CCJFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_CLOSE()
	ON_COMMAND(ID_PREVIEW_PANE, OnPreviewPane)
	ON_UPDATE_COMMAND_UI(ID_PREVIEW_PANE, OnUpdatePreviewPane)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_OUTBAR_NOTIFY, OnOutbarNotify)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	m_bPreview = TRUE;
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CCJFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_ALIGN_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndMenuBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_ALIGN_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC, CRect(0,0,0,0), ID_MENUBAR) ||
		!m_wndMenuBar.LoadMenu(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	// insert the flat combo box into the toolbar.
	m_pComboBox = (CCJFlatComboBox*)m_wndToolBar.InsertControl(RUNTIME_CLASS(CCJFlatComboBox), 
		NULL, CRect(0,0,200,150), ID_PLACEHOLDER, CBS_DROPDOWN );

	// add some strings to the combo, set the current selection and enable auto completion.
	m_pComboBox->AddString(_T("Messages"));
	m_pComboBox->AddString(_T("Messages with AutoPreview"));
	m_pComboBox->SetCurSel(0);
	m_pComboBox->EnableAutoCompletion();

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndMenuBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndMenuBar);
	DockControlBar(&m_wndToolBar);

	// Restore the previous bar and window states.
	LoadBarState(_T("Bar State"));
	m_state.LoadWindowPos(this);

	return 0;
}

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext) 
{
	// Create the splitter window with two columns
	if (!m_wndSplitter.CreateStatic(this, 1, 2))
	{
		TRACE0("Failed to create splitter window\n");
		return FALSE;
	}
	
	// "Flexible pane": The second pane may present its own
	// splitter windows.
	if (!m_wndSplitter.CreateView(0, 1, RUNTIME_CLASS(CContainerView),
		CSize(0, 0), pContext))
	{
		TRACE0("Failed to create CContainerView\n"); 
		return FALSE;
	}

	DWORD dwStyle = 
		CGfxOutBarCtrl::fDragItems    |
		CGfxOutBarCtrl::fEditGroups   |
		CGfxOutBarCtrl::fEditItems    |
		CGfxOutBarCtrl::fRemoveGroups |
		CGfxOutBarCtrl::fRemoveItems  |
		CGfxOutBarCtrl::fAddGroups    |
		CGfxOutBarCtrl::fAnimation;
	
	// Here we create the outbar control; we give as id the parent splitter pane id here
	if (!m_wndOutlookBar.Create(WS_CHILD|WS_VISIBLE, CRect(0,0,0,0),
		&m_wndSplitter, m_wndSplitter.IdFromRowCol(0, 0), dwStyle))
	{
		TRACE0("Failed to create outlook bar.");
		return FALSE;
	}
    
	// Tell the control to send message to this window (the mainframe) 
	// and not to its real parent (the splitter)
	m_wndOutlookBar.SetOwner(this);
	
	// Here we create the imagelists for the control
	m_ImageSmall.Create (16, 16, TRUE, 2, 1);
	m_ImageLarge.Create (32, 32, TRUE, 2, 1);

	for( int nIcon = IDI_ICON_OUTLOOK; nIcon <= IDI_ICON_PUBLIC; ++nIcon ) 
	{
		HICON hIcon = AfxGetApp()->LoadIcon(nIcon);
		ASSERT(hIcon);

		m_ImageSmall.Add(hIcon);
		m_ImageLarge.Add(hIcon);
	}

	// and we link them to the control
	m_wndOutlookBar.SetImageList(&m_ImageLarge, CGfxOutBarCtrl::fLargeIcon);
	m_wndOutlookBar.SetImageList(&m_ImageSmall, CGfxOutBarCtrl::fSmallIcon);

	m_wndOutlookBar.SetAnimationTickCount(20);
	m_wndOutlookBar.SetAnimSelHighlight(200);

	// Look at function reference for information about linking image list
	// Here we can add the folders to the control; we need at least one folder.
	// The numbers aside the text are an "lParam" value we can assign to each folder
	m_wndOutlookBar.AddFolder(_T("Outlook Shortcuts"),  FOLDER_0);
	m_wndOutlookBar.AddFolder(_T("My Shortcuts"),		FOLDER_1);

	// Here we insert the items; syntax is folder, index, text, image, lParam value for item
	m_wndOutlookBar.InsertItem(FOLDER_0, CMD_00, _T("Outlook Today"),  0, 0);
	m_wndOutlookBar.InsertItem(FOLDER_0, CMD_01, _T("Inbox"),		   1, 0);
	m_wndOutlookBar.InsertItem(FOLDER_0, CMD_02, _T("Calendar"),	   2, 0);
	m_wndOutlookBar.InsertItem(FOLDER_0, CMD_03, _T("Contacts"),	   3, 0);
	m_wndOutlookBar.InsertItem(FOLDER_0, CMD_04, _T("Tasks"),		   4, 0);
	m_wndOutlookBar.InsertItem(FOLDER_0, CMD_05, _T("Journal"),		   5, 0);
	m_wndOutlookBar.InsertItem(FOLDER_0, CMD_06, _T("Notes"),	       6, 0);
	m_wndOutlookBar.InsertItem(FOLDER_0, CMD_07, _T("Deleted Items"),  7, 0);
	
	m_wndOutlookBar.InsertItem(FOLDER_1, CMD_00, _T("Drafts"),		   8, 0);
	m_wndOutlookBar.InsertItem(FOLDER_1, CMD_01, _T("Outbox"),		   9, 0);
	m_wndOutlookBar.InsertItem(FOLDER_1, CMD_02, _T("Sent Items"),	  10, 0);
	
	m_wndOutlookBar.SetSelFolder(0);

	// Standard sizing for splitter
	CRect r;
	GetClientRect(&r);
	int w1 = r.Width()/7;
	int w2 = r.Width()/5;
	m_wndSplitter.SetColumnInfo( 0, w1, 0 );
	m_wndSplitter.SetColumnInfo( 1, w2, 0 );
	m_wndSplitter.RecalcLayout();

	return TRUE;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// Call base class overload to eliminate screen flicker.
	if(!CCJFrameWnd::PreCreateWindow(cs, IDR_MAINFRAME)) {
		return FALSE;
	}

	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	cs.style = WS_OVERLAPPED|WS_CAPTION|WS_THICKFRAME|WS_SYSMENU|
		WS_MINIMIZEBOX|WS_MAXIMIZEBOX|WS_MAXIMIZE;

	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CCJFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CCJFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

void CMainFrame::OnClose() 
{
	// Save the bar and window states.
	m_state.SaveWindowPos(this);
	SaveBarState(_T("Bar State"));
	
	CCJFrameWnd::OnClose();
}

CContainerView* CMainFrame::GetMainView()
{
	CContainerView* pView = DYNAMIC_DOWNCAST(CContainerView, m_wndSplitter.GetPane(0,1));
	ASSERT_KINDOF(CContainerView, pView);
	return pView;
}

void CMainFrame::OnPreviewPane() 
{
	if(m_bPreview) {
		GetMainView()->m_wndSplitter2.HideRow(1);
	}
	else {
		GetMainView()->m_wndSplitter2.ShowRow();
	}
	m_bPreview = !m_bPreview;
}

void CMainFrame::OnUpdatePreviewPane(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_bPreview);
}

long CMainFrame::OnOutbarNotify(WPARAM wParam, LPARAM lParam)
{
	switch (wParam)
	{
	case NM_OB_ITEMCLICK:
		// cast the lParam to an integer to get the clicked item
		{
			// Get the current folder.
			int nFolder = m_wndOutlookBar.GetSelFolder();
			
			// Get the current selection.
			int nIndex  = (int)lParam;
			CCJTreeCtrl* pTreeCtrl = GetMainView()->GetFolderTreeCtrl();
			HTREEITEM hItem = NULL;
			switch (nFolder)
			{
			case FOLDER_0: // Information folder is selected...
				{
					switch (nIndex)
					{
					case CMD_00:
						hItem = pTreeCtrl->FindItem(_T("Outlook Today"));
						break;
					case CMD_01:
						hItem = pTreeCtrl->FindItem(_T("Inbox"));
						break;
					case CMD_02:
						hItem = pTreeCtrl->FindItem(_T("Calendar"));
						break;
					case CMD_03:
						hItem = pTreeCtrl->FindItem(_T("Contacts"));
						break;
					case CMD_04:
						hItem = pTreeCtrl->FindItem(_T("Tasks"));
						break;
					case CMD_05:
						hItem = pTreeCtrl->FindItem(_T("Journal"));
						break;
					case CMD_06:
						hItem = pTreeCtrl->FindItem(_T("Notes"));
						break;
					case CMD_07:
						hItem = pTreeCtrl->FindItem(_T("Deleted Items"));
						break;
					}
				}
				break;
				
			case FOLDER_1: // Management folder is selected...
				{
					switch (nIndex)
					{
					case CMD_00:
						hItem = pTreeCtrl->FindItem(_T("Drafts"));
						break;
					case CMD_01:
						hItem = pTreeCtrl->FindItem(_T("Outbox"));
						break;
					case CMD_02:
						hItem = pTreeCtrl->FindItem(_T("Sent Items"));
						break;
					}
				}
				break;
			}

			if( hItem ) {
				pTreeCtrl->SelectItem( hItem );
			}
		}
		return 0;

	case NM_OB_ONLABELENDEDIT:
		// cast the lParam to an OUTBAR_INFO * struct; it will contain info about the edited item
		// return 1 to do the change and 0 to cancel it
		{
			OUTBAR_INFO * pOI = (OUTBAR_INFO *) lParam;
			TRACE2("Editing item %d, new text:%s\n", pOI->index, pOI->cText);
		}
		return 1;
		
	case NM_OB_ONGROUPENDEDIT:
		// cast the lParam to an OUTBAR_INFO * struct; it will contain info about the edited folder
		// return 1 to do the change and 0 to cancel it
		{
			OUTBAR_INFO * pOI = (OUTBAR_INFO *) lParam;
			TRACE2("Editing folder %d, new text:%s\n", pOI->index, pOI->cText);
		}
		return 1;
		
	case NM_OB_DRAGITEM:
		// cast the lParam to an OUTBAR_INFO * struct; it will contain info about the dragged items
		// return 1 to do the change and 0 to cancel it
		{
			OUTBAR_INFO * pOI = (OUTBAR_INFO *) lParam;
			TRACE2("Drag item %d at position %d\n", pOI->iDragFrom, pOI->iDragTo);
		}
		return 1;
	}
	return 0;
}

