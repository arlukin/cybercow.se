// VC6ForVC5DemoDoc.cpp : implementation of the CVC6ForVC5DemoDoc class
//

#include "stdafx.h"
#include "VC6ForVC5Demo.h"

#include "VC6ForVC5DemoDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CVC6ForVC5DemoDoc

IMPLEMENT_DYNCREATE(CVC6ForVC5DemoDoc, CDocument)

BEGIN_MESSAGE_MAP(CVC6ForVC5DemoDoc, CDocument)
	//{{AFX_MSG_MAP(CVC6ForVC5DemoDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVC6ForVC5DemoDoc construction/destruction

CVC6ForVC5DemoDoc::CVC6ForVC5DemoDoc()
{
	// TODO: add one-time construction code here

}

CVC6ForVC5DemoDoc::~CVC6ForVC5DemoDoc()
{
}

BOOL CVC6ForVC5DemoDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CVC6ForVC5DemoDoc serialization

void CVC6ForVC5DemoDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CVC6ForVC5DemoDoc diagnostics

#ifdef _DEBUG
void CVC6ForVC5DemoDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CVC6ForVC5DemoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CVC6ForVC5DemoDoc commands
