// SDIDevStudioView.h : interface of the CSDIDevStudioView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SDIDEVSTUDIOVIEW_H__1340F3FE_9081_11D3_9982_00500487D199__INCLUDED_)
#define AFX_SDIDEVSTUDIOVIEW_H__1340F3FE_9081_11D3_9982_00500487D199__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CSDIDevStudioView : public CView
{
protected: // create from serialization only
	CSDIDevStudioView();
	DECLARE_DYNCREATE(CSDIDevStudioView)

// Attributes
public:
	CSDIDevStudioDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSDIDevStudioView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CSDIDevStudioView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CSDIDevStudioView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in SDIDevStudioView.cpp
inline CSDIDevStudioDoc* CSDIDevStudioView::GetDocument()
   { return (CSDIDevStudioDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SDIDEVSTUDIOVIEW_H__1340F3FE_9081_11D3_9982_00500487D199__INCLUDED_)
