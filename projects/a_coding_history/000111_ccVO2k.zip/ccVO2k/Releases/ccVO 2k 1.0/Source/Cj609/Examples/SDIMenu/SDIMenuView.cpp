// SDIMenuView.cpp : implementation of the CSDIMenuView class
//

#include "stdafx.h"
#include "SDIMenu.h"

#include "SDIMenuDoc.h"
#include "SDIMenuView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSDIMenuView

IMPLEMENT_DYNCREATE(CSDIMenuView, CView)

BEGIN_MESSAGE_MAP(CSDIMenuView, CView)
	//{{AFX_MSG_MAP(CSDIMenuView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSDIMenuView construction/destruction

CSDIMenuView::CSDIMenuView()
{
	// TODO: add construction code here

}

CSDIMenuView::~CSDIMenuView()
{
}

BOOL CSDIMenuView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CSDIMenuView drawing

void CSDIMenuView::OnDraw(CDC* pDC)
{
	CSDIMenuDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CSDIMenuView printing

BOOL CSDIMenuView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CSDIMenuView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CSDIMenuView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CSDIMenuView diagnostics

#ifdef _DEBUG
void CSDIMenuView::AssertValid() const
{
	CView::AssertValid();
}

void CSDIMenuView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CSDIMenuDoc* CSDIMenuView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSDIMenuDoc)));
	return (CSDIMenuDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSDIMenuView message handlers
