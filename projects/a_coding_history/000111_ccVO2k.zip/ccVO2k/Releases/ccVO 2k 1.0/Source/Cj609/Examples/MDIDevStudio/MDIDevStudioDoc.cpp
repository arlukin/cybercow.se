// MDIDevStudioDoc.cpp : implementation of the CMDIDevStudioDoc class
//

#include "stdafx.h"
#include "MDIDevStudio.h"

#include "MDIDevStudioDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMDIDevStudioDoc

IMPLEMENT_DYNCREATE(CMDIDevStudioDoc, CDocument)

BEGIN_MESSAGE_MAP(CMDIDevStudioDoc, CDocument)
	//{{AFX_MSG_MAP(CMDIDevStudioDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMDIDevStudioDoc construction/destruction

CMDIDevStudioDoc::CMDIDevStudioDoc()
{
	// TODO: add one-time construction code here

}

CMDIDevStudioDoc::~CMDIDevStudioDoc()
{
}

BOOL CMDIDevStudioDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CMDIDevStudioDoc serialization

void CMDIDevStudioDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMDIDevStudioDoc diagnostics

#ifdef _DEBUG
void CMDIDevStudioDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMDIDevStudioDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMDIDevStudioDoc commands
