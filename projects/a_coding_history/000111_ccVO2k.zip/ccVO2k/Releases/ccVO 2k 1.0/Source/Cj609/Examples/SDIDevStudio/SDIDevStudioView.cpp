// SDIDevStudioView.cpp : implementation of the CSDIDevStudioView class
//

#include "stdafx.h"
#include "SDIDevStudio.h"

#include "SDIDevStudioDoc.h"
#include "SDIDevStudioView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSDIDevStudioView

IMPLEMENT_DYNCREATE(CSDIDevStudioView, CView)

BEGIN_MESSAGE_MAP(CSDIDevStudioView, CView)
	//{{AFX_MSG_MAP(CSDIDevStudioView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSDIDevStudioView construction/destruction

CSDIDevStudioView::CSDIDevStudioView()
{
	// TODO: add construction code here

}

CSDIDevStudioView::~CSDIDevStudioView()
{
}

BOOL CSDIDevStudioView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CSDIDevStudioView drawing

void CSDIDevStudioView::OnDraw(CDC* pDC)
{
	CSDIDevStudioDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CSDIDevStudioView printing

BOOL CSDIDevStudioView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CSDIDevStudioView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CSDIDevStudioView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CSDIDevStudioView diagnostics

#ifdef _DEBUG
void CSDIDevStudioView::AssertValid() const
{
	CView::AssertValid();
}

void CSDIDevStudioView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CSDIDevStudioDoc* CSDIDevStudioView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSDIDevStudioDoc)));
	return (CSDIDevStudioDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSDIDevStudioView message handlers
