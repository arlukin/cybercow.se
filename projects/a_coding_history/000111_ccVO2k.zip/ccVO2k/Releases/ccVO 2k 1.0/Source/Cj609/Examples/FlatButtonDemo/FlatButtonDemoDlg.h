// FlatButtonDemoDlg.h : header file
//

#if !defined(AFX_FLATBUTTONDEMODLG_H__D52D2374_9130_11D3_9983_00500487D199__INCLUDED_)
#define AFX_FLATBUTTONDEMODLG_H__D52D2374_9130_11D3_9983_00500487D199__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "ButtonGrp.h"

/////////////////////////////////////////////////////////////////////////////
// CFlatButtonDemoDlg dialog

class CFlatButtonDemoDlg : public CDialog
{
// Construction
public:
	CFlatButtonDemoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CFlatButtonDemoDlg)
	enum { IDD = IDD_FLATBUTTONDEMO_DIALOG };
	CButtonGrp	m_ButtonGrp;
	CCJListCtrl	m_ListCtrl;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFlatButtonDemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	virtual BOOL OnInitDialog();
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CFlatButtonDemoDlg)
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FLATBUTTONDEMODLG_H__D52D2374_9130_11D3_9983_00500487D199__INCLUDED_)
