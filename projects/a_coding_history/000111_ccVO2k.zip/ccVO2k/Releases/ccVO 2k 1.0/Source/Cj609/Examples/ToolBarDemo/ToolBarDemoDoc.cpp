// ToolBarDemoDoc.cpp : implementation of the CToolBarDemoDoc class
//

#include "stdafx.h"
#include "ToolBarDemo.h"

#include "ToolBarDemoDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CToolBarDemoDoc

IMPLEMENT_DYNCREATE(CToolBarDemoDoc, CDocument)

BEGIN_MESSAGE_MAP(CToolBarDemoDoc, CDocument)
	//{{AFX_MSG_MAP(CToolBarDemoDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CToolBarDemoDoc construction/destruction

CToolBarDemoDoc::CToolBarDemoDoc()
{
	// TODO: add one-time construction code here

}

CToolBarDemoDoc::~CToolBarDemoDoc()
{
}

BOOL CToolBarDemoDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CToolBarDemoDoc serialization

void CToolBarDemoDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CToolBarDemoDoc diagnostics

#ifdef _DEBUG
void CToolBarDemoDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CToolBarDemoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CToolBarDemoDoc commands
