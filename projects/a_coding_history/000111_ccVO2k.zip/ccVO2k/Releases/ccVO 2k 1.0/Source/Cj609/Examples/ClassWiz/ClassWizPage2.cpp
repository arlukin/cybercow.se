// ClassWizPage2.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "ClassWizSheet.h"
#include "ClassWizPage1.h"
#include "ClassWizPage2.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CClassWizPage2, CPropertyPage)

BEGIN_MESSAGE_MAP(CClassWizPage2, CPropertyPage)
	//{{AFX_MSG_MAP(CClassWizPage2)
	ON_BN_CLICKED(IDC_HEADER_CHECK2, OnHeaderCheck2)
	ON_BN_CLICKED(IDC_USE_MFC_CHECK, OnUseMfcCheck)
	ON_BN_CLICKED(IDC_SERIALIZE_CHECK, OnSerializeCheck)
	ON_CBN_EDITCHANGE(IDC_SERIALIZE_COMBO, OnEditchangeSerializeCombo)
	ON_EN_CHANGE(IDC_HEADER_EDIT, OnChangeHeaderEdit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClassWizPage2 property page

CClassWizPage2::CClassWizPage2() : CPropertyPage(CClassWizPage2::IDD)
{
	//{{AFX_DATA_INIT(CClassWizPage2)
	m_bHeader = FALSE;
	m_strHeader = _T("");
	m_bSerialize = FALSE;
	m_nSerialize = 0;
	m_bUseMFC = FALSE;
	//}}AFX_DATA_INIT

	CWinApp* pApp = AfxGetApp();
	CString strSection, strEntry;
	strSection.LoadString(IDS_Settings);

    strEntry.LoadString(IDS_m_bHeader2);
	m_bHeader = pApp->GetProfileInt(strSection, strEntry, FALSE);

    strEntry.LoadString(IDS_m_strHeader);
	m_strHeader = pApp->GetProfileString(strSection, strEntry, _T(""));

	strEntry.LoadString(IDS_m_bSerialize);
	m_bSerialize = pApp->GetProfileInt(strSection, strEntry, FALSE);

	strEntry.LoadString(IDS_m_nSerialize);
	m_nSerialize = pApp->GetProfileInt(strSection, strEntry, 0);

	strEntry.LoadString(IDS_m_bUseMFC);
	m_bUseMFC = pApp->GetProfileInt(strSection, strEntry, FALSE);
}

CClassWizPage2::~CClassWizPage2()
{
}

void CClassWizPage2::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CClassWizPage2)
	DDX_Control(pDX, IDC_STATIC_MICROSOFT, m_staticMicrosoft);
	DDX_Control(pDX, IDC_SERIALIZE_COMBO, m_comboSerialize);
	DDX_Control(pDX, IDC_USE_MFC_CHECK, m_checkUseMFC);
	DDX_Control(pDX, IDC_SERIALIZE_CHECK, m_checkSerialize);
	DDX_Control(pDX, IDC_HEADER_EDIT, m_editHeader);
	DDX_Control(pDX, IDC_HEADER_CHECK2, m_checkHeader);
	DDX_Check(pDX, IDC_HEADER_CHECK2, m_bHeader);
	DDX_Text(pDX, IDC_HEADER_EDIT, m_strHeader);
	DDX_Check(pDX, IDC_SERIALIZE_CHECK, m_bSerialize);
	DDX_CBIndex(pDX, IDC_SERIALIZE_COMBO, m_nSerialize);
	DDX_Check(pDX, IDC_USE_MFC_CHECK, m_bUseMFC);
	//}}AFX_DATA_MAP
}

BOOL CClassWizPage2::OnSetActive() 
{
	SetEnabled();
	return CPropertyPage::OnSetActive();
}

CClassWizSheet* CClassWizPage2::GetParentSheet()
{
	// Get a pointer to the parent sheet.
	CClassWizSheet *pSheet = DYNAMIC_DOWNCAST(CClassWizSheet, GetParent());
	ASSERT_KINDOF(CPropertySheet, pSheet);
	return pSheet;
}

void CClassWizPage2::SetEnabled()
{
	m_checkSerialize.EnableWindow(m_bUseMFC);
	m_comboSerialize.EnableWindow(m_bUseMFC?m_bSerialize:FALSE);
	m_editHeader.EnableWindow(m_bHeader);

	DWORD dwWizB = PSWIZB_BACK|PSWIZB_FINISH;
	
	if (m_bHeader) {
		if (m_strHeader.IsEmpty()) {
			GetParentSheet()->SetWizardButtons(PSWIZB_BACK);
			return;
		}
	}
	
	GetParentSheet()->SetWizardButtons(dwWizB);
}

void CClassWizPage2::OnUseMfcCheck() 
{
	UpdateData();
	SetEnabled();
}

void CClassWizPage2::OnSerializeCheck() 
{
	UpdateData();
	SetEnabled();
}

void CClassWizPage2::OnEditchangeSerializeCombo() 
{
	UpdateData();
	SetEnabled();
}

void CClassWizPage2::OnHeaderCheck2() 
{
	UpdateData();
	SetEnabled();
}

void CClassWizPage2::OnChangeHeaderEdit() 
{
	UpdateData();
	SetEnabled();
}

BOOL CClassWizPage2::OnWizardFinish() 
{
	CWinApp* pApp = AfxGetApp();

	CString strSection;
	strSection.LoadString(IDS_Settings);
	
	CString strEntry;

	// Initialize page 2 member variables.
    strEntry.LoadString(IDS_m_bHeader2);
	pApp->WriteProfileInt(strSection, strEntry, m_bHeader);

    strEntry.LoadString(IDS_m_strHeader);
	pApp->WriteProfileString(strSection, strEntry, m_strHeader);

	strEntry.LoadString(IDS_m_bSerialize);
	pApp->WriteProfileInt(strSection, strEntry, m_bSerialize);

	strEntry.LoadString(IDS_m_nSerialize);
	pApp->WriteProfileInt(strSection, strEntry, m_nSerialize);

	strEntry.LoadString(IDS_m_bUseMFC);
	pApp->WriteProfileInt(strSection, strEntry, m_bUseMFC);

	CClassWizPage1* pPage = GetParentSheet()->m_Page1;
	ASSERT_VALID(pPage);

	// Initialize page 1.
	strEntry.LoadString(IDS_m_strClassNameCPP);
	pApp->WriteProfileString(strSection, strEntry, pPage->m_strClassNameCPP);

	strEntry.LoadString(IDS_m_strClassNameH);
	pApp->WriteProfileString(strSection, strEntry, pPage->m_strClassNameH);

	strEntry.LoadString(IDS_m_strClassName);
	pApp->WriteProfileString(strSection, strEntry, pPage->m_strClassName);

	strEntry.LoadString(IDS_m_bDerivedFrom);
	pApp->WriteProfileInt(strSection, strEntry, pPage->m_bDerivedFrom);

	strEntry.LoadString(IDS_m_bInclude);
	pApp->WriteProfileInt(strSection, strEntry, pPage->m_bInclude);

	strEntry.LoadString(IDS_m_nAs);
	pApp->WriteProfileInt(strSection, strEntry, pPage->m_nAs);

	strEntry.LoadString(IDS_m_strDerivedFrom);
	pApp->WriteProfileString(strSection, strEntry, pPage->m_strDerivedFrom);

	strEntry.LoadString(IDS_m_strInclude);
	pApp->WriteProfileString(strSection, strEntry, pPage->m_strInclude);

	strEntry.LoadString(IDS_m_strLocationCPP);
	pApp->WriteProfileString(strSection, strEntry, pPage->m_strLocationCPP);

	strEntry.LoadString(IDS_m_strLocationH);
	pApp->WriteProfileString(strSection, strEntry, pPage->m_strLocationH);

	strEntry.LoadString(IDS_m_bHeader1);
	pApp->WriteProfileInt(strSection, strEntry, pPage->m_bHeader);
	
	GetParentSheet()->OnFinish();

	return CPropertyPage::OnWizardFinish();
}
