// LeftView.cpp : implementation file
//

#include "stdafx.h"
#include "SDIExplorer.h"
#include "LeftView.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLeftView

IMPLEMENT_DYNCREATE(CLeftView, CView)

CLeftView::CLeftView()
{
}

CLeftView::~CLeftView()
{
}


BEGIN_MESSAGE_MAP(CLeftView, CView)
	//{{AFX_MSG_MAP(CLeftView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_CAPT_BUTTON, OnCaptButton)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLeftView drawing

void CLeftView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CLeftView diagnostics

#ifdef _DEBUG
void CLeftView::AssertValid() const
{
	CView::AssertValid();
}

void CLeftView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CLeftView message handlers

int CLeftView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	// Create the image list used by frame buttons.
	m_ImageList.Create( IDB_PUSHPIN, 16, 1, RGB( 255, 0, 255 ));

	// Create the caption.
	if (!m_Caption.Create(this, _T("Folder List")))
	{
		TRACE0( "Unable to create caption.\n" );
		return -1;
	}

	// Create the caption button.
	if (!m_CaptionButton.Create(NULL, WS_VISIBLE|BS_ICON|BS_OWNERDRAW|BS_CENTER|BS_VCENTER,
		CRect(0,0,0,0), this, IDC_CAPT_BUTTON))
	{
		TRACE0( "Unable to create caption button.\n" );
		return -1;
	}
	
	// set the caption buttons icon.
	m_CaptionButton.SetIcon( m_ImageList.ExtractIcon(2), CSize( 16, 15 ));
	
	if( !m_ShellTree.Create(WS_VISIBLE, CRect(0,0,0,0), this, IDC_SHELL_TREE))
	{
		TRACE0( "Unable to create tree control.\n" );
		return -1;
	}
	
	return 0;
}

void CLeftView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	if( m_Caption.GetSafeHwnd()) {
		m_Caption.MoveWindow( 0, 0, cx, 19 );
	}

	if( m_CaptionButton.GetSafeHwnd()) {
		m_CaptionButton.MoveWindow( cx-18, 2, 16, 15 );
	}

	if( m_ShellTree.GetSafeHwnd()) {
		m_ShellTree.MoveWindow( 0, 19, cx, cy-19 );
	}
}

BOOL CLeftView::OnEraseBkgnd(CDC* pDC) 
{
	// KStowell - overridden for flicker-free drawing.
	UNUSED_ALWAYS(pDC);
	return TRUE;
}

void CLeftView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	CMainFrame* pFrame = DYNAMIC_DOWNCAST(CMainFrame, AfxGetMainWnd());
	CCJShellTree& treeCtrl = pFrame->GetLeftPane()->GetTreeCtrl();
	treeCtrl.TunnelTree(_T("C:\\"));
}

CCJShellTree& CLeftView::GetTreeCtrl()
{
	return m_ShellTree;
}

void CLeftView::OnCaptButton()
{
	((CMainFrame*)AfxGetMainWnd())->SendMessage(WM_COMMAND, ID_VIEW_ALLFOLDERS);
}
