//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SDIStaticDemo.rc
//
#define IDD_ABOUTBOX                    100
#define ID_VIEW_OUTPUT                  101
#define ID_MENUBAR                      102
#define IDC_FLATTAB                     103
#define ID_BUILDLIST                    104
#define ID_DEBUGLIST                    105
#define IDS_BUILD                       106
#define ID_FIND1LIST                    107
#define IDS_DEBUG                       108
#define ID_FIND2LIST                    109
#define IDS_FIND1                       110
#define IDS_FIND2                       111
#define IDR_MAINFRAME                   128
#define IDR_SDISTATYPE                  129
#define IDC_STATIC_ADDRESS              1000
#define IDC_CJ_LOGO                     1001
#define IDC_STATIC_MAILME               1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           107
#endif
#endif
