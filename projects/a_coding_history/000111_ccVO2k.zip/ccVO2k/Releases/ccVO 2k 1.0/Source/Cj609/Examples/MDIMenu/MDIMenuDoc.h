// MDIMenuDoc.h : interface of the CMDIMenuDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MDIMENUDOC_H__EE40D638_90D0_11D3_879B_000000000000__INCLUDED_)
#define AFX_MDIMENUDOC_H__EE40D638_90D0_11D3_879B_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


class CMDIMenuDoc : public CDocument
{
protected: // create from serialization only
	CMDIMenuDoc();
	DECLARE_DYNCREATE(CMDIMenuDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMDIMenuDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMDIMenuDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMDIMenuDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MDIMENUDOC_H__EE40D638_90D0_11D3_879B_000000000000__INCLUDED_)
