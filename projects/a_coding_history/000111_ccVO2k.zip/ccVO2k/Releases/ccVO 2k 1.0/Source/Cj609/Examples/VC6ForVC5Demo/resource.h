//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by VC6ForVC5Demo.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_VC6FORTYPE                  129
#define IDS_Item0                       130
#define IDS_Item1                       131
#define IDB_IMAGES                      132
#define IDS_Item2                       132
#define IDS_Item3                       133
#define IDS_Item4                       134
#define IDS_Item5                       135
#define IDS_Item6                       136
#define IDC_STATIC_ADDRESS              1000
#define IDC_CJ_LOGO                     1001
#define IDC_STATIC_MAILME               1002
#define IDC_CALENDAR                    1003
#define IDC_DATE                        1004
#define IDC_TIME                        1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
