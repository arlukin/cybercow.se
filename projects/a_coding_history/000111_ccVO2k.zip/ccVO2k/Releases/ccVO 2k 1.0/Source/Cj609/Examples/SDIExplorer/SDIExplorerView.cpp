// SDIExplorerView.cpp : implementation of the CSDIExplorerView class
//

#include "stdafx.h"
#include "SDIExplorer.h"

#include "SDIExplorerDoc.h"
#include "SDIExplorerView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSDIExplorerView

IMPLEMENT_DYNCREATE(CSDIExplorerView, CView)

BEGIN_MESSAGE_MAP(CSDIExplorerView, CView)
	//{{AFX_MSG_MAP(CSDIExplorerView)
	ON_WM_CREATE()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSDIExplorerView construction/destruction

CSDIExplorerView::CSDIExplorerView()
{
	// TODO: add construction code here

}

CSDIExplorerView::~CSDIExplorerView()
{
}

BOOL CSDIExplorerView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CSDIExplorerView drawing

void CSDIExplorerView::OnDraw(CDC* pDC)
{
	CSDIExplorerDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CSDIExplorerView printing

BOOL CSDIExplorerView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CSDIExplorerView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CSDIExplorerView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CSDIExplorerView diagnostics

#ifdef _DEBUG
void CSDIExplorerView::AssertValid() const
{
	CView::AssertValid();
}

void CSDIExplorerView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CSDIExplorerDoc* CSDIExplorerView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSDIExplorerDoc)));
	return (CSDIExplorerDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSDIExplorerView message handlers

void CSDIExplorerView::OnStyleChanged(int nStyleType, LPSTYLESTRUCT lpStyleStruct)
{
	//TODO: add code to react to the user changing the view style of your window
}

int CSDIExplorerView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	if (!m_ShellList.Create(WS_VISIBLE | WS_CHILD | WS_CLIPCHILDREN 
		| LVS_REPORT | LVS_SHAREIMAGELISTS | LVS_EDITLABELS,
		CRect(0,0,0,0), this, IDC_LISTCTRL))
	{
		TRACE0("Failed to create list control.\n");
		return -1;
	}
	
	m_ShellList.SubclassHeader(FALSE);
	m_ShellList.BuildDefaultColumns();
	
	return 0;
}

BOOL CSDIExplorerView::OnEraseBkgnd(CDC* pDC) 
{
	// KStowell - overridden for flicker-free drawing.
	UNUSED_ALWAYS(pDC);
	return TRUE;
}

void CSDIExplorerView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	if(m_ShellList.GetSafeHwnd()) {
		m_ShellList.MoveWindow(0,0,cx,cy);
	}
}

CCJShellList& CSDIExplorerView::GetListCtrl()
{
	return m_ShellList;
}
