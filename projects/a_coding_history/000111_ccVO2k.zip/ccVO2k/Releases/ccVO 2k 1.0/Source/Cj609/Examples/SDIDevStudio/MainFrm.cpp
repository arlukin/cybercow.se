// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "SDIDevStudio.h"

#include "MainFrm.h"
#include "TabClassDoc.h"
#include "TabClassView.h"
#include "TabFileDoc.h"
#include "TabFileView.h"
#include "TabResourceDoc.h"
#include "TabResourceView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CCJFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CCJFrameWnd)
	ON_COMMAND_EX(ID_VIEW_WORKSPACE, OnBarCheck)
	ON_UPDATE_COMMAND_UI(ID_VIEW_WORKSPACE, OnUpdateControlBarMenu)
	ON_COMMAND_EX(ID_VIEW_OUTPUT, OnBarCheck)
	ON_UPDATE_COMMAND_UI(ID_VIEW_OUTPUT, OnUpdateControlBarMenu)
	ON_COMMAND_EX(ID_VIEW_MEMORY, OnBarCheck)
	ON_UPDATE_COMMAND_UI(ID_VIEW_MEMORY, OnUpdateControlBarMenu)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_CLOSE()
	ON_COMMAND(ID_INIT_TAB_CLASS, OnInitTabClass)
	ON_UPDATE_COMMAND_UI(ID_INIT_TAB_CLASS, OnUpdateInitTabClass)
	ON_COMMAND(ID_INIT_TAB_RSRC, OnInitTabRsrc)
	ON_UPDATE_COMMAND_UI(ID_INIT_TAB_RSRC, OnUpdateInitTabRsrc)
	ON_COMMAND(ID_INIT_TAB_FILE, OnInitTabFile)
	ON_UPDATE_COMMAND_UI(ID_INIT_TAB_FILE, OnUpdateInitTabFile)
	ON_COMMAND(ID_TOGGLEFLAT, OnToggleflat)
	ON_UPDATE_COMMAND_UI(ID_TOGGLEFLAT, OnUpdateToggleflat)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	m_bFlat = FALSE;
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CCJFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_ALIGN_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndMenuBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_ALIGN_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC, CRect(0,0,0,0), ID_MENUBAR) ||
		!m_wndMenuBar.LoadMenu(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndMenuBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndMenuBar);
	DockControlBar(&m_wndToolBar);

	// Create the "Workspace" docking window.
	{
		// Initialize dialog bar m_wndWorkspace
		if( !m_wndWorkspace.Create(this, ID_VIEW_WORKSPACE,
			_T("Workspace"), CSize(225,100), CBRS_LEFT ))
		{
			TRACE0("Failed to create dialog bar m_wndWorkspace\n");
			return -1;		// fail to create
		}

		// Create the document for each of the tab views, then add the
		// document / view to the tab control. This is a very simple implementation.
		// you could go further and actually create a document template for each tab,
		// and add it to the app. If so, you would pass in m_pMyDocTemplate->CreateNewDocument(),
		// instead of dynamically allocating a pointer for each document as shown here.
		// This was done for simplicity.

		// class tab
		m_pDocClass = new CTabClassDoc;
		ASSERT_KINDOF( CDocument, m_pDocClass );
		m_wndWorkspace.AddView( _T( "Class" ), RUNTIME_CLASS( CTabClassView ), m_pDocClass );

		// resource tab
		m_pDocResource = new CTabResourceDoc;
		ASSERT_KINDOF( CDocument, m_pDocResource );
		m_wndWorkspace.AddView( _T( "Resource" ), RUNTIME_CLASS( CTabResourceView ), m_pDocResource );
		
		// file tab
		m_pDocFile = new CTabFileDoc;
		ASSERT_KINDOF( CDocument, m_pDocFile );
		m_wndWorkspace.AddView( _T( "Files" ), RUNTIME_CLASS( CTabFileView ), m_pDocFile );

		// Define the image list to use with the tab control
		m_TabImages.Create( IDB_IL_TAB, 16, 1, RGB( 0,255,0 ));
		m_wndWorkspace.SetTabImageList( &m_TabImages );

		m_wndWorkspace.EnableDockingOnSizeBar( CBRS_ALIGN_ANY );
		EnableDockingSizeBar( CBRS_ALIGN_ANY );
		DockSizeBar( &m_wndWorkspace );

		// set the popoup menu id.
		m_wndWorkspace.SetMenuID( IDR_MAINFRAME, NULL, 1 );
	}

	// create the memory docking window.
	{
		if( !m_wndMemory.Create(this, ID_VIEW_MEMORY,
			_T("Memory"), CSize(150, 150), CBRS_BOTTOM ))
		{
			TRACE0("Failed to create dialog bar m_wndMemory\n");
			return -1;		// fail to create
		}

		m_wndMemory.EnableDockingOnSizeBar( CBRS_ALIGN_ANY );
		EnableDockingSizeBar( CBRS_ALIGN_ANY );
		DockSizeBar( &m_wndMemory );

		// set the popoup menu id.
		m_wndMemory.SetMenuID( IDR_MAINFRAME, NULL, 1 );
	}

	// create the output docking window.
	{
		if( !m_wndOutput.Create(this, ID_VIEW_OUTPUT,
			_T("Output"), CSize(150, 150), CBRS_BOTTOM ))
		{
			TRACE0("Failed to create dialog bar m_wndOutput\n");
			return -1;		// fail to create
		}

		m_wndOutput.EnableDockingOnSizeBar( CBRS_ALIGN_ANY );
		EnableDockingSizeBar( CBRS_ALIGN_ANY );
		DockSizeBar( &m_wndOutput );

		// set the popoup menu id.
		m_wndOutput.SetMenuID( IDR_MAINFRAME, NULL, 1 );
	}

	// Hide the memory control bar.
	ShowControlBar( &m_wndMemory, FALSE, FALSE );

	// Restore the previous bar and window states.
	LoadBarState(_T("Bar State"));
	m_state.LoadWindowPos(this);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// Call base class overload to eliminate screen flicker.
	if(!CCJFrameWnd::PreCreateWindow(cs, IDR_MAINFRAME)) {
		return FALSE;
	}

	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CCJFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CCJFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

void CMainFrame::OnClose() 
{
	// Save the bar and window states.
	m_state.SaveWindowPos(this);
	SaveBarState(_T("Bar State"));
	
	CCJFrameWnd::OnClose();
}

void CMainFrame::OnInitTabClass() 
{
	// TODO: Add your command handler code here
	m_pDocClass->UpdateTabView();
}

void CMainFrame::OnUpdateInitTabClass(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
}

void CMainFrame::OnInitTabRsrc() 
{
	// TODO: Add your command handler code here
	m_pDocResource->UpdateTabView();
}

void CMainFrame::OnUpdateInitTabRsrc(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
}

void CMainFrame::OnInitTabFile() 
{
	// TODO: Add your command handler code here
	m_pDocFile->UpdateTabView();
}

void CMainFrame::OnUpdateInitTabFile(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
}

void CMainFrame::OnToggleflat() 
{
	// TODO: Add your command handler code here
	m_bFlat = !m_bFlat;
	m_wndWorkspace.EnableFlatLook(m_bFlat);
	m_wndOutput.EnableFlatLook(m_bFlat);
	m_wndMemory.EnableFlatLook(m_bFlat);
}

void CMainFrame::OnUpdateToggleflat(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_bFlat);
}
