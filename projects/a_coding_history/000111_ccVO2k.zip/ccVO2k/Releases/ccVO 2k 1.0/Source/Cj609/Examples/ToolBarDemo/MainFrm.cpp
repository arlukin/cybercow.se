// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "ToolBarDemo.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CCJFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CCJFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	
}

CMainFrame::~CMainFrame()
{
}

// set up the TOOLBARINFO for customization.
static TOOLBARINFO mainFrame[] =
{
	{{0, ID_FILE_NEW,	TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0 }, _T("New")	 },
	{{1, ID_FILE_OPEN,	TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 1 }, _T("Open")	 },
	{{2, ID_FILE_SAVE,	TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 2 }, _T("Save")	 },
	{{0, ID_SEPARATOR,	TBSTATE_ENABLED, TBSTYLE_SEP   , 0, 3 }, _T("")		 },
	{{3, ID_EDIT_CUT,	TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 4 }, _T("Cut")	 },
	{{4, ID_EDIT_COPY,	TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 5 }, _T("Copy")	 },
	{{5, ID_EDIT_PASTE,	TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 6 }, _T("Paste") },
	{{0, ID_SEPARATOR,	TBSTATE_ENABLED, TBSTYLE_SEP   , 0, 7 }, _T("")		 },
	{{6, ID_FILE_PRINT,	TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 8 }, _T("Print") },
	{{7, ID_APP_ABOUT,	TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 10}, _T("About") }
};

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CCJFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// right click on the toolbar to activate the customize command.
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME, mainFrame))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	LoadBarState( _T("bar state"));
	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// Call base class overload to eliminate screen flicker.
	if(!CCJFrameWnd::PreCreateWindow(cs, IDR_MAINFRAME)) {
		return FALSE;
	}

	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CCJFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CCJFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

void CMainFrame::OnClose() 
{
	SaveBarState( _T("bar state"));
	CCJFrameWnd::OnClose();
}
