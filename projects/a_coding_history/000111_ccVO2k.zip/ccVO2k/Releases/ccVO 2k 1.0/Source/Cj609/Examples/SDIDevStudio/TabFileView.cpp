// TabFileView.cpp : implementation of the CTabFileView class
//

#include "stdafx.h"
#include "SDIDevStudio.h"

#include "TabFileDoc.h"
#include "TabFileView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTabFileView

IMPLEMENT_DYNCREATE(CTabFileView, CTreeView)

BEGIN_MESSAGE_MAP(CTabFileView, CTreeView)
	//{{AFX_MSG_MAP(CTabFileView)
	ON_WM_ERASEBKGND()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CTreeView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CTreeView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CTreeView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTabFileView construction/destruction

CTabFileView::CTabFileView()
{
	// TODO: add construction code here
	m_pTreeCtrl = NULL;
}

CTabFileView::~CTabFileView()
{
	m_ImageList.DeleteImageList();
}

BOOL CTabFileView::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CTreeView::PreCreateWindow( cs ))
		return FALSE;

	// set the style for the tree control.
	cs.style |= TVS_HASBUTTONS|TVS_HASLINES|TVS_LINESATROOT;

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CTabFileView drawing

void CTabFileView::OnDraw(CDC* pDC)
{
	CTabFileDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

void CTabFileView::OnInitialUpdate()
{
	CTreeView::OnInitialUpdate();

	// Save a pointer to the tree control.
	m_pTreeCtrl = &GetTreeCtrl();

	// Create the image list for the tree control
	m_ImageList.Create (IDB_IL_FILE, 16, 1, RGB(0,255,0));
	m_pTreeCtrl->SetImageList (&m_ImageList, TVSIL_NORMAL);

	// Initialize the view.
	UpdateView();
}

/////////////////////////////////////////////////////////////////////////////
// CTabFileView printing

BOOL CTabFileView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CTabFileView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CTabFileView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CTabFileView diagnostics

#ifdef _DEBUG
void CTabFileView::AssertValid() const
{
	CTreeView::AssertValid();
}

void CTabFileView::Dump(CDumpContext& dc) const
{
	CTreeView::Dump(dc);
}

CTabFileDoc* CTabFileView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTabFileDoc)));
	return (CTabFileDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTabFileView message handlers

void CTabFileView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	// TODO: Add your specialized code here and/or call the base class

}

void CTabFileView::UpdateView()
{
	if( m_pTreeCtrl && m_pTreeCtrl->GetSafeHwnd( ))
	{
		m_pTreeCtrl->LockWindowUpdate();
		
		CString strTreeItems[] = { _T("Workspace 'demo': 1 project(s)"), _T("Tab files"), _T("File Folder") };
		
		// add the parent item, make it bold
		HTREEITEM htiParent = m_pTreeCtrl->InsertItem (strTreeItems[0]);
		HTREEITEM htiChild; // child item
		
		htiChild = m_pTreeCtrl->InsertItem (strTreeItems[1], 1, 1, htiParent, TVI_LAST);
		m_pTreeCtrl->SetItemState (htiChild, TVIS_BOLD, TVIS_BOLD);
		
		// add the children of the parent item
		for (int i = 1; i < 4; i++) {
			m_pTreeCtrl->InsertItem (strTreeItems[2], 2, 3, htiChild, TVI_LAST);
		}
		
		m_pTreeCtrl->Expand (htiParent, TVE_EXPAND);
		m_pTreeCtrl->Expand (htiChild, TVE_EXPAND);
		
		m_pTreeCtrl->UnlockWindowUpdate();
	}
}

BOOL CTabFileView::OnEraseBkgnd(CDC* pDC) 
{
	// KStowell - overridden for flicker-free drawing.
	UNUSED_ALWAYS(pDC);
	return TRUE;
}

void CTabFileView::OnPaint() 
{
    // Use a "Offscreen" DC to fill rect and send to DefWindowProc...  
	CClientDC memDC(this);
	
    CRect rcClip;
    GetClientRect(&rcClip);
    memDC.FillSolidRect(rcClip, ::GetSysColor(COLOR_WINDOW));
    DefWindowProc( WM_PAINT, (WPARAM)memDC.m_hDC, (LPARAM)0 );
	
    // Default is called for cleanup.
    Default();
}
