// ClassWiz.h : main header file for the CLASSWIZ application
//

#if !defined(AFX_CLASSWIZ_H__638940C9_F9B2_11D2_AB9F_441100C10000__INCLUDED_)
#define AFX_CLASSWIZ_H__638940C9_F9B2_11D2_AB9F_441100C10000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CClassWizApp:
// See ClassWiz.cpp for the implementation of this class
//

class CClassWizApp : public CWinApp
{
public:
	CClassWizApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClassWizApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CClassWizApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLASSWIZ_H__638940C9_F9B2_11D2_AB9F_441100C10000__INCLUDED_)
