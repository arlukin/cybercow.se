// SDIStaticDemoView.cpp : implementation of the CSDIStaticDemoView class
//

#include "stdafx.h"
#include "SDIStaticDemo.h"

#include "SDIStaticDemoDoc.h"
#include "SDIStaticDemoView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSDIStaticDemoView

IMPLEMENT_DYNCREATE(CSDIStaticDemoView, CView)

BEGIN_MESSAGE_MAP(CSDIStaticDemoView, CView)
	//{{AFX_MSG_MAP(CSDIStaticDemoView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSDIStaticDemoView construction/destruction

CSDIStaticDemoView::CSDIStaticDemoView()
{
	// TODO: add construction code here

}

CSDIStaticDemoView::~CSDIStaticDemoView()
{
}

BOOL CSDIStaticDemoView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CSDIStaticDemoView drawing

void CSDIStaticDemoView::OnDraw(CDC* pDC)
{
	CSDIStaticDemoDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CSDIStaticDemoView printing

BOOL CSDIStaticDemoView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CSDIStaticDemoView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CSDIStaticDemoView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CSDIStaticDemoView diagnostics

#ifdef _DEBUG
void CSDIStaticDemoView::AssertValid() const
{
	CView::AssertValid();
}

void CSDIStaticDemoView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CSDIStaticDemoDoc* CSDIStaticDemoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSDIStaticDemoDoc)));
	return (CSDIStaticDemoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSDIStaticDemoView message handlers
