// ClassWizPage1.h : header file
//

#ifndef __CLASSWIZPAGE1_H__
#define __CLASSWIZPAGE1_H__

/////////////////////////////////////////////////////////////////////////////
// CClassWizPage1 dialog

class CClassWizPage1 : public CPropertyPage
{
	DECLARE_DYNCREATE(CClassWizPage1)

// Construction
public:
	CClassWizPage1();
	~CClassWizPage1();

public:
	CPropertySheet* GetParentSheet();
	void SetEnabled();

// Dialog Data
	//{{AFX_DATA(CClassWizPage1)
	enum { IDD = IDD_CLASSWIZ_PAGE1 };
	CEdit	m_editClassName;
	CStatic	m_staticClass;
	CStatic	m_staticFile;
	CButton	m_checkHeader;
	CStatic	m_staticImplementation;
	CCJBrowseEdit	m_editLocationCPP;
	CCJBrowseEdit	m_editLocationH;
	CButton	m_checkDerivedFrom;
	CEdit	m_editInclude;
	CButton	m_checkInclude;
	CComboBox	m_comboAs;
	CStatic	m_staticAs;
	CEdit	m_editDerivedFrom;
	CString	m_strClassNameCPP;
	CString	m_strClassNameH;
	CString	m_strClassName;
	BOOL	m_bDerivedFrom;
	BOOL	m_bInclude;
	int		m_nAs;
	CString	m_strDerivedFrom;
	CString	m_strInclude;
	CString	m_strLocationCPP;
	CString	m_strLocationH;
	BOOL	m_bHeader;
	//}}AFX_DATA

	CString m_strRootName;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CClassWizPage1)
	public:
	virtual BOOL OnSetActive();
	virtual LRESULT OnWizardNext();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CClassWizPage1)
	afx_msg void OnChangeClassNameEdit();
	afx_msg void OnDerivedFromCheck();
	afx_msg void OnIncludeFileCheck();
	afx_msg void OnChangeDerivedFromEdit();
	afx_msg void OnChangeIncludeFileEdit();
	afx_msg void OnHeaderCheck();
	afx_msg void OnChangeLocationEditCpp();
	afx_msg void OnChangeLocationEditH();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

#endif // __CLASSWIZPAGE1_H__
