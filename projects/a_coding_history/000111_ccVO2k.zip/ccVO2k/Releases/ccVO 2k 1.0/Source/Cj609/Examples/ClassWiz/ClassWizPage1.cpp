// ClassWizPage1.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "ClassWizPage1.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CClassWizPage1, CPropertyPage)

BEGIN_MESSAGE_MAP(CClassWizPage1, CPropertyPage)
	//{{AFX_MSG_MAP(CClassWizPage1)
	ON_EN_CHANGE(IDC_CLASS_NAME_EDIT, OnChangeClassNameEdit)
	ON_BN_CLICKED(IDC_DERIVED_FROM_CHECK, OnDerivedFromCheck)
	ON_BN_CLICKED(IDC_INCLUDE_FILE_CHECK, OnIncludeFileCheck)
	ON_EN_CHANGE(IDC_DERIVED_FROM_EDIT, OnChangeDerivedFromEdit)
	ON_EN_CHANGE(IDC_INCLUDE_FILE_EDIT, OnChangeIncludeFileEdit)
	ON_BN_CLICKED(IDC_HEADER_CHECK, OnHeaderCheck)
	ON_EN_CHANGE(IDC_LOCATION_EDIT_CPP, OnChangeLocationEditCpp)
	ON_EN_CHANGE(IDC_LOCATION_EDIT_H, OnChangeLocationEditH)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClassWizPage1 property page

CClassWizPage1::CClassWizPage1() : CPropertyPage(CClassWizPage1::IDD)
{
	//{{AFX_DATA_INIT(CClassWizPage1)
	m_strClassNameCPP = _T("");
	m_strClassNameH = _T("");
	m_strClassName = _T("");
	m_bDerivedFrom = FALSE;
	m_bInclude = FALSE;
	m_nAs = 0;
	m_strDerivedFrom = _T("");
	m_strInclude = _T("");
	m_strLocationCPP = _T("");
	m_strLocationH = _T("");
	m_bHeader = FALSE;
	//}}AFX_DATA_INIT

	CWinApp* pApp = AfxGetApp();
	CString strSection, strEntry;
	strSection.LoadString(IDS_Settings);

	strEntry.LoadString(IDS_m_strClassNameCPP);
	m_strClassNameCPP = pApp->GetProfileString(strSection, strEntry, _T(""));

	strEntry.LoadString(IDS_m_strClassNameH);
	m_strClassNameH = pApp->GetProfileString(strSection, strEntry, _T(""));

	strEntry.LoadString(IDS_m_strClassName);
	m_strClassName = pApp->GetProfileString(strSection, strEntry, _T(""));

	strEntry.LoadString(IDS_m_bDerivedFrom);
	m_bDerivedFrom = pApp->GetProfileInt(strSection, strEntry, FALSE);

	strEntry.LoadString(IDS_m_bInclude);
	m_bInclude = pApp->GetProfileInt(strSection, strEntry, FALSE);

	strEntry.LoadString(IDS_m_nAs);
	m_nAs = pApp->GetProfileInt(strSection, strEntry, 0);

	strEntry.LoadString(IDS_m_strDerivedFrom);
	m_strDerivedFrom = pApp->GetProfileString(strSection, strEntry, _T(""));

	strEntry.LoadString(IDS_m_strInclude);
	m_strInclude = pApp->GetProfileString(strSection, strEntry, _T(""));

	strEntry.LoadString(IDS_m_strLocationCPP);
	m_strLocationCPP = pApp->GetProfileString(strSection, strEntry, _T(""));

	strEntry.LoadString(IDS_m_strLocationH);
	m_strLocationH = pApp->GetProfileString(strSection, strEntry, _T(""));

	strEntry.LoadString(IDS_m_bHeader1);
	m_bHeader = pApp->GetProfileInt(strSection, strEntry, FALSE);

	m_strRootName = m_strClassName;

	if (m_strRootName.GetLength())
	{
		// Get the root name for the cpp and h files.
		if (m_strClassName.GetAt(0) == 'C') {
			m_strRootName = m_strClassName.Right(
				m_strClassName.GetLength()-1);
		}

	}
}

CClassWizPage1::~CClassWizPage1()
{
}

void CClassWizPage1::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CClassWizPage1)
	DDX_Control(pDX, IDC_CLASS_NAME_EDIT, m_editClassName);
	DDX_Control(pDX, IDC_STATIC_CLASS_INFO, m_staticClass);
	DDX_Control(pDX, IDC_STATIC_FILE_LOC, m_staticFile);
	DDX_Control(pDX, IDC_HEADER_CHECK, m_checkHeader);
	DDX_Control(pDX, IDC_IMPLEMENTATION_STATIC, m_staticImplementation);
	DDX_Control(pDX, IDC_LOCATION_EDIT_CPP, m_editLocationCPP);
	DDX_Control(pDX, IDC_LOCATION_EDIT_H, m_editLocationH);
	DDX_Control(pDX, IDC_DERIVED_FROM_CHECK, m_checkDerivedFrom);
	DDX_Control(pDX, IDC_INCLUDE_FILE_EDIT, m_editInclude);
	DDX_Control(pDX, IDC_INCLUDE_FILE_CHECK, m_checkInclude);
	DDX_Control(pDX, IDC_AS_COMBO, m_comboAs);
	DDX_Control(pDX, IDC_AS_STATIC, m_staticAs);
	DDX_Control(pDX, IDC_DERIVED_FROM_EDIT, m_editDerivedFrom);
	DDX_Text(pDX, IDC_CLASS_NAME_STATIC_CPP, m_strClassNameCPP);
	DDX_Text(pDX, IDC_CLASS_NAME_STATIC_H, m_strClassNameH);
	DDX_Text(pDX, IDC_CLASS_NAME_EDIT, m_strClassName);
	DDX_Check(pDX, IDC_DERIVED_FROM_CHECK, m_bDerivedFrom);
	DDX_Check(pDX, IDC_INCLUDE_FILE_CHECK, m_bInclude);
	DDX_CBIndex(pDX, IDC_AS_COMBO, m_nAs);
	DDX_Text(pDX, IDC_DERIVED_FROM_EDIT, m_strDerivedFrom);
	DDX_Text(pDX, IDC_INCLUDE_FILE_EDIT, m_strInclude);
	DDX_Text(pDX, IDC_LOCATION_EDIT_CPP, m_strLocationCPP);
	DDX_Text(pDX, IDC_LOCATION_EDIT_H, m_strLocationH);
	DDX_Check(pDX, IDC_HEADER_CHECK, m_bHeader);
	//}}AFX_DATA_MAP
}

BOOL CClassWizPage1::OnSetActive() 
{
	SetEnabled();
	return CPropertyPage::OnSetActive();
}

CPropertySheet* CClassWizPage1::GetParentSheet()
{
	// Get a pointer to the parent sheet.
	CPropertySheet *pSheet = DYNAMIC_DOWNCAST(CPropertySheet, GetParent());
	ASSERT_KINDOF(CPropertySheet, pSheet);
	return pSheet;
}

LRESULT CClassWizPage1::OnWizardNext() 
{
	WIN32_FIND_DATA FindData;
	CString strMessage;

	// See if the path for the .cpp file is valid.
	HANDLE hFind = FindFirstFile(m_strLocationCPP, &FindData );
	if ( hFind == INVALID_HANDLE_VALUE )
	{
		strMessage.Format(IDS_INVALID_PATH_CPP, m_strLocationCPP);
		AfxMessageBox(strMessage, MB_ICONWARNING);
		return -1;
	}
	FindClose( hFind );

	// See if the path for the .h file is valid.
	hFind = FindFirstFile(m_strLocationH, &FindData );
	if ( hFind == INVALID_HANDLE_VALUE )
	{
		strMessage.Format(IDS_INVALID_PATH_H, m_strLocationH);
		AfxMessageBox(strMessage, MB_ICONWARNING);
		return -1;
	}
	FindClose( hFind );
	
	return CPropertyPage::OnWizardNext();
}

void CClassWizPage1::OnChangeClassNameEdit() 
{
	UpdateData();

	m_strClassNameCPP = _T("");
	m_strClassNameH   = _T("");

	// Get the name entered and its length.
	m_strRootName = m_strClassName;

	if (m_strRootName.GetLength())
	{
		// Get the root name for the cpp and h files.
		if (m_strClassName.GetAt(0) == 'C') {
			m_strRootName = m_strClassName.Right(
				m_strClassName.GetLength()-1);
		}
		
		if (m_strRootName.GetLength())
		{
			// Set the cpp and h file names.
			m_strClassNameCPP.Format(_T("%s.cpp"), m_strRootName);
			m_strClassNameH.Format(_T("%s.h"), m_strRootName);
		}
	}

	UpdateData(FALSE);
	SetEnabled();
}

void CClassWizPage1::SetEnabled()
{
	BOOL bEnable = !m_strRootName.IsEmpty();

	// Enable / disable dialog controls.
	m_checkDerivedFrom.EnableWindow(bEnable);
	m_editDerivedFrom.EnableWindow(bEnable?m_bDerivedFrom:FALSE);
	m_comboAs.EnableWindow(bEnable?(m_bDerivedFrom?!m_strDerivedFrom.IsEmpty():FALSE):FALSE);
	m_staticAs.EnableWindow(bEnable?(m_bDerivedFrom?!m_strDerivedFrom.IsEmpty():FALSE):FALSE);

	m_checkInclude.EnableWindow(bEnable?m_bDerivedFrom:FALSE);
	m_editInclude.EnableWindow(bEnable?(m_bDerivedFrom?m_bInclude:FALSE):FALSE);

	m_checkHeader.EnableWindow(bEnable);
	m_staticImplementation.EnableWindow(bEnable);
	m_editLocationCPP.EnableWindow(bEnable);
	m_editLocationH.EnableWindow(bEnable?m_bHeader:FALSE);

	DWORD dwWizB = (bEnable?PSWIZB_NEXT:0);
	
	if (m_strLocationCPP.IsEmpty()) {
		GetParentSheet()->SetWizardButtons(0);
		return;
	}
	
	if (m_bDerivedFrom) {
		if (m_strDerivedFrom.IsEmpty()) {
			GetParentSheet()->SetWizardButtons(0);
			return;
		}
	}
	
	if (m_bInclude) {
		if (m_strInclude.IsEmpty()) {
			GetParentSheet()->SetWizardButtons(0);
			return;
		}
	}
	
	if (m_bHeader) {
		if (m_strLocationH.IsEmpty()) {
			GetParentSheet()->SetWizardButtons(0);
			return;
		}
	}
	
	GetParentSheet()->SetWizardButtons(dwWizB);
}

void CClassWizPage1::OnDerivedFromCheck() 
{
	UpdateData();
	SetEnabled();
}

void CClassWizPage1::OnChangeDerivedFromEdit() 
{
	UpdateData();

	m_strInclude = _T("");
	CString strRootName = m_strDerivedFrom;
	
	if (strRootName.GetLength())
	{
		// Get the root name for the cpp and h files.
		if (m_strDerivedFrom.GetAt(0) == 'C') {
			strRootName = m_strDerivedFrom.Right(
				m_strDerivedFrom.GetLength()-1);
		}
		
		if (strRootName.GetLength())
		{
			strRootName += _T(".h");
			m_strInclude.Format(IDS_INCLUDE, strRootName);
		}
	}

	SetEnabled();
	UpdateData(FALSE);
}

void CClassWizPage1::OnIncludeFileCheck() 
{
	UpdateData();
	SetEnabled();
}

void CClassWizPage1::OnChangeIncludeFileEdit() 
{
	UpdateData();
	SetEnabled();
}

void CClassWizPage1::OnHeaderCheck() 
{
	UpdateData();
	m_strLocationH = m_bHeader?_T(""):m_strLocationCPP;
	UpdateData(FALSE);
	SetEnabled();
}

void CClassWizPage1::OnChangeLocationEditCpp() 
{
	UpdateData();

	if (!m_bHeader)
	{
		m_strLocationH = m_strLocationCPP;
		UpdateData(FALSE);
	}

	SetEnabled();
}

void CClassWizPage1::OnChangeLocationEditH() 
{
	UpdateData();
	SetEnabled();
}
