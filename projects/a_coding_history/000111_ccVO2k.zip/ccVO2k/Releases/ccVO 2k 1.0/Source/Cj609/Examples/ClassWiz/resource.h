//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ClassWiz.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CLASSWIZ_DIALOG             102
#define IDS_INCLUDE                     102
#define IDS_PROPSHT_CAPTION             103
#define IDD_CLASSWIZ_PAGE1              104
#define IDS_INVALID_PATH_CPP            104
#define IDD_CLASSWIZ_PAGE2              105
#define IDS_INVALID_PATH_H              105
#define IDS_m_bHeader2                  106
#define IDS_m_strHeader                 107
#define IDS_m_bSerialize                108
#define IDS_m_nSerialize                109
#define IDS_m_bUseMFC                   110
#define IDS_m_strClassNameCPP           111
#define IDS_m_strClassNameH             112
#define IDS_m_strClassName              113
#define IDS_m_bDerivedFrom              114
#define IDS_m_bInclude                  115
#define IDS_m_nAs                       116
#define IDS_m_strDerivedFrom            117
#define IDS_m_strInclude                118
#define IDS_m_strLocationCPP            119
#define IDS_m_strLocationH              120
#define IDS_m_bHeader1                  121
#define IDS_Settings                    122
#define CG_IDS_PHYSICAL_MEM             123
#define CG_IDS_DISK_SPACE               124
#define CG_IDS_DISK_SPACE_UNAVAIL       125
#define IDR_MAINFRAME                   128
#define IDB_WIZARDBACK                  129
#define IDC_STATIC_ADDRESS              1000
#define IDC_CLASS_NAME_EDIT             1000
#define IDC_CJ_LOGO                     1001
#define IDC_DERIVED_FROM_CHECK          1001
#define IDC_STATIC_MAILME               1002
#define IDC_DERIVED_FROM_EDIT           1002
#define IDC_AS_COMBO                    1003
#define IDC_LOCATION_EDIT_CPP           1004
#define IDC_LOCATION_EDIT_H             1005
#define IDC_CLASS_NAME_STATIC_CPP       1006
#define IDC_CLASS_NAME_STATIC_H         1007
#define IDC_AS_STATIC                   1008
#define IDC_INCLUDE_FILE_CHECK          1009
#define IDC_INCLUDE_FILE_EDIT           1010
#define IDC_SERIALIZE_COMBO             1010
#define IDC_HEADER_CHECK                1011
#define IDC_USE_MFC_CHECK               1011
#define IDC_IMPLEMENTATION_STATIC       1012
#define IDC_SERIALIZE_CHECK             1013
#define IDC_STATIC_CLASS_INFO           1018
#define IDC_STATIC_FILE_LOC             1019
#define IDC_STATIC_MICROSOFT            1020
#define IDC_HEADER_EDIT                 1025
#define IDC_HEADER_CHECK2               1027
#define IDB_BTN_ARROW                   5016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
