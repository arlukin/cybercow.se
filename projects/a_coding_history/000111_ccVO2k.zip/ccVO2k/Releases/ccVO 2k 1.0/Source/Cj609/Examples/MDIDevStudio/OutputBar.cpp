// OutputBar.cpp : implementation file
//
/////////////////////////////////////////////////////////////////////////////

#include "StdAfx.h"
#include "MDIDevStudio.h"
#include "OutputBar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COutputBar

COutputBar::COutputBar()
{
	UpdateFont();
	m_eChildBorder = OUTLINE;
}

COutputBar::~COutputBar()
{
	// TODO: add destruction code here.
}

IMPLEMENT_DYNAMIC(COutputBar, CCJControlBar)

BEGIN_MESSAGE_MAP(COutputBar, CCJControlBar)
	//{{AFX_MSG_MAP(COutputBar)
	ON_WM_CREATE()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static CString strBuild[] =
{
	_T("--------------------Configuration: TestApp - Win32 Debug--------------------"),
	_T("Compiling..."),
	_T("TestAppView.cpp"),
	_T("Linking..."),
	_T(""),
	_T("TestApp.exe - 0 error(s), 0 warning(s)"),
};

static CString strDebug[] =
{
	_T("Loaded 'E:\\WINNT\\System32\\ntdll.dll', no matching symbolic information found."),
	_T("Loaded symbols for 'E:\\WINNT\\system32\\MFC42D.DLL'"),
	_T("Loaded symbols for 'E:\\WINNT\\system32\\MSVCRTD.DLL'"),
	_T("Loaded 'E:\\WINNT\\system32\\KERNEL32.DLL', no matching symbolic information found."),
	_T("Loaded 'E:\\WINNT\\system32\\GDI32.DLL', no matching symbolic information found."),
	_T("Loaded 'E:\\WINNT\\system32\\USER32.DLL', no matching symbolic information found."),
	_T("Loaded 'E:\\WINNT\\system32\\ADVAPI32.DLL', no matching symbolic information found."),
	_T("Loaded 'E:\\WINNT\\system32\\RPCRT4.DLL', no matching symbolic information found."),
	_T("Loaded symbols for 'E:\\WINNT\\system32\\MFCO42D.DLL'")
};

/////////////////////////////////////////////////////////////////////////////
// COutputBar message handlers

int COutputBar::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CCJControlBar::OnCreate(lpCreateStruct) == -1)
		return -1;

	// create  the flat tab control.
	if (!m_FlatTabCtrl.Create(NULL, NULL, WS_VISIBLE | WS_CHILD | FTS_HASARROWS | FTS_BOTTOM,
		CRect(10,10,200,25), this, IDC_FLATTAB))
	{
		TRACE0( "Unable to create flat tab control bar\n" );
		return -1;
	}

	// insert the tabs into the control.
	CString strBuffer;
	strBuffer.LoadString(IDS_BUILD);
	m_FlatTabCtrl.InsertItem(0, strBuffer);
	strBuffer.LoadString(IDS_DEBUG);
	m_FlatTabCtrl.InsertItem(1, strBuffer);
	strBuffer.LoadString(IDS_FIND1);
	m_FlatTabCtrl.InsertItem(2, strBuffer);
	strBuffer.LoadString(IDS_FIND2);
	m_FlatTabCtrl.InsertItem(3, strBuffer);

	// define the default style for the output lists.
	DWORD dwStyle = WS_CHILD | WS_VISIBLE | LBS_NOINTEGRALHEIGHT | 
		WS_VSCROLL | WS_TABSTOP;

	// create the build list.
	if (!m_BuildList.Create( dwStyle, CRect(0,0,0,0), this, ID_BUILDLIST ))
	{
		TRACE( "Failed to create output window.\n" );
		return -1;
	}
	m_BuildList.SetFont( &m_Font );

	// create the debug list.
	if (!m_DebugList.Create( dwStyle, CRect(0,0,0,0), this, ID_DEBUGLIST ))
	{
		TRACE( "Failed to create output window.\n" );
		return -1;
	}
	m_DebugList.SetFont( &m_Font );
	
	// create the find 1 list.
	if (!m_Find1List.Create( dwStyle, CRect(0,0,0,0), this, ID_FIND1LIST ))
	{
		TRACE( "Failed to create output window.\n" );
		return -1;
	}
	m_Find1List.SetFont( &m_Font );

	// create the find 2 list.
	if (!m_Find2List.Create( dwStyle, CRect(0,0,0,0), this, ID_FIND2LIST ))
	{
		TRACE( "Failed to create output window.\n" );
		return -1;
	}
	m_Find2List.SetFont( &m_Font );

	// fill the debug list with some data.
	int nBuildCount = sizeof(strBuild)/sizeof(strBuild[0]);
	for( int i = 0; i < nBuildCount; ++i) {
		m_BuildList.AddString(strBuild[i]);
	}

	// fill the debug list with some data.
	int nDebugCount = sizeof(strDebug)/sizeof(strDebug[0]);
	for( i = 0; i < nDebugCount; ++i) {
		m_DebugList.AddString(strDebug[i]);
	}

	// set the current tab.
	SelectTabView(0);
	return 0;
}

BOOL COutputBar::OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult) 
{
	if(IDC_FLATTAB == (UINT)wParam)
	{
		NMHDR* pNMHDR = (NMHDR*)lParam;

		switch(pNMHDR->code)
		{
		case TCN_SELCHANGING:
			break;
		case TCN_SELCHANGE:
			SelectTabView(m_FlatTabCtrl.GetCurSel());
			break;
		}
	}
	
	return CCJControlBar::OnNotify(wParam, lParam, pResult);
}

void COutputBar::OnSize(UINT nType, int cx, int cy) 
{
	CCJControlBar::OnSize(nType, cx, cy);
	
	if(m_FlatTabCtrl.GetSafeHwnd())
	{
		CRect rc;
		GetChildRect(rc);
		rc.DeflateRect(1,1);

		// resize the flat tab control.
		m_FlatTabCtrl.MoveWindow(rc.left, rc.bottom-15, rc.Width(), 15);

		int nBottom = rc.bottom;
		if(IsHorzDocked()) {
			nBottom -= 21;
		} else if(IsVertDocked()) {
			nBottom -= 34;
		} else {
			nBottom -= 19;
		}

		// resize lists.
		m_BuildList.MoveWindow(rc.left, rc.top, rc.Width(), nBottom);
		m_DebugList.MoveWindow(rc.left, rc.top, rc.Width(), nBottom);
		m_Find1List.MoveWindow(rc.left, rc.top, rc.Width(), nBottom);
		m_Find2List.MoveWindow(rc.left, rc.top, rc.Width(), nBottom);
	}
}

void COutputBar::UpdateFont()
{
	m_Font.DeleteObject();
	NONCLIENTMETRICS ncm;
	memset(&ncm, 0, sizeof(NONCLIENTMETRICS));
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	VERIFY(::SystemParametersInfo(SPI_GETNONCLIENTMETRICS,
		sizeof(NONCLIENTMETRICS), &ncm, 0));
	_tcscpy( ncm.lfMessageFont.lfFaceName, _T("Courier"));
	m_Font.CreateFontIndirect(&ncm.lfMessageFont);
}

void COutputBar::SelectTabView(int nTab)
{
	m_BuildList.ShowWindow((nTab==0)?SW_SHOW:SW_HIDE);
	m_DebugList.ShowWindow((nTab==1)?SW_SHOW:SW_HIDE);
	m_Find1List.ShowWindow((nTab==2)?SW_SHOW:SW_HIDE);
	m_Find2List.ShowWindow((nTab==3)?SW_SHOW:SW_HIDE);
}
