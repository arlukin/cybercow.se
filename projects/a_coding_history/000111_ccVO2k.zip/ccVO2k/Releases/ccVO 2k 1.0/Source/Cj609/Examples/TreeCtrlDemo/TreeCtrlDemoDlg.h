// TreeCtrlDemoDlg.h : header file
//

#if !defined(AFX_TREECTRLDEMODLG_H__D52D23D4_9130_11D3_9983_00500487D199__INCLUDED_)
#define AFX_TREECTRLDEMODLG_H__D52D23D4_9130_11D3_9983_00500487D199__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CTreeCtrlDemoDlg dialog

class CTreeCtrlDemoDlg : public CDialog
{
// Construction
public:
	CTreeCtrlDemoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CTreeCtrlDemoDlg)
	enum { IDD = IDD_TREECTRLDEMO_DIALOG };
	CComboBox	m_SizeCombo;
	CCJColorPicker	m_ColorPicker;
	CCJTreeCtrl		m_TreeCtrl;
	CCJFontCombo	m_FontCombo;
	int		m_nIndex;
	int		m_nSizeCombo;
	BOOL	m_bBoldCheck;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTreeCtrlDemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	virtual BOOL OnInitDialog();
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON		m_hIcon;
	COLORREF	m_clrTreeText;
	LOGFONT		m_LogFont;
	CString		m_strFontSize;
	CImageList	m_ImageList;

	// Generated message map functions
	//{{AFX_MSG(CTreeCtrlDemoDlg)
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBoldCheck();
	afx_msg void OnApplyButton();
	afx_msg void OnSelendokSizeCombo();
	afx_msg void OnSelendokFontCombo();
	//}}AFX_MSG
	afx_msg void OnSelEndOK(UINT lParam, LONG wParam);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TREECTRLDEMODLG_H__D52D23D4_9130_11D3_9983_00500487D199__INCLUDED_)
