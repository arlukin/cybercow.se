// SDIStaticDemoDoc.cpp : implementation of the CSDIStaticDemoDoc class
//

#include "stdafx.h"
#include "SDIStaticDemo.h"

#include "SDIStaticDemoDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSDIStaticDemoDoc

IMPLEMENT_DYNCREATE(CSDIStaticDemoDoc, CDocument)

BEGIN_MESSAGE_MAP(CSDIStaticDemoDoc, CDocument)
	//{{AFX_MSG_MAP(CSDIStaticDemoDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSDIStaticDemoDoc construction/destruction

CSDIStaticDemoDoc::CSDIStaticDemoDoc()
{
	// TODO: add one-time construction code here

}

CSDIStaticDemoDoc::~CSDIStaticDemoDoc()
{
}

BOOL CSDIStaticDemoDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CSDIStaticDemoDoc serialization

void CSDIStaticDemoDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CSDIStaticDemoDoc diagnostics

#ifdef _DEBUG
void CSDIStaticDemoDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CSDIStaticDemoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSDIStaticDemoDoc commands
