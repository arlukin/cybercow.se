// SDIRebar.h : main header file for the SDIREBAR application
//

#if !defined(AFX_SDIREBAR_H__EE40D606_90D0_11D3_879B_000000000000__INCLUDED_)
#define AFX_SDIREBAR_H__EE40D606_90D0_11D3_879B_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CSDIRebarApp:
// See SDIRebar.cpp for the implementation of this class
//

class CSDIRebarApp : public CWinApp
{
public:
	CSDIRebarApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSDIRebarApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CSDIRebarApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SDIREBAR_H__EE40D606_90D0_11D3_879B_000000000000__INCLUDED_)
