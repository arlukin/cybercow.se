// SDIExplorerView.h : interface of the CSDIExplorerView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SDIEXPLORERVIEW_H__0500578E_9090_11D3_9982_00500487D199__INCLUDED_)
#define AFX_SDIEXPLORERVIEW_H__0500578E_9090_11D3_9982_00500487D199__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CSDIExplorerDoc;
class CSDIExplorerView : public CView
{
protected: // create from serialization only
	CSDIExplorerView();
	DECLARE_DYNCREATE(CSDIExplorerView)

// Attributes
public:
	CSDIExplorerDoc* GetDocument();
	CCJShellList	m_ShellList;

// Operations
public:
	CCJShellList& GetListCtrl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSDIExplorerView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CSDIExplorerView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CSDIExplorerView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	afx_msg void OnStyleChanged(int nStyleType, LPSTYLESTRUCT lpStyleStruct);
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in SDIExplorerView.cpp
inline CSDIExplorerDoc* CSDIExplorerView::GetDocument()
   { return (CSDIExplorerDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SDIEXPLORERVIEW_H__0500578E_9090_11D3_9982_00500487D199__INCLUDED_)
