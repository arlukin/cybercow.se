#if !defined(AFX_CCCCONTACTSTABPERSONALEMAIL_H__95C1CA76_201B_11D4_89A6_00609708DCFE__INCLUDED_)
#define AFX_CCCCONTACTSTABPERSONALEMAIL_H__95C1CA76_201B_11D4_89A6_00609708DCFE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// cccContactsTABPersonalEmail.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// cccContactsTABPersonalEmail dialog

class cccContactsTABPersonalEmail : public ccllGroup, public ccdbCtrl
{
// Construction
public:
	cccContactsTABPersonalEmail(CWnd* pParent = NULL);   // standard constructor
	~cccContactsTABPersonalEmail();

// *** Attributes
	ccdbSuperCtrl m_PrimEMail;

// Dialog Data
	//{{AFX_DATA(cccContactsTABPersonalEmail)
	enum { IDD = IDD_CONTACTS_TAB_PERSONAL_EMAIL };
	CButton	m_plainTextCtrl;
	CAnimateCtrl	m_mailAnim;
	CString	m_comment;
	CString	m_emailAdress;
	BOOL	m_plainText;
	//}}AFX_DATA
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(cccContactsTABPersonalEmail)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

	void displayFirstRecInList();

	// Build the menu who will be shown when pressing
	// Menu button.
	//
	void OnBuildMenu(ccMenuButton *menuButton);

	//
	//
	void OnNewItem();

	//
	//
	void OnDeleteItem();

	//
	//
	void OnChangedItem(bool bSave );

	bool refresh() { displayFirstRecInList(); return true;};
// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(cccContactsTABPersonalEmail)
	virtual BOOL OnInitDialog();
	afx_msg void OnChangeEmailAdress();
	afx_msg void OnChangeEmailComment();
	afx_msg void OnEmailSendusingplaintext();
	afx_msg void OnPrimemailBtn();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CCCCONTACTSTABPERSONALEMAIL_H__95C1CA76_201B_11D4_89A6_00609708DCFE__INCLUDED_)
