// cflvNewFolder.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "cflvNewFolder.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// *** Construction/Destruction
/////////////////////////////////////////////////////////////////////////////

cflvNewFolder::cflvNewFolder(CWnd* pParent /*=NULL*/)
	: CDialog(cflvNewFolder::IDD, pParent)
{
	//{{AFX_DATA_INIT(cflvNewFolder)
	m_text = _T("");
	//}}AFX_DATA_INIT
}

/////////////////////////////////////////////////////////////////////////////
// *** Overrides
/////////////////////////////////////////////////////////////////////////////

void cflvNewFolder::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(cflvNewFolder)
	DDX_Text(pDX, IDC_TEXT, m_text);
	DDV_MaxChars(pDX, m_text, 50);
	//}}AFX_DATA_MAP
}

/////////////////////////////////////////////////////////////////////////////
// *** Implementation
/////////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(cflvNewFolder, CDialog)
	//{{AFX_MSG_MAP(cflvNewFolder)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cflvNewFolder message handlers
