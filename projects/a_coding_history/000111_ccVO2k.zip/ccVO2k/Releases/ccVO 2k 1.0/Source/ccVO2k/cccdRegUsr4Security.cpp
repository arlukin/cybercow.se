// cccdRegUsr4Security.cpp : implementation file
//

#include "stdafx.h"
#include "cccdRegUsr4Security.h"
#include "TransferStructs.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccdRegUsr4Security property page

IMPLEMENT_DYNCREATE(cccdRegUsr4Security, CPropertyPage)

cccdRegUsr4Security::cccdRegUsr4Security() : CPropertyPage(cccdRegUsr4Security::IDD)
{
	//{{AFX_DATA_INIT(cccdRegUsr4Security)
	m_chgPassEveryXDay = _T("");
	m_lockoutAfterXBadLogins = _T("");
	m_resetCounterAfterXMinutes = _T("");
	m_locoutDuration = _T("");
	//}}AFX_DATA_INIT
}



cccdRegUsr4Security::~cccdRegUsr4Security()
{
}

void cccdRegUsr4Security::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(cccdRegUsr4Security)
	DDX_Text(pDX, IDC_CHG_PASS_EVERY_X_DAY, m_chgPassEveryXDay);
	DDX_Text(pDX, IDC_LOCKOUT_AFTER_X_BAD_LOGINS, m_lockoutAfterXBadLogins);
	DDX_Text(pDX, IDC_RESET_COUNTER_AFTER_X_MINUTES, m_resetCounterAfterXMinutes);
	DDX_Text(pDX, IDC_LOCKOUT_IS_DURING_X_MINUTES, m_locoutDuration);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(cccdRegUsr4Security, CPropertyPage)
	//{{AFX_MSG_MAP(cccdRegUsr4Security)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cccdRegUsr4Security message handlers


BOOL cccdRegUsr4Security::OnKillActive() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CPropertyPage::OnKillActive();
}

void cccdRegUsr4Security::OnOK() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	CPropertyPage::OnOK();
}
