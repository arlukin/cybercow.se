// cccMProjectPersonalContainer.cpp : implementation file
//

#include "stdafx.h"
#include "ccvo2k.h"
#include "cccMProjectPersonalContainer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccMProjectPersonalContainer

IMPLEMENT_DYNCREATE(cccMProjectPersonalContainer, CFormView)

cccMProjectPersonalContainer::cccMProjectPersonalContainer()
	: CFormView(cccMProjectPersonalContainer::IDD)
{
	//{{AFX_DATA_INIT(cccMProjectPersonalContainer)
	//}}AFX_DATA_INIT
}

cccMProjectPersonalContainer::~cccMProjectPersonalContainer()
{
}

void cccMProjectPersonalContainer::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(cccMProjectPersonalContainer)
	DDX_Control(pDX, IDC_LOGO_BITMAP, m_bitmap);	
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(cccMProjectPersonalContainer, CFormView)
	//{{AFX_MSG_MAP(cccMProjectPersonalContainer)
	ON_WM_CREATE()	
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(ID_BTN_CLEAR_DATABASE, OnClearDataBase)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cccMProjectPersonalContainer diagnostics

#ifdef _DEBUG
void cccMProjectPersonalContainer::AssertValid() const
{
	CFormView::AssertValid();
}

void cccMProjectPersonalContainer::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// cccMProjectPersonalContainer message handlers

int cccMProjectPersonalContainer::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CFormView::OnCreate(lpCreateStruct) == -1)
		return -1;

	theCCVOClient->setCurrentGridCtrl(NULL);
	
#ifdef _DEBUG
	m_clearDataBase.Create("Clear database", WS_VISIBLE, CRect(0,0,110,20), this, ID_BTN_CLEAR_DATABASE);
#endif

	return 0;
}

void cccMProjectPersonalContainer::OnClearDataBase() 
{
	if (MessageBox("Do you want to clear the database?", "WARNING, WARNING", MB_YESNO) == IDYES)
		if (MessageBox("Are you realy sure?", "WARNING, WARNING", MB_YESNO) == IDYES)
		{			
			if ( ( theCCVOClient->m_dataBase ) && ( theCCVOClient->m_dataBase->isOpen() ) )
			{
				try	
				{			
					try
					{													
						VARIANT RecordsEffected;
						RecordsEffected.vt = VT_INT;
						
						theCCVOClient->m_dataBase->beginTrans();
							CString strSQL;
							
							strSQL = "DELETE FROM  dtfContacts ";
							theCCVOClient->m_dataBase->getConnection()->Execute(_bstr_t(strSQL),&RecordsEffected,ADODB::adCmdText);

							strSQL = "DELETE FROM  dtfContactsEmail ";
							theCCVOClient->m_dataBase->getConnection()->Execute(_bstr_t(strSQL),&RecordsEffected,ADODB::adCmdText);

							strSQL = "DELETE FROM  dtfContactsPhone							 ";
							theCCVOClient->m_dataBase->getConnection()->Execute(_bstr_t(strSQL),&RecordsEffected,ADODB::adCmdText);

							strSQL = "DELETE FROM  dtfFavorites ";
							theCCVOClient->m_dataBase->getConnection()->Execute(_bstr_t(strSQL),&RecordsEffected,ADODB::adCmdText);

							strSQL = "DELETE FROM  dtfFTP ";
							theCCVOClient->m_dataBase->getConnection()->Execute(_bstr_t(strSQL),&RecordsEffected,ADODB::adCmdText);

							strSQL = "DELETE FROM  dtItems ";
							theCCVOClient->m_dataBase->getConnection()->Execute(_bstr_t(strSQL),&RecordsEffected,ADODB::adCmdText);

							strSQL = "DELETE FROM  dtMasterProject ";
							theCCVOClient->m_dataBase->getConnection()->Execute(_bstr_t(strSQL),&RecordsEffected,ADODB::adCmdText);

							strSQL = "DELETE FROM  dtMProjectMembers ";
							theCCVOClient->m_dataBase->getConnection()->Execute(_bstr_t(strSQL),&RecordsEffected,ADODB::adCmdText);

							strSQL = "DELETE FROM  dtTreeOrder ";
							theCCVOClient->m_dataBase->getConnection()->Execute(_bstr_t(strSQL),&RecordsEffected,ADODB::adCmdText);

							strSQL = "DELETE FROM  dtUser ";
							theCCVOClient->m_dataBase->getConnection()->Execute(_bstr_t(strSQL),&RecordsEffected,ADODB::adCmdText);

							strSQL = "DELETE FROM  dtUserActiveMProjects ";
							theCCVOClient->m_dataBase->getConnection()->Execute(_bstr_t(strSQL),&RecordsEffected,ADODB::adCmdText);							

						theCCVOClient->m_dataBase->commitTrans();

						return ;
					}
					catch(_com_error &e) 
					{ 
						theCCVOClient->m_dataBase->rollbackTrans();								

						ccErr(getProviderError( theCCVOClient->m_dataBase->getConnection()) );
						ccThrowccException( getProviderError( theCCVOClient->m_dataBase->getConnection()) ); /*Delete unreference warning*/ (void*)&e; 				
					}	
				}
				catch( ccException * e)
				{
					ccErr( *e, "", "", MB_OK );			
				}
				catch(...)
				{
					ccErrEM( IDS_CANT_RETRIVE_CONTACTS_PHONE_NUMBER, NULL, NULL, MB_OK );
				}
			}
			else
				ccErrEM( IDS_DATABASE_ISNT_OPEN, NULL, NULL, MB_OK);

		}	
}

void cccMProjectPersonalContainer::OnSize(UINT nType, int cx, int cy) 
{
	CFormView::OnSize(nType, cx, cy);

	if (IsWindow( m_bitmap ) )
	{
		CRect rect;
		m_bitmap.GetWindowRect( rect );
		m_bitmap.SetWindowPos(	NULL, (cx/2)-(rect.Width()/2), (cy/2)-(rect.Height()/2),0,0, SWP_NOZORDER | SWP_NOSIZE );		
	}
}



void cccMProjectPersonalContainer::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();

	
	if (IsWindow( m_bitmap ) )
	{
		CRect wndRect;
		GetWindowRect( wndRect );
		int cx = wndRect.Width();
		int cy = wndRect.Height();

		CRect rect;
		m_bitmap.GetWindowRect( rect );
		m_bitmap.SetWindowPos(	NULL, (cx/2)-(rect.Width()/2), (cy/2)-(rect.Height()/2),0,0, SWP_NOZORDER | SWP_NOSIZE );		
	}

	// TODO: Add your specialized code here and/or call the base class
	
}
