// cccccddFavorites.cpp: implementation of the cccccddFavorites class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "cccddFavorites.h"
#include "cccvodb.h"
#include "ccVOClient.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
#define TS ddf(cccddFavorites)

BEGIN_CCFIELD_EVENT( cccddFavorites  )		
//	ON_CCFIELD(	ID							OnSetFocus,				OnKillFocus,		OnValidate,		OnPopup,				OnEndPopup		OnChange				)
	ON_CCFIELD(	FAVORITES_DefaultBrowser,	NoFunc,					NoFunc,				NoFunc,			OnPopupDefaultBrowser,	NoFunc,			NoFunc					)
END_CCFIELD_EVENT()

//

cccddFavorites ::cccddFavorites ( ccDataBase* pDatabase ) 
: ccDataDictionary( pDatabase )
{
	try
	{
		setConfirmDeleteMsg("F2 delete doesn't work in this version");
		// Open the table.		
		openADO("SELECT  dtfFavorites.MProjectID,		dtTreeOrder.ItemID,			dtfFavorites.ItemID, "						
						"dtfFavorites.Name,				dtfFavorites.URL,			dtfFavorites.DefaultBrowser, "
						"dtfFavorites.Notes,			dtfFavorites.CreditGrade,	dtfFavorites.LastLogedOn, "
						"dtfFavorites.LastChecked,		dtfFavorites.ValidSite "
				"FROM dtfFavorites, dtItems, dtTreeOrder "
				"WHERE dtfFavorites.MProjectID = dtTreeOrder.MProjectID AND "
				"    dtfFavorites.ItemID = dtTreeOrder.ChildID AND "
				"    dtItems.MProjectID = dtTreeOrder.MProjectID AND "
				"    dtItems.ItemID = dtTreeOrder.ChildID  "
				" order by dtfFavorites.Name, dtfFavorites.URL"
				,ADODB::adOpenKeyset, ADODB::adLockPessimistic ,ADODB::adUseServer );
										
		bind( m_MProjectID,				FAVORITES_MProjectID,				_T("MProjectID")			);
		bind( m_ParentItemID,			FAVORITES_ParentItemID,				_T("dtTreeOrder.ItemID")	);
		bind( m_ItemID,					FAVORITES_ItemID,					_T("dtfFavorites.ItemID")	);
		bind( m_Name,					FAVORITES_Name,						_T("Name")					);
		bind( m_URL,					FAVORITES_URL,						_T("URL")					);
		bind( m_DefaultBrowser,			FAVORITES_DefaultBrowser,			_T("DefaultBrowser")		);
		bind( m_Notes,					FAVORITES_Notes,					_T("Notes")					);
		bind( m_CreditGrade,			FAVORITES_CreditGrade,				_T("CreditGrade")			);
		bind( m_LastLogedOn,			FAVORITES_LastLogedOn,				_T("LastLogedOn")			);
		bind( m_LastChecked,			FAVORITES_LastChecked,				_T("LastChecked")			);
		bind( m_ValidSite,				FAVORITES_ValidSite,				_T("ValidSite")				);
		
		m_Name.enableColumnSorting( true );
		m_URL.enableColumnSorting( true );		
					
		// FAVORITES_MProjectID
		m_MProjectID.setLongCaption(	_T("MProjectID") );
		m_MProjectID.setShortCaption(	_T("MProjectID") );
		m_MProjectID.setStatusHelp(		_T("MProjectID") );

		// FAVORITES_ParentItemID
		m_ParentItemID.setLongCaption(	_T("ParentItemID") );
		m_ParentItemID.setShortCaption(	_T("ParentItemID") );
		m_ParentItemID.setStatusHelp(	_T("ParentItemID") );

		// FAVORITES_ItemID
		m_ItemID.setLongCaption(	_T("ItemID") );
		m_ItemID.setShortCaption(	_T("ItemID") );
		m_ItemID.setStatusHelp(		_T("ItemID") );

		// FAVORITES_Name
		m_Name.setLongCaption(	_T("Name") );
		m_Name.setShortCaption(	_T("Name") );
		m_Name.setStatusHelp(	_T("Name") );

		// FAVORITES_URL
		m_URL.setLongCaption(	_T("URL") );
		m_URL.setShortCaption(	_T("URL") );
		m_URL.setStatusHelp(	_T("URL") );

		// FAVORITES_DefaultBrowser
		m_DefaultBrowser.setLongCaption(	_T("Default Browser") );
		m_DefaultBrowser.setShortCaption(	_T("Default Browser") );
		m_DefaultBrowser.setStatusHelp(		_T("Default Browser") );
		m_DefaultBrowser.setStyle( WS_DISABLED );
		
		// FAVORITES_Notes
		m_Notes.setLongCaption(		_T("Notes") );
		m_Notes.setShortCaption(	_T("Notes") );
		m_Notes.setStatusHelp(		_T("Notes") );
		m_Notes.setEditMultiLine( true );		

		// FAVORITES_CreditGrade
		m_CreditGrade.setLongCaption(	_T("Credit Grade") );
		m_CreditGrade.setShortCaption(	_T("Credit Grade") );
		m_CreditGrade.setStatusHelp(	_T("Credit Grade") );

		// FAVORITES_LastLogedOn
		m_LastLogedOn.setLongCaption(	_T("Last Loged On") );
		m_LastLogedOn.setShortCaption(	_T("Last Loged On") );
		m_LastLogedOn.setStatusHelp(	_T("Last Loged On") );
		m_LastLogedOn.setMaskType( CCE_DATE );		
		m_LastLogedOn.setStyle( WS_DISABLED );

		// FAVORITES_LastChecked
		m_LastChecked.setLongCaption(	_T("Last Checked") );
		m_LastChecked.setShortCaption(	_T("Last Checked") );
		m_LastChecked.setStatusHelp(	_T("Last Checked") );
		m_LastChecked.setMaskType( CCE_DATE );
		m_LastChecked.setStyle( WS_DISABLED );

		// FAVORITES_ValidSite
		m_ValidSite.setLongCaption(		_T("Valid Site") );
		m_ValidSite.setShortCaption(	_T("Valid Site") );
		m_ValidSite.setStatusHelp(		_T("Valid Site") );
		m_ValidSite.setStyle( WS_DISABLED );

	}
	catch(ccException *e) 
	{
		ccErr(*e,"","", MB_OK);
		exit(1);
	}
	catch(...) 
	{
		ccErr("DB Error", "","", MB_OK);
		exit(1);
	}
}

//

cccddFavorites ::~cccddFavorites ()
{
	

}

//////////////////////////////////////////////////////////////////////
// *** Table Field Events
//////////////////////////////////////////////////////////////////////

void cccddFavorites::creating()
{
	m_MProjectID = getSelLeafMProjectID();
	m_ItemID = getDB()->createItemID();		

	getDB()->insert_dtItems( m_MProjectID, m_ItemID, m_Name, 2, 5);
	getDB()->insert_dtTreeOrder( m_MProjectID, getSelLeafItemID(), m_ItemID);	
}

//

void cccddFavorites::updateing()
{	
	getDB()->update_dtItems( m_MProjectID, m_ItemID, (CString)m_Name);
}

//

void cccddFavorites::deleting()
{ 	
}

//

void cccddFavorites::OnFieldChangeComplete()
{
}

//

void cccddFavorites::OnFieldClearComplete()
{
}


bool cccddFavorites::OnPopupDefaultBrowser(DD_DISPINFO *aDispInfo)
{
	if (aDispInfo->m_field!=NULL)
	{	
		ccListPopupDialog *loListPopup;
		loListPopup = new ccListPopupDialog(aDispInfo->m_superCtrl);

		//Build the list poup.
		loListPopup->addItem(0, "Internet Explorer");
		loListPopup->addItem(1, "Netscape");
		loListPopup->addItem(2, "Mosaic");
		loListPopup->addItem(3, "Opera");
				
		loListPopup->popup();		
	}    
	return CCSUCCEDED;	
}

//////////////////////////////////////////////////////////////////////
// *** SQL-Script Functions
//////////////////////////////////////////////////////////////////////

bool cccddFavorites::deleteFavorite( int nMProjectID, int nParentID, int nItemID)
{
	if ( ( getDB() ) && ( getDB()->isOpen() ) )
	{
		try
		{			
			try
			{
				ccString strSQL, strWhereSQL;	
				
				strWhereSQL <<   " where MProjectID = " << nMProjectID;
				strWhereSQL <<     " and ItemID = "     << nItemID;
												
				VARIANT RecordsEffected;
				RecordsEffected.vt = VT_INT;
				
				getDB()->beginTrans();
					
					strSQL << "DELETE FROM dtfFavorites " << strWhereSQL;
					getDB()->getConnection()->Execute(_bstr_t(strSQL),&RecordsEffected,ADODB::adCmdText);

					strSQL=""; strSQL << "DELETE FROM dtItems " << strWhereSQL;
					getDB()->getConnection()->Execute(_bstr_t(strSQL),&RecordsEffected,ADODB::adCmdText);

					strSQL=""; strSQL << "DELETE FROM dtTreeOrder ";
							   strSQL << "where MProjectID = " << nMProjectID;
							   strSQL << "  and ItemID = "     << nParentID;
							   strSQL << "  and ChildID = "    << nItemID;
					getDB()->getConnection()->Execute(_bstr_t(strSQL),&RecordsEffected,ADODB::adCmdText);

				getDB()->commitTrans();

				return true;
			}
			catch(_com_error &e) 
			{ 
				getDB()->rollbackTrans();								

				ccErr(getProviderError( getDB()->getConnection()) );
				ccThrowccException( getProviderError( getDB()->getConnection()) ); /*Delete unreference warning*/ (void*)&e; 				
			}	
		}
		catch( ccException * e)
		{
			ccErr( *e, "", "", MB_OK );			
		}
		catch(...)
		{
			ccErrEM( IDS_CANT_RETRIVE_CONTACTS_PHONE_NUMBER, NULL, NULL, MB_OK );
		}
	}
	else
		ccErrEM( IDS_DATABASE_ISNT_OPEN, NULL, NULL, MB_OK);

	return false;
}