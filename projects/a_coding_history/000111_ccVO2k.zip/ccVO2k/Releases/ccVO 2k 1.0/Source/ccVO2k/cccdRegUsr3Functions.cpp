// cccdRegUsr3Functions.cpp : implementation file
//

#include "stdafx.h"
#include "cccdRegUsr3Functions.h"
#include "TransferStructs.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccdRegUsr3Functions property page

IMPLEMENT_DYNCREATE(cccdRegUsr3Functions, CPropertyPage)

cccdRegUsr3Functions::cccdRegUsr3Functions() : CPropertyPage(cccdRegUsr3Functions::IDD)
{
	//{{AFX_DATA_INIT(cccdRegUsr3Functions)
	m_currency = _T("");
	m_paymentType = _T("");
	m_storage = 1;
	m_price = 0;
	//}}AFX_DATA_INIT
}

cccdRegUsr3Functions::~cccdRegUsr3Functions()
{
}

void cccdRegUsr3Functions::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(cccdRegUsr3Functions)	
	DDX_Control(pDX, IDC_PRICE, m_priceCtrl);
	DDX_Control(pDX, IDC_DELIVERY_ADDRESS, m_deliveryAddressCtrl);
	DDX_Control(pDX, IDC_CURRENCY, m_currencyCtrl);
	DDX_Control(pDX, IDC_PAYMENT_TYPES, m_paymentTypesCtrl);
	DDX_Control(pDX, IDC_FUNCTION_LIST, m_functionListCtrl);		
	DDX_Control(pDX, IDC_STORAGE, m_storageCtrl);
	DDX_CBString(pDX, IDC_CURRENCY, m_currency);
	DDV_MaxChars(pDX, m_currency, 40);
	DDX_CBString(pDX, IDC_PAYMENT_TYPES, m_paymentType);
	DDV_MaxChars(pDX, m_paymentType, 40);
	DDX_Text(pDX, IDC_STORAGE, m_storage);
	DDV_MinMaxInt(pDX, m_storage, 1, 5000);
	DDX_Text(pDX, IDC_PRICE, m_price);
	DDV_MinMaxInt(pDX, m_price, 0, 2147483647);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(cccdRegUsr3Functions, CPropertyPage)
	//{{AFX_MSG_MAP(cccdRegUsr3Functions)
	ON_LBN_SELCHANGE(IDC_FUNCTION_LIST, OnSelchangeFunctionList)
	ON_EN_CHANGE(IDC_STORAGE, OnChangeStorage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cccdRegUsr3Functions message handlers

BOOL cccdRegUsr3Functions::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();

	// Initialie Storage spinctrl
	m_storageCtrl.setNumericMask( 1, 5000 );
	m_storageCtrl.enableSpinCtrl();

	m_currencyCtrl.EnableAutoCompletion( TRUE );	
	m_paymentTypesCtrl.EnableAutoCompletion( TRUE );	

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

//

BOOL cccdRegUsr3Functions::OnSetActive() 
{
	((CPropertySheet*)GetParent())->SetWizardButtons(PSWIZB_BACK | PSWIZB_FINISH);

	// Fill function listbox
	m_functionListCtrl.ResetContent();
	for (int i=0; i < m_regUsr->m_numOfFunctions; i++)
	{
		m_functionListCtrl.AddString( m_regUsr->m_functionName[i] );
		m_functionListCtrl.SetCheck( i, m_regUsr->m_newUser.m_functions[i] );
		m_functionListCtrl.Enable  ( i, m_regUsr->m_enabled[i] );
	}

	// Set storage
	CString lsStorage;
	lsStorage.Format("%d", m_regUsr->m_newUser.m_storage );
	m_storageCtrl.SetWindowText( lsStorage );		

	// Fill Currency types combo
	m_currencyCtrl.ResetContent();
	for (i=0; i < m_regUsr->m_numOfCurrencyTypes; i++)
	{
		int iIndex = m_currencyCtrl.AddString( m_regUsr->m_currencyTypeName[i] );	
		m_currencyCtrl.SetItemData( iIndex,i);
	}
	m_currencyCtrl.SelectString(0, m_regUsr->m_currencyTypeName[ m_regUsr->m_newUser.m_currencyType ] );

	CString lsPrice;
	lsPrice.Format("%d", calcPrice());
	m_priceCtrl.SetWindowText( lsPrice);		

	// Fill Payment types combo
	m_paymentTypesCtrl.ResetContent();
	for (i=0; i < m_regUsr->m_numOfPaymentTypes; i++)
	{
		int iIndex = m_paymentTypesCtrl.AddString( m_regUsr->m_paymentTypeName[i] );	
		m_paymentTypesCtrl.SetItemData( iIndex,i);		
	}	
	m_paymentTypesCtrl.SelectString(0, m_regUsr->m_paymentTypeName[ m_regUsr->m_newUser.m_paymentType ] );	

	// Build delivery adress
	CString lsDeliveryAdress;	
	lsDeliveryAdress += m_regUsr->m_newUser.m_fullName;	lsDeliveryAdress += "\r\n";		
	lsDeliveryAdress += m_regUsr->m_newUser.m_company;	lsDeliveryAdress += "\r\n";
	lsDeliveryAdress += m_regUsr->m_newUser.m_address;	lsDeliveryAdress += "\r\n";
	lsDeliveryAdress += m_regUsr->m_newUser.m_zipCode;	lsDeliveryAdress += " ";
	lsDeliveryAdress += m_regUsr->m_newUser.m_city;		lsDeliveryAdress += "\r\n";
	lsDeliveryAdress += m_regUsr->m_newUser.m_country;	lsDeliveryAdress += "\r\n";
	m_deliveryAddressCtrl.SetWindowText(lsDeliveryAdress);
	
	return CPropertyPage::OnSetActive();
}

//

LRESULT cccdRegUsr3Functions::OnWizardBack() 
{
	if (!validateAndSave())
		return TRUE;
	else				
		return CPropertyPage::OnWizardBack();
}

//

LRESULT cccdRegUsr3Functions::OnWizardNext() 
{
	// TODO: Add your specialized code here and/or call the base class
	if (!validateAndSave())
		return TRUE;
	else		
		return CPropertyPage::OnWizardNext();
}

//

BOOL cccdRegUsr3Functions::OnWizardFinish() 
{
	// TODO: Add your specialized code here and/or call the base class
	if (!validateAndSave())
		return TRUE;
	else		
		return CPropertyPage::OnWizardFinish();
}

//
BOOL cccdRegUsr3Functions::validateAndSave()
{
	UpdateData();
	
	CString lsErrorMessage;

	// No need for function validation	

	if ( (m_storage < 0) )
		lsErrorMessage += "You must enter how much storage you want\n";

	if ( m_currencyCtrl.GetCurSel() == CB_ERR)
	{		
		lsErrorMessage += "You have selected no or an invalid currency type\n";
	}	

	if ( m_paymentTypesCtrl.GetCurSel() == CB_ERR)
	{		
		lsErrorMessage += "You have selected no or an invalid payment type\n";
	}	
	
	if ( !lsErrorMessage.IsEmpty() )
	{
		MessageBox( lsErrorMessage, "Reminder");
		return FALSE;
	}
	else	
	{
		// Save values
		for (int i=0; i < m_regUsr->m_numOfFunctions; i++)
		{						
			m_regUsr->m_newUser.m_functions[i] = (m_functionListCtrl.GetCheck( i ) != 0 ? 1 : 0) ;
		}

		m_regUsr->m_newUser.m_storage		= m_storage;		
			
		m_regUsr->m_newUser.m_currencyType  = m_currencyCtrl.GetItemData( m_currencyCtrl.GetCurSel() );
		m_regUsr->m_newUser.m_paymentType   = m_paymentTypesCtrl.GetItemData( m_paymentTypesCtrl.GetCurSel() );
		
		m_regUsr->m_newUser.m_price			= m_price;

		return TRUE;
	}
}

//

int cccdRegUsr3Functions::calcPrice()
{
	UpdateData();

	int liPrice;
	liPrice = 0;

	for (int i=0; i < m_regUsr->m_numOfFunctions; i++)
	{		
		if (m_functionListCtrl.GetCheck(i) !=0)
		{
			liPrice += m_regUsr->m_functionPrice[i];
		}
	}
	
	int liStorageToPayFor =	m_storage - m_regUsr->m_freeStorage;
	if (liStorageToPayFor > 0)
		liPrice += (liStorageToPayFor * m_regUsr->m_storagePrice);
	
	return liPrice;
}

void cccdRegUsr3Functions::OnSelchangeFunctionList() 
{	
	CString lsPrice;
	lsPrice.Format("%d", calcPrice());
	m_priceCtrl.SetWindowText( lsPrice);	
}

void cccdRegUsr3Functions::OnChangeStorage() 
{
	CString lsPrice;
	lsPrice.Format("%d", calcPrice());
	m_priceCtrl.SetWindowText( lsPrice);	
}

