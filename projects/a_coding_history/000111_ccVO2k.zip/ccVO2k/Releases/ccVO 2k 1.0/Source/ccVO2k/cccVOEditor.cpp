// cccVOEditor.cpp : implementation file
//

#include "stdafx.h"
#include "ccvo2k.h"

#include "cccVOEditor.h"
#include "cccContactsPreviewPane.h"
#include "cccFavoritesPreviewPane.h"
#include "cccFTPPreviewPane.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccVOEditor

IMPLEMENT_DYNCREATE(cccVOEditor, ccFrameWnd)

int cccVOEditor::m_numberOfccVOEditorWindowsOpened = 0;
cccVOEditor::cccVOEditor( E_ccVOViews eMode, CWnd *pParent)
{	
	ASSERT(pParent);

	setWinPlacementRegPath( dPROGRAM_REG_PATH, "ccVOEditor_Contacts_Window");
	m_topMainFrame = pParent;
	
	m_ccVoMode = eMode;

	switch(m_ccVoMode )
	{
	case CCVO_CONTACTS_MODE:
		createContactsMode( );
		break;
	case CCVO_FAVORITES_MODE:
		createFavoritesMode();
        break;

    case CCVO_FTP_MODE:
        createFTPMode();
        break;
    default:
		ccErr("Error","","", MB_OK);		
		return;
	}
}

//

cccVOEditor::cccVOEditor()
{
}

//

cccVOEditor::~cccVOEditor()
{
}

//

BEGIN_MESSAGE_MAP(cccVOEditor, ccFrameWnd)
	//{{AFX_MSG_MAP(cccVOEditor)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_COMMAND(ID_PREVIOUS_ITEM, OnPreviousItem)
	ON_COMMAND(ID_FILE_EXIT, OnFileExit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};


/////////////////////////////////////////////////////////////////////////////
// cccVOEditor message handlers

bool cccVOEditor::createDefaultMode( int nCaptionResource, int nToolBarRecource, int nMenuBarRecource )
{
	// Create Window
	CString strCaptionName; 
	strCaptionName.LoadString( nCaptionResource );
	Create(NULL, strCaptionName,
		WS_CAPTION | WS_MAXIMIZEBOX | WS_MINIMIZEBOX | WS_THICKFRAME | FWS_ADDTOTITLE |WS_BORDER |WS_SYSMENU ,
		CRect(100,100,520,522),NULL,NULL,
		WS_EX_CLIENTEDGE | WS_EX_WINDOWEDGE  ,
		NULL);

	// Create Toolbar
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar( nToolBarRecource ))
	{
		ccErrEM( IDS_FAILED_TO_CREATE_TOOLBAR );
		return false;      // fail to create
	}

	// Create MenuBar	
	if (!m_wndMenuBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_ALIGN_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC, CRect(0,0,0,0), ID_MENUBAR) || 
		!m_wndMenuBar.LoadMenu( nMenuBarRecource ))
	{
		ccErrEM(IDS_FAILED_TO_CREATE_MENUBAR);
		return false;      // fail to create
	};

	// Create StatusBar
	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		ccErrEM(IDS_FAILED_TO_CREATE_STATUS_BAR);
		return false;      // fail to create
	}
		
	m_wndMenuBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndMenuBar);
	DockControlBar(&m_wndToolBar);

	return true;

}

//

bool cccVOEditor::createContactsMode()
{	
	if ( !createDefaultMode( IDS_F_CONTACTS, IDR_CCVOEDITOR_CONTACTS, IDR_CCVOEDITOR_CONTACTS) )
		return false;

	// Special toolbar initalization.
	m_wndToolBar.AddDropDownButton(ID_FILE_NEW_CONTACT      , IDR_CONTACTS_TB_NEW, TRUE);
	//m_wndToolBar.AddDropDownButton(IDM_NEW_MESSAGE_TO_CONTACT, IDR_CONTACTS_TB_NEW_MESSAGE_USING, TRUE);	
	m_wndToolBar.AddDropDownButton(ID_NEXT_ITEM    , IDR_NEXT_DB_ITEM, TRUE);	
	m_wndToolBar.AddDropDownButton(ID_PREVIOUS_ITEM, IDR_PREV_DB_ITEM, TRUE);	

	CRuntimeClass* pListPaneClass = RUNTIME_CLASS( cccContactsPreviewPane );
	if (!switchToView(pListPaneClass))
	{		
		ccErrEM( IDS_FAILED_TO_CREATE_CONTACTS_VIEW );		
	}		

	ShowWindow(SW_SHOW);
	UpdateWindow();	

	return true;
}

//

bool cccVOEditor::createFavoritesMode()
{
	if ( !createDefaultMode( IDS_F_FAVORITES, IDR_CCVOEDITOR_FAVORITES, IDR_CCVOEDITOR_FAVORITES) )
		return false;

	// Special toolbar initalization.
	m_wndToolBar.AddDropDownButton(ID_FILE_NEW_FAVORITE, IDR_FAVORITES_TB_NEW, TRUE);	
	m_wndToolBar.AddDropDownButton(ID_NEXT_ITEM    , IDR_NEXT_DB_ITEM, TRUE);	
	m_wndToolBar.AddDropDownButton(ID_PREVIOUS_ITEM, IDR_PREV_DB_ITEM, TRUE);	

	CRuntimeClass* pListPaneClass = RUNTIME_CLASS( cccFavoritesPreviewPane );
	if (!switchToView(pListPaneClass))
	{		
		ccErrEM( IDS_FAILED_TO_CREATE_FAVORITES_VIEW );
	}		

	ShowWindow(SW_SHOW);
	UpdateWindow();	

	return true;
}

//

bool cccVOEditor::createFTPMode()
{
        if ( !createDefaultMode( IDS_F_FTP, IDR_CCVOEDITOR_FTP, IDR_CCVOEDITOR_FTP) )
                return false;

        // Special toolbar initalization.
        m_wndToolBar.AddDropDownButton(ID_FILE_NEW_FTP,  IDR_FTP_TB_NEW, TRUE); 
        m_wndToolBar.AddDropDownButton(ID_NEXT_ITEM    , IDR_NEXT_DB_ITEM, TRUE);       
        m_wndToolBar.AddDropDownButton(ID_PREVIOUS_ITEM, IDR_PREV_DB_ITEM, TRUE);       

        CRuntimeClass* pListPaneClass = RUNTIME_CLASS( cccFTPPreviewPane );
        if (!switchToView(pListPaneClass))
        {               
                ccErrEM( IDS_FAILED_TO_CREATE_FTP_VIEW );
        }               

        ShowWindow(SW_SHOW);
        UpdateWindow(); 

        return true;
}

//

BOOL cccVOEditor::switchToView(CRuntimeClass *pNewViewClass)
{		
	// create the new view
	CCreateContext context;
	context.m_pNewViewClass = pNewViewClass;	
	CView* pNewView = STATIC_DOWNCAST(CView, CreateView(&context, AFX_IDW_PANE_FIRST ));
	if (pNewView != NULL)
	{
		// the new view is there, but invisible and not active...
		pNewView->ShowWindow(SW_SHOW);		
		//pNewView->setDB(NULL);
		pNewView->OnInitialUpdate();
		SetActiveView(pNewView);
		RecalcLayout();
		return TRUE;
	}

	return FALSE;
}

//

int cccVOEditor::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (ccFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	// If any window is already opened, move the new  
	// 20 pixel down and to the right.
	if (m_numberOfccVOEditorWindowsOpened)
	{
		WINDOWPLACEMENT wp;
		wp.length = sizeof(WINDOWPLACEMENT);
		GetWindowPlacement(&wp);
		wp.ptMinPosition.x +=20;
		wp.ptMinPosition.y +=20;
		wp.ptMaxPosition.x +=20;
		wp.ptMaxPosition.y +=20;
		wp.rcNormalPosition.top  +=20;
		wp.rcNormalPosition.left +=20;
		wp.rcNormalPosition.bottom +=20;
		wp.rcNormalPosition.right +=20;
		SetWindowPlacement(&wp);
	}
		
	m_numberOfccVOEditorWindowsOpened ++;
	
	// TODO: Add your specialized creation code here
	
	return 0;
}

//

void cccVOEditor::OnDestroy() 
{
	ccFrameWnd::OnDestroy();
	m_numberOfccVOEditorWindowsOpened--;
	

}

//

void cccVOEditor::OnPreviousItem() 
{
	// TODO: Add your command handler code here
	
}

//

BOOL cccVOEditor::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo) 
{
	if (m_topMainFrame)
		if (m_topMainFrame->OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
			return TRUE;

	
	return ccFrameWnd::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

//

void cccVOEditor::OnFileExit() 
{
	SendMessage( WM_CLOSE );
}
