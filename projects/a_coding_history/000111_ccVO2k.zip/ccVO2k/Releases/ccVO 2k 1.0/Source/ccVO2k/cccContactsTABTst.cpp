// cccContactsTABTst.cpp : implementation file
//

#include "stdafx.h"
#include "ccvo2k.h"
#include "cccContactsTABTst.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccContactsTABTst dialog


cccContactsTABTst::cccContactsTABTst(CWnd* pParent /*=NULL*/)
	: CDialog(cccContactsTABTst::IDD, pParent)
{
	//{{AFX_DATA_INIT(cccContactsTABTst)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	Create(cccContactsTABTst::IDD, pParent);		
}


void cccContactsTABTst::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(cccContactsTABTst)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(cccContactsTABTst, CDialog)
	//{{AFX_MSG_MAP(cccContactsTABTst)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cccContactsTABTst message handlers
