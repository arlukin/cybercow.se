// ContainerView.cpp : implementation file
//

#include "stdafx.h"
#include "ccVO2k.h"
#include "ContainerView.h"
#include "cccEmptyContainer.h"
#include "FolderListView.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// *** Construction / Destruction
/////////////////////////////////////////////////////////////////////////////
CContainerView::CContainerView()
{
	// define the caption font.
	NONCLIENTMETRICS ncm;
	memset(&ncm, 0, sizeof(NONCLIENTMETRICS));
	ncm.cbSize = sizeof(NONCLIENTMETRICS);

	VERIFY(::SystemParametersInfo(SPI_GETNONCLIENTMETRICS,
		sizeof(NONCLIENTMETRICS), &ncm, 0));
	ncm.lfMessageFont.lfWeight = 700;
	ncm.lfMessageFont.lfHeight = 20;
	_tcscpy(ncm.lfMessageFont.lfFaceName, _T("Arial"));
	m_CaptionFont.CreateFontIndirect(&ncm.lfMessageFont);

	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

//

IMPLEMENT_DYNCREATE(CContainerView, CView)

//

CContainerView::~CContainerView()
{
}

/////////////////////////////////////////////////////////////////////////////
// *** Overrides
/////////////////////////////////////////////////////////////////////////////

void CContainerView::OnDraw(CDC* pDC)
{

}

/////////////////////////////////////////////////////////////////////////////
// *** Generated message map functions
/////////////////////////////////////////////////////////////////////////////

int CContainerView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	// Create Caption wnd
	//
	if (!m_Caption.Create(this, _T("ccVO2k")))
	{
		TRACE0( "Failed to caption window.\n" );
		return -1;
	}

	m_Caption.SetCaptionColors( ::GetSysColor(COLOR_BTNFACE),
		::GetSysColor(COLOR_BTNSHADOW), ::GetSysColor(COLOR_WINDOW));

	// set the caption style.
	m_Caption.ModifyCaptionStyle( 4, &m_CaptionFont, NULL, m_hIcon);

	// Create splitters 
	//
	// The context information is passed on from the framework
	CCreateContext *pContext = (CCreateContext*)lpCreateStruct->lpCreateParams;

	// Create the splitter window with two columns
	if (!m_wndSplitter.CreateStatic(this, 1, 2))
	{
		TRACE0("Failed to create splitter window\n");
		return FALSE;
	}

	if (!m_wndSplitter.CreateView(0,0,RUNTIME_CLASS(CFolderListView),
		CSize(175, 0), pContext))
	{
		m_wndSplitter.DestroyWindow();
		return -1;
	}

	if (!m_wndSplitter.CreateView(0,1,RUNTIME_CLASS(cccEmptyContainer),
		CSize(175, 0), pContext))
	{
		m_wndSplitter.DestroyWindow();
		return -1;
	}
	
	return 0;
}

//

void CContainerView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);

	if( m_wndSplitter.GetSafeHwnd())
	{
		int nCX = ::GetSystemMetrics( SM_CXEDGE );
		int nCY = ::GetSystemMetrics( SM_CYEDGE );
		
		// move and grow view to clip border
		m_wndSplitter.MoveWindow(-nCX, 30, cx+(nCX*2), cy+(nCY*2)-34);	
	}
	
	if( m_Caption.GetSafeHwnd()) 
	{
		m_Caption.MoveWindow(0,0,cx,31);
	}	
}

//

void CContainerView::OnCloseFolderListView(UINT lParam, LONG wParam)
{
	m_Caption.SetChildWindow( (CCJTreeCtrl *)&CFolderListView::m_TreeCtrl, this );
	m_wndSplitter.HideColumn(0);
}

//

void CContainerView::OnPushPinButton(UINT lParam, LONG wParam)
{
	m_wndSplitter.ShowColumn();
}

//

void CContainerView::OnPushPinCancel(UINT lParam, LONG wParam)
{	
	// TODO: Add your message handler code here and/or call default	
}


BEGIN_MESSAGE_MAP(CContainerView, CView)
	//{{AFX_MSG_MAP(CContainerView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
	ON_MESSAGE(FM_CLOSEFOLDERLISTVIEW, OnCloseFolderListView)
	ON_MESSAGE(CM_ONPUSHPINBUTTON, OnPushPinButton)
	ON_MESSAGE(CM_ONPUSHPINCANCEL, OnPushPinCancel)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// *** Debug members
/////////////////////////////////////////////////////////////////////////////
#ifdef _DEBUG
void CContainerView::AssertValid() const
{
	CView::AssertValid();
}

//

void CContainerView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG
