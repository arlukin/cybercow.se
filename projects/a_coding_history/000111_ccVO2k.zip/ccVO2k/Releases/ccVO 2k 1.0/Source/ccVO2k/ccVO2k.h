// ccVO2k.h : main header file for the CCVO2K application
//

#if !defined(AFX_CCVO2K_H__B5AA1D7A_F4FE_11D3_899E_00609708DCFE__INCLUDED_)
#define AFX_CCVO2K_H__B5AA1D7A_F4FE_11D3_899E_00609708DCFE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// cccVO2kApp:
// See ccVO2k.cpp for the implementation of this class
//

class cccVO2kApp : public CWinApp
{
// *** Construction / Destruction
public:
	// Default Constructor
	//
	cccVO2kApp();
	~cccVO2kApp();


// *** Attributes
public:
	ccVOClient *m_theCCVOClient;

	// Values from the registry
	CString m_programURL;
	CString m_traceFileURL;			// If this is empty, no tracing will be enabled.
	CString	m_dataBaseURL;			// The path and name of the Access database.

// *** Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(cccVO2kApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// *** Generated message map functions
public:	
	//{{AFX_MSG(cccVO2kApp)
	afx_msg void OnHelpCybercowonthewebCheckfornewversion();
	afx_msg void OnHelpCybercowonthewebCybercowhomepage();
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// *** Debug
public:
	void test();

private:
	void getRegistrySettings();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CCVO2K_H__B5AA1D7A_F4FE_11D3_899E_00609708DCFE__INCLUDED_)
