#if !defined(__CFOLDERTREECTRL_H__)
#define __CFOLDERTREECTRL_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CFolderTreeCtrl.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFolderTreeCtrl window

class  CFolderTreeCtrl : public ccTreeCtrl
{
// *** Construction
public:
	// Default Constructor
	// 
	CFolderTreeCtrl();

	DECLARE_DYNAMIC(CFolderTreeCtrl)

	// Default destructor
	//
	virtual ~CFolderTreeCtrl();
	
// *** Operations
public:
	// Delete an treeleaf item, but only folders. It will also delete it
	// from the tables dtItems and dtTreeOrder
	//
	virtual BOOL DeleteItem( HTREEITEM hItem );

// *** Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFolderTreeCtrl)
	//}}AFX_VIRTUAL

// *** Generated message map functions
protected:
	//{{AFX_MSG(CFolderTreeCtrl)	
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // __CFOLDERTREECTRL_H__
