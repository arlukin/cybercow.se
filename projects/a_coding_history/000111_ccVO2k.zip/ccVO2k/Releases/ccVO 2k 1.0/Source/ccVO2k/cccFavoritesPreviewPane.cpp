// cccFavoritesPreviewPane.cpp : implementation file
//

#include "stdafx.h"
#include "ccvo2k.h"

#include "cccFavoritesPreviewPane.h"
#include "cccFavoritesTABGeneral.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccFavoritesPreviewPane

IMPLEMENT_DYNCREATE(cccFavoritesPreviewPane, ccTabView)

cccFavoritesPreviewPane::cccFavoritesPreviewPane()
{
	setDB( new cccVODB );
}

cccFavoritesPreviewPane::~cccFavoritesPreviewPane()
{
	try
	{
		try
		{
			// *WIN 98 * Need to delete the ctrls before the database
			if ( getTabCtrl())		
				getTabCtrl()->removeAll();

			delete getDB();
		}
		catch(_com_error &e) 
		{ 
			ccThrowccException( getComError(e) ); /*Disable unreference warning*/ (void*)&e; 
		}		
	}
	catch(ccException *e) 
	{
		ccErr(*e,"","", MB_OK);	
	}	
	catch(...) 
	{
		ccErr("DB Error", "","", MB_OK);		
	}
}


BEGIN_MESSAGE_MAP(cccFavoritesPreviewPane, ccTabView)
	//{{AFX_MSG_MAP(cccFavoritesPreviewPane)
	ON_COMMAND(ID_SAVE_AND_CLOSE, OnSaveAndClose)
	ON_WM_CREATE()
	ON_COMMAND(ID_SAVE, OnSave)	
	ON_COMMAND(IDM_DELETE_ITEM, OnDeleteItem)
	ON_COMMAND(ID_LAST_ITEM, OnLastItem)
	ON_COMMAND(ID_FIRST_ITEM, OnFirstItem)
	ON_COMMAND(ID_NEXT_ITEM, OnNextItem)
	ON_COMMAND(ID_PREVIOUS_ITEM, OnPreviousItem)
	ON_COMMAND(IDM_SUFT_TO_FAVORITE_WITH, OnSuftToFavoriteWith)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cccFavoritesPreviewPane drawing

void cccFavoritesPreviewPane::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// cccFavoritesPreviewPane diagnostics

#ifdef _DEBUG
void cccFavoritesPreviewPane::AssertValid() const
{
	ccTabView::AssertValid();
}

void cccFavoritesPreviewPane::Dump(CDumpContext& dc) const
{
	ccTabView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// cccFavoritesPreviewPane message handlers

BOOL cccFavoritesPreviewPane::PreCreateWindow(CREATESTRUCT& cs) 
{
	cs.style &= ~WS_BORDER;
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;

	return ccTabView::PreCreateWindow(cs);
}

//

void cccFavoritesPreviewPane::OnSaveAndClose() 
{	

	if (theCCVOClient->getCurrentGridCtrl())
		dd( m_ddFavorites )->bindNonDBCtrls( theCCVOClient->getCurrentGridCtrl() );

	if ( dd( m_ddFavorites )->saveRecord() == CCSUCCEDED)
		GetParent()->SendMessage(WM_CLOSE);
		// No need to remove the ctrl from the contacts DD. When sending WM_CLOSE
		// cause it's removed in the destructor
	else	
		if (theCCVOClient->getCurrentGridCtrl())
			dd( m_ddFavorites )->removeNonDBCtrls( theCCVOClient->getCurrentGridCtrl() );				
}

//

void cccFavoritesPreviewPane::OnSave() 
{
	if (theCCVOClient->getCurrentGridCtrl())
		dd( m_ddFavorites )->bindNonDBCtrls( theCCVOClient->getCurrentGridCtrl() );

	dd( m_ddFavorites )->saveRecord();		

	if (theCCVOClient->getCurrentGridCtrl())
		dd( m_ddFavorites )->removeNonDBCtrls( theCCVOClient->getCurrentGridCtrl() );		
}

//

void cccFavoritesPreviewPane::OnInitialUpdate() 
{
	ccTabView::OnInitialUpdate();		
}

//

void cccFavoritesPreviewPane::OnDeleteItem() 
{
	CString strDeleteFavorite; strDeleteFavorite.LoadString( IDS_DELETE_FAVORITE );
	CString strConfirm; strConfirm.LoadString( IDS_CONFIRM_DELETE_ITEM );
	if ( MessageBox( strDeleteFavorite, strConfirm, MB_YESNO ) == IDYES  )
	{
		dd( m_ddFavorites )->deleteFavorite( dd( m_ddFavorites )->m_MProjectID, dd( m_ddFavorites )->m_ParentItemID, dd( m_ddFavorites )->m_ItemID);
		Sleep(1000);		
		dd( m_ddFavorites )->requery();						
		if (theCCVOClient->getCurrentGridCtrl())
			theCCVOClient->getCurrentGridCtrl()->OnDeleteComplete();
	}
}

//

void cccFavoritesPreviewPane::OnLastItem() 
{
	dd( m_ddFavorites )->moveLast();
}

//

void cccFavoritesPreviewPane::OnFirstItem() 
{
	dd( m_ddFavorites )->moveFirst();
}

//

void cccFavoritesPreviewPane::OnNextItem() 
{
	dd( m_ddFavorites )->moveNext();
}

//

void cccFavoritesPreviewPane::OnPreviousItem() 
{
	dd( m_ddFavorites )->movePrev();	
}

//

int cccFavoritesPreviewPane::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (ccTabView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// If the view is used by the ccVOViewer
	try
	{
		int nMProjectID;
		int nItemID;
		nMProjectID = theCCVOClient->getSelLeafMProjectID();

		if ( theCCVOClient->getFunctionType() == cIXFAVORITES )
			nItemID = theCCVOClient->getSelLeafItemID();
		else
			nItemID = cIXFAVORITES;		

		// Create a new database.		
		dd( m_ddFavorites )->setSelLeafMProjectID( nMProjectID );
		dd( m_ddFavorites )->setSelLeafItemID(    nItemID ); 

		ccString strFilter;
		strFilter << "MProjectID = "		  << nMProjectID << " and ";
		strFilter << "dtTreeOrder.ItemID = "  << nItemID;
		dd( m_ddFavorites )->getRS()->Filter = (_bstr_t)strFilter;

		if (theCCVOClient->getSelGridItemID() != -1)
		{						
			dd( m_ddFavorites )->moveFirst();
			
			if ( !dd( m_ddFavorites )->isEmpty() )
			{
				ccString strCriteria;
				strCriteria << "dtfFavorites.ItemID = " << theCCVOClient->getSelGridItemID();
				dd( m_ddFavorites )->find( strCriteria);
			}
		}
		// If the view is used by the CMainFrame
		else
			dd( m_ddFavorites )->clearRecord( true );					

		getTabCtrl()->InsertItem( 0, "General", new cccFavoritesTABGeneral( getTabCtrl(), __getDB() ) );
	}
	catch(_com_error &e) 
	{ 
		ccErr(getComError(e),"","", MB_OK );				
	}	
	
	return 0;
}
void cccFavoritesPreviewPane::OnSuftToFavoriteWith() 
{
	surfTo( dd( m_ddFavorites )->m_URL, this);	
}
