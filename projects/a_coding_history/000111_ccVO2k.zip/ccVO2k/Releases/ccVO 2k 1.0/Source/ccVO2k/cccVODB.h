#if !defined(__CCCVODB_H__)
#define __CCCVODB_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
//
// Some comments about the database.
//
// dtTreeOrder, dtItem
//	The MasterProject isnot represented in those tables. It doesn't exist any MProj 0, ItemID 0 record.
//  And it should not exist any such record.. Cause it's "deleted" when tring to delete a new record
//	not yet saved.
//
//  The first itemID is 100.. and Id 1-3 is for function "roots"..
//

#include "cccddContacts.h"
#include "cccddFavorites.h"
#include "cccddFTP.h"
#include "resource.h"
#include "transferStructs.h"

#define dDATABASEPASSWORD "ferdnand"		// The password to the access database

// #define GETDB() ((cccVODB*)getDB())
 #define dd(x)	((cccVODB*)getDB())->x
 #define ddf(x)	( (cccVODB*)aDispInfo->m_field->__getDB() )->x
 #define getDB() ((cccVODB*)__getDB())
class cccVODB;

class cccVODB : public ccDataBase  
{
// *** Construction / Destruction
public:	
	// Default constructor
	//
	cccVODB();

	// Default destructor
	//
	virtual ~cccVODB();

// *** DataDictionarys
public:
	cccddContacts		* m_ddContacts;	
	cccddFavorites		* m_ddFavorites;
	cccddFTP			* m_ddFTP;


// *** "Update" functions updateing just one table
public:
	// Change the name of an dtItem record.
	//
	bool update_dtItems( int nMProjectID, int nItemID, LPCSTR strName);

	//
	//
	bool update_dtfContactsEmail( int nMProjectID, int nItemID, LPCSTR strComment, LPCSTR strEmailAdress, int bPlainText);
	bool update_dtfContactsPhone( int nMProjectID, int nItemID, LPCSTR strPhoneName, LPCSTR strNumber);


// *** "delete" functions, deleteing from just one table
public:
	bool delete_dtItems( int nMProjectID, int nItemID);	
	bool delete_dtTreeOrder( int nMProjectID, int nItemID, int nChildID);
	bool delete_dtfContactsEmail( int nMProjectID, int nItemID, LPCSTR strName);
	bool delete_dtfContactsPhone( int nMProjectID, int nItemID, LPCSTR strPhoneName);

// *** "Insert" functions inserting in just one table
public:
	void insert_dtUser( sNewUser &aNewUser, int nUserID );
	void insert_dtMasterProject( sNewUser &aNewUser, int nUserID );	
	void insert_dtMProjectMembers( sNewUser &aNewUser, int nUserID);
	void insert_dtUserActiveMProjects( sNewUser &aNewUser, int nUserID );
	void insert_dtItems( int nMProjectID, int nItemID, CString strName, int nFunctionType, int nItemType );
	void insert_dtTreeOrder( int nMProjectID, int nItemID, int nChildID );	
	void insert_dtfContactsEmail( int nMProjectID, int nItemID, LPCSTR strComment);
	void insert_dtfContactsPhone( int nMProjectID, int nItemID, LPCSTR strPhoneName);

// *** Create ID:s
public:
	// Create primkey IDS.	
	//
	int createNewUserID();
	int createMProjectID();
	int createItemID();

// *** Attributes
private:
	
};

#endif // __CCCVODB_H__
