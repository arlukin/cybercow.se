#if !defined(AFX_CCCCONTACTSTABBUSINESS_H__01B7E86E_2506_11D4_89A6_00609708DCFE__INCLUDED_)
#define AFX_CCCCONTACTSTABBUSINESS_H__01B7E86E_2506_11D4_89A6_00609708DCFE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// cccContactsTABBusiness.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// cccContactsTABBusiness dialog
#include "cccContactsTABBusinessMailAdress.h"
#include "cccContactsTABBusinessOfficeLocation.h"

class cccContactsTABBusiness : public ccdbDialog
{
// *** Construction
public:
	// standard constructor
	//
	cccContactsTABBusiness(CWnd* pParent, cccVODB *aoDB); 

// *** Dialog Data
	//{{AFX_DATA(cccContactsTABBusiness)
	enum { IDD = IDD_CONTACTS_TAB_BUSINESS };
	ccTabCtrl	m_tab;
	//}}AFX_DATA

	ccdbSuperCtrl	m_Company;
	ccdbSuperCtrl	m_JobTitle;
	ccdbSuperCtrl	m_Department;
	ccdbSuperCtrl	m_Office;
	ccdbSuperCtrl	m_ManagersName;
	ccdbSuperCtrl	m_AssistentsName;
	ccdbSuperCtrl	m_OthersName;
	ccdbSuperCtrl	m_Business_Notes;
	ccdbSuperCtrl	m_Bussiness_WebPage;
	ccdbSuperCtrl	m_Bussiness_FTPSite;

// *** Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(cccContactsTABBusiness)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(cccContactsTABBusiness)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CCCCONTACTSTABBUSINESS_H__01B7E86E_2506_11D4_89A6_00609708DCFE__INCLUDED_)
