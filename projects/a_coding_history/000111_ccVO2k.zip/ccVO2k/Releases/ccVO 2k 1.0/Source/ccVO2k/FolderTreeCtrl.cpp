// CFolderTreeCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "FolderTreeCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// *** Construction
/////////////////////////////////////////////////////////////////////////////

IMPLEMENT_DYNAMIC(CFolderTreeCtrl, ccTreeCtrl)

CFolderTreeCtrl::CFolderTreeCtrl()
{
}

//

CFolderTreeCtrl::~CFolderTreeCtrl()
{
}

/////////////////////////////////////////////////////////////////////////////
// *** Operations
/////////////////////////////////////////////////////////////////////////////
BOOL CFolderTreeCtrl::DeleteItem( HTREEITEM hItem )
{
	int nRet = false;

	CString strMsg;

	// Can only delete folders.
	sFLVTreeOrderSubItems * MProj = (sFLVTreeOrderSubItems*)GetItemData( hItem );
	if (MProj->nItemType == cITFOLDER)	
	{		
		strMsg.Format( IDS_ARE_YOU_SURE_YOU_WANT_TO_DELETE_FOLDER, GetItemText( hItem ) );
		if ( MessageBox(strMsg, "Confirm Delete", MB_YESNO ) == IDYES)
			 nRet = ccTreeCtrl::DeleteItem(hItem);	
	}
	else	
		ccErrEM( IDS_CANTDELETE_THIS_FOLDER, 0, 0, MB_OK );	

	SetFocus();
	return nRet;
}

/////////////////////////////////////////////////////////////////////////////
// *** Generated message map functions
/////////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CFolderTreeCtrl, ccTreeCtrl)
	//{{AFX_MSG_MAP(CFolderTreeCtrl)	
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

