#if !defined(AFX_CCCVOEDITOR_H__58659E8C_016D_11D4_89A2_00609708DCFE__INCLUDED_)
#define AFX_CCCVOEDITOR_H__58659E8C_016D_11D4_89A2_00609708DCFE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// cccVOEditor.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// cccVOEditor frame
enum E_ccVOViews
{ 
	CCVO_INVALIDE = 0,
	CCVO_DEFAULT_MODE,				// No specific view is selected.
	CCVO_CONTACTS_MODE,
	CCVO_FAVORITES_MODE,
	CCVO_FTP_MODE
};

class cccVOEditor : public ccFrameWnd
{
// *** Construction/Destruction
public:
	DECLARE_DYNCREATE(cccVOEditor)

	// Default Connstructor 
	//
	cccVOEditor(E_ccVOViews eMode, CWnd *pParent);

private:
	// Create the window in Contacts Mode
	//
	bool createContactsMode();

	// Create the window in Favorites Mode
	//
	bool createFavoritesMode();

	// Create the window in FTP Mode
	//
	bool createFTPMode();


protected:
	// protected constructor used by dynamic creation
	//
	cccVOEditor();           



// *** GFX Attributes
private:
	CStatusBar			m_wndStatusBar;
	CCJToolBar			m_wndToolBar;


// *** Attribute
private:
	E_ccVOViews m_ccVoMode;

	CWnd * m_topMainFrame;	

	static int m_numberOfccVOEditorWindowsOpened;

// *** 
public:

private:
	// Does the standard creation 
	//
	bool createDefaultMode( int nCaptionResource, int nToolBarRecource, int nMenuBarRecource );



// ***
private:
	//
	//
	BOOL switchToView(CRuntimeClass* pNewViewClass);


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(cccVOEditor)
	public:
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~cccVOEditor();

	// Generated message map functions
	//{{AFX_MSG(cccVOEditor)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnPreviousItem();
	afx_msg void OnHelpCybercowonthewebCheckfornewversion();
	afx_msg void OnHelpCybercowonthewebCybercowhomepage();
	afx_msg void OnFileExit();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CCCVOEDITOR_H__58659E8C_016D_11D4_89A2_00609708DCFE__INCLUDED_)
