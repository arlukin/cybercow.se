// cccddFTP.h: interface for the cccddFTP class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CCCDDFTP_H__5A42B216_2E62_11D4_823B_0001020E90A5__INCLUDED_)
#define AFX_CCCDDFTP_H__5A42B216_2E62_11D4_823B_0001020E90A5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// *** Field ID:s
#define FTP_MProjectID				1
#define FTP_ParentItemID			2
#define FTP_ItemID					3
#define FTP_Name					4			
#define FTP_URL						5			
#define FTP_Port					6			
#define FTP_Login					7			
#define FTP_Password				8			
#define FTP_InitialLocalDirectory	9
#define FTP_InitialRemoteDirectory	10
#define FTP_Notes					11
#define FTP_CreditGrade				12
#define FTP_LastLogedOn				13
#define FTP_LastChecked				14
#define FTP_ValidSite				15

//

class cccddFTP  : public ccDataDictionary  
{
// *** Construction/Destruction
public:
	//
	//
	DECLARE_CCFIELD_EVENT();

	//
	//
	cccddFTP ( ccDataBase* pDatabase );	

	//
	//
	virtual ~cccddFTP ();

// *** Data Members
public:
	ccField m_MProjectID;			
	ccField m_ParentItemID;		
	ccField m_ItemID;				
	ccField m_Name;				
	ccField m_URL;					
	ccField m_Port;				
	ccField m_Login;				
	ccField m_Password;			
	ccField m_InitialLocalDirectory;
	ccField m_InitialRemoteDirectory;
	ccField m_Notes;				
	ccField m_CreditGrade;			
	ccField m_LastLogedOn;			
	ccField m_LastChecked;			
	ccField m_ValidSite;			

// *** Table Events
public:	
	virtual void backout()	 {;};
	virtual void creating();
	virtual void updateing();
	virtual void deleting();
	virtual void OnFieldChangeComplete();
	virtual void OnFieldClearComplete();

// *** Table Field Events
public:
	
// *** Helper Attributes
public:
	//
	//
	void setSelLeafMProjectID( int nSelLeafMProject )	{ m_nSelLeafMProject = nSelLeafMProject;	};
	int  getSelLeafMProjectID()							{ return m_nSelLeafMProject;				};

	//
	//
	void setSelLeafItemID    ( int nSelLeafItemID )		{ m_nSelLeafItemID = nSelLeafItemID;		};
	int  getSelLeafItemID    ()							{ return m_nSelLeafItemID;					};

// *** SQL-Script Functions
public:
	// Delete a ftp from the tables dtfFTP, dtItems and dtTreeOrder
	//
	bool deleteFTP( int nMProjectID, int nParentID, int nItemID);

private:
	// See setSelLeafMProjectID etc.
	int m_nSelLeafMProject;
	int m_nSelLeafItemID;  	
};

#endif // !defined(AFX_CCCDDFTP_H__5A42B216_2E62_11D4_823B_0001020E90A5__INCLUDED_)
