#if !defined(__CCCDREGUSR1LICENCE_H__)
#define __CCCDREGUSR1LICENCE_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// cccdRegUsr1Licence.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// cccdRegUsr1Licence dialog
#include "resource.h"

struct sRegUsr;
class cccdRegUsr1Licence : public CPropertyPage
{
	DECLARE_DYNCREATE(cccdRegUsr1Licence)

// Construction
public:	
	cccdRegUsr1Licence( );	
	~cccdRegUsr1Licence();

	void setRegUsr( sRegUsr *aoRegUsr )				{ m_regUsr = aoRegUsr;	}

// Dialog Data
	//{{AFX_DATA(cccdRegUsr1Licence)
	enum { IDD = IDD_REG_USR_1_LICENCE };
	CEdit	m_LicenceCtrl;
	CButton	m_IAgreeCtrl;
	CString	m_licence;
	//}}AFX_DATA

// *** Attributes
private:
	sRegUsr * m_regUsr;			// This struct will contain input and output data from/to the ctrls.

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(cccdRegUsr1Licence)
	public:
	virtual BOOL OnSetActive();
	virtual LRESULT OnWizardNext();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(cccdRegUsr1Licence)
	afx_msg void OnIAgree();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // __CCCDREGUSR1LICENCE_H__
