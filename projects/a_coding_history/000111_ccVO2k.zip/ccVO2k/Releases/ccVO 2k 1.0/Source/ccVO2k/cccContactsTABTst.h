#if !defined(AFX_CCCCONTACTSTABTST_H__0D5ABD56_0A2D_11D4_89A4_00609708DCFE__INCLUDED_)
#define AFX_CCCCONTACTSTABTST_H__0D5ABD56_0A2D_11D4_89A4_00609708DCFE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// cccContactsTABTst.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// cccContactsTABTst dialog

class cccContactsTABTst : public CDialog
{
// Construction
public:
	cccContactsTABTst(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(cccContactsTABTst)
	enum { IDD = IDD_CONTACTS_TAB_TST };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(cccContactsTABTst)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(cccContactsTABTst)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CCCCONTACTSTABTST_H__0D5ABD56_0A2D_11D4_89A4_00609708DCFE__INCLUDED_)
