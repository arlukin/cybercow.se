#if !defined(AFX_CCCFTPVIEW_H__5A42B217_2E62_11D4_823B_0001020E90A5__INCLUDED_)
#define AFX_CCCFTPVIEW_H__5A42B217_2E62_11D4_823B_0001020E90A5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// cccFTPView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// cccFTPView form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class cccFTPView : public CFormView, public ccNonDBCtrl
{
protected:
	cccFTPView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(cccFTPView)

// Form Data
public:
	//{{AFX_DATA(cccFTPView)
	enum { IDD = IDD_FTP_VIEW };
	CListCtrl	m_grid;
	//}}AFX_DATA

// *** Attributes
public:
	//
	//
	cccVODB* __getDB(void)			{ return m_oDB;					};
	void setDB( cccVODB* aoCCVO)	{ m_oDB = aoCCVO;				};

private:
	cccVODB  *m_oDB;

// Operations
public:
	void openSelectedFTP();	
	void insertRow(int nRow, LPCSTR strName, LPCSTR strURL, LPCSTR strNotes);
	void fillGrid();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(cccFTPView)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

	virtual void refresh()			{						};
	virtual void OnDeleteComplete() {	fillGrid();			};
	virtual void OnSaveComplete()	{	fillGrid();			};

// Implementation
protected:
	virtual ~cccFTPView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(cccFTPView)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnDblclkFTPGrid(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnReturnFTPGrid(NMHDR* pNMHDR, LRESULT* pResult);	
	afx_msg void OnKeydownFTPGrid(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CCCFTPVIEW_H__5A42B217_2E62_11D4_823B_0001020E90A5__INCLUDED_)
