// cccContactsTABPersonal.cpp : implementation file
//

#include "stdafx.h"
#include "ccvo2k.h"

#include "cccContactsTABPersonal.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccContactsTABPersonal dialog


cccContactsTABPersonal::cccContactsTABPersonal(CWnd *pParent, cccVODB *aoDB)
	: ccdbDialog(cccContactsTABPersonal::IDD, pParent, aoDB), m_Email(pParent), m_Phone1(pParent) , m_Phone2(pParent), m_Phone3(pParent)
{
	//{{AFX_DATA_INIT(cccContactsTABPersonal)	
	//}}AFX_DATA_INIT
	Create(cccContactsTABPersonal::IDD, pParent);	
}

void cccContactsTABPersonal::DoDataExchange(CDataExchange* pDX)
{
	ccdbDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(cccContactsTABPersonal)	
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(cccContactsTABPersonal, ccdbDialog)
	//{{AFX_MSG_MAP(cccContactsTABPersonal)	
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cccContactsTABPersonal message handlers

BOOL cccContactsTABPersonal::OnInitDialog() 
{
	setDDServer( dd(m_ddContacts) );
	m_Display.adddbField( &dd(m_ddContacts)->m_Display  );
	m_Display.setCaptionOffset(-40);
	m_Display.SubclassDlgItem( IDC_DISPLAY, this, this );

	m_Title.adddbField( &dd(m_ddContacts)->m_Title  );
	m_Title.setCaptionOffset(-40);
	m_Title.SubclassDlgItem( IDC_TITLE, this, this );

	m_FirstName.adddbField( &dd(m_ddContacts)->m_FirstName  );
	m_FirstName.setCaptionOffset(-40);
	m_FirstName.SubclassDlgItem( IDC_FIRST_NAME, this, this );

	m_MiddleName.adddbField( &dd(m_ddContacts)->m_MiddleName  );
	m_MiddleName.setCaptionOffset(-40);
	m_MiddleName.SubclassDlgItem( IDC_MIDDLE_NAME, this, this );

	m_LastName.adddbField( &dd(m_ddContacts)->m_LastName  );
	m_LastName.setCaptionOffset(-40);
	m_LastName.SubclassDlgItem( IDC_LAST_NAME, this, this );

	m_NickName.adddbField( &dd(m_ddContacts)->m_NickName1  );
	m_NickName.adddbField( &dd(m_ddContacts)->m_NickName2  );
	m_NickName.setCaptionOffset(-40);
	m_NickName.SubclassDlgItem( IDC_NICKNAME, this, this );

	m_Chat1.adddbField( &dd(m_ddContacts)->m_ICQ_ID  );
	m_Chat1.adddbField( &dd(m_ddContacts)->m_Yahoo_ID  );
	m_Chat1.adddbField( &dd(m_ddContacts)->m_AOL_ID  );
	m_Chat1.adddbField( &dd(m_ddContacts)->m_MSN_ID  );
	m_Chat1.setCaptionOffset(-35);
	m_Chat1.setDefaultField(0);
	m_Chat1.SubclassDlgItem( IDC_CHAT1, this, this );
	
	m_Chat2.adddbField( &dd(m_ddContacts)->m_ICQ_ID  );
	m_Chat2.adddbField( &dd(m_ddContacts)->m_Yahoo_ID  );
	m_Chat2.adddbField( &dd(m_ddContacts)->m_AOL_ID  );
	m_Chat2.adddbField( &dd(m_ddContacts)->m_MSN_ID  );
	m_Chat2.setCaptionOffset(-35);		
	m_Chat2.setDefaultField(1);
	m_Chat2.SubclassDlgItem( IDC_CHAT2, this, this );	
	

	//m_PhotoGraph.adddbField( &dd(m_ddContacts)->m_Photograph  );
	//m_PhotoGraph.setCaptionOffset(0,-16);

	m_Company.adddbField( &dd(m_ddContacts)->m_Company );
	m_Company.setCaptionOffset(-60);
	m_Company.SubclassDlgItem( IDC_COMPANY_NAME, this, this );

	m_BirthDate.adddbField( &dd(m_ddContacts)->m_BirthDate  );	
	m_BirthDate.setCaptionOffset(-60);
	m_BirthDate.SubclassDlgItem( IDC_BIRTHDATE, this, this );
		
//	m_Phone1.adddbField( &dd(m_ddContacts)->m_CarPhone  );
//	m_Phone1.adddbField( &dd(m_ddContacts)->m_HomePhone  );
//	m_Phone1.adddbField( &dd(m_ddContacts)->m_FaxPhone  );
//	m_Phone1.adddbField( &dd(m_ddContacts)->m_ISDNPhone  );
//	m_Phone1.adddbField( &dd(m_ddContacts)->m_MobilPhone );
//	m_Phone1.adddbField( &dd(m_ddContacts)->m_PagerPhone  );
//	m_Phone1.adddbField( &dd(m_ddContacts)->m_BusinessPhone  );
//	m_Phone1.adddbField( &dd(m_ddContacts)->m_TelephoneExchangePhone  );		
//	m_Phone1.setDefaultField(1);
//	m_Phone1.setCaptionOffset(-80);		
//	
//	m_Phone2.adddbField( &dd(m_ddContacts)->m_CarPhone  );
//	m_Phone2.adddbField( &dd(m_ddContacts)->m_HomePhone  );
//	m_Phone2.adddbField( &dd(m_ddContacts)->m_FaxPhone  );
//	m_Phone2.adddbField( &dd(m_ddContacts)->m_ISDNPhone  );
//	m_Phone2.adddbField( &dd(m_ddContacts)->m_MobilPhone );
//	m_Phone2.adddbField( &dd(m_ddContacts)->m_PagerPhone  );
//	m_Phone2.adddbField( &dd(m_ddContacts)->m_BusinessPhone  );	
//	m_Phone2.adddbField( &dd(m_ddContacts)->m_TelephoneExchangePhone  );		
//	m_Phone2.setDefaultField(6);
//	m_Phone2.setCaptionOffset(-80);		
//
//	m_Phone3.adddbField( &dd(m_ddContacts)->m_CarPhone  );
//	m_Phone3.adddbField( &dd(m_ddContacts)->m_HomePhone  );
//	m_Phone3.adddbField( &dd(m_ddContacts)->m_FaxPhone  );
//	m_Phone3.adddbField( &dd(m_ddContacts)->m_ISDNPhone  );
//	m_Phone3.adddbField( &dd(m_ddContacts)->m_MobilPhone );
//	m_Phone3.adddbField( &dd(m_ddContacts)->m_PagerPhone  );
//	m_Phone3.adddbField( &dd(m_ddContacts)->m_BusinessPhone  );
//	m_Phone3.adddbField( &dd(m_ddContacts)->m_TelephoneExchangePhone  );		
//	m_Phone3.setDefaultField(4);
//	m_Phone3.setCaptionOffset(-80);		
//
//	m_Phone4.adddbField( &dd(m_ddContacts)->m_CarPhone  );
//	m_Phone4.adddbField( &dd(m_ddContacts)->m_HomePhone  );
//	m_Phone4.adddbField( &dd(m_ddContacts)->m_FaxPhone  );
//	m_Phone4.adddbField( &dd(m_ddContacts)->m_ISDNPhone  );
//	m_Phone4.adddbField( &dd(m_ddContacts)->m_MobilPhone );
//	m_Phone4.adddbField( &dd(m_ddContacts)->m_PagerPhone  );
//	m_Phone4.adddbField( &dd(m_ddContacts)->m_BusinessPhone  );
//	m_Phone4.adddbField( &dd(m_ddContacts)->m_TelephoneExchangePhone  );		
//	m_Phone4.setDefaultField(3);
//	m_Phone4.setCaptionOffset(-80);		

	ccdbDialog::OnInitDialog();

	// Set up the Email Container and dataDictonary
	m_Email.setDB( __getDB() );
	m_Email.init(IDD_CONTACTS_TAB_PERSONAL_EMAIL, this, IDC_NICKNAME, 10, 180, "Email");	

	m_Phone1.setDB( __getDB() );
	m_Phone1.setPhoneGroup(1);
	m_Phone1.init(IDD_CONTACTS_TAB_PERSONAL_PHONE, this, IDC_NICKNAME, 60, 270,"");	
	

	m_Phone2.setDB( __getDB() );
	m_Phone2.setPhoneGroup(2);
	m_Phone2.init(IDD_CONTACTS_TAB_PERSONAL_PHONE, this, IDC_NICKNAME, 200, 270,"");	

	m_Phone3.setDB( __getDB() );
	m_Phone3.setPhoneGroup(3);
	m_Phone3.init(IDD_CONTACTS_TAB_PERSONAL_PHONE, this, IDC_NICKNAME, 340, 270,"");	
	

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
