// cccContactsView.cpp : implementation file
//

#include "stdafx.h"
#include "ccvo2k.h"
#include "cccContactsView.h"
#include "cccVOEditor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccContactsView

IMPLEMENT_DYNCREATE(cccContactsView, CFormView)

cccContactsView::cccContactsView()
	: CFormView(cccContactsView::IDD)
{
	//{{AFX_DATA_INIT(cccContactsView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

cccContactsView::~cccContactsView()
{
}

void cccContactsView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(cccContactsView)
	DDX_Control(pDX, ID_CONTACTS_GRID, m_grid);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(cccContactsView, CFormView)
	//{{AFX_MSG_MAP(cccContactsView)
	ON_WM_SIZE()
	ON_NOTIFY(NM_DBLCLK, ID_CONTACTS_GRID, OnDblclkContactsGrid)
	ON_NOTIFY(NM_RETURN, ID_CONTACTS_GRID, OnReturnContactsGrid)	
	ON_NOTIFY(LVN_KEYDOWN, ID_CONTACTS_GRID, OnKeydownContactsGrid)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cccContactsView diagnostics

#ifdef _DEBUG
void cccContactsView::AssertValid() const
{
	CFormView::AssertValid();
}

void cccContactsView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// cccContactsView message handlers

void cccContactsView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);

	if (::IsWindow(m_grid.m_hWnd) )
		m_grid.SetWindowPos(NULL, 0, 0, cx, cy,  SWP_NOZORDER );	
}

//

void cccContactsView::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	theCCVOClient->setCurrentGridCtrl(this);

	setDB( theCCVOClient->m_dataBase );

	// Set the size of the listCtrl so it will fill the FormView.
	CRect lpRect;
	GetClientRect( lpRect );
	m_grid.SetWindowPos(NULL, 0, 0, lpRect.Width(), lpRect.Height(),  SWP_NOZORDER );		

	m_grid.SetExtendedStyle(LVS_EX_FULLROWSELECT | 
				 LVS_EX_ONECLICKACTIVATE | 
				 LVS_EX_UNDERLINEHOT );

	for(int nCol = 3;nCol>-1;nCol--)
		m_grid.DeleteColumn( nCol);

	m_grid.InsertColumn(0, "Name",			LVCFMT_LEFT, 100,0);
	m_grid.InsertColumn(1, "E-Mail",		LVCFMT_LEFT, 100,1);
	m_grid.InsertColumn(2, "Business Phone",LVCFMT_LEFT, 100,2);
	m_grid.InsertColumn(3, "Home Phone",	LVCFMT_LEFT, 100,3);

	fillGrid();
}

//

void cccContactsView::fillGrid()
{
	m_grid.DeleteAllItems();

	if ( theCCVOClient->m_dataBase )	
	{
		try
		{
			ADODB::_RecordsetPtr PopSet;						
			try
			{
				ccString strSQL;	

				strSQL << "SELECT dtfContacts.ItemID, dtfContacts.Display, dtfContacts.PrimEMail ";
				strSQL << "FROM dtfContacts, dtItems, dtTreeOrder ";
				strSQL << "WHERE dtfContacts.MProjectID = dtTreeOrder.MProjectID AND ";
				strSQL << "    dtfContacts.ItemID = dtTreeOrder.ChildID AND ";
				strSQL << "    dtItems.MProjectID = dtTreeOrder.MProjectID AND ";
				strSQL << "    dtItems.ItemID = dtTreeOrder.ChildID AND ";
				strSQL << "    dtTreeOrder.MProjectID = " << theCCVOClient->getSelLeafMProjectID() << " AND";
				strSQL << "    dtTreeOrder.ItemID = "<< theCCVOClient->getSelLeafItemID();	

				if ( theCCVOClient->m_dataBase->getRS(strSQL, PopSet) )							
				{		
					dd( m_ddContacts )->initContactsPhone(theCCVOClient->getSelLeafMProjectID(), theCCVOClient->getSelLeafItemID() );
					while(!PopSet->adoEOF)
					{					
						insertRow( (long)PopSet->Fields->Item[_variant_t(0l)]->Value,
							(char*)(_bstr_t)PopSet->Fields->Item[_variant_t(1l)]->Value,
							(char*)(_bstr_t)PopSet->Fields->Item[_variant_t(2l)]->Value, 
							dd( m_ddContacts )->getContactsPhone( (long)PopSet->Fields->Item[_variant_t(0l)]->Value, "Business"), 
							dd( m_ddContacts )->getContactsPhone( (long)PopSet->Fields->Item[_variant_t(0l)]->Value, "Home") );
						
						PopSet->MoveNext();						
					}

					PopSet->Close();					
				}			
				return ;
			}
			catch(_com_error &e) 
			{ 
				ccErr(getProviderError( theCCVOClient->m_dataBase->getConnection()) );
				ccThrowccException( getProviderError( theCCVOClient->m_dataBase->getConnection()) ); /*Delete unreference warning*/ (void*)&e; 				
			}	
		}
		catch( ccException * e)
		{
			ccErr( *e, "", "", MB_OK );			
		}
		catch(...)
		{
			ccErrEM( IDS_CANT_RETRIVE_CONTACTS, NULL, NULL, MB_OK );
		}
	}
	else
		ccErrEM( IDS_DATABASE_ISNT_OPEN, NULL, NULL, MB_OK);
}

//

void cccContactsView::insertRow(int nRow, LPCSTR strName, LPCSTR strEMail, LPCSTR strBusPhone, LPCSTR strHomePhone)
{
	LVITEM item;	
	item.mask = LVIF_TEXT;
	item.iItem = nRow;
	item.iSubItem = 0;
	
	//item.cchTextMax  =100;
	item.pszText = new char[100];
	strcpy(item.pszText, strName);	

	item.iItem = m_grid.InsertItem(&item);	
	m_grid.SetItemData( item.iItem, nRow );
	
	item.iSubItem = 1; strcpy(item.pszText, strEMail);
	m_grid.SetItem(&item);

	item.iSubItem = 2; strcpy( item.pszText, strBusPhone);	
	m_grid.SetItem(&item);

	item.iSubItem = 3; strcpy( item.pszText, strHomePhone);	
	m_grid.SetItem(&item);
}

//

void cccContactsView::OnDblclkContactsGrid(NMHDR* pNMHDR, LRESULT* pResult) 
{
	openSelectedContact();	
	*pResult = 0;
}

//

void cccContactsView::OnReturnContactsGrid(NMHDR* pNMHDR, LRESULT* pResult) 
{
	openSelectedContact();	
	*pResult = 0;
}

//

void cccContactsView::openSelectedContact()
{
	POSITION pos = m_grid.GetFirstSelectedItemPosition();
	if (pos != NULL)
	{
		int nItem = m_grid.GetNextSelectedItem(pos);
		int nItemData = m_grid.GetItemData( nItem );
		theCCVOClient->setSelGridItemID( nItemData);
	}
	else
		theCCVOClient->setSelGridItemID( -1);

	cccVOEditor* pFrame = new cccVOEditor(CCVO_CONTACTS_MODE, AfxGetMainWnd());

	theCCVOClient->setSelGridItemID( -1);
}

void cccContactsView::OnKeydownContactsGrid(NMHDR* pNMHDR, LRESULT* pResult) 
{
	LV_KEYDOWN* pLVKeyDow = (LV_KEYDOWN*)pNMHDR;
	
	if ( pLVKeyDow->wVKey == VK_DELETE)
	{
		CString strDeleteContact; strDeleteContact.LoadString( IDS_DELETE_CONTACT );
		CString strConfirm; strConfirm.LoadString( IDS_CONFIRM_DELETE_ITEM );
		if ( MessageBox( strDeleteContact, strConfirm, MB_YESNO ) == IDYES  )
		{

			POSITION pos = m_grid.GetFirstSelectedItemPosition();
			if (pos == NULL)
			   TRACE0("No items to delete!\n");
			else
			{
			   while (pos)
			   {
					int nItem = m_grid.GetNextSelectedItem(pos);
					// TODO Maybe move this to DeleteItem.
	  				dd( m_ddContacts )->deleteContact( theCCVOClient->getSelLeafMProjectID(), theCCVOClient->getSelLeafItemID(), m_grid.GetItemData( nItem ) );
					m_grid.DeleteItem( nItem );			  
			   }
			}					
		}
	}
	
	*pResult = 0;
}



