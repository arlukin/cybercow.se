// cccContactsTABBusinessMailAdress.cpp : implementation file
//

#include "stdafx.h"
#include "ccvo2k.h"
#include "cccContactsTABBusinessMailAdress.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccContactsTABBusinessMailAdress dialog


cccContactsTABBusinessMailAdress::cccContactsTABBusinessMailAdress(CWnd* pParent, cccVODB *aoDB)
	: ccdbDialog(cccContactsTABBusinessMailAdress::IDD, pParent, aoDB)	
{
	//{{AFX_DATA_INIT(cccContactsTABBusinessMailAdress)		
	//}}AFX_DATA_INIT
	Create(cccContactsTABBusinessMailAdress::IDD, pParent);	
}


void cccContactsTABBusinessMailAdress::DoDataExchange(CDataExchange* pDX)
{
	ccdbDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(cccContactsTABBusinessMailAdress)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(cccContactsTABBusinessMailAdress, ccdbDialog)
	//{{AFX_MSG_MAP(cccContactsTABBusinessMailAdress)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cccContactsTABBusinessMailAdress message handlers
BOOL cccContactsTABBusinessMailAdress::OnInitDialog() 
{
	setDDServer( dd(m_ddContacts) );

	m_Business_Mail_Street.adddbField( &dd(m_ddContacts)->m_Business_Mail_Street  );
	m_Business_Mail_Street.setCaptionOffset(-90);		
	m_Business_Mail_Street.SubclassDlgItem( IDC_BUSINESS_MAIL_STREET, this, this );

	m_Business_Mail_Zip_Or_PostalCode.adddbField( &dd(m_ddContacts)->m_Business_Mail_ZipOrPostalCode  );
	m_Business_Mail_Zip_Or_PostalCode.setCaptionOffset(-90);
	m_Business_Mail_Zip_Or_PostalCode.SubclassDlgItem( IDC_BUSINESS_MAIL_ZIP_OR_POSTALCODE, this, this );

	m_Business_Mail_City.adddbField( &dd(m_ddContacts)->m_Business_Mail_City  );
	m_Business_Mail_City.setCaptionOffset(-90);		
	m_Business_Mail_City.SubclassDlgItem( IDC_BUSINESS_MAIL_CITY, this, this );

	m_Business_Mail_State_Or_Province.adddbField( &dd(m_ddContacts)->m_Business_Mail_StateOrProvince  );
	m_Business_Mail_State_Or_Province.setCaptionOffset(-90);
	m_Business_Mail_State_Or_Province.SubclassDlgItem( IDC_BUSINESS_MAIL_STATE_OR_PROVINCE, this, this );

	m_Business_Mail_Country_Or_Region.adddbField( &dd(m_ddContacts)->m_Business_Mail_CountryOrRegion  );
	m_Business_Mail_Country_Or_Region.setCaptionOffset(-90);
	m_Business_Mail_Country_Or_Region.SubclassDlgItem( IDC_BUSINESS_MAIL_COUNTRY_OR_REGION, this, this );

	ccdbDialog::OnInitDialog();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
