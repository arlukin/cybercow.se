// ccllGroup.cpp : implementation file
//

#include "stdafx.h"
#include "ccllGroup.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// ccllGroup dialog


ccllGroup::ccllGroup( UINT nIDTemplate, CWnd * aParent)
	: CDialog(nIDTemplate, aParent)	
{

	//{{AFX_DATA_INIT(ccllGroup)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_nSelectedItem = -1;
}


BEGIN_MESSAGE_MAP(ccllGroup, CDialog)
	//{{AFX_MSG_MAP(ccllGroup)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP

	ON_BN_CLICKED(ID_CCLLGROUP_MENU_BUTTON, OnMenuButton)

	ON_BN_CLICKED(ID_CCLLGROUP_NEW_BUTTON, OnNewItem)
	ON_BN_CLICKED(ID_CCLLGROUP_DELETE_BUTTON, OnDeleteItem)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// ccllGroup message handlers

BOOL ccllGroup::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	//Is it an accelerator key
	if (HIWORD(wParam)==0)
	{
		switch (LOWORD(wParam))
		{
		case VK_ESCAPE:
			//Delegate the message to the parrent.
			GetParent()->SendMessage(WM_COMMAND, wParam);
			return true;
			break;
		}
	}

	
	return CDialog::OnCommand(wParam, lParam);
}

BOOL ccllGroup::PreTranslateMessage(MSG* pMsg) 
{
	return CDialog::PreTranslateMessage(pMsg);
}

void ccllGroup::OnCancel()
{
	// Cancel the CDialog OnCancel function.
}

void ccllGroup::OnOK()
{
	// Cancel the CDialog OnOk function.
}

//

void ccllGroup::init( int nResource, CWnd * parent, int nCtrlResourceID, int x, int y, LPCSTR strCaption)
{
	m_caption = strCaption;
	Create( nResource, parent );
	ShowWindow( TRUE );

	CWnd * pWnd = parent->GetDlgItem( nCtrlResourceID );	
   ::SetWindowPos( m_hWnd, pWnd->m_hWnd, x, y, 0, 0, SWP_SHOWWINDOW|SWP_NOSIZE );
}

//

int ccllGroup::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;

	CRect lClientRect;
	GetClientRect(lClientRect);

	m_group.Create(m_caption, WS_CHILD | WS_VISIBLE, lClientRect, this, ID_CCLLGROUP_GROUP);
	m_group.SetButtonStyle(BS_GROUPBOX);

	lClientRect.top += 2;
	lClientRect.right -=8;
	lClientRect.left  = lClientRect.right - 17;
	lClientRect.bottom = lClientRect.top + FIELD_CHANGER_OBJECT_HEIGHT;
	
	// Set the flags, 
	DWORD ldwStyle =  WS_CHILD | WS_VISIBLE | BS_CENTER ;
	

	m_deleteButton.Create( "", ldwStyle, lClientRect, this, ID_CCLLGROUP_DELETE_BUTTON );
	m_deleteButton.SetIcon( IDI_DELETE);
	m_deleteButton.DrawBorder(FALSE);	

	lClientRect.right = lClientRect.left;
	lClientRect.left  = lClientRect.right - 21;
	m_newButton.Create( "", ldwStyle, lClientRect, this, ID_CCLLGROUP_NEW_BUTTON );
	m_newButton.SetIcon( IDI_NEW );
	m_newButton.DrawBorder(FALSE);

	lClientRect.right = lClientRect.left;
	lClientRect.left  = lClientRect.right - 16;	
	m_menuButton.Create( "", ldwStyle, lClientRect, this, ID_CCLLGROUP_MENU_BUTTON );
	
	return 0;
}

//

void ccllGroup::OnMenuButton()
{
	m_menuButton.clearMenu();

	OnBuildMenu( &m_menuButton ); 

	// Show the menu. If the user make a choice
	// change to that field.
	m_nSelectedItem = m_menuButton.showMenu();
	
	OnChangedItem( false );

}

