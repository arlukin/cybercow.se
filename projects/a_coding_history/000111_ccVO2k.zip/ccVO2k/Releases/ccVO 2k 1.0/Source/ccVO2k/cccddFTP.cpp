// cccddFTP.cpp: implementation of the cccddFTP class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "cccddFTP.h"
#include "cccvodb.h"
#include "ccVOClient.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
#define TS ddf(cccddFTP)

BEGIN_CCFIELD_EVENT( cccddFTP  )		
//	ON_CCFIELD(	ID							OnSetFocus,				OnKillFocus,		OnValidate,		OnPopup,				OnEndPopup		OnChange				)	
END_CCFIELD_EVENT()

//

cccddFTP ::cccddFTP ( ccDataBase* pDatabase ) 
: ccDataDictionary( pDatabase )
{
	try
	{
		setConfirmDeleteMsg("F2 delete doesn't work in this version");
		// Open the table.		
		openADO("SELECT  dtfFTP.MProjectID,				dtTreeOrder.ItemID,			dtfFTP.ItemID, "						
						"dtfFTP.Name,					dtfFTP.URL,					dtfFTP.Port, "
						"dtfFTP.Login,					dtfFTP.Password, "
						"dtfFTP.InitialLocalDirectory,	dtfFTP.InitialRemoteDirectory, "
						"dtfFTP.Notes,					dtfFTP.CreditGrade,			dtfFTP.LastLogedOn, "
						"dtfFTP.LastChecked,			dtfFTP.ValidSite "
				"FROM dtfFTP, dtItems, dtTreeOrder "
				"WHERE dtfFTP.MProjectID = dtTreeOrder.MProjectID AND "
				"    dtfFTP.ItemID = dtTreeOrder.ChildID AND "
				"    dtItems.MProjectID = dtTreeOrder.MProjectID AND "
				"    dtItems.ItemID = dtTreeOrder.ChildID  "
				" order by dtfFTP.Name, dtfFTP.URL"
				,ADODB::adOpenKeyset, ADODB::adLockPessimistic ,ADODB::adUseServer );		
		
		bind( m_MProjectID,				FTP_MProjectID,				_T("MProjectID")			);
		bind( m_ParentItemID,			FTP_ParentItemID,			_T("dtTreeOrder.ItemID")	);
		bind( m_ItemID,					FTP_ItemID,					_T("dtfFTP.ItemID")			);
		bind( m_Name,					FTP_Name,					_T("Name")					);
		bind( m_URL,					FTP_URL,					_T("URL")					);		
		bind( m_Port,					FTP_Port,					_T("Port")					);				
		bind( m_Login,					FTP_Login,					_T("Login")					);				
		bind( m_Password,				FTP_Password,				_T("Password")				);			
		bind( m_InitialLocalDirectory,	FTP_InitialLocalDirectory,	_T("InitialLocalDirectory"));
		bind( m_InitialRemoteDirectory,	FTP_InitialRemoteDirectory,	_T("InitialRemoteDirectory"));		
		bind( m_Notes,					FTP_Notes,					_T("Notes")					);
		bind( m_CreditGrade,			FTP_CreditGrade,			_T("CreditGrade")			);
		bind( m_LastLogedOn,			FTP_LastLogedOn,			_T("LastLogedOn")			);
		bind( m_LastChecked,			FTP_LastChecked,			_T("LastChecked")			);
		bind( m_ValidSite,				FTP_ValidSite,				_T("ValidSite")				);
		
		m_Name.enableColumnSorting( true );
		m_URL.enableColumnSorting( true );		
					
		// FTP_MProjectID
		m_MProjectID.setLongCaption(	_T("MProjectID") );
		m_MProjectID.setShortCaption(	_T("MProjectID") );
		m_MProjectID.setStatusHelp(		_T("MProjectID") );

		// FTP_ParentItemID
		m_ParentItemID.setLongCaption(	_T("ParentItemID") );
		m_ParentItemID.setShortCaption(	_T("ParentItemID") );
		m_ParentItemID.setStatusHelp(	_T("ParentItemID") );

		// FTP_ItemID
		m_ItemID.setLongCaption(	_T("ItemID") );
		m_ItemID.setShortCaption(	_T("ItemID") );
		m_ItemID.setStatusHelp(		_T("ItemID") );

		// FTP_Name
		m_Name.setLongCaption(	_T("Name") );
		m_Name.setShortCaption(	_T("Name") );
		m_Name.setStatusHelp(	_T("Name") );

		// FTP_URL
		m_URL.setLongCaption(	_T("URL") );
		m_URL.setShortCaption(	_T("URL") );
		m_URL.setStatusHelp(	_T("URL") );

		// FTP_Port
		m_Port.setLongCaption(		_T("Port") );
		m_Port.setShortCaption(		_T("Port") );
		m_Port.setStatusHelp(		_T("Port") );
	
		// FTP_Login.
		m_Login.setLongCaption(		_T("Login") );
		m_Login.setShortCaption(	_T("Login") );
		m_Login.setStatusHelp(		_T("Login") );
		
		// FTP_Password
		m_Password.setLongCaption(		_T("Password") );
		m_Password.setShortCaption(		_T("Password") );
		m_Password.setStatusHelp(		_T("Password") );
		
		// FTP_InitialLocalDirectory
		m_InitialLocalDirectory.setLongCaption(		_T("Initial Local Directory") );
		m_InitialLocalDirectory.setShortCaption(	_T("Local Dir") );
		m_InitialLocalDirectory.setStatusHelp(		_T("Initial Local Directory") );
		
		// FTP_InitialRemoteDirectory
		m_InitialRemoteDirectory.setLongCaption(	_T("Initial Remote Directory") );
		m_InitialRemoteDirectory.setShortCaption(	_T("Remote Dir") );
		m_InitialRemoteDirectory.setStatusHelp(		_T("Initial Remote Directory") );
		
		// FTP_Notes
		m_Notes.setLongCaption(		_T("Notes") );
		m_Notes.setShortCaption(	_T("Notes") );
		m_Notes.setStatusHelp(		_T("Notes") );
		m_Notes.setEditMultiLine( true );		

		// FTP_CreditGrade
		m_CreditGrade.setLongCaption(	_T("Credit Grade") );
		m_CreditGrade.setShortCaption(	_T("Credit Grade") );
		m_CreditGrade.setStatusHelp(	_T("Credit Grade") );

		// FTP_LastLogedOn
		m_LastLogedOn.setLongCaption(	_T("Last Loged On") );
		m_LastLogedOn.setShortCaption(	_T("Last Loged On") );
		m_LastLogedOn.setStatusHelp(	_T("Last Loged On") );
		m_LastLogedOn.setMaskType( CCE_DATE );		
		m_LastLogedOn.setStyle( WS_DISABLED );

		// FTP_LastChecked
		m_LastChecked.setLongCaption(	_T("Last Checked") );
		m_LastChecked.setShortCaption(	_T("Last Checked") );
		m_LastChecked.setStatusHelp(	_T("Last Checked") );
		m_LastChecked.setMaskType( CCE_DATE );
		m_LastChecked.setStyle( WS_DISABLED );

		// FTP_ValidSite
		m_ValidSite.setLongCaption(		_T("Valid Site") );
		m_ValidSite.setShortCaption(	_T("Valid Site") );
		m_ValidSite.setStatusHelp(		_T("Valid Site") );
		m_ValidSite.setStyle( WS_DISABLED );

	}
	catch(ccException *e) 
	{
		ccErr(*e,"","", MB_OK);
		exit(1);
	}
	catch(...) 
	{
		ccErr("DB Error", "","", MB_OK);
		exit(1);
	}
}

//

cccddFTP ::~cccddFTP ()
{
	

}

//////////////////////////////////////////////////////////////////////
// *** Table Field Events
//////////////////////////////////////////////////////////////////////

void cccddFTP::creating()
{
	m_MProjectID = getSelLeafMProjectID();
	m_ItemID =	   getDB()->createItemID();		

	getDB()->insert_dtItems( m_MProjectID, m_ItemID, m_Name, 3, 5);
	getDB()->insert_dtTreeOrder( m_MProjectID, getSelLeafItemID(), m_ItemID);	
}

//

void cccddFTP::updateing()
{	
	getDB()->update_dtItems( m_MProjectID, m_ItemID, (CString)m_Name);
}

//

void cccddFTP::deleting()
{ 	
}

//

void cccddFTP::OnFieldChangeComplete()
{
}

//

void cccddFTP::OnFieldClearComplete()
{
}


//////////////////////////////////////////////////////////////////////
// *** SQL-Script Functions
//////////////////////////////////////////////////////////////////////

bool cccddFTP::deleteFTP( int nMProjectID, int nParentID, int nItemID)
{
	if ( ( getDB() ) && ( getDB()->isOpen() ) )
	{
		try
		{			
			try
			{
				ccString strSQL, strWhereSQL;	
				
				strWhereSQL <<   " where MProjectID = " << nMProjectID;
				strWhereSQL <<     " and ItemID = "     << nItemID;
												
				VARIANT RecordsEffected;
				RecordsEffected.vt = VT_INT;
				
				getDB()->beginTrans();
					
					strSQL << "DELETE FROM dtfFTP " << strWhereSQL;
					getDB()->getConnection()->Execute(_bstr_t(strSQL),&RecordsEffected,ADODB::adCmdText);

					strSQL=""; strSQL << "DELETE FROM dtItems " << strWhereSQL;
					getDB()->getConnection()->Execute(_bstr_t(strSQL),&RecordsEffected,ADODB::adCmdText);

					strSQL=""; strSQL << "DELETE FROM dtTreeOrder ";
							   strSQL << "where MProjectID = " << nMProjectID;
							   strSQL << "  and ItemID = "     << nParentID;
							   strSQL << "  and ChildID = "    << nItemID;
					getDB()->getConnection()->Execute(_bstr_t(strSQL),&RecordsEffected,ADODB::adCmdText);

				getDB()->commitTrans();

				return true;
			}
			catch(_com_error &e) 
			{ 
				getDB()->rollbackTrans();								

				ccErr(getProviderError( getDB()->getConnection()) );
				ccThrowccException( getProviderError( getDB()->getConnection()) ); /*Delete unreference warning*/ (void*)&e; 				
			}	
		}
		catch( ccException * e)
		{
			ccErr( *e, "", "", MB_OK );			
		}
		catch(...)
		{
			ccErrEM( IDS_DB_ERROR, NULL, NULL, MB_OK );
		}
	}
	else
		ccErrEM( IDS_DATABASE_ISNT_OPEN, NULL, NULL, MB_OK);

	return false;
}