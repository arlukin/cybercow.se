// ccdbGroup.cpp : implementation file
//

#include "stdafx.h"
#include "ccdbGroup.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// ccdbGroup dialog


ccdbGroup::ccdbGroup( UINT nIDTemplate, CWnd * aParent)
	: CDialog(nIDTemplate, aParent)	
{

	//{{AFX_DATA_INIT(ccdbGroup)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


BEGIN_MESSAGE_MAP(ccdbGroup, CDialog)
	//{{AFX_MSG_MAP(ccdbGroup)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// ccdbGroup message handlers

BOOL ccdbGroup::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	//Is it an accelerator key
	if (HIWORD(wParam)==0)
	{
		switch (LOWORD(wParam))
		{
		case VK_ESCAPE:
			//Delegate the message to the parrent.
			GetParent()->SendMessage(WM_COMMAND, wParam);
			return true;
			break;
		}
	}

	
	return CDialog::OnCommand(wParam, lParam);
}

BOOL ccdbGroup::PreTranslateMessage(MSG* pMsg) 
{
	return CDialog::PreTranslateMessage(pMsg);
}

void ccdbGroup::OnCancel()
{
	// Cancel the CDialog OnCancel function.
}

void ccdbGroup::OnOK()
{
	// Cancel the CDialog OnOk function.
}

//

void ccdbGroup::init( int nResource, CWnd * parent, int nCtrlResourceID, int x, int y)
{
	Create( nResource, parent );
	ShowWindow( TRUE );

	CWnd * pWnd = parent->GetDlgItem( nCtrlResourceID );	
   ::SetWindowPos( m_hWnd, pWnd->m_hWnd, x, y, 0, 0, SWP_SHOWWINDOW|SWP_NOSIZE );
}