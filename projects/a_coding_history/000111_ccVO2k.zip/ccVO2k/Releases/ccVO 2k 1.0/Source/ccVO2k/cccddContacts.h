// cccddContacts.h: interface for the cccddContacts class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CCCDDCONTACTS_H__B6B88D66_0AFE_11D4_89A5_00609708DCFE__INCLUDED_)
#define AFX_CCCDDCONTACTS_H__B6B88D66_0AFE_11D4_89A5_00609708DCFE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// *** Field ID:s
#define CONTACTS_MProjectID				1
#define CONTACTS_ParentItemID			2
#define CONTACTS_DisplayType			3
#define CONTACTS_ItemID					4
#define CONTACTS_Title					5
#define CONTACTS_FirstName				6
#define CONTACTS_MiddleName				7
#define CONTACTS_LastName				8
#define CONTACTS_Display				9
#define CONTACTS_NickName1				10
#define CONTACTS_NickName2				11
#define CONTACTS_BirthDate				12
#define CONTACTS_SpousesName			13
#define CONTACTS_SpousesInterests		14
#define CONTACTS_Aniversary				15
#define CONTACTS_ChildrenNames			16
#define CONTACTS_Photo					17
#define CONTACTS_PersonalNotes			18
#define CONTACTS_Company				19
#define CONTACTS_JobTitle				20
#define CONTACTS_Office					21
#define CONTACTS_Department				22
#define CONTACTS_ManagerName			23
#define CONTACTS_AssistensName			24
#define CONTACTS_OthersName				25
#define CONTACTS_BusinessNotes			26
#define CONTACTS_PrimEMail				27
#define CONTACTS_PhoneName1				28
#define CONTACTS_PhoneName2				29
#define CONTACTS_PhoneName3				30
#define CONTACTS_ICQ_ID					31
#define CONTACTS_Yahoo_ID				32
#define CONTACTS_AOL_ID					33
#define CONTACTS_MSN_ID					34
#define CONTACTS_Home_Street			35		
#define CONTACTS_Home_City				36
#define CONTACTS_Home_StateOrProvince	37
#define CONTACTS_Home_ZipOrPostalCode	38
#define CONTACTS_Home_CountryOrRegion	39
#define CONTACTS_Business_Mail_Street				40		
#define CONTACTS_Business_Mail_City					41
#define CONTACTS_Business_Mail_StateOrProvince		42
#define CONTACTS_Business_Mail_ZipOrPostalCode		43
#define CONTACTS_Business_Mail_CountryOrRegion		44
#define CONTACTS_Business_Office_Street				45		
#define CONTACTS_Business_Office_City				46
#define CONTACTS_Business_Office_StateOrProvince	47
#define CONTACTS_Business_Office_ZipOrPostalCode	48
#define CONTACTS_Business_Office_CountryOrRegion	49
#define CONTACTS_Personal_WebPage1		50
#define CONTACTS_Personal_WebPage2		51
#define CONTACTS_Personal_FTPSite1		52	
#define CONTACTS_Personal_FTPSite2		53
#define CONTACTS_Business_WebPage1		54
#define CONTACTS_Business_WebPage2		55
#define CONTACTS_Business_FTPSite1		56	
#define CONTACTS_Business_FTPSite2		57


// Structs
struct sContactsEmail
{
	// Fields from dtfContactsEmail
	CString strComment;
	CString strEmailAdress;
	bool	bPlainText;
	
	// Status Attributes	
	bool	bNew;				// The record is new
	bool	bCantDelete;		// Can't delete this record, need to always be there.
	bool	bDeletedRecord;		// Delete this record from the table.
	bool	bChanged;			// The record is changed.
};

// Structs
struct sContactsPhone
{
	// Fields from dtfContactsEmail
	CString strPhoneName;
	CString strNumber;	
	
	// Status Attributes	
	bool	bNew;				// The record is new
	bool	bCantDelete;		// Can't delete this record, need to always be there.
	bool	bDeletedRecord;		// Delete this record from the table.
	bool	bChanged;			// The record is changed.
};

//

class cccddContacts : public ccDataDictionary  
{
// *** Construction/Destruction
public:
	//
	//
	DECLARE_CCFIELD_EVENT();

	//
	//
	cccddContacts ( ccDataBase* pDatabase );	

	//
	//
	virtual ~cccddContacts ();
	

// *** Data Members
public:
	ccField m_MProjectID;	
	ccField m_ItemID;
	ccField m_ParentItemID;
	ccField m_DisplayType;
	ccField m_Title;
	ccField m_FirstName;
	ccField m_MiddleName;
	ccField m_LastName;
	ccField m_Display;
	ccField m_NickName1;
	ccField m_NickName2;
	ccField m_BirthDate;
	ccField m_SpousesName;
	ccField m_SpousesInterests;
	ccField m_Aniversary;
	ccField m_ChildrenNames;
	ccField m_Photo;
	ccField m_PersonalNotes;
	ccField m_Company;
	ccField m_JobTitle;
	ccField m_Office;
	ccField m_Department;
	ccField m_ManagerName;
	ccField m_AssistensName;
	ccField m_OthersName;
	ccField m_BusinessNotes;
	ccField m_PrimEMail;
	ccField m_PhoneName1;
	ccField m_PhoneName2;
	ccField m_PhoneName3;
	ccField m_ICQ_ID;
	ccField m_Yahoo_ID;
	ccField m_AOL_ID;
	ccField m_MSN_ID;
	ccField m_Home_Street;
	ccField m_Home_City;
	ccField m_Home_StateOrProvince;
	ccField m_Home_ZipOrPostalCode;
	ccField m_Home_CountryOrRegion;

	ccField m_Business_Mail_Street;
	ccField m_Business_Mail_City;
	ccField m_Business_Mail_StateOrProvince;
	ccField m_Business_Mail_ZipOrPostalCode;
	ccField m_Business_Mail_CountryOrRegion;

	ccField m_Business_Office_Street;
	ccField m_Business_Office_City;
	ccField m_Business_Office_StateOrProvince;
	ccField m_Business_Office_ZipOrPostalCode;
	ccField m_Business_Office_CountryOrRegion;

	ccField m_Personal_WebPage1;
	ccField m_Personal_WebPage2;
	ccField m_Personal_FTPSite1;
	ccField m_Personal_FTPSite2;
	ccField m_Business_WebPage1;
	ccField m_Business_WebPage2;
	ccField m_Business_FTPSite1;
	ccField m_Business_FTPSite2;
	
// *** Table Events
public:	
	virtual void backout()	 {;};
	virtual void creating();
	virtual void updateing();
	virtual void deleting();
	virtual void OnFieldChangeComplete();
	virtual void OnFieldClearComplete();

// *** Table Field Events
	bool OnSetFocusFirstName(  DD_DISPINFO * aDispInfo  );
	
	bool OnChangeDisplay( DD_DISPINFO * aDispInfo );
	bool OnChangeTitle( DD_DISPINFO * aDispInfo );
	
	bool OnChangeFirstName( DD_DISPINFO * aDispInfo );
	bool OnChangeMiddleName( DD_DISPINFO * aDispInfo );
	bool OnChangeLastName( DD_DISPINFO * aDispInfo );	
		
	bool OnChangeNickName1( DD_DISPINFO * aDispInfo );
	bool OnChangeNickName2( DD_DISPINFO * aDispInfo );
	
	bool OnPopupDisplay( DD_DISPINFO * aDispInfo  );
	bool OnEndPopupDisplay( DD_DISPINFO * aDispInfo );

	bool OnPopupTitle( DD_DISPINFO * aDispInfo );
	bool OnEndPopupTitle( DD_DISPINFO * aDispInfo );

	
// *** Helper Attributes
public:
	//
	//
	void setSelLeafMProjectID( int nSelLeafMProject )	{ m_nSelLeafMProject = nSelLeafMProject;	};
	int  getSelLeafMProjectID()							{ return m_nSelLeafMProject;				};

	//
	//
	void setSelLeafItemID    ( int nSelLeafItemID )		{ m_nSelLeafItemID = nSelLeafItemID;		};
	int  getSelLeafItemID    ()							{ return m_nSelLeafItemID;					};

protected:
	//
	//
	static  CString *getDisplayText(DD_DISPINFO * aDispInfo , int aiItem);

	//
	//
	bool	updateDisplayField(DD_DISPINFO * aDispInfo );

// *** SQL-Script Functions
public:

	// Get all contacts under a specific leaf in the folder tree.
	//
	bool getTreeLeafContacts( CPtrList &treeLeafContacts);

	// Get the PhoneNumber from a Contact
	//
	void initContactsPhone(int nMProjectID, int nItemID);
	CString getContactsPhone( long nItemID, LPCSTR strPhoneName);	

	// Delete a contact from the tables dtfContacts, dtfContactsAddress, dtfContactsWebPage, 
	// dtfContactsEmail, dtfContactsFTPSite, dtfContactsPhone, dtfContactsICQ and dtItems
	//
	bool deleteContact( int nMProjectID, int nParentID, int nItemID);

	//
	//
	void buildEmailStruct(bool bNew);
	void saveEmailStruct();

	//
	//
	void buildPhoneStruct(bool bNew);
	void savePhoneStruct();
public:
	CPtrList m_contactsEmailSL;		//		see buildEmailStruct;
	CPtrList m_contactsPhoneSL;		//		see buildPhoneStruct;
	
private:
	// See setSelLeafMProjectID etc.
	int m_nSelLeafMProject;
	int m_nSelLeafItemID;  	

	CPtrArray m_contactsPhoneList;	// see initContactsPhone	
};
#endif // !defined(AFX_CCCDDCONTACTS_H__B6B88D66_0AFE_11D4_89A5_00609708DCFE__INCLUDED_)
