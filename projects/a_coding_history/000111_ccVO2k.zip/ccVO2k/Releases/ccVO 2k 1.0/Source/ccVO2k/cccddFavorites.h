// cccddFavorites.h: interface for the cccddFavorites class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CCCDDFAVORITES_H__0C9A87E4_281B_11D4_89A6_00609708DCFE__INCLUDED_)
#define AFX_CCCDDFAVORITES_H__0C9A87E4_281B_11D4_89A6_00609708DCFE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// *** Field ID:s
#define FAVORITES_MProjectID				1
#define FAVORITES_ParentItemID				2
#define FAVORITES_ItemID					3
#define FAVORITES_Name						4			
#define FAVORITES_URL						5			
#define FAVORITES_DefaultBrowser			6				
#define FAVORITES_Notes						7			
#define FAVORITES_CreditGrade				7				
#define FAVORITES_LastLogedOn				8				
#define FAVORITES_LastChecked				9				
#define FAVORITES_ValidSite					10			

//

class cccddFavorites  : public ccDataDictionary  
{
// *** Construction/Destruction
public:
	//
	//
	DECLARE_CCFIELD_EVENT();

	//
	//
	cccddFavorites ( ccDataBase* pDatabase );	

	//
	//
	virtual ~cccddFavorites ();

// *** Data Members
public:
	ccField m_MProjectID;
	ccField m_ParentItemID;
	ccField m_ItemID;
	ccField m_Name;
	ccField m_URL;
	ccField m_DefaultBrowser;
	ccField m_Notes;
	ccField m_CreditGrade;
	ccField m_LastLogedOn;
	ccField m_LastChecked;
	ccField m_ValidSite;

// *** Table Events
public:	
	virtual void backout()	 {;};
	virtual void creating();
	virtual void updateing();
	virtual void deleting();
	virtual void OnFieldChangeComplete();
	virtual void OnFieldClearComplete();

// *** Table Field Events
public:
	bool OnPopupDefaultBrowser( DD_DISPINFO * aDispInfo );
// *** Helper Attributes
public:
	//
	//
	void setSelLeafMProjectID( int nSelLeafMProject )	{ m_nSelLeafMProject = nSelLeafMProject;	};
	int  getSelLeafMProjectID()							{ return m_nSelLeafMProject;				};

	//
	//
	void setSelLeafItemID    ( int nSelLeafItemID )		{ m_nSelLeafItemID = nSelLeafItemID;		};
	int  getSelLeafItemID    ()							{ return m_nSelLeafItemID;					};

// *** SQL-Script Functions
public:
	// Delete a favorite from the tables dtfFavorites, dtItems and dtTreeOrder
	//
	bool deleteFavorite( int nMProjectID, int nParentID, int nItemID);

private:
	// See setSelLeafMProjectID etc.
	int m_nSelLeafMProject;
	int m_nSelLeafItemID;  	
};

#endif // !defined(AFX_CCCDDFAVORITES_H__0C9A87E4_281B_11D4_89A6_00609708DCFE__INCLUDED_)
