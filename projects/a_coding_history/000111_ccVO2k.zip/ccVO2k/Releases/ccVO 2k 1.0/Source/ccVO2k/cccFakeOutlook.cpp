// cccFakeOutlook.cpp : implementation file
//

#include "stdafx.h"
#include "ccVO2k.h"
#include "cccFakeOutlook.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccFakeOutlook

IMPLEMENT_DYNCREATE(cccFakeOutlook, CView)

cccFakeOutlook::cccFakeOutlook()
{
}

cccFakeOutlook::~cccFakeOutlook()
{
}


BEGIN_MESSAGE_MAP(cccFakeOutlook, CView)
	//{{AFX_MSG_MAP(cccFakeOutlook)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cccFakeOutlook drawing

void cccFakeOutlook::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// cccFakeOutlook diagnostics

#ifdef _DEBUG
void cccFakeOutlook::AssertValid() const
{
	CView::AssertValid();
}

void cccFakeOutlook::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// cccFakeOutlook message handlers
