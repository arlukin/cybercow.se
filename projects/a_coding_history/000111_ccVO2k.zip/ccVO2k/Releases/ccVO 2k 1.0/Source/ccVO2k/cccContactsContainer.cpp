// cccContactsContainer.cpp : implementation file
//

#include "stdafx.h"
#include "ccVO2k.h"
#include "cccContactsContainer.h"
#include "cccContactsView.h"
#include "cccContactsPreviewPane.h"
#include "cccEmptyContainer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccContactsContainer

IMPLEMENT_DYNCREATE(cccContactsContainer, CView)

cccContactsContainer::cccContactsContainer()
{
}

cccContactsContainer::~cccContactsContainer()
{
}


BEGIN_MESSAGE_MAP(cccContactsContainer, CView)
	//{{AFX_MSG_MAP(cccContactsContainer)
	ON_WM_CREATE()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cccContactsContainer drawing

void cccContactsContainer::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// cccContactsContainer diagnostics

#ifdef _DEBUG
void cccContactsContainer::AssertValid() const
{
	CView::AssertValid();
}

void cccContactsContainer::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// cccContactsContainer message handlers

int cccContactsContainer::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// Create splitters 
	//
	// The context information is passed on from the framework
	CCreateContext *pContext = (CCreateContext*)lpCreateStruct->lpCreateParams;

	// Create the splitter window with two columns
	if (!m_wndSplitter.CreateStatic(this, 2, 1))
	{
		TRACE0("Failed to create splitter window\n");
		return FALSE;
	}


	// Standard sizing for splitter
	if (!m_wndSplitter.CreateView(0,0,RUNTIME_CLASS(cccContactsView),
		CSize(0, 250), pContext))
	{
		m_wndSplitter.DestroyWindow();
		return -1;
	}

	// if (!m_wndSplitter.CreateView(1,0,RUNTIME_CLASS(cccContactsPreviewPane),
	if (!m_wndSplitter.CreateView(1,0,RUNTIME_CLASS(cccEmptyContainer),
		CSize(0, 0), pContext))
	{
		m_wndSplitter.DestroyWindow();
		return -1;
	}
	m_wndSplitter.HideRow(1);
		
	return 0;
}

//

void cccContactsContainer::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	if( m_wndSplitter.GetSafeHwnd())
	{
		int nCX = ::GetSystemMetrics( SM_CXEDGE );
		int nCY = ::GetSystemMetrics( SM_CYEDGE );
		
		// move and grow view to clip border
		m_wndSplitter.MoveWindow(-2, -2, cx+4, cy+4);	
	}
	
}
