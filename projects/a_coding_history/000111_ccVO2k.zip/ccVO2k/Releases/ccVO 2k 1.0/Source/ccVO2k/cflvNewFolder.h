// cflvNewFolder.h: interface for the ccVOClient class.
//
//////////////////////////////////////////////////////////////////////

#ifndef __CCFLVFOLDER_H__
#define __CCFLVFOLDER_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// cflvNewFolder.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// cflvNewFolder dialog

class cflvNewFolder : public CDialog
{
// *** Construction/Destruction
public:
	cflvNewFolder(CWnd* pParent = NULL);   // standard constructor

// *** Dialog Data
	//{{AFX_DATA(cflvNewFolder)
	enum { IDD = IDD_FLV_FOLDER_NAME };
	CString	m_text;
	//}}AFX_DATA


// *** Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(cflvNewFolder)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// *** Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(cflvNewFolder)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // __CCFLVFOLDER_H__
