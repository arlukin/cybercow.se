// ccVO2k.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "ccVO2k.h"

#include "MainFrame.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// *** Construction / Destruction
/////////////////////////////////////////////////////////////////////////////
cccVO2kApp::cccVO2kApp()
{
	m_theCCVOClient = NULL;	
}

//

cccVO2kApp::~cccVO2kApp()
{
	if (m_theCCVOClient )
		delete m_theCCVOClient;
}
/////////////////////////////////////////////////////////////////////////////
// *** Overrides
/////////////////////////////////////////////////////////////////////////////

BOOL cccVO2kApp::InitInstance()
{
	if (!AfxSocketInit())
	{
		AfxMessageBox(IDP_SOCKETS_INIT_FAILED);
		return FALSE;
	}

	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	// Change the registry key under which our settings are stored.
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization.
	SetRegistryKey(_T("CyberCow"));

	// TODO LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	try
	{
		// Check if an ccVO2k instance is already started.
		if ( FindWindow(NULL, "ccVO2k") ) //TODO find the real window?? Now it can also find a directory window..			
			ccThrowccException( IDS_CAN_ONLY_HAVE_ONE_INSTANCE_STARTED_AT_THE_SAME_TIME );
		
		getRegistrySettings();

		// Initialize error handling system		
		if ( !m_traceFileURL.IsEmpty() )
		{
			oError.setFileName( m_traceFileURL + "ccVO2k.trc" );	
			oError.enableLogging( TRUE, TRUE );
		}
		#ifdef _DEBUG
			oError.enableJEDebugMode( );
		#endif

	}
	catch(ccException *e) 
	{
		ccErr(*e,"","", MB_OK);
		exit(1);
	}


	// Create the "Document" or data Container.
	m_theCCVOClient = new ccVOClient;

	test();

	if ( theCCVOClient->login() )	// TODO this is local project version only, next version should login.
	{
		// To create the main window, this code creates a new frame window
		// object and then sets it as the application's main window object.

		CMainFrame* pFrame = new CMainFrame;
		m_pMainWnd = pFrame;

		// create and load the frame with its resources

		pFrame->LoadFrame(IDR_MAINFRAME,
			WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE, NULL,
			NULL);




		// The one and only window has been initialized, so show and update it.
		pFrame->ShowWindow(SW_SHOW);
		pFrame->UpdateWindow();

		theCCVOClient->setStarted();

		return TRUE;
	}
	else
		return FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// *** Generated message map functions
/////////////////////////////////////////////////////////////////////////////

void cccVO2kApp::OnAppAbout()
{
	CWnd wnd;
	wnd.Attach( GetTopWindow(NULL) );
	cccdAboutCCVO2K aboutDlg( &wnd );
	aboutDlg.DoModal();
	wnd.Detach( );
}

//

BEGIN_MESSAGE_MAP(cccVO2kApp, CWinApp)
	//{{AFX_MSG_MAP(cccVO2kApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_HELP_CYBERCOWONTHEWEB_CHECKFORNEWVERSION, OnHelpCybercowonthewebCheckfornewversion)
	ON_COMMAND(ID_HELP_CYBERCOWONTHEWEB_CYBERCOWHOMEPAGE, OnHelpCybercowonthewebCybercowhomepage)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// *** Menu/Toolbar Commands
/////////////////////////////////////////////////////////////////////////////

void cccVO2kApp::OnHelpCybercowonthewebCheckfornewversion() 
{
	surfTo( "http://home.bip.net/cybercow/newversion", m_pMainWnd );
}

//

void cccVO2kApp::OnHelpCybercowonthewebCybercowhomepage() 
{
	surfTo( "http://home.bip.net/cybercow", m_pMainWnd);
}


/////////////////////////////////////////////////////////////////////////////
// *** Debug
/////////////////////////////////////////////////////////////////////////////

void cccVO2kApp::test()
{
#ifdef _DEBUG

	return;

#endif
}

/////////////////////////////////////////////////////////////////////////////
// The one and only cccVO2kApp object

cccVO2kApp theApp;

void cccVO2kApp::getRegistrySettings()
{
	// Get the program URL		
	ccRegistry reg;
	reg.openCreate(HKEY_LOCAL_MACHINE, dPROGRAM_REG_PATH);
	reg.readWriteString( "ProgramURL", m_programURL, ".\\" );
	reg.readWriteString( "DataBaseURL", m_dataBaseURL, m_programURL + "\\ccVO2k.mdb" );
	reg.ReadString("traceFileURL", m_traceFileURL );
	reg.Close();				

	// Verify regsettings
	if (!fileExist( m_programURL +"ccVO2k.exe") == CCFOUND)
	{
		ccThrowccException( IDS_WRONG_PROGRAMURL_DIRECTORY );		
	}

	if (!fileExist( m_dataBaseURL) == CCFOUND)
	{	
		ccThrowccException( IDS_WRONG_DATABASEURL_DIRECTORY );
	}
	
	if (!fileExist( m_traceFileURL ) == CCFOUND)
	{
		m_traceFileURL = "";
	}
}
