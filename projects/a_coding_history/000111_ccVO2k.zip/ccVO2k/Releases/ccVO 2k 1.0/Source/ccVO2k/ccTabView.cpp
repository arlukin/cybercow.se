// ccTabView.cpp : implementation file
//

#include "stdafx.h"
#include "ccvo2k.h"
#include "ccTabView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// ccTabView

IMPLEMENT_DYNCREATE(ccTabView, CScrollView)

ccTabView::ccTabView()
{
	setSize(CSize(500,380));
}

//

ccTabView::~ccTabView()
{
}

//

BEGIN_MESSAGE_MAP(ccTabView, CScrollView)
	//{{AFX_MSG_MAP(ccTabView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// ccTabView drawing

void ccTabView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// ccTabView diagnostics

#ifdef _DEBUG
void ccTabView::AssertValid() const
{
	CScrollView::AssertValid();
}

void ccTabView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// ccTabView message handlers

void ccTabView::OnInitialUpdate() 
{
	CScrollView::OnInitialUpdate();
	getTabCtrl()->SetFocus();
	
}

//

int ccTabView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CScrollView::OnCreate(lpCreateStruct) == -1)
		return -1;
		
	m_tab.Create( WS_VISIBLE, CRect(0, 0, lpCreateStruct->cx, lpCreateStruct->cy), this, ID_CCTAB_VIEW_ID);
	
	CSize lSize = getSize();
	m_tab.SetWindowPos(NULL,0, 0, lSize.cx, lSize.cy, SWP_NOZORDER | SWP_NOMOVE);	

	SetScrollSizes(MM_TEXT, getSize());
		
	return 0;
}

//

void ccTabView::OnSize(UINT nType, int cx, int cy) 
{
	

	CSize lSize = getSize();

	if (lSize.cx < cx)
		lSize.cx = cx;

	if (lSize.cy < cy)
		lSize.cy = cy;
	
	m_tab.SetWindowPos(NULL,0, 0, lSize.cx, lSize.cy, SWP_NOZORDER | SWP_NOMOVE);	
	CScrollView::OnSize(nType, cx, cy);
}

BOOL ccTabView::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	//Is it an accelerator key
	if (HIWORD(wParam)==0)
	{
		switch (LOWORD(wParam))
		{
		case VK_ESCAPE:
			//Delegate the message to the parrent.
			GetParent()->SendMessage(WM_COMMAND, wParam);
			return true;	
		}
	}
	
	return CScrollView::OnCommand(wParam, lParam);
}
