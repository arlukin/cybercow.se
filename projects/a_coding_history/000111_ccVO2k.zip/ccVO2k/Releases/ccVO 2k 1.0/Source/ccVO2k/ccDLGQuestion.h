#if !defined(AFX_CCDLGQUESTION_H__01B7E869_2506_11D4_89A6_00609708DCFE__INCLUDED_)
#define AFX_CCDLGQUESTION_H__01B7E869_2506_11D4_89A6_00609708DCFE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ccDLGQuestion.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// ccDLGQuestion dialog

class ccDLGQuestion : public CDialog
{
// Construction
public:
	ccDLGQuestion(CWnd* pParent = NULL);   // standard constructor

	CString getAnswer(LPCSTR strCaption);
// Dialog Data
	//{{AFX_DATA(ccDLGQuestion)
	enum { IDD = IDD_QUESTION_DIALOG };
	CString	m_answer;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(ccDLGQuestion)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(ccDLGQuestion)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// *** Attributes
private:
	CString m_caption;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CCDLGQUESTION_H__01B7E869_2506_11D4_89A6_00609708DCFE__INCLUDED_)
