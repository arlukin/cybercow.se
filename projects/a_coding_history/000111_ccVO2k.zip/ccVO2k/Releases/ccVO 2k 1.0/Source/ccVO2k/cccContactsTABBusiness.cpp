// cccContactsTABBusiness.cpp : implementation file
//

#include "stdafx.h"
#include "ccvo2k.h"

#include "cccContactsTABBusiness.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccContactsTABBusiness dialog


cccContactsTABBusiness::cccContactsTABBusiness(CWnd* pParent /*=NULL*/, cccVODB *aoDB)
	: ccdbDialog(cccContactsTABBusiness::IDD, pParent, aoDB)	
{
	//{{AFX_DATA_INIT(cccContactsTABBusiness)		
	//}}AFX_DATA_INIT
	Create(cccContactsTABBusiness::IDD, pParent);	
}


void cccContactsTABBusiness::DoDataExchange(CDataExchange* pDX)
{
	ccdbDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(cccContactsTABBusiness)
	DDX_Control(pDX, IDC_ADRESS_TAB, m_tab);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(cccContactsTABBusiness, ccdbDialog)
	//{{AFX_MSG_MAP(cccContactsTABBusiness)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cccContactsTABBusiness message handlers
BOOL cccContactsTABBusiness::OnInitDialog() 
{
	setDDServer( dd(m_ddContacts) );

	m_Company.adddbField( &dd(m_ddContacts)->m_Company  );
	m_Company.setCaptionOffset(-90);
	m_Company.SubclassDlgItem( IDC_COMPANY_NAME, this, this );

	m_JobTitle.adddbField( &dd(m_ddContacts)->m_JobTitle  );
	m_JobTitle.setCaptionOffset(-90);
	m_JobTitle.SubclassDlgItem( IDC_JOBTITLE, this, this );

	m_Department.adddbField( &dd(m_ddContacts)->m_Department  );
	m_Department.setCaptionOffset(-90);
	m_Department.SubclassDlgItem( IDC_DEPARTMENT, this, this );

	m_Office.adddbField( &dd(m_ddContacts)->m_Office  );
	m_Office.setCaptionOffset(-90);
	m_Office.SubclassDlgItem( IDC_OFFICE, this, this );

	m_ManagersName.adddbField( &dd(m_ddContacts)->m_ManagerName  );
	m_ManagersName.setCaptionOffset(-90);
	m_ManagersName.SubclassDlgItem( IDC_MANAGERS_NAME, this, this );

	m_AssistentsName.adddbField( &dd(m_ddContacts)->m_AssistensName  );
	m_AssistentsName.setCaptionOffset(-90);
	m_AssistentsName.SubclassDlgItem( IDC_ASSISTENTS_NAME, this, this );

	m_OthersName.adddbField( &dd(m_ddContacts)->m_OthersName  );
	m_OthersName.setCaptionOffset(-90);
	m_OthersName.SubclassDlgItem( IDC_OTHERS_NAME, this, this );

	m_Business_Notes.adddbField( &dd(m_ddContacts)->m_BusinessNotes  );
	m_Business_Notes.setCaptionOffset(0,-15);
	m_Business_Notes.SubclassDlgItem( IDC_BUSINESS_NOTES, this, this );

	m_Bussiness_WebPage.adddbField( &dd(m_ddContacts)->m_Business_WebPage1 );
	m_Bussiness_WebPage.adddbField( &dd(m_ddContacts)->m_Business_WebPage2 );
	m_Bussiness_WebPage.setCaptionOffset(-77);
	m_Bussiness_WebPage.SubclassDlgItem( IDC_WEBPAGE, this, this );

	m_Bussiness_FTPSite.adddbField( &dd(m_ddContacts)->m_Business_FTPSite1 );
	m_Bussiness_FTPSite.adddbField( &dd(m_ddContacts)->m_Business_FTPSite2 );
	m_Bussiness_FTPSite.setCaptionOffset(-77);
	m_Bussiness_FTPSite.SubclassDlgItem( IDC_FTPSITE, this, this );

	ccdbDialog::OnInitDialog();

	m_tab.InsertItem(0,"Mail Adress"    , new cccContactsTABBusinessMailAdress(&m_tab, getDB() ));
	m_tab.InsertItem(1,"Office Location", new cccContactsTABBusinessOfficeLocation(&m_tab, getDB()     ));	

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
