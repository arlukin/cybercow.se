// cccEmptyContainer.cpp : implementation file
//

#include "stdafx.h"
#include "ccvo2k.h"
#include "cccEmptyContainer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccEmptyContainer

IMPLEMENT_DYNCREATE(cccEmptyContainer, CView)

cccEmptyContainer::cccEmptyContainer()
{
}

cccEmptyContainer::~cccEmptyContainer()
{
}


BEGIN_MESSAGE_MAP(cccEmptyContainer, CView)
	//{{AFX_MSG_MAP(cccEmptyContainer)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cccEmptyContainer drawing

void cccEmptyContainer::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// cccEmptyContainer diagnostics

#ifdef _DEBUG
void cccEmptyContainer::AssertValid() const
{
	CView::AssertValid();
}

void cccEmptyContainer::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// cccEmptyContainer message handlers
