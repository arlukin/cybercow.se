// cccMProjectPersContainer.cpp : implementation file
//

#include "stdafx.h"
#include "ccvo2k.h"
#include "cccMProjectPersContainer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccMProjectPersContainer

IMPLEMENT_DYNCREATE(cccMProjectPersContainer, CView)

cccMProjectPersContainer::cccMProjectPersContainer()
{
}

cccMProjectPersContainer::~cccMProjectPersContainer()
{
}


BEGIN_MESSAGE_MAP(cccMProjectPersContainer, CView)
	//{{AFX_MSG_MAP(cccMProjectPersContainer)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cccMProjectPersContainer drawing

void cccMProjectPersContainer::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here

	pDC->TextOut(0,0, "Personal MasterProject Container");
}

/////////////////////////////////////////////////////////////////////////////
// cccMProjectPersContainer diagnostics

#ifdef _DEBUG
void cccMProjectPersContainer::AssertValid() const
{
	CView::AssertValid();
}

void cccMProjectPersContainer::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// cccMProjectPersContainer message handlers
