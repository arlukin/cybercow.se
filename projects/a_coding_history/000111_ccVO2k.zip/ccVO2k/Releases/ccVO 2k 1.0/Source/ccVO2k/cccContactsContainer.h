#if !defined(AFX_CCCCONTACTSCONTAINER_H__C1EBB0B6_F50D_11D3_899E_00609708DCFE__INCLUDED_)
#define AFX_CCCCONTACTSCONTAINER_H__C1EBB0B6_F50D_11D3_899E_00609708DCFE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// cccContactsContainer.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// cccContactsContainer view

class cccContactsContainer : public CView
{
// *** Construction / Destruction
protected:
	// Defalt constructor
	//
	cccContactsContainer();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(cccContactsContainer)

	// Default destructor
	//
	virtual ~cccContactsContainer();

// *** GFX Attributes
public:
	CCJFlatSplitterWnd	m_wndSplitter;

// *** Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(cccContactsContainer)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// *** Generated message map functions
protected:
	//{{AFX_MSG(cccContactsContainer)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// *** Debug members
protected:	
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CCCCONTACTSCONTAINER_H__C1EBB0B6_F50D_11D3_899E_00609708DCFE__INCLUDED_)
