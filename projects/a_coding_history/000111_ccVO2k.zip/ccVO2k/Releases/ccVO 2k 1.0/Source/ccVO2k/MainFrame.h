// MainFrame.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRAME_H__B5AA1D7E_F4FE_11D3_899E_00609708DCFE__INCLUDED_)
#define AFX_MAINFRAME_H__B5AA1D7E_F4FE_11D3_899E_00609708DCFE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CContainerView;

class CMainFrame : public CCJFrameWnd
{
// *** Construction / Destruction	
public:
	// Default constructor
	//
	CMainFrame();

	// Default destructor.
	//
	virtual ~CMainFrame();

protected:
	DECLARE_DYNAMIC(CMainFrame)

// *** GFX Attributes
public:	
	ccGFXSplitterWnd	m_wndSplitter;		// Should maybe use cccGFXSplitterWnd	
		CContainerView* m_vwContainer;

	CCJStatusBar		m_wndStatusBar;	

	CCJWindowPlacement	m_state;		

// *** Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo);
	protected:
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);
	//}}AFX_VIRTUAL

// *** Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSetFocus(CWnd *pOldWnd);
	afx_msg void OnClose();
	afx_msg void OnFileNewContact();
	afx_msg void OnFileHtmlprint();
	afx_msg void OnFileNewFavorite();
	afx_msg void OnFileNewFtp();
	afx_msg void OnFileOptions();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// *** Debug Members
public:	
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRAME_H__B5AA1D7E_F4FE_11D3_899E_00609708DCFE__INCLUDED_)
