#if !defined(AFX_CCCEMPTYCONTAINER_H__8B18BAE5_0098_11D4_89A2_00609708DCFE__INCLUDED_)
#define AFX_CCCEMPTYCONTAINER_H__8B18BAE5_0098_11D4_89A2_00609708DCFE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// cccEmptyContainer.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// cccEmptyContainer view

class cccEmptyContainer : public CView
{
protected:
	cccEmptyContainer();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(cccEmptyContainer)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(cccEmptyContainer)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~cccEmptyContainer();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(cccEmptyContainer)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CCCEMPTYCONTAINER_H__8B18BAE5_0098_11D4_89A2_00609708DCFE__INCLUDED_)
