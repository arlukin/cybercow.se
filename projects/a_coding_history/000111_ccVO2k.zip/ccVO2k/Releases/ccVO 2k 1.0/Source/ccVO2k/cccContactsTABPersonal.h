#if !defined(AFX_CCCCONTACTSTABPERSONAL_H__B6B88D67_0AFE_11D4_89A5_00609708DCFE__INCLUDED_)
#define AFX_CCCCONTACTSTABPERSONAL_H__B6B88D67_0AFE_11D4_89A5_00609708DCFE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// cccContactsTABPersonal.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// cccContactsTABPersonal dialog
#include "cccContactsTABPersonalEmail.h"
#include "cccContactsTABPersonalPhone.h"

class cccContactsTABPersonal : public ccdbDialog
{
// *** Construction
public:
	// standard constructor
	//
	cccContactsTABPersonal(CWnd *pParent, cccVODB *aoDB);

// *** Dialog Data
	//{{AFX_DATA(cccContactsTABPersonal)
	enum { IDD = IDD_CONTACTS_TAB_PERSONAL };
	//}}AFX_DATA
	ccdbSuperCtrl m_Display;	
	ccdbSuperCtrl m_Title;
	ccdbSuperCtrl m_FirstName;
	ccdbSuperCtrl m_MiddleName;
	ccdbSuperCtrl m_LastName;
	
	ccdbSuperCtrl m_NickName;	

	cccContactsTABPersonalEmail m_Email;

	ccdbSuperCtrl	m_Chat1;
	ccdbSuperCtrl	m_Chat2;

	ccdbSuperCtrl m_Company;
	ccdbSuperCtrl m_BirthDate;

	cccContactsTABPersonalPhone m_Phone1;
	cccContactsTABPersonalPhone m_Phone2;
	cccContactsTABPersonalPhone m_Phone3;

// *** Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(cccContactsTABPersonal)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(cccContactsTABPersonal)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CCCCONTACTSTABPERSONAL_H__B6B88D67_0AFE_11D4_89A5_00609708DCFE__INCLUDED_)


	
