// ccVOClient.h: interface for the ccVOClient class.
//
// Stuff in this class is here and not in cccVO2kAPP becuase
// the class may be used in other smaler ccVO2k programs,
// like the trayIcon program..
//
//////////////////////////////////////////////////////////////////////

#if !defined(__CCVOCLIENT_H__)
#define __CCVOCLIENT_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

struct sRegUsr;
struct sNewUser;

class cccVO2kApp;
class cccVODB;
//#include "cccVODB.h"

struct sFLVTreeOrderSubItems;

// Contacts Phone optimzing struct
struct sContactsPhoneOptimizer
{	
	long	nItemID;
	CString strPhoneName;
	CString strNumber;
} ;

#define theCCVOClient (((cccVO2kApp*)AfxGetApp())->m_theCCVOClient)
#define dPROGRAM_REG_PATH "Software\\CyberCow\\ccVO2k\\Settings"

class ccVOClient  
{
public:	
// *** Construction / Destruction
public:
	// Default Constructor
	//	
	ccVOClient();

	// Default Destructor
	//
	virtual ~ccVOClient();


// *** Login/Logout functions
public:
	// Login the user with Autologin (Registry options) or Show the Login dialog 
	//
	bool login();

protected:
	// Check userName and Psw in the dtUser table
	// if existing return true, meaning evertying okej.
	//
	bool loginUser(LPCSTR sUserName, LPCSTR sPassword);

// *** Attributes
public:
	// True when the program has started, a.k.a. all folders
	// , outlook bars etc has been filled.
	//
	void setStarted()			{ m_started = true;							};
	bool isStarted()			{ return m_started;							};

private:
	bool m_started;		

// *** FolderListView Help Functions
public:
	// Get all Projects associated to this user from
	// dtUserActiveMProjects
	// Will fill a "sFLVTreeOrderSubItems" struct
	//
	bool getActiveMProjects( CPtrList &activeMProjects );

	// Get all items in item "nItemId" from dtTreeOrder and dtItem
	// Will fill a "sFLVTreeOrderSubItems" struct
	//
	bool getTreeOrderSubItems( int MProjectID, int nItemID, CPtrList &subItems );

	// Set the selected treeLeaf.. Will always be set when a tree leaf is changed 
	// in class FolderListView.
	//
	void setSelectedTreeLeaf( int nMProjectID, int nParentID, int nItemID, int nFunctionType );

	// Save PrimKey of the selected treeLeaf/folder in the FolderListView
	// So we can restore the selection to this treeLeaf/folder
	// next time we start the program.
	//
	void saveSelectedTreeLeaf();

	// Get the selected leaf item.
	//
	int getSelLeafMProjectID()			{ return m_nSelLeafMProject;				};
	int getSelLeafParentID  ()			{ return m_nSelLeafItemID;					};
	int getSelLeafItemID    ()			{ return m_nSelLeafChildID;					};
	int getFunctionType     ()			{ return m_nFunctionType;					};

	// Get the selected grid item.
	//
	void setSelGridItemID(int nItemID)	{ m_nSelGridItemID = nItemID;				};
	int  getSelGridItemID()				{ return m_nSelGridItemID;					};

	// Check if the SubItem is the last selected tree leaf.
	//
	bool isLastSelectedTreeLeaf( sFLVTreeOrderSubItems * SubItem );

	// If an Folder is expanded or colapsed (CFolderListView.OnItemExpand) this
	// function will save the state to the dtTreeOrder so it will have the same
	// state next time program is executed.
	//
	void saveTreeLeafExpandState( int nMProjectID, int nParentID, int nItemID, bool bExpanded );

// *** Email functions
	//
	//
	bool emailUserInfo( sNewUser &aNewUser );
// *** "Create" functions updateing more then one table
public:
	// Creates a new user account, Personal Project
	// Tree/Folder items etc. 	
	//	
	bool createUser( sRegUsr &aRegUser );

	// Create a new item in dtItems and dtTreeOrder
	//
	bool createNewItem( sFLVTreeOrderSubItems * newItem );

// *** "Delete" functions, deleting from more then one table
public:
	// Delete a folder from the FolderView.
	// Both item and treeOrder
	//
	bool delete_dtItem_And_dtTreeOrder( int nMProjectID, int nParentID, int nItemID);

// *** Helper functions

	// A pointer to The grid ctrl view in the Contacts, Favorites and FTP (maye more functions)
	// mode. A fillGrid message will be sent to this when a record will be created, updated or deleted
	// in the cccVOEditor.
	//
	void setCurrentGridCtrl(ccNonDBCtrl* ctrl)	{ m_currentGridCtrl = ctrl;					};
	ccNonDBCtrl* getCurrentGridCtrl()			{ return m_currentGridCtrl;					};

// *** Attributes
public:
	cccVODB* m_dataBase;		// Connecton to access database
private:	
	CString m_userName;
	int		m_nUserID;	

	// See saveSelectedTreeLeaf and isLastSelectedTreeLeaf
	int m_nSelLeafMProject;
	int m_nSelLeafItemID;  
	int m_nSelLeafChildID; 	
	int m_nFunctionType;

	// see getSelGridItemID
	int m_nSelGridItemID;

	ccNonDBCtrl* m_currentGridCtrl;	// See getCurrentGridCtrl	
};


#endif // __CCVOCLIENT_H__
