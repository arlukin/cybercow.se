#if !defined(__CCCDREGUSR2GENERAL_H__)
#define __CCCDREGUSR2GENERAL_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// cccdRegUsr2General.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// cccdRegUsr2General dialog
#include "resource.h"

struct sRegUsr;
class cccdRegUsr2General : public CPropertyPage
{
	DECLARE_DYNCREATE(cccdRegUsr2General)

// Construction
public:
	BOOL validateAndSave();
	cccdRegUsr2General();
	~cccdRegUsr2General();

	void setRegUsr( sRegUsr *aoRegUsr )				{ m_regUsr = aoRegUsr;	}

// Dialog Data
	//{{AFX_DATA(cccdRegUsr2General)
	enum { IDD = IDD_REG_USR_2_GENERAL };
	CString	m_userName;
	CString	m_password;
	CString	m_confirmPassword;
	CString	m_company;
	CString	m_fullName;
	CString	m_address;
	CString	m_zipCode;
	CString	m_phone;
	CString	m_fax;
	CString	m_country;
	CString	m_city;
	CString	m_email;
	//}}AFX_DATA

// *** Attributes
private:
	sRegUsr * m_regUsr;			// This struct will contain input and output data from/to the ctrls.

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(cccdRegUsr2General)
	public:
	virtual LRESULT OnWizardNext();
	virtual BOOL OnSetActive();
	virtual LRESULT OnWizardBack();
	virtual BOOL OnWizardFinish();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(cccdRegUsr2General)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // __CCCDREGUSR2GENERAL_H__
