// MainFrame.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "ccVO2k.h"

#include "MainFrame.h"
#include "ContainerView.h"
#include "cccFakeOutlook.h"
#include "cccVOEditor.h"

#include "ccDLGOptions.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// *** Construction / Destruction	
/////////////////////////////////////////////////////////////////////////////
CMainFrame::CMainFrame()
{
}

//

CMainFrame::~CMainFrame()
{
}

//

IMPLEMENT_DYNAMIC(CMainFrame, CCJFrameWnd)

/////////////////////////////////////////////////////////////////////////////
// *** Overrides
/////////////////////////////////////////////////////////////////////////////

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CCJFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(0);
	return TRUE;
}

//

BOOL CMainFrame::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo)
{
	// let the view have first crack at the command
//	if (m_wndView.OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
//		return TRUE;

	// otherwise, do default handling
	return CCJFrameWnd::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

//

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext) 
{
	// Create the splitter window with two columns
	if (!m_wndSplitter.CreateStatic(this, 1, 2))
	{
		TRACE0("Failed to create splitter window\n");
		return FALSE;
	}
	
	// "Flexible pane": The second pane may present its own
	// splitter windows.
	if (!m_wndSplitter.CreateView(0, 0, RUNTIME_CLASS(cccFakeOutlook),
		CSize(0, 0), pContext))
	{
		TRACE0("Failed to create CContainerView\n"); 
		return FALSE;
	}

	if (!m_wndSplitter.CreateView(0, 1, RUNTIME_CLASS(CContainerView),
		CSize(0, 0), pContext))
	{
		TRACE0("Failed to create CContainerView\n"); 
		return FALSE;
	}
	m_vwContainer = DYNAMIC_DOWNCAST(CContainerView, m_wndSplitter.GetPane(0,1));
	ASSERT_KINDOF(CContainerView, m_vwContainer);	

	// Standard sizing for splitter
	CRect r;
	GetClientRect(&r);
	int w1 = r.Width()/7;
	int w2 = r.Width()/1;
	m_wndSplitter.SetColumnInfo( 0, w1, 0 );
	m_wndSplitter.SetColumnInfo( 1, w2, 0 );
	m_wndSplitter.RecalcLayout();
	m_wndSplitter.HideColumn(0);

	return CCJFrameWnd::OnCreateClient(lpcs, pContext);
}


/////////////////////////////////////////////////////////////////////////////
// *** Generated message map functions
/////////////////////////////////////////////////////////////////////////////

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CCJFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	// Create Docking Menu
	if (!m_wndMenuBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_ALIGN_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC, CRect(0,0,0,0), ID_MENUBAR) ||
		!m_wndMenuBar.LoadMenu(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	// Create statusbar.
	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// Dock toolbars.
	m_wndMenuBar.EnableDocking(CBRS_ALIGN_ANY);	
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndMenuBar);	

	// Restore the previous bar and window states.
	LoadBarState(_T("Bar State"));
	m_state.LoadWindowPos(this);

	return 0;
}

//

void CMainFrame::OnSetFocus(CWnd* pOldWnd)
{
	// forward focus to the view window
	// TODO Set to the treeCtrl
//	m_wndView.SetFocus();
}

//

void CMainFrame::OnClose() 
{
	// TODO Save this to a table in the database.
	m_state.SaveWindowPos(this);
	SaveBarState(_T("Bar State"));
	
	CCJFrameWnd::OnClose();
}

//

BEGIN_MESSAGE_MAP(CMainFrame, CCJFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_SETFOCUS()
	ON_WM_CLOSE()
	ON_COMMAND(ID_FILE_NEW_CONTACT, OnFileNewContact)
	ON_COMMAND(ID_FILE_HTMLPRINT, OnFileHtmlprint)
	ON_COMMAND(ID_FILE_NEW_FAVORITE, OnFileNewFavorite)
	ON_COMMAND(ID_FILE_NEW_FTP, OnFileNewFtp)
	ON_COMMAND(ID_FILE_OPTIONS, OnFileOptions)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// *** Debug Members
/////////////////////////////////////////////////////////////////////////////

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CCJFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CCJFrameWnd::Dump(dc);
}

#endif //_DEBUG

void CMainFrame::OnFileNewContact() 
{
	cccVOEditor* pFrame = new cccVOEditor(CCVO_CONTACTS_MODE, this);		
}

//

void CMainFrame::OnFileNewFavorite() 
{
	cccVOEditor* pFrame = new cccVOEditor(CCVO_FAVORITES_MODE, this);			
}

//

void CMainFrame::OnFileNewFtp() 
{
	cccVOEditor* pFrame = new cccVOEditor(CCVO_FTP_MODE, this);			
}

//

void CMainFrame::OnFileHtmlprint() 
{
	ccErr("Doesn't support printing in this version.", "","",MB_OK);	
}

//

void CMainFrame::OnFileOptions() 
{
	CWinApp* pApp = AfxGetApp();
	ccDLGOptions oOptions;					

	oOptions.m_autoLogin = pApp->GetProfileInt("Settings", "AutoLogin", 0);

	if ( oOptions.DoModal() == IDOK)
	{
		pApp->WriteProfileInt("Settings", "AutoLogin", oOptions.m_autoLogin);
	}
}


