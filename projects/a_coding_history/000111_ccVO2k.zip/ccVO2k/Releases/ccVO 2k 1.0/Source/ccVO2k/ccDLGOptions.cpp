// ccDLGOptions.cpp : implementation file
//

#include "stdafx.h"
#include "ccvo2k.h"
#include "ccDLGOptions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// ccDLGOptions dialog


ccDLGOptions::ccDLGOptions(CWnd* pParent /*=NULL*/)
	: CDialog(ccDLGOptions::IDD, pParent)
{
	//{{AFX_DATA_INIT(ccDLGOptions)
	m_autoLogin = FALSE;
	//}}AFX_DATA_INIT
}


void ccDLGOptions::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(ccDLGOptions)
	DDX_Check(pDX, IDC_AUTOLOGIN, m_autoLogin);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(ccDLGOptions, CDialog)
	//{{AFX_MSG_MAP(ccDLGOptions)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// ccDLGOptions message handlers
