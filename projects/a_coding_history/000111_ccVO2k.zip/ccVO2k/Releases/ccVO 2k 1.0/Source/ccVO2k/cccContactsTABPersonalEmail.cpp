// cccContactsTABPersonalEmail.cpp : implementation file
//

#include "stdafx.h"
#include "ccvo2k.h"
#include "cccContactsTABPersonalEmail.h"
#include "resource.h"
#include "ccDLGQuestion.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccContactsTABPersonalEmail dialog


cccContactsTABPersonalEmail::cccContactsTABPersonalEmail(CWnd* pParent /*=NULL*/)
	: ccllGroup(cccContactsTABPersonalEmail::IDD, pParent)
{
	//{{AFX_DATA_INIT(cccContactsTABPersonalEmail)
	m_comment = _T("");
	m_emailAdress = _T("");
	m_plainText = FALSE;
	//}}AFX_DATA_INIT	
}

//

cccContactsTABPersonalEmail::~cccContactsTABPersonalEmail()
{
	// Not needed to removeAttachedCtrl the datadictionary
	// will be deleted anyway by the parentClass.
	// and if removeing here, program crach...
	//dd(m_ddContacts)->m_PrimEMail.removeAttachedCtrl(this);
}

//

void cccContactsTABPersonalEmail::DoDataExchange(CDataExchange* pDX)
{
	ccllGroup::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(cccContactsTABPersonalEmail)
	DDX_Control(pDX, IDC_EMAIL_SENDUSINGPLAINTEXT, m_plainTextCtrl);
	DDX_Control(pDX, IDC_MAIL_ANIM, m_mailAnim);
	DDX_Text(pDX, IDC_EMAIL_COMMENT, m_comment);
	DDV_MaxChars(pDX, m_comment, 50);
	DDX_Text(pDX, IDC_EMAIL_ADRESS, m_emailAdress);
	DDV_MaxChars(pDX, m_emailAdress, 50);
	DDX_Check(pDX, IDC_EMAIL_SENDUSINGPLAINTEXT, m_plainText);
	//}}AFX_DATA_MAP
}

//

void cccContactsTABPersonalEmail::OnBuildMenu(ccMenuButton *menuButton)
{	
	POSITION pos;
   	int nIndex = 0;

	for( pos = dd(m_ddContacts)->m_contactsEmailSL.GetHeadPosition(); pos != NULL; )
	{
		sContactsEmail * contactsEmail = ((sContactsEmail*)dd(m_ddContacts)->m_contactsEmailSL.GetNext( pos ));
		if (!contactsEmail->bDeletedRecord)
			menuButton->addMenuItem( contactsEmail->strComment, nIndex);

		nIndex++;
	}
}

//

void cccContactsTABPersonalEmail::OnNewItem()
{
	CString strCaption;strCaption.LoadString( IDS_NAME_OF_THE_NEW_EMAIL_ADRESS);
	ccDLGQuestion question( this );
	
	CString strComment = question.getAnswer(strCaption);

	if ( strComment != "-1")
	{		
		// Create the new record
		sContactsEmail * ptrContactsEmail = new sContactsEmail;

		ptrContactsEmail->strComment	  = strComment;
		ptrContactsEmail->bNew			  = true;
		ptrContactsEmail->bCantDelete	  = false;
		ptrContactsEmail->bDeletedRecord  = false;
		ptrContactsEmail->bChanged		  = false;
		dd(m_ddContacts)->m_contactsEmailSL.AddTail( ptrContactsEmail );

		// Select the new record;
		POSITION pos;

		if( ( pos = dd(m_ddContacts)->m_contactsEmailSL.GetTailPosition() ) != NULL )
		{
			sContactsEmail * contactsEmail = (sContactsEmail*)dd(m_ddContacts)->m_contactsEmailSL.GetAt( pos ) ;
			m_comment = contactsEmail->strComment;
			m_emailAdress = contactsEmail->strEmailAdress;
			m_plainText = contactsEmail->bPlainText;
			UpdateData(false);
			dd(m_ddContacts)->setModified(true);

			// Get the last menuitem index
			int nIndex = 0;
			for( pos = dd(m_ddContacts)->m_contactsEmailSL.GetHeadPosition(); pos != NULL; )
			{
				sContactsEmail * contactsEmail = ((sContactsEmail*)dd(m_ddContacts)->m_contactsEmailSL.GetNext( pos ));
				if (!contactsEmail->bDeletedRecord)
				{
					m_nSelectedItem = nIndex;	
				}
				nIndex++;
			}			
		}    
	}
}

//

void cccContactsTABPersonalEmail::OnDeleteItem()
{
	POSITION pos;

	if( ( pos = dd(m_ddContacts)->m_contactsEmailSL.FindIndex( m_nSelectedItem )) != NULL )
	{
		sContactsEmail * contactsEmail = (sContactsEmail*)dd(m_ddContacts)->m_contactsEmailSL.GetAt( pos ) ;
	
		if (contactsEmail)
		{			
			if (contactsEmail->bCantDelete)			
				ccErrEM(IDS_CANT_DELETE_THIS_EMAIL_ADRESS, NULL, NULL, MB_OK);
			else
			{
				contactsEmail->bDeletedRecord = true;

				// Get the first menu item.
				int nIndex = 0;
				for( pos = dd(m_ddContacts)->m_contactsEmailSL.GetHeadPosition(); pos != NULL; )
				{
					sContactsEmail * contactsEmail = ((sContactsEmail*)dd(m_ddContacts)->m_contactsEmailSL.GetNext( pos ));
					if (!contactsEmail->bDeletedRecord)
					{
						m_nSelectedItem = nIndex;
						break;
					}
					nIndex++;
				}			
				OnChangedItem(false);
				dd(m_ddContacts)->setModified(true);
			}
		}
	}
}

//

void cccContactsTABPersonalEmail::OnChangedItem(bool bSave ) 
{
	POSITION pos;

	if( ( pos = dd(m_ddContacts)->m_contactsEmailSL.FindIndex( m_nSelectedItem )) != NULL )
	{
		sContactsEmail * contactsEmail = (sContactsEmail*)dd(m_ddContacts)->m_contactsEmailSL.GetAt( pos ) ;
	
		if (contactsEmail)
		{
			if (bSave)
			{
				UpdateData(true);
				contactsEmail->strComment     = m_comment ;
				contactsEmail->strEmailAdress = m_emailAdress;
				contactsEmail->bPlainText     = m_plainText ? 1:0 ;
				contactsEmail->bChanged       = true;
			}
			else
			{
				m_comment = contactsEmail->strComment;
				m_emailAdress = contactsEmail->strEmailAdress;				
				m_plainText = contactsEmail->bPlainText;				
				UpdateData(false);
			}
		}
	}
}

//

void cccContactsTABPersonalEmail::displayFirstRecInList()
{
	// Display the first record in the LinkedList on the screen.
	POSITION pos;

	m_comment = "";
	m_emailAdress = "";
	m_plainText = 0;

	m_nSelectedItem = -1;
	int nIndex = 0;
	for( pos = dd(m_ddContacts)->m_contactsEmailSL.GetHeadPosition(); pos != NULL; )
	{
		sContactsEmail * contactsEmail = ((sContactsEmail*)dd(m_ddContacts)->m_contactsEmailSL.GetNext( pos ));		

		if (contactsEmail)
		{
			if (contactsEmail->strEmailAdress == dd(m_ddContacts)->m_PrimEMail)
			{
				m_nSelectedItem = nIndex;
				m_comment = contactsEmail->strComment;
				m_emailAdress = contactsEmail->strEmailAdress;				
				m_plainText = contactsEmail->bPlainText;					
				break;
			}
		}		
		nIndex++;
	}	
	
	UpdateData(false);
}

//

BEGIN_MESSAGE_MAP(cccContactsTABPersonalEmail, ccllGroup)
	//{{AFX_MSG_MAP(cccContactsTABPersonalEmail)
	ON_EN_CHANGE(IDC_EMAIL_ADRESS, OnChangeEmailAdress)
	ON_EN_CHANGE(IDC_EMAIL_COMMENT, OnChangeEmailComment)
	ON_BN_CLICKED(IDC_EMAIL_SENDUSINGPLAINTEXT, OnEmailSendusingplaintext)
	ON_BN_CLICKED(IDC_PRIMEMAIL_BTN, OnPrimemailBtn)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cccContactsTABPersonalEmail message handlers

BOOL cccContactsTABPersonalEmail::OnInitDialog() 
{
	ccllGroup::OnInitDialog();
	
	setDDServer( dd(m_ddContacts) );

	
	m_PrimEMail.adddbField( &dd(m_ddContacts)->m_PrimEMail  );
	m_PrimEMail.setCaptionOffset(-98);
	m_PrimEMail.SubclassDlgItem( IDC_PRIMEMAIL, this, this );	

	dd(m_ddContacts)->m_PrimEMail.addAttachedCtrl( this );
	displayFirstRecInList();
	
	m_mailAnim.Open( IDR_MAIL );	

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void cccContactsTABPersonalEmail::OnChangeEmailAdress() 
{
	OnChangedItem( true );
	dd(m_ddContacts)->setModified(true);
}

void cccContactsTABPersonalEmail::OnChangeEmailComment() 
{
	OnChangedItem( true );	
	dd(m_ddContacts)->setModified(true);
}

void cccContactsTABPersonalEmail::OnEmailSendusingplaintext() 
{
	OnChangedItem( true );	
	dd(m_ddContacts)->setModified(true);
}

void cccContactsTABPersonalEmail::OnPrimemailBtn() 
{
	UpdateData(true);
	dd(m_ddContacts)->m_PrimEMail.setValue( m_emailAdress );	
}
