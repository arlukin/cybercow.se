// FolderListView.cpp : implementation file
//

#include "stdafx.h"
#include "ccVO2K.h"
#include "FolderListView.h"
#include "FolderTreeCtrl.h"
#include "ContainerView.h"
#include "ccTreeCtrl.h"
#include "resource.h"
#include "mainframe.h"

#include "cccEmptyContainer.h"
#include "cccMProjectPersonalContainer.h"
#include "cccContactsContainer.h"
#include "cccFavoritesContainer.h"
#include "cccFTPContainer.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// *** Construction / Destruction
/////////////////////////////////////////////////////////////////////////////

IMPLEMENT_DYNCREATE(CFolderListView, CView)

CFolderListView::CFolderListView()
{
	// Create the image list used by frame buttons.
	m_ImageList.Create( IDB_PUSHPIN, 16, 1, RGB( 255, 0, 255 ));

	m_ImageSmall.Create (16, 16, ILC_COLOR32  , 2, 1);

	for( int nIcon = IDB_PERSONAL_PROJECT; nIcon <= IDB_FTP_SEL; ++nIcon ) 
	{
		CBitmap bm;
		bm.LoadBitmap(nIcon);
		
		m_ImageSmall.Add(&bm, RGB(0, 0, 0));
	}

	m_bOnDestroyHasBeenExecuted = false;
	m_lastSelectedTreeLeaf = NULL;
}

CFolderListView::~CFolderListView()
{
	m_ImageList.DeleteImageList();
	m_ImageSmall.DeleteImageList();
}

/////////////////////////////////////////////////////////////////////////////
// *** GFX Attribute
/////////////////////////////////////////////////////////////////////////////
CFolderTreeCtrl 	CFolderListView::m_TreeCtrl;

/////////////////////////////////////////////////////////////////////////////
// *** TreeCtrl functions
/////////////////////////////////////////////////////////////////////////////
void CFolderListView::fillTreeCtrl()
{
	try
	{
		// Get all existing Active MProjects
		CPtrList activeMProjects;	
		if ( !theCCVOClient->getActiveMProjects( activeMProjects ) )
		{		
			ccErrEM( IDS_COULDNT_RETRIVE_ACTIVEMPROJECTS, NULL, NULL, MB_OK );
			return;
		}
		
		// Fill the treeCtrl with all folders..
		HTREEITEM hti;
		while ( !activeMProjects.IsEmpty() )
		{
			sFLVTreeOrderSubItems * MProj = (sFLVTreeOrderSubItems*) activeMProjects.RemoveHead();
			
			hti = m_TreeCtrl.InsertItem( MProj->strName, IS_PERSONAL, IS_PERSONAL_SEL);	// todo other icon for Shareable project.

			if ( !m_TreeCtrl.SetItemData( hti, (unsigned long)MProj ) )
				ccThrowccException( IDS_COULDNT_SET_LEAF_DATA );

			if ( theCCVOClient->isLastSelectedTreeLeaf( MProj ))
				m_lastSelectedTreeLeaf = hti;
						
			// Insert all subfolders.
			insertSubItem(MProj->nMProjectID, 0, hti );		

			if ( MProj->bExpanded)
				m_TreeCtrl.Expand( hti, TVE_EXPAND );
		}

		if (m_lastSelectedTreeLeaf)
			m_TreeCtrl.Select( m_lastSelectedTreeLeaf, TVGN_CARET   );

	}
	catch( ccException * e)
	{
		ccErr( *e, "", "", MB_OK );			
	}
	catch(...)
	{
		ccErrEM( IDS_GENERAL_CCVOVCLIENT_ERROR );		
		return;
	}
}

//

HTREEITEM CFolderListView::insertItem(sFLVTreeOrderSubItems * newItem, HTREEITEM hParentTreeLeaf)
{
	HTREEITEM hti ;
	switch (newItem->nFunctionType)
	{
	case cIXCONTACTS: // Contacts
		hti = m_TreeCtrl.InsertItem( newItem->strName, IS_CONTACTS, IS_CONTACTS_SEL, hParentTreeLeaf);
		break;
	case cIXFAVORITES: // Favorites
		hti = m_TreeCtrl.InsertItem( newItem->strName, IS_FAVORITE, IS_FAVORITE_SEL, hParentTreeLeaf);
		break;		

	case cIXFTP: // FTP
		hti = m_TreeCtrl.InsertItem( newItem->strName, IS_FTP, IS_FTP_SEL, hParentTreeLeaf);
		break;		

	default:
		ccThrowccException( IDS_UNSUPORTED_FUNCTION_BUG );
	}

	if ( !m_TreeCtrl.SetItemData( hti, (unsigned long)newItem ) )
		ccThrowccException( IDS_COULDNT_SET_LEAF_DATA );
	
	return hti;
}

//

bool CFolderListView::insertSubItem( int MProjectID, int nItemID, HTREEITEM hParentTreeLeaf )
{
	CPtrList subItems;
	if ( ! theCCVOClient->getTreeOrderSubItems( MProjectID, nItemID, subItems ) )
		ccThrowccException( IDS_COULDNT_RETRIVE_SUB_FOLDERS );
	
	HTREEITEM hti ;
	while ( !subItems.IsEmpty() )
	{
		sFLVTreeOrderSubItems * SubItem = (sFLVTreeOrderSubItems*) subItems.RemoveHead();

		hti = insertItem(SubItem, hParentTreeLeaf);		
				
		if ( theCCVOClient->isLastSelectedTreeLeaf( SubItem ))
			m_lastSelectedTreeLeaf = hti;


		insertSubItem( MProjectID, SubItem->nItemID, hti );		

		if ( SubItem->bExpanded)
			m_TreeCtrl.Expand( hti, TVE_EXPAND );
	}
	return true;
}

/////////////////////////////////////////////////////////////////////////////
// *** Overrides
/////////////////////////////////////////////////////////////////////////////
void CFolderListView::OnDraw(CDC* pDC) 
{
	// Must be here due to IMPLEMENT_DYNCREATE(CFolderListView, CView)		
}

/////////////////////////////////////////////////////////////////////////////
// *** Generated message map functions
/////////////////////////////////////////////////////////////////////////////

int CFolderListView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// Create the caption.
	if (!m_Caption.Create(this, _T("Folder List")))
	{
		ccErr( "Unable to create caption.\n" );
		return -1;
	}

	// Create the caption button.
	if (!m_CaptionButton.Create(NULL, WS_VISIBLE|BS_ICON|BS_OWNERDRAW|BS_CENTER|BS_VCENTER,
		CRect(0,0,0,0), this, IDC_CAPT_BUTTON))
	{
		ccErr( "Unable to create caption button.\n" );
		return -1;
	}
	
	// set the caption buttons icon.
	m_CaptionButton.SetIcon( m_ImageList.ExtractIcon(2), CSize( 16, 15 ));
	
	// create the tree control.
	if (!m_TreeCtrl.Create(WS_VISIBLE|TVS_EDITLABELS, CRect(0,0,0,0), this, IDC_TREE_VIEW))
	{
		ccErr( "Unable to create tree control.\n" );
		return -1;
	}

	// set the tree controls image list.
	m_TreeCtrl.SetImageList( &m_ImageSmall, TVSIL_NORMAL );

	//fillTreeCtrl();

	return 0;
}

//

void CFolderListView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	if( m_Caption.GetSafeHwnd()) 
	{
		m_Caption.MoveWindow( 0, 0, cx, 19 );
	}

	if( m_CaptionButton.GetSafeHwnd()) 
	{
		m_CaptionButton.MoveWindow( cx-18, 2, 16, 15 );
	}

	if( m_TreeCtrl.GetSafeHwnd()) 
	{
		m_TreeCtrl.MoveWindow( 0, 19, cx, cy-19 );
	}
}

//

void CFolderListView::OnCaptButton()
{
	GetParent()->GetParent()->SendMessage( FM_CLOSEFOLDERLISTVIEW, 0, 0 );
}

//

void CFolderListView::OnSelchanged(NMHDR* pNMHDR, LRESULT* pResult) 
{
//	if (theCCVOClient->isStarted() )
	{
		NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
		*pResult = 0;
		
		HTREEITEM hItem = m_TreeCtrl.GetSelectedItem();

		// ** Get the container view.			
		
		CMainFrame* wndMain = DYNAMIC_DOWNCAST(CMainFrame, AfxGetMainWnd() );

		CContainerView* pView = DYNAMIC_DOWNCAST(CContainerView, wndMain->m_vwContainer);
		ASSERT_KINDOF(CContainerView, pView);

		// *** Update the icon and text in the Caption bar.
		int nImage;	
		m_TreeCtrl.GetItemImage( hItem, nImage, nImage );

		pView->m_Caption.UpdateCaption(m_TreeCtrl.GetItemText( hItem ),
			m_ImageSmall.ExtractIcon(nImage));

		// *** Change Container view
		CRuntimeClass * pNewView;
		sFLVTreeOrderSubItems * MProj = (sFLVTreeOrderSubItems*)m_TreeCtrl.GetItemData( hItem );				
		
		theCCVOClient->setSelectedTreeLeaf( MProj->nMProjectID, MProj->nParentID, MProj->nItemID, MProj->nFunctionType );		

		switch ( MProj->nFunctionType )
		{
		case cIXPROJECT:
			pNewView = RUNTIME_CLASS( cccMProjectPersonalContainer );
			break;

		case cIXCONTACTS:		
			pNewView = RUNTIME_CLASS( cccContactsContainer );		
			break;

		case cIXFAVORITES:
			pNewView = RUNTIME_CLASS( cccFavoritesContainer );
			break;

		case cIXFTP:		
		default:		
			pNewView = RUNTIME_CLASS( cccFTPContainer );
			break;			
		}

		// todo maybe some error detection here, but ReplaceView returns 
		// true also when changing to the same view as was before. You know 
		// what I mean.		
		pView->m_wndSplitter.ReplaceView(0, pView->m_wndSplitter.GetColumnCount()-1, pNewView);

		// Send WM_INITIALUPDATE to the newly created window
		CView *pChangedView = DYNAMIC_DOWNCAST( CView, pView->m_wndSplitter.GetPane( 0, pView->m_wndSplitter.GetColumnCount()-1));
		ASSERT_KINDOF( CView, pChangedView );
		pChangedView->SendMessage(WM_INITIALUPDATE, 0,0);
		pChangedView->SendMessageToDescendants(WM_INITIALUPDATE, 0, 0, TRUE, TRUE);				
	}
}

//

void CFolderListView::OnItemexpanded(NMHDR* pNMHDR, LRESULT* pResult) 
{	
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;

	if (theCCVOClient->isStarted() )
	{
		bool bExpand;
		if ( pNMTreeView->action == TVE_COLLAPSE)
			bExpand = false;

		if ( pNMTreeView->action == TVE_EXPAND)
			bExpand = true;

		if ( ( pNMTreeView->action == TVE_COLLAPSE) || (pNMTreeView->action == TVE_EXPAND) )
		{			
			HTREEITEM hti = pNMTreeView->itemNew.hItem;			
			ASSERT(hti != NULL);
			sFLVTreeOrderSubItems * MProj = (sFLVTreeOrderSubItems*)m_TreeCtrl.GetItemData( hti );
			theCCVOClient->saveTreeLeafExpandState( MProj->nMProjectID, MProj->nParentID, MProj->nItemID, bExpand );		
		}	
	}
	*pResult = 0;
}

//

void CFolderListView::OnBeginlabeledit(NMHDR* pNMHDR, LRESULT* pResult) 
{
	TV_DISPINFO* pTVDispInfo = (TV_DISPINFO*)pNMHDR;

	// Only rename folders of type cITFOLDER, NOT functions or projects.
	sFLVTreeOrderSubItems * MProj = (sFLVTreeOrderSubItems*)m_TreeCtrl.GetItemData( pTVDispInfo->item.hItem );				
	if (MProj->nItemType == cITFOLDER)	
	{		
		cflvNewFolder newFolder;
		newFolder.m_text = pTVDispInfo->item.pszText;
		if (newFolder.DoModal() == IDOK)
		{								
			if ( theCCVOClient->m_dataBase->update_dtItems( MProj->nMProjectID, MProj->nItemID, newFolder.m_text) )
				m_TreeCtrl.SetItemText( pTVDispInfo->item.hItem, newFolder.m_text );
			else
			{
				ccErrEM(IDS_COULDNT_CHANGE_LABEL_NAME);
			}
		}
	}
	else	
		ccErrEM( IDS_CANTRENAME_THIS_FOLDER, 0, 0, MB_OK );	

	// Set the focus to the TreeCtrl.. Back from newFolder Dialog.
	SetFocus();
	m_TreeCtrl.SetFocus();
		
	*pResult = 1;
}

//

void CFolderListView::OnDeleteitem(NMHDR* pNMHDR, LRESULT* pResult) 
// Will delete the records in dtItems and dtTree order associated
// to this treeLeaf/Folder
// 
// The MessageBox question to the user about deleting is placed in
// CFolderTreeCtrl
//
{	
 	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;

	if (!m_bOnDestroyHasBeenExecuted)
	{		
		sFLVTreeOrderSubItems * MProj = (sFLVTreeOrderSubItems*)m_TreeCtrl.GetItemData( pNMTreeView->itemOld.hItem );
		if (MProj->nItemType == cITFOLDER)
		{
			if ( !theCCVOClient->delete_dtItem_And_dtTreeOrder( MProj->nMProjectID, MProj->nParentID, MProj->nItemID) )
				ccErrEM( IDS_COULDNT_DELETE_ITEM_FROM_DATABASE );
		}

		// Delete the "struct-data" associated to the tree leaf.
		delete MProj;
	}
	
	*pResult = 0;
}

//

BOOL CFolderListView::OnEraseBkgnd(CDC* pDC)   
{
	UNUSED_ALWAYS(pDC);
	return TRUE;
}

//

void CFolderListView::OnDestroy() 
{
	CView::OnDestroy();

	// Tell the OnDelete that we will close the program now
	// so it won't delete folders and data from the databse
	m_bOnDestroyHasBeenExecuted = true;	
	
	// Save the selected treeLeaf, so we have the same leaf
	// selected next time we start the program.
	theCCVOClient->saveSelectedTreeLeaf();
}

//

void CFolderListView::OnContextMenu(CWnd* pWnd, CPoint point) 
{		
	// TODO TODO TODO Should have a specific menu to every function.

	CMenu menu;
	VERIFY(menu.LoadMenu(IDR_PROJECT_MENU));

	CMenu* pPopup = menu.GetSubMenu(0);
	ASSERT(pPopup != NULL);
	CWnd* pWndPopupOwner = this;

	while (pWndPopupOwner->GetStyle() & WS_CHILD)
			pWndPopupOwner = pWndPopupOwner->GetParent();

	pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y,
			pWndPopupOwner);
}

//

void CFolderListView::OnProjectmenuNewfolder() 
{
	try
	{
		HTREEITEM hti = m_TreeCtrl.GetSelectedItem();
		sFLVTreeOrderSubItems * parentItem;
		parentItem = (sFLVTreeOrderSubItems*)m_TreeCtrl.GetItemData(hti);

		if ( (parentItem->nItemType == cITFUNCTION) || (parentItem->nItemType == cITFOLDER) )
		{
			if (sFLVTreeOrderSubItems)
			{
				sFLVTreeOrderSubItems * newItem = new sFLVTreeOrderSubItems;
				
				newItem->nMProjectID   = parentItem->nMProjectID;
				newItem->nParentID     = parentItem->nItemID;
				newItem->nItemID       = theCCVOClient->m_dataBase->createItemID();
				newItem->strName       = "New Folder";
				newItem->nItemType	   = cITFOLDER;
				newItem->nFunctionType = parentItem->nFunctionType;
				newItem->bExpanded	   = true;

				theCCVOClient->createNewItem( newItem );
				
				HTREEITEM hNewItem = insertItem( newItem, hti );
				if (hNewItem)
				{				
					m_TreeCtrl.SelectItem( hNewItem );
					m_TreeCtrl.EditLabel( hNewItem );			
				}
			}
		}
		else
		{
			ccErrEM(IDS_CANT_CREATE_FOLDER_HERE, NULL, NULL, MB_OK );
			//SetFocus();
			m_TreeCtrl.SetFocus();
		}
	}
	catch( ccException * e)
	{
		ccErr( *e, "", "", MB_OK );			
	}
	catch(...)
	{
		ccErrEM( IDS_GENERAL_CCVOVCLIENT_ERROR );		
		return;
	}
}

//

void CFolderListView::OnProjectmenuDelete() 
{
	HTREEITEM hti = m_TreeCtrl.GetSelectedItem();
	m_TreeCtrl.DeleteItem( hti );
}

//

void CFolderListView::OnProjectmenuRename() 
{
	HTREEITEM hti = m_TreeCtrl.GetSelectedItem();
	m_TreeCtrl.EditLabel( hti );	
}

BEGIN_MESSAGE_MAP(CFolderListView, CView)
	//{{AFX_MSG_MAP(CFolderListView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_BN_CLICKED(IDC_CAPT_BUTTON, OnCaptButton)
	ON_NOTIFY(TVN_SELCHANGED, IDC_TREE_VIEW, OnSelchanged)
	ON_NOTIFY(TVN_ITEMEXPANDED, IDC_TREE_VIEW, OnItemexpanded)
	ON_NOTIFY(TVN_BEGINLABELEDIT, IDC_TREE_VIEW, OnBeginlabeledit)
	ON_NOTIFY(TVN_DELETEITEM, IDC_TREE_VIEW, OnDeleteitem)
	ON_WM_ERASEBKGND()
	ON_WM_DESTROY()
	ON_WM_CONTEXTMENU()
	ON_COMMAND(ID_PROJECTMENU_NEWFOLDER, OnProjectmenuNewfolder)
	ON_COMMAND(ID_PROJECTMENU_DELETE, OnProjectmenuDelete)
	ON_COMMAND(ID_PROJECTMENU_RENAME, OnProjectmenuRename)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// *** Debug members
/////////////////////////////////////////////////////////////////////////////

#ifdef _DEBUG
void CFolderListView::AssertValid() const
{
	CView::AssertValid();
}

void CFolderListView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

//

void CFolderListView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	
	fillTreeCtrl();
	
}

