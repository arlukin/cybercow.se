// cccddContacts.cpp: implementation of the cccddContacts class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "cccddContacts.h"
#include "cccvodb.h"
#include "ccVOClient.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
#define TS ddf(m_ddContacts)

BEGIN_CCFIELD_EVENT( cccddContacts  )		
//	ON_CCFIELD(	ID							OnSetFocus,				OnKillFocus,		OnValidate,		OnPopup,			OnEndPopup				OnChange				)
	ON_CCFIELD( CONTACTS_Display,			NoFunc,					NoFunc,				NoFunc,			OnPopupDisplay,		OnEndPopupDisplay,		OnChangeDisplay			)
	ON_CCFIELD( CONTACTS_Title,				NoFunc,					NoFunc,				NoFunc,			OnPopupTitle,		OnEndPopupTitle,		OnChangeTitle			)
	ON_CCFIELD( CONTACTS_FirstName,			OnSetFocusFirstName,	NoFunc,				NoFunc,			NoFunc,				NoFunc,					OnChangeFirstName		)
	ON_CCFIELD( CONTACTS_MiddleName,		NoFunc,					NoFunc,				NoFunc,			NoFunc,				NoFunc,					OnChangeMiddleName		)
	ON_CCFIELD( CONTACTS_LastName,			NoFunc,					NoFunc,				NoFunc,			NoFunc,				NoFunc,					OnChangeLastName		)
	ON_CCFIELD( CONTACTS_NickName1,			NoFunc,					NoFunc,				NoFunc,			NoFunc,				NoFunc,					OnChangeNickName1		)
	ON_CCFIELD( CONTACTS_NickName2,			NoFunc,					NoFunc,				NoFunc,			NoFunc,				NoFunc,					OnChangeNickName2		)
END_CCFIELD_EVENT()

//

cccddContacts ::cccddContacts ( ccDataBase* pDatabase ) 
: ccDataDictionary( pDatabase )
{
	try
	{
		setConfirmDeleteMsg("F2 delete doesn't work in this version");
		// Open the table.		
		openADO("SELECT dtfContacts.MProjectID,		dtTreeOrder.ItemID,			dtfContacts.ItemID, "
					"dtfContacts.DisplayType, "
					"dtfContacts.Title,				dtfContacts.FirstName,		dtfContacts.MiddleName, "
					"dtfContacts.LastName,			dtfContacts.Display,		dtfContacts.NickName1, "
					"dtfContacts.NickName2,			dtfContacts.BirthDate,		dtfContacts.SpousesName, "
					"dtfContacts.SpousesInterests,	dtfContacts.Aniversary,		dtfContacts.ChildrenNames, "
					"dtfContacts.Photo,				dtfContacts.PersonalNotes,	dtfContacts.Company, "
					"dtfContacts.JobTitle,			dtfContacts.Office,			dtfContacts.Department, "
					"dtfContacts.ManagerName,		dtfContacts.AssistensName,	dtfContacts.OthersName,	"
					"dtfContacts.BusinessNotes,		dtfContacts.PrimEmail, "
					"dtfContacts.PhoneName1,		dtfContacts.PhoneName2,		dtfContacts.PhoneName3, "
					"dtfContacts.ICQ_ID,			dtfContacts.Yahoo_ID,		dtfContacts.AOL_ID, "
					"dtfContacts.MSN_ID, "

					"dtfContacts.Home_Street,						dtfContacts.Home_City, "
					"dtfContacts.Home_StateOrProvince,				dtfContacts.Home_ZipOrPostalCode, "
					"dtfContacts.Home_CountryRegion, "

					"dtfContacts.Business_Mail_Street,				dtfContacts.Business_Mail_City, "
					"dtfContacts.Business_Mail_StateOrProvince,		dtfContacts.Business_Mail_ZipOrPostalCode, "
					"dtfContacts.Business_Mail_CountryRegion, "

					"dtfContacts.Business_Office_Street,			dtfContacts.Business_Office_City, "
					"dtfContacts.Business_Office_StateOrProvince,	dtfContacts.Business_Office_ZipOrPostalCode, "
					"dtfContacts.Business_Office_CountryRegion, "

					"dtfContacts.Personal_WebPage1, dtfContacts.Personal_WebPage2, "
					"dtfContacts.Personal_FTPSite1, dtfContacts.Personal_FTPSite2, "

					"dtfContacts.Business_WebPage1, dtfContacts.Business_WebPage2, "
					"dtfContacts.Business_FTPSite1, dtfContacts.Business_FTPSite2 "

				"FROM dtfContacts, dtItems, dtTreeOrder "
				"WHERE dtfContacts.MProjectID = dtTreeOrder.MProjectID AND "
				"    dtfContacts.ItemID = dtTreeOrder.ChildID AND "
				"    dtItems.MProjectID = dtTreeOrder.MProjectID AND "
				"    dtItems.ItemID = dtTreeOrder.ChildID  "
				//"    dtTreeOrder.MProjectID = " << getSelLeafMProjectID() << " AND";
				//"    dtTreeOrder.ItemID = "<< getSelLeafItemID();					
				//"    dtfContacts.ItemID = "<< getSelLeafItemID();	
				" order by dtfContacts.Display"
				,ADODB::adOpenKeyset, ADODB::adLockPessimistic ,ADODB::adUseServer );
										
		bind( m_MProjectID,				CONTACTS_MProjectID,				_T("MProjectID")			);		
		bind( m_ParentItemID,			CONTACTS_ParentItemID,				_T("dtTreeOrder.ItemID")	);
		bind( m_ItemID,					CONTACTS_ItemID,					_T("dtfContacts.ItemID")	);
		bind( m_DisplayType,			CONTACTS_DisplayType,				_T("DisplayType")			);
		bind( m_Title,					CONTACTS_Title,						_T("Title")					);
		bind( m_FirstName,				CONTACTS_FirstName,					_T("FirstName")				);
		bind( m_MiddleName,				CONTACTS_MiddleName,				_T("MiddleName")			);
		bind( m_LastName,				CONTACTS_LastName,					_T("LastName")				);
		bind( m_Display,				CONTACTS_Display,					_T("Display")				);
		bind( m_NickName1,				CONTACTS_NickName1,					_T("NickName1")				);
		bind( m_NickName2,				CONTACTS_NickName2,					_T("NickName2")				);
		bind( m_BirthDate,				CONTACTS_BirthDate,					_T("BirthDate")				);
		bind( m_SpousesName,			CONTACTS_SpousesName,				_T("SpousesName")			);
		bind( m_SpousesInterests,		CONTACTS_SpousesInterests,			_T("SpousesInterests")		);
		bind( m_Aniversary,				CONTACTS_Aniversary,				_T("Aniversary")			);
		bind( m_ChildrenNames,			CONTACTS_ChildrenNames,				_T("ChildrenNames")			);
		bind( m_Photo,					CONTACTS_Photo,						_T("Photo")					);
		bind( m_PersonalNotes,			CONTACTS_PersonalNotes,				_T("PersonalNotes")			);
		bind( m_Company,				CONTACTS_Company,					_T("Company")				);
		bind( m_JobTitle,				CONTACTS_JobTitle,					_T("JobTitle")				);
		bind( m_Office,					CONTACTS_Office,					_T("Office")			);
		bind( m_Department,				CONTACTS_Department,				_T("Department")			);
		bind( m_ManagerName,			CONTACTS_ManagerName,				_T("ManagerName")			);
		bind( m_AssistensName,			CONTACTS_AssistensName,				_T("AssistensName")			);
		bind( m_OthersName,				CONTACTS_OthersName,				_T("OthersName")			);
		bind( m_BusinessNotes,			CONTACTS_BusinessNotes,				_T("BusinessNotes")			);
		bind( m_PrimEMail,				CONTACTS_PrimEMail,					_T("PrimEMail")				);
		bind( m_PhoneName1,				CONTACTS_PhoneName1,				_T("PhoneName1")			);
		bind( m_PhoneName2,				CONTACTS_PhoneName2,				_T("PhoneName2")			);
		bind( m_PhoneName3,				CONTACTS_PhoneName3,				_T("PhoneName3")			);		
		bind( m_ICQ_ID,					CONTACTS_ICQ_ID,					_T("ICQ_ID")				);
		bind( m_Yahoo_ID,				CONTACTS_Yahoo_ID,					_T("Yahoo_ID")				);
		bind( m_AOL_ID,					CONTACTS_AOL_ID,					_T("AOL_ID")				);
		bind( m_MSN_ID,					CONTACTS_MSN_ID,					_T("MSN_ID")				);
		bind( m_Home_Street,			CONTACTS_Home_Street,				_T("Home_Street")			);
		bind( m_Home_City,				CONTACTS_Home_City,					_T("Home_City")				);
		bind( m_Home_StateOrProvince,	CONTACTS_Home_StateOrProvince,		_T("Home_StateOrProvince")	);
		bind( m_Home_ZipOrPostalCode,	CONTACTS_Home_ZipOrPostalCode,		_T("Home_ZipOrPostalCode")	);
		bind( m_Home_CountryOrRegion,	CONTACTS_Home_CountryOrRegion,		_T("Home_CountryRegion")	);

		bind( m_Business_Mail_Street,				CONTACTS_Business_Mail_Street,				_T("Business_Mail_Street")			);
		bind( m_Business_Mail_City,					CONTACTS_Business_Mail_City,				_T("Business_Mail_City")				);
		bind( m_Business_Mail_StateOrProvince,		CONTACTS_Business_Mail_StateOrProvince,		_T("Business_Mail_StateOrProvince")	);
		bind( m_Business_Mail_ZipOrPostalCode,		CONTACTS_Business_Mail_ZipOrPostalCode,		_T("Business_Mail_ZipOrPostalCode")	);
		bind( m_Business_Mail_CountryOrRegion,		CONTACTS_Business_Mail_CountryOrRegion,		_T("Business_Mail_CountryRegion")	);
		bind( m_Business_Office_Street,				CONTACTS_Business_Office_Street,			_T("Business_Office_Street")			);
		bind( m_Business_Office_City,				CONTACTS_Business_Office_City,				_T("Business_Office_City")				);
		bind( m_Business_Office_StateOrProvince,	CONTACTS_Business_Office_StateOrProvince,	_T("Business_Office_StateOrProvince")	);
		bind( m_Business_Office_ZipOrPostalCode,	CONTACTS_Business_Office_ZipOrPostalCode,	_T("Business_Office_ZipOrPostalCode")	);
		bind( m_Business_Office_CountryOrRegion,	CONTACTS_Business_Office_CountryOrRegion,	_T("Business_Office_CountryRegion")	);

		bind( m_Personal_WebPage1,		CONTACTS_Personal_WebPage1,			_T("Personal_WebPage1")		);
		bind( m_Personal_WebPage2,		CONTACTS_Personal_WebPage2,			_T("Personal_WebPage2")		);
		bind( m_Personal_FTPSite1,		CONTACTS_Personal_FTPSite1,			_T("Personal_FTPSite1")		);
		bind( m_Personal_FTPSite2,		CONTACTS_Personal_FTPSite2,			_T("Personal_FTPSite2")		);			
		bind( m_Business_WebPage1,		CONTACTS_Business_WebPage1,			_T("Business_WebPage1")		);
		bind( m_Business_WebPage2,		CONTACTS_Business_WebPage2,			_T("Business_WebPage2")		);
		bind( m_Business_FTPSite1,		CONTACTS_Business_FTPSite1,			_T("Business_FTPSite1")		);
		bind( m_Business_FTPSite2,		CONTACTS_Business_FTPSite2,			_T("Business_FTPSite2")		);			
		
		m_Display.enableColumnSorting( true );
		m_ItemID.enableColumnSorting( true );
		m_FirstName.enableColumnSorting( true );

		// CONTACTS.MProjectID
		m_MProjectID.setLongCaption( _T("MProjectID") );
		m_MProjectID.setShortCaption(	_T("MProjectID") );
		m_MProjectID.setStatusHelp(	_T("MProjectID") );
		
		// CONTACTS.ItemID
		m_ItemID.setLongCaption(	_T("ItemID") );
		m_ItemID.setShortCaption(	_T("ItemID") );
		m_ItemID.setStatusHelp(		_T("ItemID") );
		
		// CONTACTS.Title
		m_Title.setLongCaption(		_T("Title") );
		m_Title.setShortCaption(	_T("Title") );
		m_Title.setStatusHelp(		_T("Title") );
		
		// CONTACTS.FirstName
		m_FirstName.setLongCaption(		_T("First") );
		m_FirstName.setShortCaption(	_T("First") );
		m_FirstName.setStatusHelp(		_T("Firstname") );
		
		// CONTACTS.MiddleName
		m_MiddleName.setLongCaption(	_T("Middle") );
		m_MiddleName.setShortCaption(	_T("Middle") );
		m_MiddleName.setStatusHelp(		_T("Middlename") );
		
		// CONTACTS.LastName
		m_LastName.setLongCaption(		_T("Last") );
		m_LastName.setShortCaption(		_T("Last") );
		m_LastName.setStatusHelp(		_T("Lastname") );
		
		// CONTACTS.Display
		m_Display.setLongCaption(		_T("Display") );
		m_Display.setShortCaption(		_T("Display") );
		m_Display.setStatusHelp(		_T("Display") );
		
		// CONTACTS.NickName1
		m_NickName1.setLongCaption(		_T("Nick1") );
		m_NickName1.setShortCaption(	_T("Nick1") );
		m_NickName1.setStatusHelp(		_T("Nickname1") );
		
		// CONTACTS.NickName2
		m_NickName2.setLongCaption(		_T("Nick2") );
		m_NickName2.setShortCaption(	_T("Nick2") );
		m_NickName2.setStatusHelp(		_T("Nickname2") );
		
		// CONTACTS.BirthDate
		m_BirthDate.setLongCaption(		_T("Birthday") );
		m_BirthDate.setShortCaption(	_T("Birthday") );
		m_BirthDate.setStatusHelp(		_T("Birthday") );
		m_BirthDate.setMaskType(		CCE_DATE		);
		
		// CONTACTS.SpousesName
		m_SpousesName.setLongCaption(	_T("Spouse's name") );
		m_SpousesName.setShortCaption(	_T("Spouse's name") );
		m_SpousesName.setStatusHelp(	_T("Spouse's name") );
		
		// CONTACTS.SpousesInterests
		m_SpousesInterests.setLongCaption(	_T("Spouse's interests") );
		m_SpousesInterests.setShortCaption(	_T("Spouse's interests") );
		m_SpousesInterests.setStatusHelp(	_T("Spouse's interests") );
		
		// CONTACTS.Aniversary
		m_Aniversary.setLongCaption(	_T("Aniversary") );
		m_Aniversary.setShortCaption(	_T("Aniversary") );
		m_Aniversary.setStatusHelp(		_T("Aniversary") );
		m_Aniversary.setMaskType(		CCE_DATE		 );
		
		// CONTACTS.ChildrenNames
		m_ChildrenNames.setLongCaption(		_T("Children's name") );
		m_ChildrenNames.setShortCaption(	_T("Children's name") );
		m_ChildrenNames.setStatusHelp(		_T("Children's name") );
		
		// CONTACTS.Photo
		m_Photo.setLongCaption(		_T("Photo") );
		m_Photo.setShortCaption(	_T("Photo") );
		m_Photo.setStatusHelp(		_T("Photo") );
		
		// CONTACTS.PersonalNotes
		m_PersonalNotes.setLongCaption(		_T("Personal notes") );
		m_PersonalNotes.setShortCaption(	_T("Personal notes") );
		m_PersonalNotes.setStatusHelp(		_T("Personal notes") );
		m_PersonalNotes.setEditMultiLine( true );
		
		// CONTACTS.Company
		m_Company.setLongCaption(	_T("Company") );
		m_Company.setShortCaption(	_T("Company") );
		m_Company.setStatusHelp(	_T("Company") );
		
		// CONTACTS.JobTitle
		m_JobTitle.setLongCaption(	_T("Job title") );
		m_JobTitle.setShortCaption(	_T("Job title") );
		m_JobTitle.setStatusHelp(	_T("Job title") );
		
		// CONTACTS.Department
		m_Department.setLongCaption(	_T("Department") );
		m_Department.setShortCaption(	_T("Department") );
		m_Department.setStatusHelp(		_T("Department") );
		
		// CONTACTS.ManagerName
		m_ManagerName.setLongCaption(	_T("Manager's name") );
		m_ManagerName.setShortCaption(	_T("Manager's name") );
		m_ManagerName.setStatusHelp(	_T("Manager's name") );
		
		// CONTACTS.AssistensName
		m_AssistensName.setLongCaption(		_T("Assisten's name") );
		m_AssistensName.setShortCaption(	_T("Assisten's name") );
		m_AssistensName.setStatusHelp(		_T("Assisten's name") );
		
		// CONTACTS.OthersName
		m_OthersName.setLongCaption(	_T("Other's name") );
		m_OthersName.setShortCaption(	_T("Other's name") );
		m_OthersName.setStatusHelp(		_T("Other's name") );
		
		// CONTACTS.BusinessNotes
		m_BusinessNotes.setLongCaption(		_T("Business notes") );
		m_BusinessNotes.setShortCaption(	_T("Business notes") );
		m_BusinessNotes.setStatusHelp(		_T("Business notes") );		
		m_BusinessNotes.setEditMultiLine( true );

		// CONTACTS_PrimEMail
		m_PrimEMail.setLongCaption(		_T("Primery Email") );
		m_PrimEMail.setShortCaption(	_T("Prim Email") );
		m_PrimEMail.setStatusHelp(		_T("Primery Email") );				
		m_PrimEMail.setStyle( WS_DISABLED );

		// CONTACTS_ICQ_ID
		m_ICQ_ID.setLongCaption(	_T("ICQ") );
		m_ICQ_ID.setShortCaption(	_T("ICQ") );
		m_ICQ_ID.setStatusHelp(		_T("ICQ ID") );

		// CONTACTS_ICQ_ID
		m_Yahoo_ID.setLongCaption(	_T("Yahoo") );
		m_Yahoo_ID.setShortCaption(	_T("Yahoo") );
		m_Yahoo_ID.setStatusHelp(	_T("Yahoo Instant Messeger ID") );

		// CONTACTS_ICQ_ID
		m_AOL_ID.setLongCaption(	_T("AOL") );
		m_AOL_ID.setShortCaption(	_T("AOL") );
		m_AOL_ID.setStatusHelp(		_T("AOL ID") );

		// CONTACTS_ICQ_ID
		m_MSN_ID.setLongCaption(	_T("MSN") );
		m_MSN_ID.setShortCaption(	_T("MSN") );
		m_MSN_ID.setStatusHelp(		_T("MSN ID") );
	
		// CONTACTS_Home_Street
		m_Home_Street.setLongCaption(	_T("Street") );
		m_Home_Street.setShortCaption(	_T("Street") );
		m_Home_Street.setStatusHelp(	_T("Street") );
		m_Home_Street.setEditMultiLine( true );

		// CONTACTS_Home_City
		m_Home_City.setLongCaption(		_T("City") );
		m_Home_City.setShortCaption(	_T("City") );
		m_Home_City.setStatusHelp(		_T("City") );

		// CONTACTS_Home_StateOrProvince
		m_Home_StateOrProvince.setLongCaption(	_T("State/Province") );
		m_Home_StateOrProvince.setShortCaption(	_T("State/Province") );
		m_Home_StateOrProvince.setStatusHelp(	_T("State/Province") );

		// CONTACTS_Home_ZipOrPostalCode
		m_Home_ZipOrPostalCode.setLongCaption(	_T("ZIP/Postalcode") );
		m_Home_ZipOrPostalCode.setShortCaption(	_T("ZIP/Postalcode") );
		m_Home_ZipOrPostalCode.setStatusHelp(	_T("ZIP/Postalcode") );

		// CONTACTS_Home_CountryOrRegion
		m_Home_CountryOrRegion.setLongCaption(	_T("Country/Region") );
		m_Home_CountryOrRegion.setShortCaption(	_T("Country/Region") );
		m_Home_CountryOrRegion.setStatusHelp(	_T("Country/Region") );		

		// CONTACTS_Business_Mail_Street
		m_Business_Mail_Street.setLongCaption(	_T("Street") );
		m_Business_Mail_Street.setShortCaption(	_T("Street") );
		m_Business_Mail_Street.setStatusHelp(	_T("Street") );
		m_Business_Mail_Street.setEditMultiLine( true );

		// CONTACTS_Business_Mail_City
		m_Business_Mail_City.setLongCaption(		_T("City") );
		m_Business_Mail_City.setShortCaption(	_T("City") );
		m_Business_Mail_City.setStatusHelp(		_T("City") );

		// CONTACTS_Business_Mail_StateOrProvince
		m_Business_Mail_StateOrProvince.setLongCaption(	_T("State/Province") );
		m_Business_Mail_StateOrProvince.setShortCaption(	_T("State/Province") );
		m_Business_Mail_StateOrProvince.setStatusHelp(	_T("State/Province") );

		// CONTACTS_Business_Mail_ZipOrPostalCode
		m_Business_Mail_ZipOrPostalCode.setLongCaption(	_T("ZIP/Postalcode") );
		m_Business_Mail_ZipOrPostalCode.setShortCaption(	_T("ZIP/Postalcode") );
		m_Business_Mail_ZipOrPostalCode.setStatusHelp(	_T("ZIP/Postalcode") );

		// CONTACTS_Business_Mail_CountryOrRegion
		m_Business_Mail_CountryOrRegion.setLongCaption(	_T("Country/Region") );
		m_Business_Mail_CountryOrRegion.setShortCaption(	_T("Country/Region") );
		m_Business_Mail_CountryOrRegion.setStatusHelp(	_T("Country/Region") );		
		
		// CONTACTS_Business_Office_Street
		m_Business_Office_Street.setLongCaption(	_T("Street") );
		m_Business_Office_Street.setShortCaption(	_T("Street") );
		m_Business_Office_Street.setStatusHelp(	_T("Street") );
		m_Business_Office_Street.setEditMultiLine( true );

		// CONTACTS_Business_Office_City
		m_Business_Office_City.setLongCaption(		_T("City") );
		m_Business_Office_City.setShortCaption(	_T("City") );
		m_Business_Office_City.setStatusHelp(		_T("City") );

		// CONTACTS_Business_Office_StateOrProvince
		m_Business_Office_StateOrProvince.setLongCaption(	_T("State/Province") );
		m_Business_Office_StateOrProvince.setShortCaption(	_T("State/Province") );
		m_Business_Office_StateOrProvince.setStatusHelp(	_T("State/Province") );

		// CONTACTS_Business_Office_ZipOrPostalCode
		m_Business_Office_ZipOrPostalCode.setLongCaption(	_T("ZIP/Postalcode") );
		m_Business_Office_ZipOrPostalCode.setShortCaption(	_T("ZIP/Postalcode") );
		m_Business_Office_ZipOrPostalCode.setStatusHelp(	_T("ZIP/Postalcode") );

		// CONTACTS_Business_Mail_CountryOrRegion
		m_Business_Office_CountryOrRegion.setLongCaption(	_T("Country/Region") );
		m_Business_Office_CountryOrRegion.setShortCaption(	_T("Country/Region") );
		m_Business_Office_CountryOrRegion.setStatusHelp(	_T("Country/Region") );		
		
		// CONTACTS_Personal_WebPage1
		m_Personal_WebPage1.setLongCaption(		_T("Webpage 1") );
		m_Personal_WebPage1.setShortCaption(	_T("Webpage 1") );
		m_Personal_WebPage1.setStatusHelp(		_T("Webpage 1") );
		
		// CONTACTS_Personal_WebPage2
		m_Personal_WebPage2.setLongCaption(		_T("Web-page 2") );
		m_Personal_WebPage2.setShortCaption(	_T("Web-page 2") );
		m_Personal_WebPage2.setStatusHelp(		_T("Web-page 2") );
		
		// CONTACTS_Personal_FTPSite1
		m_Personal_FTPSite1.setLongCaption(		_T("FTP-site1") );
		m_Personal_FTPSite1.setShortCaption(	_T("FTP-site1") );
		m_Personal_FTPSite1.setStatusHelp(		_T("FTP-site1") );
		
		// CONTACTS_Personal_FTPSite2
		m_Personal_FTPSite2.setLongCaption(		_T("FTP-site2") );
		m_Personal_FTPSite2.setShortCaption(	_T("FTP-site2") );
		m_Personal_FTPSite2.setStatusHelp(		_T("FTP-site2") );		

		// CONTACTS_Business_WebPage1
		m_Business_WebPage1.setLongCaption(		_T("Webpage 1") );
		m_Business_WebPage1.setShortCaption(	_T("Webpage 1") );
		m_Business_WebPage1.setStatusHelp(		_T("Webpage 1") );
		
		// CONTACTS_Business_WebPage2
		m_Business_WebPage2.setLongCaption(		_T("Web-page 2") );
		m_Business_WebPage2.setShortCaption(	_T("Web-page 2") );
		m_Business_WebPage2.setStatusHelp(		_T("Web-page 2") );
		
		// CONTACTS_Business_FTPSite1
		m_Business_FTPSite1.setLongCaption(		_T("FTP-site1") );
		m_Business_FTPSite1.setShortCaption(	_T("FTP-site1") );
		m_Business_FTPSite1.setStatusHelp(		_T("FTP-site1") );
		
		// CONTACTS_Business_FTPSite2
		m_Business_FTPSite2.setLongCaption(		_T("FTP-site2") );
		m_Business_FTPSite2.setShortCaption(	_T("FTP-site2") );
		m_Business_FTPSite2.setStatusHelp(		_T("FTP-site2") );		

	}
	catch(ccException *e) 
	{
		ccErr(*e,"","", MB_OK);
		exit(1);
	}
	catch(...) 
	{
		ccErr("DB Error", "","", MB_OK);
		exit(1);
	}
}

cccddContacts ::~cccddContacts ()
{
	

}
//////////////////////////////////////////////////////////////////////
// *** Table Events
//////////////////////////////////////////////////////////////////////

void cccddContacts::creating()
{
	m_MProjectID = getSelLeafMProjectID();
	m_ItemID = getDB()->createItemID();		
//
	getDB()->insert_dtItems( m_MProjectID, m_ItemID, m_Display, 2, 5);
	getDB()->insert_dtTreeOrder( m_MProjectID, getSelLeafItemID(), m_ItemID);	
}

//

void cccddContacts::updateing()
{	
	getDB()->update_dtItems( m_MProjectID, m_ItemID, (CString)m_Display);
	saveEmailStruct();
	savePhoneStruct();
}

//

void cccddContacts::deleting()
{ 	
}

//

void cccddContacts::OnFieldChangeComplete()
{
	buildEmailStruct( false );
	buildPhoneStruct( false );
}

//

void cccddContacts::OnFieldClearComplete()
{
	buildEmailStruct( true );
	buildPhoneStruct( true );
}

//////////////////////////////////////////////////////////////////////
// *** Table Field Events
//////////////////////////////////////////////////////////////////////

bool cccddContacts::OnSetFocusFirstName( DD_DISPINFO * aDispInfo )
{	
	return CCSUCCEDED;
}

//

bool cccddContacts::OnChangeDisplay( DD_DISPINFO * aDispInfo )
{
	ddf(m_ddContacts)->m_DisplayType = -1 ;
	return CCSUCCEDED;
}

//

bool cccddContacts::OnChangeTitle( DD_DISPINFO * aDispInfo )
{
	return updateDisplayField( aDispInfo );
}

//

bool cccddContacts::OnChangeFirstName( DD_DISPINFO * aDispInfo )
{
	return updateDisplayField( aDispInfo );
}

//

bool cccddContacts::OnChangeMiddleName( DD_DISPINFO * aDispInfo )
{
	return updateDisplayField( aDispInfo );
}

//

bool cccddContacts::OnChangeLastName( DD_DISPINFO * aDispInfo )
{
	return updateDisplayField( aDispInfo );
}

//

bool cccddContacts::OnChangeNickName1( DD_DISPINFO * aDispInfo )
{	
	return updateDisplayField( aDispInfo );
}

//

bool cccddContacts::OnChangeNickName2( DD_DISPINFO * aDispInfo )
{
	return updateDisplayField( aDispInfo );
}

//

bool cccddContacts::OnPopupDisplay( DD_DISPINFO * aDispInfo )
{
	if (aDispInfo->m_field!=NULL)
	{	
		ccListPopupDialog * loListPopup;
		loListPopup = new ccListPopupDialog(aDispInfo->m_superCtrl);

		//Build the list poup.
		for (int i = 0;;i++)
		{
			CString *lsDisplayText = getDisplayText(aDispInfo,i);
			if (lsDisplayText == NULL)
				break;
			loListPopup->addItem(i, *lsDisplayText );
			delete lsDisplayText;
		}
		
		//Display and update the display field.
		loListPopup->popup();		
	}    
	return CCSUCCEDED;	
}

//

bool cccddContacts::OnEndPopupDisplay( DD_DISPINFO * aDispInfo )
{	
	ddf(m_ddContacts)->m_DisplayType = aDispInfo->m_endPopupInfo->m_itemNum; 
	updateDisplayField( aDispInfo );	

	return CCSUCCEDED;
}

//

bool cccddContacts::OnEndPopupTitle( DD_DISPINFO * aDispInfo )
{	
	return updateDisplayField( aDispInfo );	
}

//

bool cccddContacts::OnPopupTitle( DD_DISPINFO * aDispInfo )
{
	if (aDispInfo->m_field!=NULL)
	{	
		ccListPopupDialog *loListPopup;
		loListPopup = new ccListPopupDialog(aDispInfo->m_superCtrl);

		//Build the list poup.
		loListPopup->addItem(0, "DR.");
		loListPopup->addItem(1, "Miss");
		loListPopup->addItem(2, "Mr.");
		loListPopup->addItem(3, "Mrs.");
		loListPopup->addItem(4, "Ms.");
		loListPopup->addItem(5, "Prof.");
				
		loListPopup->popup();		
	}    
	return CCSUCCEDED;	
}

//////////////////////////////////////////////////////////////////////
// *** Helper Attributes
//////////////////////////////////////////////////////////////////////

CString *cccddContacts::getDisplayText(DD_DISPINFO * aDispInfo, int aiItem)
{
	CString * lsText;
	lsText = new CString;
	switch( aiItem)
	{
	case 0: // Title FirstName MiddleName LastName

		if ( !TS->m_Title.getValue().IsEmpty() )
			*lsText += TS->m_Title + CString(' ');

		if ( !TS->m_FirstName.getValue().IsEmpty() )
			*lsText += TS->m_FirstName + CString(' ');

		if ( !TS->m_MiddleName.getValue().IsEmpty() )
			*lsText += TS->m_MiddleName + CString(' ');

		if ( !TS->m_LastName.getValue().IsEmpty() )
			*lsText += TS->m_LastName;

		break;
	case 1:	// LastName, FirstName MiddleName
		if ( !TS->m_LastName.getValue().IsEmpty() )
			*lsText += TS->m_LastName + CString(", ");

		if ( !TS->m_FirstName.getValue().IsEmpty() )
			*lsText += TS->m_FirstName + CString(' ');

		if ( !TS->m_MiddleName.getValue().IsEmpty() )
			*lsText += TS->m_MiddleName;
		break;

	case 2: // FirstName LastName
		if ( !TS->m_FirstName.getValue().IsEmpty() )
			*lsText += TS->m_FirstName + CString(' ');

		if ( !TS->m_LastName.getValue().IsEmpty() )
			*lsText += TS->m_LastName;
					      
		break;

	case 3: // LastName FirstName 
		if ( !TS->m_LastName.getValue().IsEmpty() )
			*lsText += TS->m_LastName + CString(' ');

		if ( !TS->m_FirstName.getValue().IsEmpty() )
			*lsText += TS->m_FirstName;					      
		break;

	case 4: // NickName1
		if ( !TS->m_NickName1.getValue().IsEmpty() )
			*lsText += TS->m_NickName1;
		break;

	case 5: //NickName2
		if ( !TS->m_NickName2.getValue().IsEmpty() )
			*lsText +=  TS->m_NickName2;
		break;
	default:
		delete lsText;
		lsText = NULL;		
	}	
	return lsText;
}

//

bool cccddContacts::updateDisplayField(DD_DISPINFO * aDispInfo )
{
	if ( TS->m_DisplayType  != -1)
	{
		CString *lsText = TS->getDisplayText(aDispInfo, m_DisplayType   );
		if (lsText != NULL)
			TS->m_Display.setValue( *lsText );			
	}
	return CCSUCCEDED;
}

//////////////////////////////////////////////////////////////////////
// *** SQL-Script Functions
//////////////////////////////////////////////////////////////////////

bool cccddContacts::getTreeLeafContacts( CPtrList &treeLeafContacts)
{
	if ( getDB() )	
	{
		try
		{
			ADODB::_RecordsetPtr PopSet;						
			try
			{
				ccString strSQL;	

				strSQL << "SELECT dtfContacts.ItemID, dtfContacts.Display, dtfContacts.PrimEMail ";
				strSQL << "FROM dtfContacts, dtItems, dtTreeOrder ";
				strSQL << "WHERE dtfContacts.MProjectID = dtTreeOrder.MProjectID AND ";
				strSQL << "    dtfContacts.ItemID = dtTreeOrder.ChildID AND ";
				strSQL << "    dtItems.MProjectID = dtTreeOrder.MProjectID AND ";
				strSQL << "    dtItems.ItemID = dtTreeOrder.ChildID AND ";
				strSQL << "    dtTreeOrder.MProjectID = " << getSelLeafMProjectID() << " AND";
				strSQL << "    dtTreeOrder.ItemID = "<< getSelLeafItemID();	

				if ( getDB()->getRS(strSQL, PopSet) )							
				{
					while(!PopSet->adoEOF)
					{		
						sTFContacts * TFContacts = new sTFContacts;
						TFContacts->nItemID				= PopSet->Fields->Item[_variant_t(0l)]->Value;						
						TFContacts->strDisplay			= (char*)(_bstr_t)PopSet->Fields->Item[_variant_t(1l)]->Value;;		
						TFContacts->strPrimMail			= (char*)(_bstr_t)PopSet->Fields->Item[_variant_t(2l)]->Value;;		
						TFContacts->strBussinessPhone	= getContactsPhone( TFContacts->nItemID, "Bussiness");
						TFContacts->strHomePhone		= getContactsPhone( TFContacts->nItemID, "Home");
											
						treeLeafContacts.AddTail( TFContacts );
						
						PopSet->MoveNext();						
					}

					PopSet->Close();					
				}			
				return true;
			}
			catch(_com_error &e) 
			{ 
				ccErr(getProviderError( getDB()->getConnection()) );
				ccThrowccException( getProviderError( getDB()->getConnection()) ); /*Delete unreference warning*/ (void*)&e; 				
			}	
		}
		catch( ccException * e)
		{
			ccErr( *e, "", "", MB_OK );			
		}
		catch(...)
		{
			ccErrEM( IDS_CANT_RETRIVE_CONTACTS, NULL, NULL, MB_OK );
		}
	}
	else
		ccErrEM( IDS_DATABASE_ISNT_OPEN, NULL, NULL, MB_OK);

	return false;
}

//

void cccddContacts::initContactsPhone(int nMProjectID, int nItemID)
{		
	// Clear the list
	for( int nIndex=0;nIndex<m_contactsPhoneList.GetSize();nIndex++ ) 
	{
        sContactsPhoneOptimizer* contactsPhone=(sContactsPhoneOptimizer*)m_contactsPhoneList[nIndex];
		delete contactsPhone;
	}
	m_contactsPhoneList.RemoveAll();


	if ( getDB() )	
	{
		try
		{
			ADODB::_RecordsetPtr PopSet;						
			try
			{
				ccString strSQL;	


				strSQL << "SELECT dtfContactsPhone.ItemID, dtfContactsPhone.`PhoneName`, ";
				strSQL << "    dtfContactsPhone.`Number` ";
				strSQL << "FROM dtfContacts, dtItems, dtTreeOrder, dtfContactsPhone ";
				strSQL << "WHERE dtfContactsPhone.MProjectID = dtfContacts.MProjectID AND  ";
				strSQL << "    dtfContactsPhone.ItemID = dtfContacts.ItemID AND  ";
				strSQL << "    dtfContacts.MProjectID = dtTreeOrder.MProjectID AND ";
				strSQL << "    dtfContacts.ItemID = dtTreeOrder.ChildID AND ";
				strSQL << "    dtItems.MProjectID = dtTreeOrder.MProjectID AND "; 
				strSQL << "    dtItems.ItemID = dtTreeOrder.ChildID AND ";
				strSQL << "    dtTreeOrder.MProjectID = " << nMProjectID << " AND ";
				strSQL << "    dtTreeOrder.ItemID = " << nItemID ;

				if ( getDB()->getRS(strSQL, PopSet) )							
				{
					if ((PopSet->adoEOF && PopSet->BOF))
						return;

					while(!PopSet->adoEOF )
					{		
						sContactsPhoneOptimizer * contactsPhone = new sContactsPhoneOptimizer;						
						contactsPhone->nItemID				= PopSet->Fields->Item[_variant_t(0l)]->Value;						
						contactsPhone->strPhoneName			= (char*)(_bstr_t)PopSet->Fields->Item[_variant_t(1l)]->Value;;		
						contactsPhone->strNumber			= (char*)(_bstr_t)PopSet->Fields->Item[_variant_t(2l)]->Value;;		
											
						m_contactsPhoneList.Add( contactsPhone );
						
						PopSet->MoveNext();						
					}


					PopSet->Close();					
				}							
			}
			catch(_com_error &e) 
			{ 
				ccErr(getProviderError( getDB()->getConnection()) );
				ccThrowccException( getProviderError( getDB()->getConnection()) ); /*Delete unreference warning*/ (void*)&e; 				
			}	
		}
		catch( ccException * e)
		{
			ccErr( *e, "", "", MB_OK );			
		}
		catch(...)
		{
			ccErrEM( IDS_CANT_RETRIVE_CONTACTS_PHONE_NUMBER, NULL, NULL, MB_OK );
		}
	}
	else
		ccErrEM( IDS_DATABASE_ISNT_OPEN, NULL, NULL, MB_OK);	
}

//

CString cccddContacts::getContactsPhone( long nItemID, LPCSTR strPhoneName)
{	
	for( int nIndex=0;nIndex<m_contactsPhoneList.GetSize();nIndex++ ) 
	{
        sContactsPhoneOptimizer* contactsPhone=(sContactsPhoneOptimizer*)m_contactsPhoneList[nIndex];
		if (contactsPhone->nItemID == nItemID)
			if (contactsPhone->strPhoneName == strPhoneName)
				return contactsPhone->strNumber;
	}
	return "----";
}

//

bool cccddContacts::deleteContact( int nMProjectID, int nParentID, int nItemID)
{
	if ( ( getDB() ) && ( getDB()->isOpen() ) )
	{
		try
		{			
			try
			{
				ccString strSQL, strWhereSQL;	
				
				strWhereSQL <<   " where MProjectID = " << nMProjectID;
				strWhereSQL <<     " and ItemID = "     << nItemID;
												
				VARIANT RecordsEffected;
				RecordsEffected.vt = VT_INT;
				
				getDB()->beginTrans();
					
					strSQL << "DELETE FROM dtfContacts " << strWhereSQL;
					getDB()->getConnection()->Execute(_bstr_t(strSQL),&RecordsEffected,ADODB::adCmdText);

					strSQL=""; strSQL << "DELETE FROM dtfContactsEmail " << strWhereSQL;
					getDB()->getConnection()->Execute(_bstr_t(strSQL),&RecordsEffected,ADODB::adCmdText);

					strSQL=""; strSQL << "DELETE FROM dtfContactsPhone " << strWhereSQL;
					getDB()->getConnection()->Execute(_bstr_t(strSQL),&RecordsEffected,ADODB::adCmdText);

					strSQL=""; strSQL << "DELETE FROM dtItems " << strWhereSQL;
					getDB()->getConnection()->Execute(_bstr_t(strSQL),&RecordsEffected,ADODB::adCmdText);

					strSQL=""; strSQL << "DELETE FROM dtTreeOrder ";
							   strSQL << "where MProjectID = " << nMProjectID;
							   strSQL << "  and ItemID = "     << nParentID;
							   strSQL << "  and ChildID = "    << nItemID;
					getDB()->getConnection()->Execute(_bstr_t(strSQL),&RecordsEffected,ADODB::adCmdText);

				getDB()->commitTrans();

				return true;
			}
			catch(_com_error &e) 
			{ 
				getDB()->rollbackTrans();								

				ccErr(getProviderError( getDB()->getConnection()) );
				ccThrowccException( getProviderError( getDB()->getConnection()) ); /*Delete unreference warning*/ (void*)&e; 				
			}	
		}
		catch( ccException * e)
		{
			ccErr( *e, "", "", MB_OK );			
		}
		catch(...)
		{
			ccErrEM( IDS_CANT_RETRIVE_CONTACTS_PHONE_NUMBER, NULL, NULL, MB_OK );
		}
	}
	else
		ccErrEM( IDS_DATABASE_ISNT_OPEN, NULL, NULL, MB_OK);

	return false;
}

//

void cccddContacts::buildEmailStruct(bool bNew)
{
	try
	{
		try
		{					
			while ( !m_contactsEmailSL.IsEmpty() )
				delete m_contactsEmailSL.RemoveHead();			

			if (bNew)
			{
				sContactsEmail * ptrContactsEmail = new sContactsEmail;
				
				ptrContactsEmail->strComment	  = "Home";
				ptrContactsEmail->strEmailAdress  = "";
				ptrContactsEmail->bPlainText	  = false;
				ptrContactsEmail->bNew			  = true;
				ptrContactsEmail->bCantDelete	  = true;
				ptrContactsEmail->bDeletedRecord  = false;
				ptrContactsEmail->bChanged		  = false;
				m_contactsEmailSL.AddTail( ptrContactsEmail );

				ptrContactsEmail = new sContactsEmail;
				ptrContactsEmail->strComment	  = "Business";
				ptrContactsEmail->strEmailAdress  = "";
				ptrContactsEmail->bPlainText	  = false;
				ptrContactsEmail->bNew			  = true;
				ptrContactsEmail->bCantDelete	  = true;
				ptrContactsEmail->bDeletedRecord  = false;
				ptrContactsEmail->bChanged		  = false;
				m_contactsEmailSL.AddTail( ptrContactsEmail );
			}
			else
			{
				ADODB::_RecordsetPtr PopSet;						
				ccString strSQL;	

				strSQL << "SELECT [Comment], [EmailAdress], [SendUsingPlainText] ";
				strSQL << "FROM dtfContactsEmail ";
				strSQL << "WHERE MProjectID = " << m_MProjectID;
				strSQL << " AND  ItemID =  "    << m_ItemID;

				if ( getDB()->getRS(strSQL, PopSet) )							
				{
					while(!PopSet->adoEOF)
					{		
						sContactsEmail * ptrContactsEmail = new sContactsEmail;

						ptrContactsEmail->strComment	  = (char*)(_bstr_t)PopSet->Fields->Item[_variant_t(0l)]->Value;
						ptrContactsEmail->strEmailAdress = (char*)(_bstr_t)PopSet->Fields->Item[_variant_t(1l)]->Value;
						ptrContactsEmail->bPlainText	  = PopSet->Fields->Item[_variant_t(2l)]->Value;

						ptrContactsEmail->bNew			  = false;
						ptrContactsEmail->bDeletedRecord  = false;				
						ptrContactsEmail->bChanged		  = false;

						if ( (ptrContactsEmail->strComment == "Home") || (ptrContactsEmail->strComment == "Business") )
							ptrContactsEmail->bCantDelete	  = true;
						else
							ptrContactsEmail->bCantDelete	  = false;
						
						m_contactsEmailSL.AddTail( ptrContactsEmail );
						
						PopSet->MoveNext();						
					}

					PopSet->Close();					
				}			
			} // if(bNew)
		}
		catch(_com_error &e) 
		{ 
			ccErr(getProviderError( getDB()->getConnection()) );
			ccThrowccException( getProviderError( getDB()->getConnection()) ); /*Delete unreference warning*/ (void*)&e; 				
		}	
	}
	catch( ccException * e)
	{
		ccErr( *e, "", "", MB_OK );			
	}
	catch(...)
	{
		ccErrEM( IDS_CANT_RETRIVE_CONTACTS, NULL, NULL, MB_OK );
	}
}

//

void cccddContacts::saveEmailStruct()
{
	try
	{
		while ( !m_contactsEmailSL.IsEmpty() )
		{
			sContactsEmail * ptrContactsEmail = (sContactsEmail *)m_contactsEmailSL.RemoveHead();	
			
			if ( ptrContactsEmail->bNew)
				getDB()->insert_dtfContactsEmail( m_MProjectID, m_ItemID, ptrContactsEmail->strComment);

			if ( ptrContactsEmail->bDeletedRecord)
				getDB()->delete_dtfContactsEmail( m_MProjectID, m_ItemID, ptrContactsEmail->strComment);
			
			if ( ptrContactsEmail->bChanged)
				getDB()->update_dtfContactsEmail(m_MProjectID, m_ItemID, ptrContactsEmail->strComment,
												 ptrContactsEmail->strEmailAdress, ptrContactsEmail->bPlainText);

			delete ptrContactsEmail;		
		}

	}
	catch( ccException * e)
	{
		ccErr( *e, "", "", MB_OK );			
	}
	catch(...)
	{
		ccErrEM( IDS_UNKNOWN_ERROR, NULL, NULL, MB_OK );
	}
}

//

void cccddContacts::buildPhoneStruct(bool bNew)
{
	try
	{
		try
		{					
			while ( !m_contactsPhoneSL.IsEmpty() )
				delete m_contactsPhoneSL.RemoveHead();			

			if (bNew)
			{
				sContactsPhone * ptrContactsPhone = new sContactsPhone;
				
				ptrContactsPhone->strPhoneName	  = "Home";				
				ptrContactsPhone->strNumber		  = "";				
				ptrContactsPhone->bNew			  = true;
				ptrContactsPhone->bCantDelete	  = true;
				ptrContactsPhone->bDeletedRecord  = false;
				ptrContactsPhone->bChanged		  = false;
				m_contactsPhoneSL.AddTail( ptrContactsPhone );

				ptrContactsPhone = new sContactsPhone;				
				ptrContactsPhone->strPhoneName	  = "Business";				
				ptrContactsPhone->strNumber		  = "";				
				ptrContactsPhone->bNew			  = true;
				ptrContactsPhone->bCantDelete	  = true;
				ptrContactsPhone->bDeletedRecord  = false;
				ptrContactsPhone->bChanged		  = false;
				m_contactsPhoneSL.AddTail( ptrContactsPhone );

				ptrContactsPhone = new sContactsPhone;				
				ptrContactsPhone->strPhoneName	  = "Fax";				
				ptrContactsPhone->strNumber		  = "";				
				ptrContactsPhone->bNew			  = true;
				ptrContactsPhone->bCantDelete	  = true;
				ptrContactsPhone->bDeletedRecord  = false;
				ptrContactsPhone->bChanged		  = false;
				m_contactsPhoneSL.AddTail( ptrContactsPhone );
			}
			else
			{
				ADODB::_RecordsetPtr PopSet;						
				ccString strSQL;	

				strSQL << "SELECT [PhoneName], [Number]";
				strSQL << "FROM dtfContactsPhone ";
				strSQL << "WHERE MProjectID = " << m_MProjectID;
				strSQL << " AND  ItemID =  "    << m_ItemID;

				if ( getDB()->getRS(strSQL, PopSet) )							
				{
					while(!PopSet->adoEOF)
					{		
						sContactsPhone * ptrContactsPhone = new sContactsPhone;

						ptrContactsPhone->strPhoneName	  = (char*)(_bstr_t)PopSet->Fields->Item[_variant_t(0l)]->Value;
						ptrContactsPhone->strNumber       = (char*)(_bstr_t)PopSet->Fields->Item[_variant_t(1l)]->Value;						

						ptrContactsPhone->bNew			  = false;
						ptrContactsPhone->bDeletedRecord  = false;				
						ptrContactsPhone->bChanged		  = false;

						if ( (ptrContactsPhone->strPhoneName == "Home") || (ptrContactsPhone->strPhoneName== "Business") || (ptrContactsPhone->strPhoneName == "Fax") )
							ptrContactsPhone->bCantDelete	  = true;
						else
							ptrContactsPhone->bCantDelete	  = false;
						
						m_contactsPhoneSL.AddTail( ptrContactsPhone );
						
						PopSet->MoveNext();						
					}

					PopSet->Close();					
				}			
			} // if(bNew)
		}
		catch(_com_error &e) 
		{ 
			ccErr(getProviderError( getDB()->getConnection()) );
			ccThrowccException( getProviderError( getDB()->getConnection()) ); /*Delete unreference warning*/ (void*)&e; 				
		}	
	}
	catch( ccException * e)
	{
		ccErr( *e, "", "", MB_OK );			
	}
	catch(...)
	{
		ccErrEM( IDS_CANT_RETRIVE_CONTACTS, NULL, NULL, MB_OK );
	}
}

//

void cccddContacts::savePhoneStruct()
{
	try
	{
		while ( !m_contactsPhoneSL.IsEmpty() )
		{
			sContactsPhone * ptrContactsPhone = (sContactsPhone *)m_contactsPhoneSL.RemoveHead();	
			
			if ( ptrContactsPhone->bNew)
				getDB()->insert_dtfContactsPhone( m_MProjectID, m_ItemID, ptrContactsPhone->strPhoneName);

			if ( ptrContactsPhone->bDeletedRecord)
				getDB()->delete_dtfContactsPhone( m_MProjectID, m_ItemID, ptrContactsPhone->strPhoneName);
			
			if ( ptrContactsPhone->bChanged)
				getDB()->update_dtfContactsPhone(m_MProjectID, m_ItemID, ptrContactsPhone->strPhoneName,
												 ptrContactsPhone->strNumber);

			delete ptrContactsPhone;		
		}

	}
	catch( ccException * e)
	{
		ccErr( *e, "", "", MB_OK );			
	}
	catch(...)
	{
		ccErrEM( IDS_UNKNOWN_ERROR, NULL, NULL, MB_OK );
	}
}

