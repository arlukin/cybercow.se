// ccFrameWnd.h : header file
//
/////////////////////////////////////////////////////////////////////////////

#ifndef __CFRAMEWND_H__
#define __CFRAMEWND_H__

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// ccFrameWnd class

class ccFrameWnd : public CCJFrameWnd
{
	DECLARE_DYNAMIC(ccFrameWnd)

// Construction
public:
	ccFrameWnd();

	virtual ~ccFrameWnd();

// Attributes
private:
	CString m_regPath;
	CString m_placmentName;


// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(ccFrameWnd)
	//}}AFX_VIRTUAL

// Implementation
public:
	void setWinPlacementRegPath( LPCSTR sRegPath, LPCSTR sPlacementName);

private:
	void saveWindowPlacement();
	void loadWindowPlacement();
	

// Generated message map functions
protected:
	//{{AFX_MSG(ccFrameWnd)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnMove(int x, int y);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // __CFRAMEWND_H__

