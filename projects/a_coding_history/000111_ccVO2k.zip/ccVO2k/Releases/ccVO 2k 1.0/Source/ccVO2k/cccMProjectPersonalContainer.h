#if !defined(AFX_CCCMPROJECTPERSONALCONTAINER_H__EE01EC31_2FE9_11D4_823D_0001020E90A5__INCLUDED_)
#define AFX_CCCMPROJECTPERSONALCONTAINER_H__EE01EC31_2FE9_11D4_823D_0001020E90A5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// cccMProjectPersonalContainer.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// cccMProjectPersonalContainer form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class cccMProjectPersonalContainer : public CFormView
{
protected:
	cccMProjectPersonalContainer();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(cccMProjectPersonalContainer)

// Form Data
public:
	//{{AFX_DATA(cccMProjectPersonalContainer)
	enum { IDD = IDD_MPROJECT_CONTAINER };
	CStatic	m_bitmap;	
	//}}AFX_DATA

	// Admin Buttons
	CButton m_clearDataBase;

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(cccMProjectPersonalContainer)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~cccMProjectPersonalContainer();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(cccMProjectPersonalContainer)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);	
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	afx_msg void OnClearDataBase();
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CCCMPROJECTPERSONALCONTAINER_H__EE01EC31_2FE9_11D4_823D_0001020E90A5__INCLUDED_)
