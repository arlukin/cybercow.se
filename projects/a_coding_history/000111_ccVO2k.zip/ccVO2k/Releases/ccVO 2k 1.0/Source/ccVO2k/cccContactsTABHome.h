#if !defined(AFX_CCCCONTACTSTABHOME_H__0D5ABD57_0A2D_11D4_89A4_00609708DCFE__INCLUDED_)
#define AFX_CCCCONTACTSTABHOME_H__0D5ABD57_0A2D_11D4_89A4_00609708DCFE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// cccContactsTABHome.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// cccContactsTABHome dialog

class cccContactsTABHome : public ccdbDialog
{
// Construction
public:
	// standard constructor
	//
	cccContactsTABHome(CWnd *pParent, cccVODB *aoDB);
// Dialog Data
	//{{AFX_DATA(cccContactsTABHome)
	enum { IDD = IDD_CONTACTS_TAB_HOME };
	CAnimateCtrl	m_homeJump;
	//}}AFX_DATA
	ccdbSuperCtrl	m_Home_Street;
	ccdbSuperCtrl	m_Home_City;
	ccdbSuperCtrl	m_Home_State_Or_Province;
	ccdbSuperCtrl	m_Home_Zip_Or_PostalCode;
	ccdbSuperCtrl	m_Home_Country_Or_Region;		
	ccdbSuperCtrl	m_Spouse_s_Name;
	ccdbSuperCtrl	m_SpousesInterests;
	ccdbSuperCtrl	m_Aniversary;
	ccdbSuperCtrl	m_ChildrenNames;
	ccdbSuperCtrl	m_Personal_Web_Page;
	ccdbSuperCtrl	m_Personal_FTP_Page;
	ccdbSuperCtrl	m_Personal_Notes;
	ccdbSuperCtrl	m_PhotoGraph;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(cccContactsTABHome)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(cccContactsTABHome)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CCCCONTACTSTABHOME_H__0D5ABD57_0A2D_11D4_89A4_00609708DCFE__INCLUDED_)
