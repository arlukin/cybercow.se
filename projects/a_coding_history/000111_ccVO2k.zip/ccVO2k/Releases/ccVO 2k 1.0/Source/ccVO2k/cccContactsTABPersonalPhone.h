#if !defined(AFX_CCCCONTACTSTABPERSONALPHONE_H__01B7E86D_2506_11D4_89A6_00609708DCFE__INCLUDED_)
#define AFX_CCCCONTACTSTABPERSONALPHONE_H__01B7E86D_2506_11D4_89A6_00609708DCFE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// cccContactsTABPersonalPhone.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// cccContactsTABPersonalPhone dialog

class cccContactsTABPersonalPhone : public ccllGroup, public ccdbCtrl
{
// Construction
public:
	cccContactsTABPersonalPhone(CWnd* pParent = NULL);   // standard constructor

	// Tell which Phone Group this class is.. There is 3 diffrent...
	//
	void setPhoneGroup(int nPhoneGroup)			{ m_nPhoneGroup = nPhoneGroup;	};

private:
	int m_nPhoneGroup;			// See setPhoneGroup

// Dialog Data
	//{{AFX_DATA(cccContactsTABPersonalPhone)
	enum { IDD = IDD_CONTACTS_TAB_PERSONAL_PHONE };
	CString	m_phoneName;
	CString	m_phoneNumber;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(cccContactsTABPersonalPhone)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	void displayFirstRecInList();

	// Build the menu who will be shown when pressing
	// Menu button.
	//
	void OnBuildMenu(ccMenuButton *menuButton);

	//
	//
	void OnNewItem();

	//
	//
	void OnDeleteItem();

	//
	//
	void OnChangedItem(bool bSave );

	bool refresh() { displayFirstRecInList(); return true;};

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(cccContactsTABPersonalPhone)
	virtual BOOL OnInitDialog();
	afx_msg void OnChangePhoneName();
	afx_msg void OnChangePhoneNumber();
	afx_msg void OnKillfocusPhoneNumber();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CCCCONTACTSTABPERSONALPHONE_H__01B7E86D_2506_11D4_89A6_00609708DCFE__INCLUDED_)
