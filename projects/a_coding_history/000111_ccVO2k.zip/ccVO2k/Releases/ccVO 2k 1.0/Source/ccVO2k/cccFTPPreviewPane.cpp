// cccFTPPreviewPane.cpp : implementation file
//

#include "stdafx.h"
#include "ccvo2k.h"

#include "cccFTPPreviewPane.h"
#include "cccFTPTABGeneral.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccFTPPreviewPane

IMPLEMENT_DYNCREATE(cccFTPPreviewPane, ccTabView)

cccFTPPreviewPane::cccFTPPreviewPane()
{
	setDB( new cccVODB );
}

cccFTPPreviewPane::~cccFTPPreviewPane()
{
	try
	{
		try
		{
			// *WIN 98 * Need to delete the ctrls before the database
			if ( getTabCtrl())		
				getTabCtrl()->removeAll();

			delete getDB();
		}
		catch(_com_error &e) 
		{ 
			ccThrowccException( getComError(e) ); /*Disable unreference warning*/ (void*)&e; 
		}		
	}
	catch(ccException *e) 
	{
		ccErr(*e,"","", MB_OK);	
	}	
	catch(...) 
	{
		ccErr("DB Error", "","", MB_OK);		
	}
}


BEGIN_MESSAGE_MAP(cccFTPPreviewPane, ccTabView)
	//{{AFX_MSG_MAP(cccFTPPreviewPane)
	ON_COMMAND(ID_SAVE_AND_CLOSE, OnSaveAndClose)
	ON_WM_CREATE()
	ON_COMMAND(ID_SAVE, OnSave)	
	ON_COMMAND(IDM_DELETE_ITEM, OnDeleteItem)
	ON_COMMAND(ID_LAST_ITEM, OnLastItem)
	ON_COMMAND(ID_FIRST_ITEM, OnFirstItem)
	ON_COMMAND(ID_NEXT_ITEM, OnNextItem)
	ON_COMMAND(ID_PREVIOUS_ITEM, OnPreviousItem)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cccFTPPreviewPane drawing

void cccFTPPreviewPane::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// cccFTPPreviewPane diagnostics

#ifdef _DEBUG
void cccFTPPreviewPane::AssertValid() const
{
	ccTabView::AssertValid();
}

void cccFTPPreviewPane::Dump(CDumpContext& dc) const
{
	ccTabView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// cccFTPPreviewPane message handlers

BOOL cccFTPPreviewPane::PreCreateWindow(CREATESTRUCT& cs) 
{
	cs.style &= ~WS_BORDER;
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;

	return ccTabView::PreCreateWindow(cs);
}

//

void cccFTPPreviewPane::OnSaveAndClose() 
{	
	if (theCCVOClient->getCurrentGridCtrl())
		dd( m_ddFTP )->bindNonDBCtrls( theCCVOClient->getCurrentGridCtrl() );

	if ( dd( m_ddFTP )->saveRecord() == CCSUCCEDED)
		GetParent()->SendMessage(WM_CLOSE);
		// No need to remove the ctrl from the contacts DD. When sending WM_CLOSE
		// cause it's removed in the destructor
	else	
		if (theCCVOClient->getCurrentGridCtrl())
			dd( m_ddFTP )->removeNonDBCtrls( theCCVOClient->getCurrentGridCtrl() );		

}

//

void cccFTPPreviewPane::OnSave() 
{
	if (theCCVOClient->getCurrentGridCtrl())
		dd( m_ddFTP )->bindNonDBCtrls( theCCVOClient->getCurrentGridCtrl() );

	dd( m_ddFTP )->saveRecord();		

	if (theCCVOClient->getCurrentGridCtrl())
		dd( m_ddFTP )->removeNonDBCtrls( theCCVOClient->getCurrentGridCtrl() );		
}


//

void cccFTPPreviewPane::OnInitialUpdate() 
{
	ccTabView::OnInitialUpdate();		
}

//

void cccFTPPreviewPane::OnDeleteItem() 
{
	CString strDeleteFavorite; strDeleteFavorite.LoadString( IDS_DELETE_FTP );
	CString strConfirm; strConfirm.LoadString( IDS_CONFIRM_DELETE_ITEM );
	if ( MessageBox( strDeleteFavorite, strConfirm, MB_YESNO ) == IDYES  )
	{
		dd( m_ddFTP )->deleteFTP( dd( m_ddFTP )->m_MProjectID, dd( m_ddFTP )->m_ParentItemID, dd( m_ddFTP )->m_ItemID);
		Sleep(1000);		
		dd( m_ddFTP )->requery();						
		if (theCCVOClient->getCurrentGridCtrl())
			theCCVOClient->getCurrentGridCtrl()->OnDeleteComplete();
	}
}

//

void cccFTPPreviewPane::OnLastItem() 
{
	dd( m_ddFTP )->moveLast();
}

//

void cccFTPPreviewPane::OnFirstItem() 
{
	dd( m_ddFTP )->moveFirst();
}

//

void cccFTPPreviewPane::OnNextItem() 
{
	dd( m_ddFTP )->moveNext();
}

//

void cccFTPPreviewPane::OnPreviousItem() 
{
	dd( m_ddFTP )->movePrev();	
}

//

int cccFTPPreviewPane::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (ccTabView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// If the view is used by the ccVOViewer
	try
	{
		int nMProjectID;
		int nItemID;
		nMProjectID = theCCVOClient->getSelLeafMProjectID();

		if ( theCCVOClient->getFunctionType() == cIXFTP )
			nItemID = theCCVOClient->getSelLeafItemID();
		else
			nItemID = cIXFTP;		

		// Create a new database.		
		dd( m_ddFTP )->setSelLeafMProjectID(nMProjectID);
		dd( m_ddFTP )->setSelLeafItemID( nItemID ); 

		ccString strFilter;
		strFilter << "MProjectID = "		  << nMProjectID << " and ";
		strFilter << "dtTreeOrder.ItemID = "  << nItemID;
		dd( m_ddFTP )->getRS()->Filter = (_bstr_t)strFilter;

		if (theCCVOClient->getSelGridItemID() != -1)
		{						
			dd( m_ddFTP )->moveFirst();
			
			if ( !dd( m_ddFTP )->isEmpty() )
			{
				ccString strCriteria;
				strCriteria << "dtfFTP.ItemID = " << theCCVOClient->getSelGridItemID();
				dd( m_ddFTP )->find( strCriteria);
			}
		}
		// If the view is used by the CMainFrame
		else
			dd( m_ddFTP )->clearRecord( true );					
	
		getTabCtrl()->InsertItem( 0, "General", new cccFTPTABGeneral( getTabCtrl(), __getDB() ) );
	}
	catch(_com_error &e) 
	{ 
		ccErr(getComError(e),"","", MB_OK );				
	}	
	
	return 0;
}