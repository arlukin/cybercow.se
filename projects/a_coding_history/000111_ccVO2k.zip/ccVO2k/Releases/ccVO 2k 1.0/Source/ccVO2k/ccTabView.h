#if !defined(AFX_CCTABVIEW_H__070833F6_0A1F_11D4_89A4_00609708DCFE__INCLUDED_)
#define AFX_CCTABVIEW_H__070833F6_0A1F_11D4_89A4_00609708DCFE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ccTabView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// ccTabView view

class ccTabView : public CScrollView
{
protected:
	ccTabView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(ccTabView)

// Attributes
public:
	ccTabCtrl * getTabCtrl()			{ return &m_tab;							};

	void setSize(CSize aSize)			{ m_size = aSize;							};
	CSize getSize()						{ return m_size;							};
private:
	ccTabCtrl	m_tab;

	CSize m_size;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(ccTabView)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~ccTabView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(ccTabView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CCTABVIEW_H__070833F6_0A1F_11D4_89A4_00609708DCFE__INCLUDED_)
