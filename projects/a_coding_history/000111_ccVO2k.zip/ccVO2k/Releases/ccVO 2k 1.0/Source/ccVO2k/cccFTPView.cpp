// cccFTPView.cpp : implementation file
//

#include "stdafx.h"
#include "ccvo2k.h"
#include "cccFTPView.h"
#include "cccVOEditor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccFTPView

IMPLEMENT_DYNCREATE(cccFTPView, CFormView)

cccFTPView::cccFTPView()
	: CFormView(cccFTPView::IDD)
{
	//{{AFX_DATA_INIT(cccFTPView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

cccFTPView::~cccFTPView()
{
}

void cccFTPView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(cccFTPView)
	DDX_Control(pDX, ID_FTP_GRID, m_grid);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(cccFTPView, CFormView)
	//{{AFX_MSG_MAP(cccFTPView)
	ON_WM_SIZE()
	ON_NOTIFY(NM_DBLCLK, ID_FTP_GRID, OnDblclkFTPGrid)
	ON_NOTIFY(NM_RETURN, ID_FTP_GRID, OnReturnFTPGrid)	
	ON_NOTIFY(LVN_KEYDOWN, ID_FTP_GRID, OnKeydownFTPGrid)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cccFTPView diagnostics

#ifdef _DEBUG
void cccFTPView::AssertValid() const
{
	CFormView::AssertValid();
}

void cccFTPView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// cccFTPView message handlers

void cccFTPView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);

	if (::IsWindow(m_grid.m_hWnd) )
		m_grid.SetWindowPos(NULL, 0, 0, cx, cy,  SWP_NOZORDER );	
}

//

void cccFTPView::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();

	theCCVOClient->setCurrentGridCtrl(this);

	setDB( theCCVOClient->m_dataBase );

	// Set the size of the listCtrl so it will fill the FormView.
	CRect lpRect;
	GetClientRect( lpRect );
	m_grid.SetWindowPos(NULL, 0, 0, lpRect.Width(), lpRect.Height(),  SWP_NOZORDER );		

	m_grid.SetExtendedStyle(LVS_EX_FULLROWSELECT | 
				 LVS_EX_ONECLICKACTIVATE | 
				 LVS_EX_UNDERLINEHOT );

	for(int nCol = 3;nCol>-1;nCol--)
		m_grid.DeleteColumn( nCol);

	m_grid.InsertColumn(0, "Name",		LVCFMT_LEFT, 100,0);
	m_grid.InsertColumn(1, "URL",		LVCFMT_LEFT, 100,1);
	m_grid.InsertColumn(2, "Notes",		LVCFMT_LEFT, 300,2);	

	fillGrid();
}

//

void cccFTPView::fillGrid()
// Move the sql question to ccVOClient..
// and make a forward only recordset.... 
{
	m_grid.DeleteAllItems();	

	if ( theCCVOClient->m_dataBase )	
	{
		try
		{
			ADODB::_RecordsetPtr PopSet;						
			try
			{
				ccString strSQL;	

				strSQL << "SELECT dtfFTP.ItemID, ";
				strSQL << "dtfFTP.[Name], dtfFTP.[URL], dtfFTP.[Notes] ";
				strSQL << "FROM dtfFTP, dtItems, dtTreeOrder ";
				strSQL << "WHERE dtfFTP.MProjectID = dtTreeOrder.MProjectID AND ";
				strSQL << "    dtfFTP.ItemID = dtTreeOrder.ChildID AND ";
				strSQL << "    dtItems.MProjectID = dtTreeOrder.MProjectID AND ";
				strSQL << "    dtItems.ItemID = dtTreeOrder.ChildID AND ";
				strSQL << "    dtTreeOrder.MProjectID = " << theCCVOClient->getSelLeafMProjectID() << " AND";
				strSQL << "    dtTreeOrder.ItemID =      "<< theCCVOClient->getSelLeafItemID();	

				if ( theCCVOClient->m_dataBase->getRS(strSQL, PopSet) )							
				{							
					while(!PopSet->adoEOF)
					{					
						insertRow( (long)PopSet->Fields->Item[_variant_t(0l)]->Value,
							(char*)(_bstr_t)PopSet->Fields->Item[_variant_t(1l)]->Value,
							(char*)(_bstr_t)PopSet->Fields->Item[_variant_t(2l)]->Value, 
							(char*)(_bstr_t)PopSet->Fields->Item[_variant_t(3l)]->Value);
						
						PopSet->MoveNext();						
					}

					PopSet->Close();					
				}			
				return ;
			}
			catch(_com_error &e) 
			{ 
				ccErr(getProviderError( theCCVOClient->m_dataBase->getConnection()) );
				ccThrowccException( getProviderError( theCCVOClient->m_dataBase->getConnection()) ); /*Delete unreference warning*/ (void*)&e; 				
			}	
		}
		catch( ccException * e)
		{
			ccErr( *e, "", "", MB_OK );			
		}
		catch(...)
		{
			ccErrEM( IDS_CANT_RETRIVE_FTP, NULL, NULL, MB_OK );
		}
	}
	else
		ccErrEM( IDS_DATABASE_ISNT_OPEN, NULL, NULL, MB_OK);	
}

//

void cccFTPView::insertRow(int nRow, LPCSTR strName, LPCSTR strURL, LPCSTR strNotes)
{
	LVITEM item;	
	item.mask = LVIF_TEXT;
	item.iItem = nRow;
	item.iSubItem = 0;
	
	//item.cchTextMax  =100;
	item.pszText = new char[100];
	strcpy(item.pszText, strName);	

	item.iItem = m_grid.InsertItem(&item);	
	m_grid.SetItemData( item.iItem, nRow );
	
	item.iSubItem = 1; strcpy(item.pszText, strURL);
	m_grid.SetItem(&item);

	item.iSubItem = 2; strcpy( item.pszText, strNotes);	
	m_grid.SetItem(&item);
}

//

void cccFTPView::OnDblclkFTPGrid(NMHDR* pNMHDR, LRESULT* pResult) 
{
	openSelectedFTP();	
	*pResult = 0;
}

//

void cccFTPView::OnReturnFTPGrid(NMHDR* pNMHDR, LRESULT* pResult) 
{
	openSelectedFTP();	
	*pResult = 0;
}

//

void cccFTPView::openSelectedFTP()
{
	POSITION pos = m_grid.GetFirstSelectedItemPosition();
	if (pos != NULL)
	{
		int nItem = m_grid.GetNextSelectedItem(pos);
		int nItemData = m_grid.GetItemData( nItem );
		theCCVOClient->setSelGridItemID( nItemData);
	}
	else
		theCCVOClient->setSelGridItemID( -1);

	cccVOEditor* pFrame = new cccVOEditor(CCVO_FTP_MODE, AfxGetMainWnd());

	theCCVOClient->setSelGridItemID( -1);
}

//

void cccFTPView::OnKeydownFTPGrid(NMHDR* pNMHDR, LRESULT* pResult) 
{
	LV_KEYDOWN* pLVKeyDow = (LV_KEYDOWN*)pNMHDR;
	
	if ( pLVKeyDow->wVKey == VK_DELETE)
	{
		CString strDeleteFTP; strDeleteFTP.LoadString( IDS_DELETE_FTP );
		CString strConfirm; strConfirm.LoadString( IDS_CONFIRM_DELETE_ITEM );
		if ( MessageBox( strDeleteFTP, strConfirm, MB_YESNO ) == IDYES  )
		{
			POSITION pos = m_grid.GetFirstSelectedItemPosition();
			if (pos == NULL)
			   TRACE0("No items to delete!\n");
			else
			{
			   while (pos)
			   {
					int nItem = m_grid.GetNextSelectedItem(pos);
					// TODO Maybe move this to DeleteItem.
	  				dd( m_ddFTP )->deleteFTP( theCCVOClient->getSelLeafMProjectID(), theCCVOClient->getSelLeafItemID(), m_grid.GetItemData( nItem ) );
					m_grid.DeleteItem( nItem );			  
			   }
			}					
		}
	}
	
	*pResult = 0;
}
