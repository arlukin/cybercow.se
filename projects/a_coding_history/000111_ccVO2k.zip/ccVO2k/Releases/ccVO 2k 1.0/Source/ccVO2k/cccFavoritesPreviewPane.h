#if !defined(AFX_CCCFAVORITESPREVIEWPANE_H__0C9A87EB_281B_11D4_89A6_00609708DCFE__INCLUDED_)
#define AFX_CCCFAVORITESPREVIEWPANE_H__0C9A87EB_281B_11D4_89A6_00609708DCFE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// cccFavoritesPreviewPane.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// cccFavoritesPreviewPane view

class cccFavoritesPreviewPane : public ccTabView
{
protected:
	cccFavoritesPreviewPane();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(cccFavoritesPreviewPane)

// Attributes
public:
	//
	//
	cccVODB* __getDB(void)			 { return m_oDB;				};
	void setDB( cccVODB* aoCCVO)	 { m_oDB = aoCCVO;				};

private:
	cccVODB  *m_oDB;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(cccFavoritesPreviewPane)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~cccFavoritesPreviewPane();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(cccFavoritesPreviewPane)
	afx_msg void OnSaveAndClose();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSave();	
	afx_msg void OnDeleteItem();
	afx_msg void OnLastItem();
	afx_msg void OnFirstItem();
	afx_msg void OnNextItem();
	afx_msg void OnPreviousItem();
	afx_msg void OnSuftToFavoriteWith();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CCCFAVORITESPREVIEWPANE_H__0C9A87EB_281B_11D4_89A6_00609708DCFE__INCLUDED_)
