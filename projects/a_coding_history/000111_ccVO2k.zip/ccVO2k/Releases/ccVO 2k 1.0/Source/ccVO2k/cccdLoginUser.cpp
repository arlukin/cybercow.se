// cccdLoginUser.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"

#include "ccVOClient.h"

#include "cccdLoginUser.h"

// Reg new user includes
#include "TransferStructs.h"
#include "cccdRegUsr1Licence.h"
#include "cccdRegUsr2General.h"
#include "cccdRegUsr3Functions.h"
#include "cccdRegUsr4Security.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccdLoginUser dialog


cccdLoginUser::cccdLoginUser(CWnd* pParent /*=NULL*/)
	: CDialog(cccdLoginUser::IDD, pParent)
{
	//{{AFX_DATA_INIT(cccdLoginUser)
	m_userName = _T("");
	m_password = _T("");
	m_bSavePassword = FALSE;
	m_bAutoLogin = FALSE;
	//}}AFX_DATA_INIT
}


void cccdLoginUser::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(cccdLoginUser)
	DDX_Control(pDX, IDC_SAVE_PASSWORD, m_ctrlAutoLogin);
	DDX_Text(pDX, IDC_LOGIN_USER_NAME, m_userName);
	DDX_Text(pDX, IDC_LOGIN_PASSWORD, m_password);
	DDX_Check(pDX, IDC_SAVE_PASSWORD, m_bSavePassword);
	DDX_Check(pDX, IDC_AUTOLOGIN, m_bAutoLogin);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(cccdLoginUser, CDialog)
	//{{AFX_MSG_MAP(cccdLoginUser)
	ON_BN_CLICKED(IDC_NEW_USER, OnNewUser)
	ON_BN_CLICKED(IDC_AUTOLOGIN, OnAutologin)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cccdLoginUser message handlers

void cccdLoginUser::OnOK() 
{
	// Check so user has entered a user name and password.
	UpdateData();
	if ( m_userName.IsEmpty() )
	{
		MessageBox("You must enter a UserName", "Error");
		return;
	}

	if ( m_password.IsEmpty() )
	{
		MessageBox("You must enter a password", "Error");
		return;
	}
	
	CDialog::OnOK();
}

void cccdLoginUser::OnAutologin() 
{
	UpdateData();
	if ( m_bAutoLogin )
	{
		m_ctrlAutoLogin.SetCheck( TRUE );
		m_ctrlAutoLogin.EnableWindow( FALSE );
	}
	else
	{
		m_ctrlAutoLogin.EnableWindow( TRUE);
	}	
}

void cccdLoginUser::OnNewUser() 
{	
	sRegUsr loRegUsr;
	loRegUsr.initNewUser();

	CPropertySheet		 oRegNewUsr;
	cccdRegUsr1Licence   oRegNewUsrLicence;   
	cccdRegUsr2General	 oRegNewUsrGeneral;   
	cccdRegUsr3Functions oRegNewUsrFunctions;
	cccdRegUsr4Security  oRegNewUsrSecurity;
	
	oRegNewUsrLicence.setRegUsr(&loRegUsr);   
	oRegNewUsrGeneral.setRegUsr(&loRegUsr);   
	oRegNewUsrFunctions.setRegUsr(&loRegUsr);   
	oRegNewUsrSecurity.setRegUsr(&loRegUsr);   

	// Setup the Proerty sheet
	oRegNewUsr.SetWizardMode();	
	oRegNewUsr.AddPage( &oRegNewUsrLicence );
	oRegNewUsr.AddPage( &oRegNewUsrGeneral );
	// *** Not supported in this version **** oRegNewUsr.AddPage( &oRegNewUsrFunctions );
	// *** Not supported in this version **** oRegNewUsr.AddPage( &oRegNewUsrSecurity );

	for(;;)
	{
		if ( oRegNewUsr.DoModal() == ID_WIZFINISH  )
		{
			if ( m_theCCVOClient->createUser( loRegUsr ) )
				return;
		}
		else
			return;
	}	
}
