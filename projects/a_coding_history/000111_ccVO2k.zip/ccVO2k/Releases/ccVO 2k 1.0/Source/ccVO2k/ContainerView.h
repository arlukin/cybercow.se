#if !defined(AFX_CONTAINERVIEW_H__B5AA1D88_F4FE_11D3_899E_00609708DCFE__INCLUDED_)
#define AFX_CONTAINERVIEW_H__B5AA1D88_F4FE_11D3_899E_00609708DCFE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ContainerView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CContainerView view

class CContainerView : public CView
{
// *** Construction / Destruction
protected:
	// Default constructor
	//
	CContainerView();           // protected constructor used by dynamic creation

	DECLARE_DYNCREATE(CContainerView)

	// Default destructor
	//
	virtual ~CContainerView();

// *** GFX Attributes
public:
	// Caption Window
	CCJCaption			m_Caption;
	CFont				m_CaptionFont;
	HICON				m_hIcon;

	// Splitters
	CCJFlatSplitterWnd	m_wndSplitter;

// *** Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CContainerView)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// *** Generated message map functions
protected:
	//{{AFX_MSG(CContainerView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG

	// Caption message map functions
	afx_msg void OnCloseFolderListView(UINT lParam, LONG wParam);
	afx_msg void OnPushPinButton(UINT lParam, LONG wParam);
	afx_msg void OnPushPinCancel(UINT lParam, LONG wParam);

	DECLARE_MESSAGE_MAP()

// *** Debug members
protected:
	
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONTAINERVIEW_H__B5AA1D88_F4FE_11D3_899E_00609708DCFE__INCLUDED_)
