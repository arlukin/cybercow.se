// ccVOClient.cpp: implementation of the ccVOClient class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "resource.h"

#include "ccVOClient.h"
#include "cccVODB.h"

#include "cccdLoginUser.h"

#include "transferStructs.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// *** Construction / Destruction
//////////////////////////////////////////////////////////////////////

ccVOClient::ccVOClient()
{
	m_started = false;
	setCurrentGridCtrl( NULL );
	setSelGridItemID(-1);

	try
	{
		// Initialize COM
		if(FAILED(::CoInitialize(NULL)))
		{
			ccErrEM( IDS_COM_FAILED );		
			return ;
		}
			
		m_dataBase = new cccVODB();
		if (m_dataBase == NULL )
		{
			ccErrEM( IDS_COM_FAILED );		
			return ;
		}
	}
	catch(...)
	{
		ccErrEM( IDS_GENERAL_CCVOVCLIENT_ERROR );		
		return;
	}

}

//

ccVOClient::~ccVOClient()
{
	if (m_dataBase)
		delete m_dataBase;
	// Disconnect COM
	::CoUninitialize();
}

//////////////////////////////////////////////////////////////////////
// *** Login/Logout functions
//////////////////////////////////////////////////////////////////////

bool ccVOClient::login()
{
	CWinApp* pApp = AfxGetApp();

	int lbAutoLogin, lbSavePassword;
	CString lsUserName, lsPassword;	
	lbAutoLogin	   = pApp->GetProfileInt("Settings", "AutoLogin", 0);
	lbSavePassword = pApp->GetProfileInt("Settings", "SavePassword", 0);
	lsUserName     = pApp->GetProfileString("Settings", "UserName","");
	lsPassword     = pApp->GetProfileString("Settings", "PassWord","");	//TODO Need to encrypt or maybe place in windows password file

	if (lsUserName.IsEmpty())
		lbAutoLogin = 0;	

	for (;;)
	{
		switch (lbAutoLogin)
		{
		default:
			{
				CString strWrongKeyValue;
				strWrongKeyValue.LoadString( IDS_WRONG_REGKEY_VALUE_AUTOLOGIN );

				CString strRegistryError;
				strRegistryError.LoadString( IDS_REGISTRY_ERROR );
				MessageBox(NULL, strWrongKeyValue, strRegistryError, NULL);
				lbAutoLogin = 0;
			}

		case 0:	
			{		
				// Ask user for login name and password.
				cccdLoginUser odLoginUser;
				
				odLoginUser.m_userName		= lsUserName;
				odLoginUser.m_bAutoLogin    = lbAutoLogin;
				odLoginUser.m_bSavePassword = lbSavePassword;
				if ( lbSavePassword )
					odLoginUser.m_password = lsPassword;

				odLoginUser.m_theCCVOClient = this;

				if ( odLoginUser.DoModal() == IDOK )
				{
					lsUserName = odLoginUser.m_userName;
					lsPassword = odLoginUser.m_password;
					lbAutoLogin	  = odLoginUser.m_bAutoLogin;
					lbSavePassword = odLoginUser.m_bSavePassword;
				}
				else
					return false; //Quit program
			}
			break;

		case 1:
			{		
				CString lsAutoLoginMessage; 
				lsAutoLoginMessage.LoadString( IDS_THE_PROGRAM_WILL_AUTOLOGIN_USER );			
				lsAutoLoginMessage += lsUserName;

				CString strAutoLogin; strAutoLogin.LoadString( IDS_AUTOLOGIN );

				//MessageBox(NULL, lsAutoLoginMessage, strAutoLogin , NULL);	// TODO Just show a splash screen, no need for user input.
			}
			break;
		}

		// Login User	
		if ( loginUser(lsUserName, lsPassword) )
		{
			m_userName = lsUserName;

			// Save settings to registry
			pApp->WriteProfileString("Settings", "UserName", lsUserName);
			
			if (lbSavePassword)
				pApp->WriteProfileString("Settings", "Password", lsPassword);
			else
				pApp->WriteProfileString("Settings", "Password", "");

			pApp->WriteProfileInt("Settings", "AutoLogin", lbAutoLogin);
			pApp->WriteProfileInt("Settings", "SavePassword", lbSavePassword);

			return true;
		}
		
		// Autlogin user couldn't login, there will be a forever loop here
		// if we doesn't set lbAutoLogin to zero.
		lbAutoLogin = 0;
	}

	return false;
}

//

bool ccVOClient::loginUser(LPCSTR sUserName, LPCSTR sPassword) 
{	
	if ( m_dataBase )	
	{
		try
		{
			ADODB::_RecordsetPtr PopSet;			
			try
			{		ccString strSQL;	
					strSQL << "SELECT [Password], [UserID], ";
					strSQL << "[SelLeafMProject], [SelLeafItemID], [SelLeafChildID]";
					strSQL <<	"FROM dtUser ";
					strSQL <<	"where UserName = '" << sUserName << "'";
					
					if ( m_dataBase->getRS(strSQL, PopSet) )							
					{
						if ( !PopSet->adoEOF) 
						{
							CString dtPassword = (char*)(_bstr_t)PopSet->Fields->Item[_variant_t(0l)]->Value;					
							if (sPassword == dtPassword )
							{
								m_nUserID = (long)PopSet->Fields->Item[_variant_t(1l)]->Value;
								m_nSelLeafMProject = (long)PopSet->Fields->Item[_variant_t(2l)]->Value;
								m_nSelLeafItemID   = (long)PopSet->Fields->Item[_variant_t(3l)]->Value;
								m_nSelLeafChildID  = (long)PopSet->Fields->Item[_variant_t(4l)]->Value;

								return true;
							}
							else
								ccErrEM( IDS_LOGIN_INVALID_PASSWORD, NULL, NULL, MB_OK);
						}		
						else
							ccErrEM( IDS_LOGIN_INVALID_USERNAME, NULL, NULL, MB_OK);
					}	
					else
						ccErrEM( IDS_NO_USER_IS_REGISTERED, NULL, NULL, MB_OK);
			}
			catch(_com_error &e) 
			{ 				
				ccThrowccException( getProviderError( m_dataBase->getConnection()) ); /*Delete unreference warning*/ (void*)&e; 				
			}	
		}
		catch( ccException * e)
		{
			ccErr( *e, "", "", MB_OK );			
		}
		catch(...)
		{
			ccErrEM( IDS_GENERAL_CREATE_USER_ERROR, NULL, NULL, MB_OK );
		}
	}
	else
		ccErrEM( IDS_DATABASE_ISNT_OPEN, NULL, NULL, MB_OK);

	return false;
}

//////////////////////////////////////////////////////////////////////
// *** Functions to help filling FolderListView
//////////////////////////////////////////////////////////////////////

bool ccVOClient::getActiveMProjects( CPtrList &activeMProjects )
{
	if ( m_dataBase )	
	{
		try
		{
			ADODB::_RecordsetPtr PopSet;						
			try
			{
					ccString strSQL;	

					strSQL << "SELECT dtUserActiveMProjects.[MProjectID], ";				
					strSQL <<        "dtMasterProject.[name], dtUserActiveMProjects.[Expanded] ";
					strSQL <<  "FROM dtUserActiveMProjects, dtMasterProject ";
					strSQL <<  "WHERE     dtMasterProject.MProjectID = dtUserActiveMProjects.MProjectID ";
					strSQL <<  		 "AND dtUserActiveMProjects.UserID = " << m_nUserID;
		
					if ( m_dataBase->getRS(strSQL, PopSet) )							
					{
						while(!PopSet->adoEOF)
						{		
							sFLVTreeOrderSubItems* MProj = new sFLVTreeOrderSubItems;
							MProj->nMProjectID   = (int)(long)PopSet->Fields->Item[_variant_t(0l)]->Value;;
							MProj->nParentID     = -1;
							MProj->nItemID       = 1;					
							MProj->strName       = (char*)(_bstr_t)PopSet->Fields->Item[_variant_t(1l)]->Value;
							MProj->nItemType	 = cITMASTERPROJECT;
							MProj->nFunctionType = cIXPROJECT;
							MProj->bExpanded	 = PopSet->Fields->Item[_variant_t(2l)]->Value;
							
							activeMProjects.AddTail( MProj );
							
							PopSet->MoveNext();						
						}

						PopSet->Close();

						return true;
					}			
			}
			catch(_com_error &e) 
			{ 
				ccErr(getProviderError( m_dataBase->getConnection()) );
				ccThrowccException( getProviderError( m_dataBase->getConnection()) ); /*Delete unreference warning*/ (void*)&e; 				
			}	
		}
		catch( ccException * e)
		{
			ccErr( *e, "", "", MB_OK );			
		}
		catch(...)
		{
			ccErrEM( IDS_GENERAL_CREATE_USER_ERROR, NULL, NULL, MB_OK );
		}
	}
	else
		ccErrEM( IDS_DATABASE_ISNT_OPEN, NULL, NULL, MB_OK);

	return false;
}

//

bool ccVOClient::getTreeOrderSubItems( int MProjectID, int nItemID, CPtrList &subItems ) 
{
	if ( m_dataBase )	
	{
		try
		{
			ADODB::_RecordsetPtr PopSet;						
			try
			{
				ccString strSQL;	

				strSQL << "SELECT dtTreeOrder.[ChildID], dtItems.[Name], ";
				strSQL <<        "dtItems.[ItemType], dtItems.[FunctionType], ";
				strSQL <<		 "dtTreeOrder.[Expanded] ";
				strSQL <<  "FROM dtTreeOrder, dtItems ";
				strSQL <<  "WHERE dtTreeOrder.MProjectID = dtItems.MProjectID ";
				strSQL <<  		 "AND dtTreeOrder.ChildID = dtItems.ItemID ";
				strSQL <<  		 "AND (dtItems.ItemType = 3 OR dtItems.ItemType = 4) ";
				strSQL <<  		 "AND (dtTreeOrder.MProjectID = " << MProjectID << ") ";
				strSQL <<  		 "AND (dtTreeOrder.ItemID = " << nItemID << ")";				
	
				if ( m_dataBase->getRS(strSQL, PopSet) )							
				{
					while(!PopSet->adoEOF)
					{		
						sFLVTreeOrderSubItems * SubItem = new sFLVTreeOrderSubItems;
						SubItem->nMProjectID   = MProjectID;
						SubItem->nParentID     = nItemID;
						SubItem->nItemID       = (int)(long)PopSet->Fields->Item[_variant_t(0l)]->Value;
						SubItem->strName	   = (char*)(_bstr_t)PopSet->Fields->Item[_variant_t(1l)]->Value;
						SubItem->nItemType	   = (int)(long)PopSet->Fields->Item[_variant_t(2l)]->Value;
						SubItem->nFunctionType = (int)(long)PopSet->Fields->Item[_variant_t(3l)]->Value;
						SubItem->bExpanded	   = PopSet->Fields->Item[_variant_t(4l)]->Value;						
						subItems.AddTail( SubItem );
						
						PopSet->MoveNext();						
					}

					PopSet->Close();					
				}			
				return true;
			}
			catch(_com_error &e) 
			{ 
				ccErr(getProviderError( m_dataBase->getConnection()) );
				ccThrowccException( getProviderError( m_dataBase->getConnection()) ); /*Delete unreference warning*/ (void*)&e; 				
			}	
		}
		catch( ccException * e)
		{
			ccErr( *e, "", "", MB_OK );			
		}
		catch(...)
		{
			ccErrEM( IDS_GENERAL_CREATE_USER_ERROR, NULL, NULL, MB_OK );
		}
	}
	else
		ccErrEM( IDS_DATABASE_ISNT_OPEN, NULL, NULL, MB_OK);

	return false;
}

//

void ccVOClient::setSelectedTreeLeaf( int nMProjectID, int nParentID, int nItemID, int nFunctionType )
{
	m_nSelLeafMProject = nMProjectID;
	m_nSelLeafItemID   = nParentID;  
	m_nSelLeafChildID  = nItemID; 	
	m_nFunctionType	   = nFunctionType;
}
//

void ccVOClient::saveSelectedTreeLeaf()
// TODO TODO TODO This could be optimized using an ADODB::Command whos not returning a recordset.
//
{	
	try
	{
		ccString strSQL;	

		strSQL << "UPDATE dtUser ";
		strSQL <<	"SET SelLeafMProject = " << getSelLeafMProjectID();
		strSQL <<	  ", SelLeafItemID   = " << getSelLeafParentID(); 
		strSQL <<	  ", SelLeafChildID  = " << getSelLeafItemID();
 		strSQL <<	" where UserID = " << m_nUserID;

		// Execute SQL statement
		_variant_t vRecordsEffected;		
		if ( m_dataBase->executeSQLNoRet( strSQL, vRecordsEffected ) )
		{
			ASSERT( vRecordsEffected.intVal != 0);
			return;
		}
		else
			ccThrowccException( IDS_COULDNT_SAVE_SELECTED_TREE_LEAF );
	}
	catch( ccException * e)
	{
		ccErr( *e, "", "", MB_OK );			
	}
	catch(...)
	{
		ccErrEM( IDS_GENERAL_CREATE_USER_ERROR, NULL, NULL, MB_OK );
	}
}

//

bool ccVOClient::isLastSelectedTreeLeaf( sFLVTreeOrderSubItems * SubItem )
{
	if ( ( m_nSelLeafMProject == -1) && ( m_nSelLeafItemID == -1) && (m_nSelLeafChildID == -1) )
		return false;

	if ( ( m_nSelLeafMProject == SubItem->nMProjectID) && \
		 ( m_nSelLeafItemID == SubItem->nParentID) && \
		 (m_nSelLeafChildID == SubItem->nItemID)
	   )
	   return true;
	else
		return false;
}

//

void ccVOClient::saveTreeLeafExpandState( int nMProjectID, int nParentID, int nItemID, bool bExpanded )
{	
	try
	{
		ccString strSQL;	
		
		if (nParentID == -1)
		// The Master project Expand State has been changed.
		{
			strSQL << "UPDATE dtUserActiveMProjects ";
			strSQL <<	"SET Expanded = " << (int)bExpanded;
 			strSQL <<	" where [MProjectID] = " << nMProjectID;
			strSQL <<	  " and [UserID] = "     << m_nUserID;
		}
		else
		{		
			strSQL << "UPDATE dtTreeOrder ";
			strSQL <<	"SET Expanded = " << (int)bExpanded;
 			strSQL <<	" where [MProjectID] = " << nMProjectID;
			strSQL <<	  " and [ItemID] = "     << nParentID;
			strSQL <<	  " and [ChildID] = "    << nItemID;
		}
		// Execute SQL statement
		_variant_t vRecordsEffected;		
		if ( m_dataBase->executeSQLNoRet( strSQL, vRecordsEffected ) )
		{
			ASSERT( vRecordsEffected.intVal != 0);
			return;
		}
		else
			ccThrowccException( IDS_COULDNT_SAVE_TREE_LEAF_EXPAND_STATE );
	}
	catch( ccException * e)
	{
		ccErr( *e, "", "", MB_OK );			
	}
	catch(...)
	{
		ccErrEM( IDS_GENERAL_CREATE_USER_ERROR, NULL, NULL, MB_OK );
	}
}

//////////////////////////////////////////////////////////////////////
// *** Email functions
//////////////////////////////////////////////////////////////////////

bool ccVOClient::emailUserInfo( sNewUser &aNewUser )
{	
	//Create the SMTP connection
	CSMTPConnection smtp;

	//Connect to the server
	if (!smtp.Connect(_T("smtp.home.se")))
	{
		CString sResponse = smtp.GetLastCommandResponse();
		ccErr(sResponse, "Failed to connect to SMTP server\n");
		return false;
	}

	// Build body
	ccString strBody;

	strBody << "userName = " << aNewUser.m_userName << "\r\n";
	strBody << "password = " << aNewUser.m_password << "\r\n";
	strBody << "confirmPassword = " << aNewUser.m_confirmPassword << "\r\n";
	strBody << "company = " << aNewUser.m_company << "\r\n";
	strBody << "fullName = " << aNewUser.m_fullName << "\r\n";
	strBody << "address = " << aNewUser.m_address << "\r\n";
	strBody << "zipCode = " << aNewUser.m_zipCode << "\r\n";
	strBody << "phone = " << aNewUser.m_phone << "\r\n";
	strBody << "fax = " << aNewUser.m_fax << "\r\n";
	strBody << "country = " << aNewUser.m_country << "\r\n";
	strBody << "city = " << aNewUser.m_city << "\r\n";
	strBody << "email = " << aNewUser.m_email << "\r\n";


	//Create the message
	CSMTPMessage m;
	CSMTPAddress From(aNewUser.m_fullName, aNewUser.m_city); 
	m.m_From = From;

	CSMTPAddress To(_T("CyberCow"), _T("CyberCow@home.se"));
	m.AddRecipient(To, CSMTPMessage::TO);

	m.m_sSubject = _T("ccVO2k NewUser");
	m.AddBody(strBody);

	//Send the message
	if (!smtp.SendMessage(m))
	{
		CString sResponse = smtp.GetLastCommandResponse();		
		ccErr(sResponse, "Failed to send the SMTP message\n");
		return false;
	}

	//Disconnect from the server
	smtp.Disconnect();
	return true;

}

//////////////////////////////////////////////////////////////////////
// *** "Create" functions updateing more then one table
//////////////////////////////////////////////////////////////////////

bool ccVOClient::createUser( sRegUsr &aRegUser )
// Insert information about the new user in the local database
// TODOTODO this should be done on the server side in ccVO2k version 2.0
{
	if ( m_dataBase )	
	{	
		try
		{	
			// Is User already existing.
			ccString strSQL;
			strSQL << "SELECT [UserName] ";				
			strSQL <<	"FROM dtUser ";
			strSQL <<	"where UserName = '" << aRegUser.m_newUser.m_userName << "'";
			
			VARIANT Result;
			if ( m_dataBase->getRSVariant(strSQL, &Result) )							
				if ( (_bstr_t)Result ==  aRegUser.m_newUser.m_userName)				
				{
					ccErrEM( IDS_USER_ALREADY_EXIST, NULL, NULL, MB_OK);	
					return false;
				}

			
			m_nUserID = m_dataBase->createNewUserID();
			aRegUser.m_newUser.m_MProjectID = m_dataBase->createMProjectID();
						
			m_dataBase->beginTrans();

				m_dataBase->insert_dtUser( aRegUser.m_newUser, m_nUserID );
				m_dataBase->insert_dtMasterProject( aRegUser.m_newUser, m_nUserID );
				m_dataBase->insert_dtMProjectMembers( aRegUser.m_newUser, m_nUserID );
				m_dataBase->insert_dtUserActiveMProjects( aRegUser.m_newUser, m_nUserID );								

				int nItemRoot = 0;	// The root folder in the folderView. The Project.
				int nItemID;
				int nMProjectID = aRegUser.m_newUser.m_MProjectID;
				for( int idx=cIXCONTACTS; idx<=cIXFTP;idx++)
				{
					if ( aRegUser.m_newUser.m_functions[idx-1] )
					{		
						nItemID = idx;

						m_dataBase->insert_dtItems( nMProjectID, nItemID, aRegUser.m_functionName[idx-1], idx, cITFUNCTION);	
						m_dataBase->insert_dtTreeOrder( nMProjectID, nItemRoot, nItemID );
					}
				}

			// TODO Show wait screen
			m_dataBase->commitTrans();

			emailUserInfo( aRegUser.m_newUser );
			// TODO Close wait screen

			return true;
		}
		catch( ccException * e)
		{
			m_dataBase->rollbackTrans();				

			ccErr( *e, "", "", MB_OK );			
		}
		catch(...)
		{
			ccErrEM( IDS_GENERAL_CREATE_USER_ERROR, NULL, NULL, MB_OK );
		}
	}
	else
		ccErrEM( IDS_DATABASE_ISNT_OPEN, IDS_DB_ERROR, MB_OK );

	return false;
}

//

bool ccVOClient::createNewItem( sFLVTreeOrderSubItems * newItem )
{
	try
	{
		m_dataBase->beginTrans();

			m_dataBase->insert_dtItems( newItem->nMProjectID, newItem->nItemID, newItem->strName, \
									   newItem->nFunctionType, newItem->nItemType);	
			m_dataBase->insert_dtTreeOrder( newItem->nMProjectID, newItem->nParentID, newItem->nItemID );

		m_dataBase->commitTrans();

		return true;
	}
	catch( ccException * e)
	{
		m_dataBase->rollbackTrans();				

		ccErr( *e, "", "", MB_OK );			
	}
	catch(...)
	{
		ccErrEM( IDS_GENERAL_CCVOVCLIENT_ERROR );				
	}		
	return false;
}

//////////////////////////////////////////////////////////////////////
// *** "Create" functions updateing more then one table
//////////////////////////////////////////////////////////////////////
bool ccVOClient::delete_dtItem_And_dtTreeOrder( int nMProjectID, int nParentID, int nItemID)
{
	try
	{		
		m_dataBase->beginTrans();
			m_dataBase->delete_dtTreeOrder( nMProjectID, nParentID, nItemID );
			m_dataBase->delete_dtItems( nMProjectID, nItemID );			

		m_dataBase->commitTrans();

		return true;
	}
	catch( ccException * e)
	{
		m_dataBase->rollbackTrans();					

		ccErr( *e, "", "", MB_OK );			
	}
	catch(...)
	{
		ccErrEM( IDS_GENERAL_CCVOVCLIENT_ERROR );				
	}		
	return false;
}

