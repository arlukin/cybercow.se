// cccFTPTABGeneral.cpp : implementation file
//

#include "stdafx.h"
#include "ccvo2k.h"

#include "cccFTPTABGeneral.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccFTPTABGeneral dialog


cccFTPTABGeneral::cccFTPTABGeneral(CWnd *pParent, cccVODB *aoDB)
	: ccdbDialog(cccFTPTABGeneral::IDD, pParent, aoDB)
{
	//{{AFX_DATA_INIT(cccFTPTABGeneral)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	Create(cccFTPTABGeneral::IDD, pParent);	
}


void cccFTPTABGeneral::DoDataExchange(CDataExchange* pDX)
{
	ccdbDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(cccFTPTABGeneral)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(cccFTPTABGeneral, ccdbDialog)
	//{{AFX_MSG_MAP(cccFTPTABGeneral)		
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cccFTPTABGeneral message handlers

BOOL cccFTPTABGeneral::OnInitDialog() 
{
	setDDServer( dd(m_ddFTP) );

	m_Name.adddbField( &dd(m_ddFTP)->m_Name );
	m_Name.setCaptionOffset(-35);
	m_Name.SubclassDlgItem( IDC_FTP_NAME, this, this );

	m_URL.adddbField( &dd(m_ddFTP)->m_URL );
	m_URL.setCaptionOffset(-55);
	m_URL.SubclassDlgItem( IDC_FTP_URL, this, this );

	m_Port.adddbField( &dd(m_ddFTP)->m_Port );
	m_Port.setCaptionOffset( -30 );
	m_Port.SubclassDlgItem( IDC_FTP_PORT, this, this );

	m_Login.adddbField( &dd(m_ddFTP)->m_Login );
	m_Login.setCaptionOffset( -35 );
	m_Login.SubclassDlgItem( IDC_FTP_LOGIN, this, this );

	m_Password.adddbField( &dd(m_ddFTP)->m_Password );
	m_Password.setCaptionOffset( -55 );
	m_Password.SubclassDlgItem( IDC_FTP_PASSWORD, this, this );

	m_InitialLocalDirectory.adddbField( &dd(m_ddFTP)->m_InitialLocalDirectory );
	m_InitialLocalDirectory.setCaptionOffset( -114 );
	m_InitialLocalDirectory.SubclassDlgItem( IDC_FTP_LOCALDIR, this, this );

	m_InitialRemoteDirectory.adddbField( &dd(m_ddFTP)->m_InitialRemoteDirectory );
	m_InitialRemoteDirectory.setCaptionOffset( -114 );
	m_InitialRemoteDirectory.SubclassDlgItem( IDC_FTP_REMOTEDIR, this, this );

	m_CreditGrade.adddbField( &dd(m_ddFTP)->m_CreditGrade );
	m_CreditGrade.setCaptionOffset(-80);
	m_CreditGrade.SubclassDlgItem( IDC_FTP_CREDIT_GRADE, this, this );

	m_LastLogedOn.adddbField( &dd(m_ddFTP)->m_LastLogedOn );
	m_LastLogedOn.setCaptionOffset(-80);
	m_LastLogedOn.SubclassDlgItem( IDC_FTP_LAST_LOGED_ON, this, this );

	m_LastChecked.adddbField( &dd(m_ddFTP)->m_LastChecked );
	m_LastChecked.setCaptionOffset(-80);
	m_LastChecked.SubclassDlgItem( IDC_FTP_LAST_CHECKED, this, this );

	m_ValidSite.adddbField( &dd(m_ddFTP)->m_ValidSite );
	m_ValidSite.setCaptionOffset(-80);
	m_ValidSite.SubclassDlgItem( IDC_FTP_VALID_SITE, this, this );

	m_Notes.adddbField( &dd(m_ddFTP)->m_Notes );
	m_Notes.setCaptionOffset(-80);
	m_Notes.SubclassDlgItem( IDC_FTP_NOTES, this, this );

	ccdbDialog::OnInitDialog();

	// Set up the Email Container and dataDictonary	

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
