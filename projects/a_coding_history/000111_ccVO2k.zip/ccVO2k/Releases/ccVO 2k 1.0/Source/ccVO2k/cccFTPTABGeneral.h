#if !defined(AFX_CCCFTPTABGENERAL_H__5A42B21A_2E62_11D4_823B_0001020E90A5__INCLUDED_)
#define AFX_CCCFTPTABGENERAL_H__5A42B21A_2E62_11D4_823B_0001020E90A5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// cccFTPTABGeneral.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// cccFTPTABGeneral dialog

class cccFTPTABGeneral : public ccdbDialog
{
// *** Construction
public:
	// standard constructor
	//
	cccFTPTABGeneral(CWnd *pParent, cccVODB *aoDB);

// *** Dialog Data
	//{{AFX_DATA(cccFTPTABGeneral)
	enum { IDD = IDD_FTP_TAB_GENERAL };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	ccdbSuperCtrl m_MProjectID;
	ccdbSuperCtrl m_ParentItemID;
	ccdbSuperCtrl m_ItemID;
	ccdbSuperCtrl m_Name;
	ccdbSuperCtrl m_URL;	
	ccdbSuperCtrl m_Port;				
	ccdbSuperCtrl m_Login;				
	ccdbSuperCtrl m_Password;			
	ccdbSuperCtrl m_InitialLocalDirectory;
	ccdbSuperCtrl m_InitialRemoteDirectory;
	ccdbSuperCtrl m_Notes;
	ccdbSuperCtrl m_CreditGrade;
	ccdbSuperCtrl m_LastLogedOn;
	ccdbSuperCtrl m_LastChecked;
	ccdbSuperCtrl m_ValidSite;

// *** Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(cccFTPTABGeneral)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(cccFTPTABGeneral)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CCCFTPTABGENERAL_H__5A42B21A_2E62_11D4_823B_0001020E90A5__INCLUDED_)
