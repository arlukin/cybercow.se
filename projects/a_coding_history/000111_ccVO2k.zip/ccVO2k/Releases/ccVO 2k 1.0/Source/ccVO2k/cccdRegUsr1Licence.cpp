// cccdRegUsr1Licence.cpp : implementation file
//

#include "stdafx.h"
#include "cccdRegUsr1Licence.h"
#include "TransferStructs.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccdRegUsr1Licence property page

IMPLEMENT_DYNCREATE(cccdRegUsr1Licence, CPropertyPage)

cccdRegUsr1Licence::cccdRegUsr1Licence( ) : CPropertyPage(cccdRegUsr1Licence::IDD)
{
	//{{AFX_DATA_INIT(cccdRegUsr1Licence)
	//m_licence = _T("Licence, if you agree, We can put you in our register, h�nvisar till DataLagen");	

	m_licence = ""
"Copyright � 2000 CyberCow AB\r\n"
"All rights reserved.\r\n"
"\r\n"
"You should carefully read the following terms and conditions before using this software. Unless you have a different licence agreement signed by CyberCow your use of this software indicates your acceptance of this licence agreement and warranty.\r\n"
"\r\n"
"BETA LICENCE\r\n"
"This software is under beta test, and free to use on your own risk. The application will not stop working after a specific day (except if there is an unknown bug in the program) and its okej for you to use it as long as you want. But we can not guarantee that future versions will be compatible with the database used in this beta. But we will do whatever we can to make this and the next version of the program compatible.\r\n"
"\r\n"
"You should also be aware of that the information you register on the next 'tab' page would be e-mailed to cybercow. The information will be kept on a secure place and will only be used by us for the purpose of informing you of a newer version of the program.\r\n"
"\r\n"
"Governing Law\r\n"
"This agreement shall be governed by the laws of Sweden.\r\n"
"\r\n"
"Disclaimer of Warranty\r\n"
"THIS SOFTWARE AND THE ACCOMPANYING FILES ARE SOLD 'AS IS' AND WITHOUT WARRANTIES AS TO PERFORMANCE OF MERCHANTABILITY OR ANY OTHER WARRANTIES WHETHER EXPRESSED OR IMPLIED. Because of the various hardware and software environments into which ccVO2k may be put, NO WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE IS OFFERED.\r\n"
"\r\n"
"Good data processing procedure dictates that any program be thoroughly tested with non-critical data before relying on it. The user must assume the entire risk of using the program. ANY LIABILITY OF THE SELLER WILL BE LIMITED EXCLUSIVELY TO PRODUCT REPLACEMENT OR REFUND OF PURCHASE PRICE.\r\n"
"\r\n"
"If you have any questions regarding this Licence, please contact:\r\n"
"\r\n"
"CyberCow AB\r\n"
"Telephone: +46 (08) 555 362 95\r\n"
"Fax: +46 (08) 598 280 24\r\n"
"E-mail: cybercow@home.se\r\n"
"Web site: home.bip.net/cybercow\r\n";



	//}}AFX_DATA_INIT
}


cccdRegUsr1Licence::~cccdRegUsr1Licence()
{
}

void cccdRegUsr1Licence::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(cccdRegUsr1Licence)
	DDX_Control(pDX, IDC_LICENCE_EDIT, m_LicenceCtrl);
	DDX_Control(pDX, IDC_I_AGREE, m_IAgreeCtrl);
	DDX_Text(pDX, IDC_LICENCE_EDIT, m_licence);
	DDV_MaxChars(pDX, m_licence, 80000);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(cccdRegUsr1Licence, CPropertyPage)
	//{{AFX_MSG_MAP(cccdRegUsr1Licence)
	ON_BN_CLICKED(IDC_I_AGREE, OnIAgree)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cccdRegUsr1Licence message handlers

void cccdRegUsr1Licence::OnIAgree() 
{	
	((CPropertySheet*)GetParent())->GetDlgItem(ID_WIZNEXT)->EnableWindow( m_IAgreeCtrl.GetCheck()  );
}

BOOL cccdRegUsr1Licence::OnSetActive() 
{	
	// Set Wizard buttons.	
	((CPropertySheet*)GetParent())->GetDlgItem(ID_WIZBACK)->EnableWindow( FALSE  );
	((CPropertySheet*)GetParent())->GetDlgItem(ID_WIZNEXT)->EnableWindow( m_IAgreeCtrl.GetCheck()  );
	
	return CPropertyPage::OnSetActive();
}

LRESULT cccdRegUsr1Licence::OnWizardNext() 
{
	CWnd * oOKButton;
	oOKButton = GetParent()->GetDlgItem(ID_WIZNEXT);
	NEEDVALUE( oOKButton );
	if ( m_IAgreeCtrl.GetCheck() != TRUE )
	{		
		SetActiveWindow();
		MessageBox("You must agree to the licence");
		return TRUE;
	}	
	return CPropertyPage::OnWizardNext();
}
