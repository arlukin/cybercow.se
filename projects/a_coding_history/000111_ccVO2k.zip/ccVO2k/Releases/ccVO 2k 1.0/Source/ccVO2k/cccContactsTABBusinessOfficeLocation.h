#if !defined(AFX_CCCCONTACTSTABBUSINESSOFFICELOCATION_H__F3FB3E24_273B_11D4_89A6_00609708DCFE__INCLUDED_)
#define AFX_CCCCONTACTSTABBUSINESSOFFICELOCATION_H__F3FB3E24_273B_11D4_89A6_00609708DCFE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// cccContactsTABBusinessOfficeLocation.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// cccContactsTABBusinessOfficeLocation dialog

class cccContactsTABBusinessOfficeLocation : public ccdbDialog
{
// *** Construction
public:
	// standard constructor
	//
	cccContactsTABBusinessOfficeLocation(CWnd* pParent, cccVODB *aoDB); 

// *** Dialog Data
	//{{AFX_DATA(cccContactsTABBusinessOfficeLocation)
	enum { IDD = IDD_CONTACTS_TAB_BUSINESS_OFFICE_LOCATION };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA
	ccdbSuperCtrl	m_Business_Office_Street;
	ccdbSuperCtrl	m_Business_Office_City;
	ccdbSuperCtrl	m_Business_Office_State_Or_Province;
	ccdbSuperCtrl	m_Business_Office_Zip_Or_PostalCode;	
	ccdbSuperCtrl	m_Business_Office_Country_Or_Region;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(cccContactsTABBusinessOfficeLocation)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(cccContactsTABBusinessOfficeLocation)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CCCCONTACTSTABBUSINESSOFFICELOCATION_H__F3FB3E24_273B_11D4_89A6_00609708DCFE__INCLUDED_)
