#if !defined(AFX_FOLDERLISTVIEW_H__33B79F65_355D_11D3_9922_00500487D199__INCLUDED_)
#define AFX_FOLDERLISTVIEW_H__33B79F65_355D_11D3_9922_00500487D199__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FolderListView.h : header file
//

#define FM_CLOSEFOLDERLISTVIEW		(WM_USER + 100)

class ccTreeCtrl;
class CFolderTreeCtrl;
/////////////////////////////////////////////////////////////////////////////
// CFolderListView view

// ImageSmall Indes.
// 
#define IS_PERSONAL     0
#define IS_PERSONAL_SEL 1
#define IS_CONTACTS     2
#define IS_CONTACTS_SEL 3
#define IS_FAVORITE		4
#define IS_FAVORITE_SEL	5
#define IS_FTP			6
#define IS_FTP_SEL		7


class CFolderListView : public CView
{
// *** Construction / Destruction
protected:
	DECLARE_DYNCREATE(CFolderListView)

	// Default Constructor
	//
	CFolderListView();           // protected constructor used by dynamic creation	

	// Default destructor
	//
	virtual ~CFolderListView();


// *** GFX Attribute
public:
	CCJCaption		m_Caption;			// frame caption contains 
	CCJFlatButton	m_CaptionButton;	// close button located on frame
	CImageList		m_ImageList, m_ImageSmall;
	
	// static because we need to access control even when
	// the parent view is not visible.
	static CFolderTreeCtrl 	m_TreeCtrl;

// *** Attribute
private:
	bool	m_bOnDestroyHasBeenExecuted;		// This is used by OnDeleteItem, so we don't delete all folders from
												// the database.

	HTREEITEM m_lastSelectedTreeLeaf;			// This is the handle to the leaf last selected in the last
												// started/closed ccVO2k.exe 

// *** TreeCtrl functions
private:
	// Fill the treectrl with all dtUserActiveMProjects, 
	// includeing subitems from dtTreeorder
	//
	void fillTreeCtrl();

	// Insert a leaf into the treeCtrl
	//
	HTREEITEM  insertItem( sFLVTreeOrderSubItems * MProj, HTREEITEM hParentTreeLeaf );

	// Insertng subfolders into treeCtrl, takeing data from dtTreeOrder and dtItems
	//
	bool insertSubItem( int MProjectID, int nItemID, HTREEITEM hParentTreeLeaf );

// *** Overrides
public:		
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFolderListView)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void OnDraw(CDC* pDC);
	//}}AFX_VIRTUAL

// *** Generated message map functions
protected:
	//{{AFX_MSG(CFolderListView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnCaptButton();
	afx_msg void OnSelchanged(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnItemexpanded(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnBeginlabeledit(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeleteitem(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnDestroy();
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnProjectmenuNewfolder();
	afx_msg void OnProjectmenuDelete();
	afx_msg void OnProjectmenuRename();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// *** Debug members
protected:	
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOLDERLISTVIEW_H__33B79F65_355D_11D3_9922_00500487D199__INCLUDED_)
