#if !defined(__CCCDREGUSR3FUNCTIONS_H__)
#define __CCCDREGUSR3FUNCTIONS_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// cccdRegUsr3Functions.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// cccdRegUsr3Functions dialog
#include "resource.h"

struct sRegUsr;
class cccdRegUsr3Functions : public CPropertyPage
{
	DECLARE_DYNCREATE(cccdRegUsr3Functions)

// Construction
public:
	int calcPrice();
	BOOL validateAndSave();	

	cccdRegUsr3Functions();
	~cccdRegUsr3Functions();

	void setRegUsr( sRegUsr *aoRegUsr )				{ m_regUsr = aoRegUsr;	}

// Dialog Data
	//{{AFX_DATA(cccdRegUsr3Functions)
	enum { IDD = IDD_REG_USR_3_FUNCTIONS };
	CEdit	m_priceCtrl;
	CEdit	m_deliveryAddressCtrl;
	CCJFlatComboBox	m_currencyCtrl;
	CCJFlatComboBox	m_paymentTypesCtrl;
	CCheckListBox	m_functionListCtrl;	
	ccEdit	m_storageCtrl;
	CString	m_currency;
	CString	m_paymentType;
	int		m_storage;
	int		m_price;
	//}}AFX_DATA

// *** Attributes
private:
	sRegUsr * m_regUsr;			// This struct will contain input and output data from/to the ctrls.

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(cccdRegUsr3Functions)
	public:
	virtual BOOL OnSetActive();
	virtual LRESULT OnWizardBack();
	virtual LRESULT OnWizardNext();
	virtual BOOL OnWizardFinish();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(cccdRegUsr3Functions)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeFunctionList();
	afx_msg void OnChangeStorage();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // __CCCDREGUSR3FUNCTIONS_H__
