#if !defined(AFX_CCCCONTACTSTABBUSINESSMAILADRESS_H__F3FB3E25_273B_11D4_89A6_00609708DCFE__INCLUDED_)
#define AFX_CCCCONTACTSTABBUSINESSMAILADRESS_H__F3FB3E25_273B_11D4_89A6_00609708DCFE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// cccContactsTABBusinessMailAdress.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// cccContactsTABBusinessMailAdress dialog

class cccContactsTABBusinessMailAdress : public ccdbDialog
{
// *** Construction
public:
	// standard constructor
	//
	cccContactsTABBusinessMailAdress(CWnd* pParent, cccVODB *aoDB); 

// *** Dialog Data
	//{{AFX_DATA(cccContactsTABBusinessMailAdress)
	enum { IDD = IDD_CONTACTS_TAB_BUSINESS_MAIL_ADRESS };
	//}}AFX_DATA
	ccdbSuperCtrl	m_Business_Mail_Street;
	ccdbSuperCtrl	m_Business_Mail_City;
	ccdbSuperCtrl	m_Business_Mail_State_Or_Province;
	ccdbSuperCtrl	m_Business_Mail_Zip_Or_PostalCode;	
	ccdbSuperCtrl	m_Business_Mail_Country_Or_Region;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(cccContactsTABBusinessMailAdress)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(cccContactsTABBusinessMailAdress)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CCCCONTACTSTABBUSINESSMAILADRESS_H__F3FB3E25_273B_11D4_89A6_00609708DCFE__INCLUDED_)
