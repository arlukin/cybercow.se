// cccFavoritesView.cpp : implementation file
//

#include "stdafx.h"
#include "ccvo2k.h"
#include "cccFavoritesView.h"
#include "cccVOEditor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccFavoritesView

IMPLEMENT_DYNCREATE(cccFavoritesView, CFormView)

cccFavoritesView::cccFavoritesView()
	: CFormView(cccFavoritesView::IDD)
{
	//{{AFX_DATA_INIT(cccFavoritesView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

cccFavoritesView::~cccFavoritesView()
{
}

void cccFavoritesView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(cccFavoritesView)
	DDX_Control(pDX, ID_FAVORITES_GRID, m_grid);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(cccFavoritesView, CFormView)
	//{{AFX_MSG_MAP(cccFavoritesView)
	ON_WM_SIZE()
	ON_NOTIFY(NM_DBLCLK, ID_FAVORITES_GRID, OnDblclkFavoritesGrid)
	ON_NOTIFY(NM_RETURN, ID_FAVORITES_GRID, OnReturnFavoritesGrid)
	ON_NOTIFY(LVN_KEYDOWN, ID_FAVORITES_GRID, OnKeydownFavoritesGrid)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cccFavoritesView diagnostics

#ifdef _DEBUG
void cccFavoritesView::AssertValid() const
{
	CFormView::AssertValid();
}

void cccFavoritesView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// cccFavoritesView message handlers

void cccFavoritesView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);

	if (::IsWindow(m_grid.m_hWnd) )
		m_grid.SetWindowPos(NULL, 0, 0, cx, cy,  SWP_NOZORDER );	
}

//

void cccFavoritesView::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();

	theCCVOClient->setCurrentGridCtrl(this);

	setDB( theCCVOClient->m_dataBase );

	// Set the size of the listCtrl so it will fill the FormView.
	CRect lpRect;
	GetClientRect( lpRect );
	m_grid.SetWindowPos(NULL, 0, 0, lpRect.Width(), lpRect.Height(),  SWP_NOZORDER );		

	m_grid.SetExtendedStyle(LVS_EX_FULLROWSELECT | 
				 LVS_EX_ONECLICKACTIVATE | 
				 LVS_EX_UNDERLINEHOT );

	for(int nCol = 3;nCol>-1;nCol--)
		m_grid.DeleteColumn( nCol);

	m_grid.InsertColumn(0, "Name",		LVCFMT_LEFT, 100,0);
	m_grid.InsertColumn(1, "URL",		LVCFMT_LEFT, 100,1);
	m_grid.InsertColumn(2, "Notes",		LVCFMT_LEFT, 300,2);	

	fillGrid();
}

//

void cccFavoritesView::fillGrid()
// Move the sql question to ccVOClient..
// and make a forward only recordset.... 
{
	m_grid.DeleteAllItems();	

	if ( theCCVOClient->m_dataBase )	
	{
		try
		{
			ADODB::_RecordsetPtr PopSet;						
			try
			{
				ccString strSQL;	

				strSQL << "SELECT dtfFavorites.ItemID, ";
				strSQL << "dtfFavorites.[Name], dtfFavorites.[URL], dtfFavorites.[Notes] ";
				strSQL << "FROM dtfFavorites, dtItems, dtTreeOrder ";
				strSQL << "WHERE dtfFavorites.MProjectID = dtTreeOrder.MProjectID AND ";
				strSQL << "    dtfFavorites.ItemID = dtTreeOrder.ChildID AND ";
				strSQL << "    dtItems.MProjectID = dtTreeOrder.MProjectID AND ";
				strSQL << "    dtItems.ItemID = dtTreeOrder.ChildID AND ";
				strSQL << "    dtTreeOrder.MProjectID = " << theCCVOClient->getSelLeafMProjectID() << " AND";
				strSQL << "    dtTreeOrder.ItemID =      "<< theCCVOClient->getSelLeafItemID();	

				if ( theCCVOClient->m_dataBase->getRS(strSQL, PopSet) )							
				{							
					while(!PopSet->adoEOF)
					{					
						insertRow( (long)PopSet->Fields->Item[_variant_t(0l)]->Value,
							(char*)(_bstr_t)PopSet->Fields->Item[_variant_t(1l)]->Value,
							(char*)(_bstr_t)PopSet->Fields->Item[_variant_t(2l)]->Value, 
							(char*)(_bstr_t)PopSet->Fields->Item[_variant_t(3l)]->Value);
						
						PopSet->MoveNext();						
					}

					PopSet->Close();					
				}			
				return ;
			}
			catch(_com_error &e) 
			{ 
				ccErr(getProviderError( theCCVOClient->m_dataBase->getConnection()) );
				ccThrowccException( getProviderError( theCCVOClient->m_dataBase->getConnection()) ); /*Delete unreference warning*/ (void*)&e; 				
			}	
		}
		catch( ccException * e)
		{
			ccErr( *e, "", "", MB_OK );			
		}
		catch(...)
		{
			ccErrEM( IDS_CANT_RETRIVE_FAVORITES, NULL, NULL, MB_OK );
		}
	}
	else
		ccErrEM( IDS_DATABASE_ISNT_OPEN, NULL, NULL, MB_OK);	
}

//

void cccFavoritesView::insertRow(int nRow, LPCSTR strName, LPCSTR strURL, LPCSTR strNotes)
{
	LVITEM item;	
	item.mask = LVIF_TEXT;
	item.iItem = nRow;
	item.iSubItem = 0;
	
	//item.cchTextMax  =100;
	item.pszText = new char[100];
	strcpy(item.pszText, strName);	

	item.iItem = m_grid.InsertItem(&item);	
	m_grid.SetItemData( item.iItem, nRow );
	
	item.iSubItem = 1; strcpy(item.pszText, strURL);
	m_grid.SetItem(&item);

	item.iSubItem = 2; strcpy( item.pszText, strNotes);	
	m_grid.SetItem(&item);
}

//

void cccFavoritesView::OnDblclkFavoritesGrid(NMHDR* pNMHDR, LRESULT* pResult) 
{
	openSelectedFavorite();	
	*pResult = 0;
}

//

void cccFavoritesView::OnReturnFavoritesGrid(NMHDR* pNMHDR, LRESULT* pResult) 
{
	openSelectedFavorite();	
	*pResult = 0;
}
	
//

void cccFavoritesView::openSelectedFavorite()
{
	POSITION pos = m_grid.GetFirstSelectedItemPosition();
	if (pos != NULL)
	{
		int nItem = m_grid.GetNextSelectedItem(pos);
		int nItemData = m_grid.GetItemData( nItem );
		theCCVOClient->setSelGridItemID( nItemData);
	}
	else
		theCCVOClient->setSelGridItemID( -1);

	cccVOEditor* pFrame = new cccVOEditor(CCVO_FAVORITES_MODE, AfxGetMainWnd());

	theCCVOClient->setSelGridItemID( -1);
}

void cccFavoritesView::OnKeydownFavoritesGrid(NMHDR* pNMHDR, LRESULT* pResult) 
{
	LV_KEYDOWN* pLVKeyDow = (LV_KEYDOWN*)pNMHDR;
	
	if ( pLVKeyDow->wVKey == VK_DELETE)
	{
		CString strDeleteFavorite; strDeleteFavorite.LoadString( IDS_DELETE_FAVORITE );
		CString strConfirm; strConfirm.LoadString( IDS_CONFIRM_DELETE_ITEM );
		if ( MessageBox( strDeleteFavorite, strConfirm, MB_YESNO ) == IDYES  )
		{
			POSITION pos = m_grid.GetFirstSelectedItemPosition();
			if (pos == NULL)
			   TRACE0("No items to delete!\n");
			else
			{
			   while (pos)
			   {
					int nItem = m_grid.GetNextSelectedItem(pos);
					// TODO Maybe move this to DeleteItem.
	  				dd( m_ddFavorites )->deleteFavorite( theCCVOClient->getSelLeafMProjectID(), theCCVOClient->getSelLeafItemID(), m_grid.GetItemData( nItem ) );
					m_grid.DeleteItem( nItem );			  
			   }
			}					
		}
	}
	
	*pResult = 0;
}
