// cccContactsPreviewPane.cpp : implementation file
//

#include "stdafx.h"
#include "ccvo2k.h"

#include "cccContactsPreviewPane.h"

#include "cccContactsTABPersonal.h"
#include "cccContactsTABHome.h"
#include "cccContactsTABBusiness.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccContactsPreviewPane

IMPLEMENT_DYNCREATE(cccContactsPreviewPane, ccTabView)

cccContactsPreviewPane::cccContactsPreviewPane()
{
	setDB( new cccVODB );
}

cccContactsPreviewPane::~cccContactsPreviewPane()
{
	try
	{
		try
		{
			// *WIN 98 * Need to delete the ctrls before the database
			if ( getTabCtrl())		
				getTabCtrl()->removeAll();

			delete getDB();
		}
		catch(_com_error &e) 
		{ 
			ccThrowccException( getComError(e) ); /*Disable unreference warning*/ (void*)&e; 
		}		
	}
	catch(ccException *e) 
	{
		ccErr(*e,"","", MB_OK);	
	}	
	catch(...) 
	{
		ccErr("DB Error", "","", MB_OK);		
	}
}


BEGIN_MESSAGE_MAP(cccContactsPreviewPane, ccTabView)
	//{{AFX_MSG_MAP(cccContactsPreviewPane)
	ON_COMMAND(ID_SAVE_AND_CLOSE, OnSaveAndClose)
	ON_WM_CREATE()
	ON_COMMAND(ID_SAVE, OnSave)
	ON_COMMAND(IDM_NEW_MESSAGE_TO_CONTACT, OnNewMessageToContact)
	ON_COMMAND(IDM_DELETE_ITEM, OnDeleteItem)
	ON_COMMAND(ID_LAST_ITEM, OnLastItem)
	ON_COMMAND(ID_FIRST_ITEM, OnFirstItem)
	ON_COMMAND(ID_NEXT_ITEM, OnNextItem)
	ON_COMMAND(ID_PREVIOUS_ITEM, OnPreviousItem)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cccContactsPreviewPane drawing

void cccContactsPreviewPane::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();		
}

/////////////////////////////////////////////////////////////////////////////
// cccContactsPreviewPane diagnostics

#ifdef _DEBUG
void cccContactsPreviewPane::AssertValid() const
{
	ccTabView::AssertValid();
}

void cccContactsPreviewPane::Dump(CDumpContext& dc) const
{
	ccTabView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// cccContactsPreviewPane message handlers

BOOL cccContactsPreviewPane::PreCreateWindow(CREATESTRUCT& cs) 
{
	cs.style &= ~WS_BORDER;
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;

	return ccTabView::PreCreateWindow(cs);
}

//

void cccContactsPreviewPane::OnSaveAndClose() 
{	
	if (theCCVOClient->getCurrentGridCtrl())
		dd( m_ddContacts )->bindNonDBCtrls( theCCVOClient->getCurrentGridCtrl() );

	if ( dd( m_ddContacts )->saveRecord() == CCSUCCEDED)
		GetParent()->SendMessage(WM_CLOSE);	
		// No need to remove the ctrl from the contacts DD. When sending WM_CLOSE
		// cause it's removed in the destructor
	else	
		if (theCCVOClient->getCurrentGridCtrl())
			dd( m_ddContacts )->removeNonDBCtrls( theCCVOClient->getCurrentGridCtrl() );		
}

//

void cccContactsPreviewPane::OnSave() 
{
	if (theCCVOClient->getCurrentGridCtrl())
		dd( m_ddContacts )->bindNonDBCtrls( theCCVOClient->getCurrentGridCtrl() );

	dd( m_ddContacts )->saveRecord();		

	if (theCCVOClient->getCurrentGridCtrl())
		dd( m_ddContacts )->removeNonDBCtrls( theCCVOClient->getCurrentGridCtrl() );		
}

//

void cccContactsPreviewPane::OnInitialUpdate() 
{
	ccTabView::OnInitialUpdate();		
}

//

void cccContactsPreviewPane::OnNewMessageToContact() 
{	
	mailTo( dd( m_ddContacts )->m_PrimEMail, this);
}

//

void cccContactsPreviewPane::OnDeleteItem() 
{
 	CString strDeleteContact; strDeleteContact.LoadString( IDS_DELETE_CONTACT );
	CString strConfirm; strConfirm.LoadString( IDS_CONFIRM_DELETE_ITEM );
	if ( MessageBox( strDeleteContact, strConfirm, MB_YESNO ) == IDYES  )
	{
		dd( m_ddContacts )->deleteContact( dd( m_ddContacts )->m_MProjectID, dd( m_ddContacts )->m_ParentItemID, dd( m_ddContacts )->m_ItemID);
		Sleep(1000);				
		dd( m_ddContacts )->requery();				
		if (theCCVOClient->getCurrentGridCtrl())
			theCCVOClient->getCurrentGridCtrl()->OnDeleteComplete();
	}
}

//

void cccContactsPreviewPane::OnLastItem() 
{
	dd( m_ddContacts )->moveLast();
}

//

void cccContactsPreviewPane::OnFirstItem() 
{
	dd( m_ddContacts )->moveFirst();
}

//

void cccContactsPreviewPane::OnNextItem() 
{
	dd( m_ddContacts )->moveNext();
}

//

void cccContactsPreviewPane::OnPreviousItem() 
{
	dd( m_ddContacts )->movePrev();	
}

//

int cccContactsPreviewPane::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (ccTabView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	//If the view is used by the ccVOViewer
	try
	{
		int nMProjectID;
		int nItemID;
		nMProjectID = theCCVOClient->getSelLeafMProjectID();

		if ( theCCVOClient->getFunctionType() == cIXCONTACTS )
			nItemID = theCCVOClient->getSelLeafItemID();
		else
			nItemID = cIXCONTACTS;

		// Create a new database.		
		dd( m_ddContacts )->setSelLeafMProjectID(nMProjectID );
		dd( m_ddContacts )->setSelLeafItemID( nItemID ); 

		ccString strFilter;
		strFilter << "MProjectID = "		  << nMProjectID << " and ";
		strFilter << "dtTreeOrder.ItemID = "  << nItemID;	

		dd( m_ddContacts )->getRS()->Filter = (_bstr_t)strFilter;

		if (theCCVOClient->getSelGridItemID() != -1)
		{						
			dd( m_ddContacts )->moveFirst();
			
			if ( !dd( m_ddContacts )->isEmpty() )
			{
				ccString strCriteria;
				strCriteria << "dtfContacts.ItemID = " << theCCVOClient->getSelGridItemID();
				dd( m_ddContacts )->find( strCriteria);
			}
		}
		//If the view is used by the CMainFrame
		else
			dd( m_ddContacts )->clearRecord( true );					

		getTabCtrl()->InsertItem( 0, "Personal", new cccContactsTABPersonal( getTabCtrl(), __getDB() ) );
		getTabCtrl()->InsertItem( 1, "Home",     new cccContactsTABHome(getTabCtrl(), __getDB() ) );
		getTabCtrl()->InsertItem( 2, "Business", new cccContactsTABBusiness(getTabCtrl(), __getDB() ) );	
	}
	catch(_com_error &e) 
	{ 
		ccErr(getComError(e),"","", MB_OK );				
	}	


	
	return 0;
}

