// cccdRegUsr2General.cpp : implementation file
//

#include "stdafx.h"
#include "cccdRegUsr2General.h"
#include "TransferStructs.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccdRegUsr2General property page

IMPLEMENT_DYNCREATE(cccdRegUsr2General, CPropertyPage)

cccdRegUsr2General::cccdRegUsr2General() : CPropertyPage(cccdRegUsr2General::IDD)
{
	//{{AFX_DATA_INIT(cccdRegUsr2General)
	m_userName = _T("");
	m_password = _T("");
	m_confirmPassword = _T("");
	m_company = _T("");
	m_fullName = _T("");
	m_address = _T("");
	m_zipCode = _T("");
	m_phone = _T("");
	m_fax = _T("");
	m_country = _T("");
	m_city = _T("");
	m_email = _T("");
	//}}AFX_DATA_INIT
}


cccdRegUsr2General::~cccdRegUsr2General()
{
}

void cccdRegUsr2General::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(cccdRegUsr2General)
	DDX_Text(pDX, IDC_USER_NAME, m_userName);
	DDV_MaxChars(pDX, m_userName, 40);
	DDX_Text(pDX, IDC_PASSWORD, m_password);
	DDV_MaxChars(pDX, m_password, 40);
	DDX_Text(pDX, IDC_CONFIRM_PASSWORD, m_confirmPassword);
	DDV_MaxChars(pDX, m_confirmPassword, 40);
	DDX_Text(pDX, IDC_COMPANY, m_company);
	DDV_MaxChars(pDX, m_company, 40);
	DDX_Text(pDX, IDC_FULL_NAME, m_fullName);
	DDV_MaxChars(pDX, m_fullName, 40);
	DDX_Text(pDX, IDC_ADDRESS, m_address);
	DDV_MaxChars(pDX, m_address, 40);
	DDX_Text(pDX, IDC_ZIP_CODE, m_zipCode);
	DDV_MaxChars(pDX, m_zipCode, 40);
	DDX_Text(pDX, IDC_PHONE, m_phone);
	DDV_MaxChars(pDX, m_phone, 40);
	DDX_Text(pDX, IDC_FAX, m_fax);
	DDV_MaxChars(pDX, m_fax, 40);
	DDX_Text(pDX, IDC_COUNTRY, m_country);
	DDV_MaxChars(pDX, m_country, 40);
	DDX_Text(pDX, IDC_CITY, m_city);
	DDV_MaxChars(pDX, m_city, 40);
	DDX_Text(pDX, IDC_EMAIL, m_email);
	DDV_MaxChars(pDX, m_email, 50);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(cccdRegUsr2General, CPropertyPage)
	//{{AFX_MSG_MAP(cccdRegUsr2General)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cccdRegUsr2General message handlers

BOOL cccdRegUsr2General::OnSetActive() 
{
	//((CPropertySheet*)GetParent())->SetWizardButtons(PSWIZB_BACK | PSWIZB_NEXT);
	((CPropertySheet*)GetParent())->SetWizardButtons(PSWIZB_BACK | PSWIZB_FINISH);

	
	m_userName	= m_regUsr->m_newUser.m_userName;
	m_password	= m_regUsr->m_newUser.m_password;		
	m_confirmPassword = m_regUsr->m_newUser.m_confirmPassword;
	m_company	= m_regUsr->m_newUser.m_company	;
	m_fullName	= m_regUsr->m_newUser.m_fullName;
	m_address	= m_regUsr->m_newUser.m_address;
	m_zipCode	= m_regUsr->m_newUser.m_zipCode;
	m_phone		= m_regUsr->m_newUser.m_phone;
	m_fax		= m_regUsr->m_newUser.m_fax;
	m_country	= m_regUsr->m_newUser.m_country;
	m_city		= m_regUsr->m_newUser.m_city;
	m_email		= m_regUsr->m_newUser.m_email;
	UpdateData( FALSE );
	
	return CPropertyPage::OnSetActive();
}

//

BOOL cccdRegUsr2General::validateAndSave()
{
	UpdateData();
	
	CString lsErrorMessage;
	
	if ( m_userName.IsEmpty() )
		lsErrorMessage += "You must enter a username\n";

	if ( m_password.IsEmpty() )
		lsErrorMessage += "You must enter a password\n";
		
	if ( m_confirmPassword.IsEmpty() )
		lsErrorMessage += "You must enter a confirmation password\n";

	if ( m_password != m_confirmPassword)
		lsErrorMessage += "Confirmation password doesn't match password\n";

	if ( m_fullName.IsEmpty() )
		lsErrorMessage += "You must enter your fullname\n";

	if ( m_address.IsEmpty() )
		lsErrorMessage += "You must enter an address\n";

	if ( m_zipCode.IsEmpty() )
		lsErrorMessage += "You must enter a zipcode\n";

	if ( m_city.IsEmpty() )
		lsErrorMessage += "You must enter a city\n";

	if ( m_email.IsEmpty() )
		lsErrorMessage += "You must enter an email\n";

	if ( m_country.IsEmpty() )
		lsErrorMessage += "You must enter country\n";

	if ( m_phone.IsEmpty() )
		lsErrorMessage += "You must enter phone number\n";

	if ( !lsErrorMessage.IsEmpty() )
	{
		SetActiveWindow();
		MessageBox( lsErrorMessage, "Reminder");		
		return FALSE;
	}
	else		
	{		
		m_regUsr->m_newUser.m_userName			= m_userName;
		m_regUsr->m_newUser.m_password			= m_password;	
		m_regUsr->m_newUser.m_confirmPassword	= m_confirmPassword;
		m_regUsr->m_newUser.m_company			= m_company;
		m_regUsr->m_newUser.m_fullName			= m_fullName;
		m_regUsr->m_newUser.m_address			= m_address;
		m_regUsr->m_newUser.m_zipCode			= m_zipCode;
		m_regUsr->m_newUser.m_phone				= m_phone;
		m_regUsr->m_newUser.m_fax				= m_fax;
		m_regUsr->m_newUser.m_country			= m_country;
		m_regUsr->m_newUser.m_city				= m_city;
		m_regUsr->m_newUser.m_email				= m_email;

		return TRUE;
	}
}

//

LRESULT cccdRegUsr2General::OnWizardNext() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	if (!validateAndSave())
		return TRUE;
	else	
		return CPropertyPage::OnWizardNext();
}

//

LRESULT cccdRegUsr2General::OnWizardBack() 
{
	if (!validateAndSave())
		return TRUE;
	else	
	{
		((CPropertySheet*)GetParent())->SetWizardButtons(PSWIZB_NEXT);
		return CPropertyPage::OnWizardBack();
	}
}

BOOL cccdRegUsr2General::OnWizardFinish() 
{	
	if (!validateAndSave())
		return TRUE;
	else		
		return CPropertyPage::OnWizardFinish();		
}
