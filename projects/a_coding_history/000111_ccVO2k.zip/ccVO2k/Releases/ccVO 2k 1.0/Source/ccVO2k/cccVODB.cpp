// cccVODB.cpp: implementation of the cccVODB class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "resource.h"
#include "ccVOClient.h"
#include "cccVODB.h"



// ** Datadictionary includes
#include "cccddContacts.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


class cccVO2kApp;
cccVODB::cccVODB()
{
	try
	{	
		CString strDataBaseURL;
		// This reg key is verifyed in the app.
		ccRegistry reg;
		reg.openCreate(HKEY_LOCAL_MACHINE, dPROGRAM_REG_PATH);		
		reg.readWriteString( "DataBaseURL", strDataBaseURL,  "\\ccVO2k.mdb" );		
		reg.Close();			
		
		//if ( !openMSSQLServer( "cybercow", "ccvo2", NULL, NULL) )
		openADOAccessDB( strDataBaseURL, dDATABASEPASSWORD);	

 		m_ddContacts  = new cccddContacts( this );			
		m_ddFavorites = new cccddFavorites( this );
		m_ddFTP		  = new cccddFTP( this );

		// Relations.
		//m_ddINVT->relate( m_ddContacts->m_VENDOR_ID, m_ddVENDOR->m_ID );
		enableReadyToUseDB( );
	}
	catch(ccException *e) 
	{
		ccErr(*e,"","", MB_OK);
		exit(1);
	}
	catch(...) 
	{
		ccErr("DB Error", "","", MB_OK);
		exit(1);
	}
}

//

cccVODB::~cccVODB()
{
	delete m_ddContacts;	
	delete m_ddFavorites;
	delete m_ddFTP;
}
//////////////////////////////////////////////////////////////////////
// *** "Update" functions updateing just one table
//////////////////////////////////////////////////////////////////////

bool cccVODB::update_dtItems( int nMProjectID, int nItemID, LPCSTR strName)
{
	try
	{
		// Get Current Time
		ccTime crntTime = *((ccTime*)&CGoodTime::GetCurrentTime());
		ccString strCrntTime;  
		strCrntTime << "'" << crntTime.getDateTime() << "'";
		
		//Update dtItems
		ccString strSQL;
		strSQL = "";	
		strSQL << "UPDATE dtItems ";
		strSQL <<	"SET Name = " << "'" << strName << "'";		
		strSQL <<   " , ChangedSinceInternetMerge = 1";
		strSQL <<   " , DateModified = "<< strCrntTime;
 		strSQL <<	" where [MProjectID] = " << nMProjectID;
		strSQL <<	   " AND [ItemID] = " << nItemID;

		// Execute SQL statement
		_variant_t vRecordsEffected;		
		if ( executeSQLNoRet( strSQL, vRecordsEffected ) )
		{
			ASSERT( vRecordsEffected.intVal != 0);
			return true;
		}
		else
			ccThrowccException( IDS_COULDNT_UPDATE_ITEM_NAME );		
	}
	catch( ccException * e)
	{
		ccErr( *e, "", "", MB_OK );			
	}
	catch(...)
	{
		ccErrEM( IDS_GENERAL_CCVOVCLIENT_ERROR );				
	}		
	return false;
}

//

bool cccVODB::update_dtfContactsEmail( int nMProjectID, int nItemID, LPCSTR strComment, LPCSTR strEmailAdress, int bPlainText)
{
	try
	{		
		ccString strSQL;
		strSQL = "";	
		strSQL << "UPDATE dtfContactsEmail ";
		strSQL <<	"SET EmailAdress= "         << "'" << strEmailAdress << "'";		
		strSQL <<   " , SendUsingPlainText = " << bPlainText;
 		strSQL <<	" where [MProjectID] = " << nMProjectID;
		strSQL <<	   " AND [ItemID] = "  << nItemID;
		strSQL <<	   " AND [Comment] = '" << strComment << "'";

		// Execute SQL statement
		_variant_t vRecordsEffected;		
		if ( executeSQLNoRet( strSQL, vRecordsEffected ) )
		{
			ASSERT( vRecordsEffected.intVal != 0);
			return true;
		}
		else
			ccThrowccException( IDS_COULDNT_UPDATE_DTFCONTACTS_EMAIL );		
	}
	catch( ccException * e)
	{
		ccErr( *e, "", "", MB_OK );			
	}
	catch(...)
	{
		ccErrEM( IDS_GENERAL_CCVOVCLIENT_ERROR );				
	}		
	return false;
}

//

bool cccVODB::update_dtfContactsPhone( int nMProjectID, int nItemID, LPCSTR strPhoneName, LPCSTR strNumber)
{
	try
	{		
		ccString strSQL;
		strSQL = "";	
		strSQL << "UPDATE dtfContactsPhone ";
		strSQL <<	"SET [Number] = "            << "'" << strNumber << "'";				
 		strSQL <<	" where [MProjectID] = "  << nMProjectID;
		strSQL <<	   " AND [ItemID] = "     << nItemID;
		strSQL <<	   " AND [PhoneName] = '" << strPhoneName << "'";

		// Execute SQL statement
		_variant_t vRecordsEffected;		
		if ( executeSQLNoRet( strSQL, vRecordsEffected ) )
		{
			ASSERT( vRecordsEffected.intVal != 0);
			return true;
		}
		else
			ccThrowccException( IDS_COULDNT_UPDATE_DTFCONTACTS_PHONE );		
	}
	catch( ccException * e)
	{
		ccErr( *e, "", "", MB_OK );			
	}
	catch(...)
	{
		ccErrEM( IDS_GENERAL_CCVOVCLIENT_ERROR );				
	}		
	return false;
}



//////////////////////////////////////////////////////////////////////
// *** "delete" functions, deleteing from just one table
//////////////////////////////////////////////////////////////////////

bool cccVODB::delete_dtItems( int nMProjectID, int nItemID)
{
	try
	{
		ccString strSQL;	

		strSQL << "DELETE from dtItems ";		
 		strSQL <<	" where [MProjectID] = " << nMProjectID;
		strSQL <<	   " AND [ItemID] = " << nItemID;

		// Execute SQL statement
		_variant_t vRecordsEffected;		
		if ( executeSQLNoRet( strSQL, vRecordsEffected ) )
		{
			ASSERT( vRecordsEffected.intVal != 0);
			return true;
		}
		else
			ccThrowccException( IDS_COULDNT_DELETE_DTITEM );		
	}
	catch( ccException * e)
	{
		ccErr( *e, "", "", MB_OK );			
	}
	catch(...)
	{
		ccErrEM( IDS_GENERAL_CCVOVCLIENT_ERROR );				
	}		
	return false;
}

//

bool cccVODB::delete_dtTreeOrder( int nMProjectID, int nItemID, int nChildID)
{
	try
	{
		ccString strSQL;	

		strSQL << "DELETE from dtTreeOrder ";
 		strSQL <<	" where [MProjectID] = " << nMProjectID;
		strSQL <<	   " AND [ItemID] = "    << nItemID;
		strSQL <<	   " AND [ChildID] = " << nChildID;

		// Execute SQL statement
		_variant_t vRecordsEffected;		
		if ( executeSQLNoRet( strSQL, vRecordsEffected ) )
		{
			ASSERT( vRecordsEffected.intVal != 0);
			return true;
		}
		else
			ccThrowccException( IDS_COULDNT_DELETE_DTTREEORDER );		
	}
	catch( ccException * e)
	{
		ccErr( *e, "", "", MB_OK );			
	}
	catch(...)
	{
		ccErrEM( IDS_GENERAL_CCVOVCLIENT_ERROR );				
	}		
	return false;
}

//

bool cccVODB::delete_dtfContactsEmail( int nMProjectID, int nItemID, LPCSTR strName)
{
	try
	{
		ccString strSQL;	

		strSQL << "DELETE from dtfContactsEmail";
 		strSQL <<	" where [MProjectID] = " << nMProjectID;
		strSQL <<	   " AND [ItemID] = "    << nItemID;
		strSQL <<	   " AND [Comment] = '"   << strName << "'";

		// Execute SQL statement
		_variant_t vRecordsEffected;		
		if ( executeSQLNoRet( strSQL, vRecordsEffected ) )
		{
			ASSERT( vRecordsEffected.intVal != 0);
			return true;
		}
		else
			ccThrowccException( "Couldn't delete dtfContactsEmail");		
	}
	catch( ccException * e)
	{
		ccErr( *e, "", "", MB_OK );			
	}
	catch(...)
	{
		ccErrEM( IDS_GENERAL_CCVOVCLIENT_ERROR );				
	}		
	return false;
}

//

bool cccVODB::delete_dtfContactsPhone( int nMProjectID, int nItemID, LPCSTR strPhoneName)
{
	try
	{
		ccString strSQL;	

		strSQL << "DELETE from dtfContactsPhone";
 		strSQL <<	" where [MProjectID] = " << nMProjectID;
		strSQL <<	   " AND [ItemID] = "    << nItemID;
		strSQL <<	   " AND [PhoneName] = '"   << strPhoneName<< "'";

		// Execute SQL statement
		_variant_t vRecordsEffected;		
		if ( executeSQLNoRet( strSQL, vRecordsEffected ) )
		{
			ASSERT( vRecordsEffected.intVal != 0);
			return true;
		}
		else
			ccThrowccException( "Couldn't delete dtfContactsPhone");		
	}
	catch( ccException * e)
	{
		ccErr( *e, "", "", MB_OK );			
	}
	catch(...)
	{
		ccErrEM( IDS_GENERAL_CCVOVCLIENT_ERROR );				
	}		
	return false;
}

//////////////////////////////////////////////////////////////////////
// *** "insert" functions, inserting to just one table
//////////////////////////////////////////////////////////////////////
void cccVODB::insert_dtUser( sNewUser &aNewUser, int nUserID)
{
	// Create SQL Statement
	ccString strSQL;	

	strSQL << "INSERT INTO dtUser ";
	strSQL <<	"([UserID], [Username], [Password], [Company], [fullname], [address], [zipCode], ";
	strSQL <<	"[phone], [fax], [country], [city], [email], [bContacts], [bFavorite], [bFTP], [storage],";
	strSQL <<	"[currencyType], [paymentType], [price])";
	strSQL << " VALUES (";
	
	strSQL << "'" << nUserID		     << "', ";
	strSQL << "'" << aNewUser.m_userName << "', ";
	strSQL << "'" << aNewUser.m_password << "', ";
	strSQL << "'" << aNewUser.m_company  << "', "; 
	strSQL << "'" << aNewUser.m_fullName << "', "; 
	strSQL << "'" << aNewUser.m_address  << "', ";
	strSQL << "'" << aNewUser.m_zipCode  << "', ";
	strSQL << "'" << aNewUser.m_phone    << "', ";
	strSQL << "'" << aNewUser.m_fax      << "', ";
	strSQL << "'" << aNewUser.m_country  << "', ";
	strSQL << "'" << aNewUser.m_city     << "', ";
	strSQL << "'" << aNewUser.m_email     << "', ";
	strSQL << aNewUser.m_functions[ cIXCONTACTS-1 ]  << ", ";
	strSQL << aNewUser.m_functions[ cIXFAVORITES-1 ] << ", ";
	strSQL << aNewUser.m_functions[ cIXFTP-1]      << ", ";
	strSQL << aNewUser.m_storage      << ", ";
	strSQL << aNewUser.m_currencyType << ", ";
	strSQL << aNewUser.m_paymentType  << ", ";
	strSQL << aNewUser.m_price;

	strSQL << ")";	

	// Execute SQL statement
	_variant_t vRecordsEffected;		
	if ( executeSQLNoRet( strSQL, vRecordsEffected ) )
	{
		ASSERT( vRecordsEffected.intVal != 0);
		return;
	}
	else
		ccThrowccException( IDS_COULDNT_CREATE_USER );
}

//

void cccVODB::insert_dtMasterProject( sNewUser &aNewUser, int nUserID )
{
	ccString strSQL;	

	strSQL << "INSERT INTO dtMasterProject ";
	strSQL <<	"([MProjectID], [Name], [OwnerID], [MProjectTypeID]) ";
	strSQL << " VALUES (";
	
	strSQL << aNewUser.m_MProjectID << ", ";
	strSQL << "'Personal (" << aNewUser.m_userName << ")', ";
	strSQL << nUserID << ", "; 
	strSQL << 2;	// Personal project type, from dtcMProjectTypes
	strSQL << ")";	

	// Execute SQL statement
	_variant_t vRecordsEffected;		
	if ( executeSQLNoRet( strSQL, vRecordsEffected ) )
	{
		ASSERT( vRecordsEffected.intVal != 0);
		return;
	}
	else
		ccThrowccException( IDS_COULDNT_CREATE_MASTERPROJECT );
}

//

void cccVODB::insert_dtMProjectMembers( sNewUser &aNewUser, int nUserID )
{
	ccString strSQL;	

	strSQL << "INSERT INTO dtMProjectMembers ";
	strSQL <<	"([MProjectID], [MemberID]) ";
	strSQL << " VALUES (";
	
	strSQL << aNewUser.m_MProjectID << ", ";	
	strSQL << nUserID; 
	strSQL << ")";	

	// Execute SQL statement
	_variant_t vRecordsEffected;		
	if ( executeSQLNoRet( strSQL, vRecordsEffected ) )
	{
		ASSERT( vRecordsEffected.intVal != 0);
		return;
	}
	else
		ccThrowccException( IDS_COULDNT_CREATE_MASTERPROJECTMEMBERS );
}

//

void cccVODB::insert_dtUserActiveMProjects( sNewUser &aNewUser, int nUserID )
{
	ccString strSQL;	

	strSQL << "INSERT INTO dtUserActiveMProjects ";
	strSQL <<	"([UserID], [MProjectID]) ";
	strSQL << " VALUES (";
	
	strSQL << nUserID		<< ", "; 
	strSQL << aNewUser.m_MProjectID;
	strSQL << ")";	

	// Execute SQL statement
	_variant_t vRecordsEffected;		
	if ( executeSQLNoRet( strSQL, vRecordsEffected ) )
	{
		ASSERT( vRecordsEffected.intVal != 0);
		return;
	}
	else
		ccThrowccException( IDS_COULDNT_CREATE_USERACTIVEMPROJECTS );
}

//

void cccVODB::insert_dtItems( int nMProjectID, int nItemID, CString strName, int nFunctionType, int nItemType )
{	
	ccString strSQL;	
	
	ccTime crntTime = *((ccTime*)&CGoodTime::GetCurrentTime());
	ccString strCrntTime;  
	strCrntTime << "'" << crntTime.getDateTime() << "'";

	strSQL << "INSERT INTO dtItems ";
	strSQL <<	"([MProjectID], [ItemID], [ItemType], [Name], [FunctionType], ";
	strSQL <<	"[DateRegistered],[DateModified], [Revision], ";
	strSQL <<	"[ChangedSinceInternetMerge])";
	strSQL << " VALUES (";
	
	strSQL		     << nMProjectID;		// MProjectID
	strSQL << ", "   << nItemID;			// ItemID
	strSQL << ", "   << nItemType;		// ItemType
	strSQL << ", '"  << strName <<"'";			// Name
	strSQL << ", "   << nFunctionType;	// FunctionType
	strSQL << ", "   << strCrntTime;		// DateRegistered
	strSQL << ", "   << strCrntTime;		// DataModified
	strSQL << ", "   << "0";				// Revision
	strSQL << ", "   << "1";				// ChangedSinceInternetMerge
	strSQL << ")";	

	// Execute SQL statement
	_variant_t vRecordsEffected;		
	if ( executeSQLNoRet( strSQL, vRecordsEffected ) )
	{
		ASSERT( vRecordsEffected.intVal != 0);
		return;
	}
	else
		ccThrowccException( IDS_COULDNT_CREATE_DTITEM );
}

//

void cccVODB::insert_dtTreeOrder( int nMProjectID, int nItemID, int nChildID )
{	
	ccString strSQL;	
	
	strSQL << "INSERT INTO dtTreeOrder ";
	strSQL <<	"([MProjectID], [ItemID], [ChildID])";
	strSQL << " VALUES (";
	
	strSQL		    << nMProjectID;		// MProjectID
	strSQL << ", "  << nItemID;			// ItemID	
	strSQL << ", "  << nChildID;		// ChildID
	strSQL << ")";	

	// Execute SQL statement
	_variant_t vRecordsEffected;		
	if ( executeSQLNoRet( strSQL, vRecordsEffected ) )
	{
		ASSERT( vRecordsEffected.intVal != 0);
		return;
	}
	else
		ccThrowccException( IDS_COULDNT_CREATE_DTTREEITEM );
}

//

void cccVODB::insert_dtfContactsEmail( int nMProjectID, int nItemID, LPCSTR strComment) //, LPCSTR strEmail, bool bPlainText);
{	
	ccString strSQL;	
	
	strSQL << "INSERT INTO dtfContactsEmail ";
	strSQL <<	"([MProjectID], [ItemID], [Comment]) "; //, [EmailAdress], [SendUsingPlainText]) ";
	strSQL << " VALUES (";
	
	strSQL		     << nMProjectID;			// MProjectID
	strSQL << ", "   << nItemID;				// ItemID	
	strSQL << ", '"  << strComment << "'";		// Comment
	strSQL << ")";	

	// Execute SQL statement
	_variant_t vRecordsEffected;		
	if ( executeSQLNoRet( strSQL, vRecordsEffected ) )
	{
		ASSERT( vRecordsEffected.intVal != 0);
		return;
	}
	else
		ccThrowccException( IDS_COULDNT_CREATE_DTFCONTACTSEMAIL );
}

//

void cccVODB::insert_dtfContactsPhone( int nMProjectID, int nItemID, LPCSTR strPhoneName)
{	
	ccString strSQL;	
	
	strSQL << "INSERT INTO dtfContactsPhone ";
	strSQL <<	"([MProjectID], [ItemID], [PhoneName]) ";
	strSQL << " VALUES (";
	
	strSQL		     << nMProjectID;			// MProjectID
	strSQL << ", "   << nItemID;				// ItemID	
	strSQL << ", '"  << strPhoneName << "'";	// Comment
	strSQL << ")";	

	// Execute SQL statement
	_variant_t vRecordsEffected;		
	if ( executeSQLNoRet( strSQL, vRecordsEffected ) )
	{
		ASSERT( vRecordsEffected.intVal != 0);
		return;
	}
	else		
		ccThrowccException( "Couldn't create dtfContactsPhone");		
}


//////////////////////////////////////////////////////////////////////
// *** Create ID:s
//
// Those won't work on the server, Multi user mode.
//
//////////////////////////////////////////////////////////////////////

int cccVODB::createNewUserID()
{
	ccString strSQL;	
	strSQL << "SELECT TOP 1 UserID ";
	strSQL <<	"FROM dtUser ";
	strSQL <<	"ORDER BY UserID DESC";

	_variant_t vReturn;
	if ( getRSVariant(strSQL, &vReturn) )			
		return (int)(vReturn.intVal+1);		
	else 
		return 0;
}

//

int cccVODB::createMProjectID()
// TODO need a new function to create USERID
{
	ccString strSQL;	
	strSQL << "SELECT TOP 1 MProjectID ";
	strSQL <<	"FROM dtMasterProject ";
	strSQL <<	"ORDER BY MProjectID DESC";

	_variant_t vReturn;
	if ( getRSVariant(strSQL, &vReturn) )			
		return (int)(vReturn.intVal+1);	
	else 
		return 0;
}

//

int cccVODB::createItemID()
// TODO need a new function to create USERID
{
	ccString strSQL;	
	strSQL << "SELECT TOP 1 ItemID ";
	strSQL <<	"FROM dtItems ";
	strSQL <<	"ORDER BY ItemID DESC";

	_variant_t vReturn;
	if ( getRSVariant(strSQL, &vReturn) )			
	{
		int nItemID = (int)(vReturn.intVal+1);
		if (nItemID <= 100) 
			nItemID = 100;
		return nItemID;	
	}
	else 
		return 0;
}

//


