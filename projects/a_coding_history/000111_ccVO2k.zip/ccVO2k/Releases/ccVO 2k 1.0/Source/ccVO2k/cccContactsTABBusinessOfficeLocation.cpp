// cccContactsTABBusinessOfficeLocation.cpp : implementation file
//

#include "stdafx.h"
#include "ccvo2k.h"
#include "cccContactsTABBusinessOfficeLocation.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccContactsTABBusinessOfficeLocation dialog


cccContactsTABBusinessOfficeLocation::cccContactsTABBusinessOfficeLocation(CWnd* pParent, cccVODB *aoDB)
	: ccdbDialog(cccContactsTABBusinessOfficeLocation::IDD, pParent, aoDB)	
{
	//{{AFX_DATA_INIT(cccContactsTABBusinessOfficeLocation)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	Create(cccContactsTABBusinessOfficeLocation::IDD, pParent);	
}


void cccContactsTABBusinessOfficeLocation::DoDataExchange(CDataExchange* pDX)
{
	ccdbDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(cccContactsTABBusinessOfficeLocation)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(cccContactsTABBusinessOfficeLocation, ccdbDialog)
	//{{AFX_MSG_MAP(cccContactsTABBusinessOfficeLocation)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cccContactsTABBusinessOfficeLocation message handlers
BOOL cccContactsTABBusinessOfficeLocation::OnInitDialog() 
{
	setDDServer( dd(m_ddContacts) );

	m_Business_Office_Street.adddbField( &dd(m_ddContacts)->m_Business_Office_Street  );
	m_Business_Office_Street.setCaptionOffset(-90);		
	m_Business_Office_Street.SubclassDlgItem( IDC_OFFICE_STREET, this, this );

	m_Business_Office_Zip_Or_PostalCode.adddbField( &dd(m_ddContacts)->m_Business_Office_ZipOrPostalCode  );
	m_Business_Office_Zip_Or_PostalCode.setCaptionOffset(-90);
	m_Business_Office_Zip_Or_PostalCode.SubclassDlgItem( IDC_OFFICE_ZIP_OR_POSTALCODE, this, this );

	m_Business_Office_City.adddbField( &dd(m_ddContacts)->m_Business_Office_City  );
	m_Business_Office_City.setCaptionOffset(-90);		
	m_Business_Office_City.SubclassDlgItem( IDC_OFFICE_CITY, this, this );

	m_Business_Office_State_Or_Province.adddbField( &dd(m_ddContacts)->m_Business_Office_StateOrProvince  );
	m_Business_Office_State_Or_Province.setCaptionOffset(-90);
	m_Business_Office_State_Or_Province.SubclassDlgItem( IDC_OFFICE_STATE_OR_PROVINCE, this, this );

	m_Business_Office_Country_Or_Region.adddbField( &dd(m_ddContacts)->m_Business_Office_CountryOrRegion  );
	m_Business_Office_Country_Or_Region.setCaptionOffset(-90);
	m_Business_Office_Country_Or_Region.SubclassDlgItem( IDC_OFFICE_COUNTRY_OR_REGION, this, this );

	ccdbDialog::OnInitDialog();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
