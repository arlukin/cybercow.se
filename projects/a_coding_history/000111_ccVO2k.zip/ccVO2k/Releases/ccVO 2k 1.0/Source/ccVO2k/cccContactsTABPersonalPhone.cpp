// cccContactsTABPersonalPhone.cpp : implementation file
//

#include "stdafx.h"
#include "ccvo2k.h"
#include "cccContactsTABPersonalPhone.h"
#include "resource.h"
#include "ccDLGQuestion.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccContactsTABPersonalPhone dialog


cccContactsTABPersonalPhone::cccContactsTABPersonalPhone(CWnd* pParent /*=NULL*/)
	: ccllGroup(cccContactsTABPersonalPhone::IDD, pParent)
{
	//{{AFX_DATA_INIT(cccContactsTABPersonalPhone)
	m_phoneName = _T("");
	m_phoneNumber = _T("");
	//}}AFX_DATA_INIT	
}


void cccContactsTABPersonalPhone::DoDataExchange(CDataExchange* pDX)
{
	ccllGroup::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(cccContactsTABPersonalPhone)
	DDX_Text(pDX, IDC_PHONE_NAME, m_phoneName);
	DDV_MaxChars(pDX, m_phoneName, 50);
	DDX_Text(pDX, IDC_PHONE_NUMBER, m_phoneNumber);
	DDV_MaxChars(pDX, m_phoneNumber, 50);
	//}}AFX_DATA_MAP
}

//
//

void cccContactsTABPersonalPhone::OnBuildMenu(ccMenuButton *menuButton)
{
	POSITION pos;
   	int nIndex = 0;

	for( pos = dd(m_ddContacts)->m_contactsPhoneSL.GetHeadPosition(); pos != NULL; )
	{
		sContactsPhone * contactsPhone = ((sContactsPhone*)dd(m_ddContacts)->m_contactsPhoneSL.GetNext( pos ));
		if (!contactsPhone->bDeletedRecord)
			menuButton->addMenuItem( contactsPhone->strPhoneName, nIndex);

		nIndex++;
	}
}

//

void cccContactsTABPersonalPhone::OnNewItem()
{
	
	CString strCaption;strCaption.LoadString( IDS_NAME_OF_THE_NEW_PHONE_NAME);
	ccDLGQuestion question( this );
	
	CString strPhoneName = question.getAnswer(strCaption);

	if ( strPhoneName != "-1")
	{		
		// Create the new record
		sContactsPhone * ptrContactsPhone = new sContactsPhone;

		ptrContactsPhone->strPhoneName	  = strPhoneName;
		ptrContactsPhone->bNew			  = true;
		ptrContactsPhone->bCantDelete	  = false;
		ptrContactsPhone->bDeletedRecord  = false;
		ptrContactsPhone->bChanged		  = false;
		dd(m_ddContacts)->m_contactsPhoneSL.AddTail( ptrContactsPhone );

		// Select the new record;
		POSITION pos;

		if( ( pos = dd(m_ddContacts)->m_contactsPhoneSL.GetTailPosition() ) != NULL )
		{
			sContactsPhone * contactsPhone = (sContactsPhone*)dd(m_ddContacts)->m_contactsPhoneSL.GetAt( pos ) ;
			m_phoneName   = contactsPhone->strPhoneName;
			m_phoneNumber = contactsPhone->strNumber;

			switch ( m_nPhoneGroup)
			{
			case 1: dd(m_ddContacts)->m_PhoneName1.setValue( m_phoneName );
					break;
			case 2: dd(m_ddContacts)->m_PhoneName2.setValue( m_phoneName );
					break;
			case 3: dd(m_ddContacts)->m_PhoneName3.setValue( m_phoneName );
					break;
			}

			UpdateData(false);
			dd(m_ddContacts)->setModified(true);

			// Get the last menuitem index
			int nIndex = 0;
			for( pos = dd(m_ddContacts)->m_contactsPhoneSL.GetHeadPosition(); pos != NULL; )
			{
				sContactsPhone * contactsPhone = ((sContactsPhone*)dd(m_ddContacts)->m_contactsPhoneSL.GetNext( pos ));
				if (!contactsPhone->bDeletedRecord)
				{
					m_nSelectedItem = nIndex;	
				}
				nIndex++;
			}			
		}    
	}
}

//

void cccContactsTABPersonalPhone::OnDeleteItem()
{
	POSITION pos;

	if( ( pos = dd(m_ddContacts)->m_contactsPhoneSL.FindIndex( m_nSelectedItem )) != NULL )
	{
		sContactsPhone * contactsPhone = (sContactsPhone*)dd(m_ddContacts)->m_contactsPhoneSL.GetAt( pos ) ;
	
		if (contactsPhone)
		{			
			if (contactsPhone->bCantDelete)			
				ccErrEM(IDS_CANT_DELETE_THIS_PHONE_NUMBER, NULL, NULL, MB_OK);
			else
			{
				contactsPhone->bDeletedRecord = true;

				dd(m_ddContacts)->m_PhoneName1.refresh();
				dd(m_ddContacts)->m_PhoneName2.refresh();
				dd(m_ddContacts)->m_PhoneName3.refresh();
			}
		}
	}
}

//

void cccContactsTABPersonalPhone::OnChangedItem(bool bSave ) 
{
	
	POSITION pos;

	if( ( pos = dd(m_ddContacts)->m_contactsPhoneSL.FindIndex( m_nSelectedItem )) != NULL )
	{
		sContactsPhone * contactsPhone = (sContactsPhone*)dd(m_ddContacts)->m_contactsPhoneSL.GetAt( pos ) ;
	
		if (contactsPhone)
		{
			if (bSave)
			{
				UpdateData(true);
				contactsPhone->strPhoneName  = m_phoneName;
				contactsPhone->strNumber     = m_phoneNumber;
				contactsPhone->bChanged      = true;
			}
			else
			{
				m_phoneName   = contactsPhone->strPhoneName;
				m_phoneNumber = contactsPhone->strNumber;

				switch ( m_nPhoneGroup)
				{
				case 1: dd(m_ddContacts)->m_PhoneName1.setValue( m_phoneName );
						break;
				case 2: dd(m_ddContacts)->m_PhoneName2.setValue( m_phoneName );
						break;
				case 3: dd(m_ddContacts)->m_PhoneName3.setValue( m_phoneName );
						break;
				}
				UpdateData(false);
			}
		}
	}
	
}

//

void cccContactsTABPersonalPhone::displayFirstRecInList()
{	
	// Display the first record in the LinkedList on the screen.
	POSITION pos;
	
	m_phoneNumber = "";

	CString strPhoneName;

	switch ( m_nPhoneGroup)
	{
	case 1: strPhoneName = dd(m_ddContacts)->m_PhoneName1;
			if (strPhoneName == "") strPhoneName = "Home";
			break;
	case 2: strPhoneName = dd(m_ddContacts)->m_PhoneName2;
			if (strPhoneName == "") strPhoneName = "Business";
			break;
	case 3: strPhoneName = dd(m_ddContacts)->m_PhoneName3;
			if (strPhoneName == "") strPhoneName = "Fax";
			break;
	}

	m_nSelectedItem = -1;
	int nIndex = 0;
	for( pos = dd(m_ddContacts)->m_contactsPhoneSL.GetHeadPosition(); pos != NULL; )
	{
		sContactsPhone * contactsPhone = ((sContactsPhone*)dd(m_ddContacts)->m_contactsPhoneSL.GetNext( pos ));		

		if (contactsPhone)
		{
			if (contactsPhone->strPhoneName == strPhoneName)
			{
				if ( !contactsPhone->bDeletedRecord )
				{
					m_nSelectedItem = nIndex;
					m_phoneName   = contactsPhone->strPhoneName;
					m_phoneNumber = contactsPhone->strNumber;
					break;
				}
			}
		}		
		nIndex++;
	}	

	// If the selected Phone wasn't found, select the first available phone.
	if ( m_nSelectedItem == -1)
	{
		// Get the first menu item.
		int nIndex = 0;
		for( pos = dd(m_ddContacts)->m_contactsPhoneSL.GetHeadPosition(); pos != NULL; )
		{
			sContactsPhone * contactsPhone = ((sContactsPhone*)dd(m_ddContacts)->m_contactsPhoneSL.GetNext( pos ));
			if (!contactsPhone->bDeletedRecord)
			{
				m_nSelectedItem = nIndex;							
				break;
			}
			nIndex++;
		}			
		OnChangedItem(false);
		dd(m_ddContacts)->setModified(true);
	}
	
	UpdateData(false);	
}

//

//

BEGIN_MESSAGE_MAP(cccContactsTABPersonalPhone, ccllGroup)
	//{{AFX_MSG_MAP(cccContactsTABPersonalPhone)
	ON_EN_CHANGE(IDC_PHONE_NAME, OnChangePhoneName)
	ON_EN_CHANGE(IDC_PHONE_NUMBER, OnChangePhoneNumber)
	ON_EN_KILLFOCUS(IDC_PHONE_NUMBER, OnKillfocusPhoneNumber)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cccContactsTABPersonalPhone message handlers

BOOL cccContactsTABPersonalPhone::OnInitDialog() 
{
	ccllGroup::OnInitDialog();
	
	setDDServer( dd(m_ddContacts) );

	switch ( m_nPhoneGroup)
	{
	case 1: dd(m_ddContacts)->m_PhoneName1.addAttachedCtrl( this );
			break;
	case 2: dd(m_ddContacts)->m_PhoneName2.addAttachedCtrl( this );
			break;
	case 3: dd(m_ddContacts)->m_PhoneName3.addAttachedCtrl( this );
			break;
	}

	
	displayFirstRecInList();

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void cccContactsTABPersonalPhone::OnChangePhoneName() 
{
	OnChangedItem( true );
	dd(m_ddContacts)->setModified(true);
}

void cccContactsTABPersonalPhone::OnChangePhoneNumber() 
{
	OnChangedItem( true );
	dd(m_ddContacts)->setModified(true);	
}

void cccContactsTABPersonalPhone::OnKillfocusPhoneNumber() 
{	
	dd(m_ddContacts)->m_PhoneName1.refresh();
	dd(m_ddContacts)->m_PhoneName2.refresh();
	dd(m_ddContacts)->m_PhoneName3.refresh();
}
