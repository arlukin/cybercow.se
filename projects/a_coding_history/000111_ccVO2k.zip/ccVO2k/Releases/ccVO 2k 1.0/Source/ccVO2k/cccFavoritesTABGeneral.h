#if !defined(AFX_CCCFAVORITESTABGENERAL_H__0C9A87EC_281B_11D4_89A6_00609708DCFE__INCLUDED_)
#define AFX_CCCFAVORITESTABGENERAL_H__0C9A87EC_281B_11D4_89A6_00609708DCFE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// cccFavoritesTABGeneral.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// cccFavoritesTABGeneral dialog

class cccFavoritesTABGeneral : public ccdbDialog
{
// *** Construction
public:
	// standard constructor
	//
	cccFavoritesTABGeneral(CWnd *pParent, cccVODB *aoDB);

// *** Dialog Data
	//{{AFX_DATA(cccFavoritesTABGeneral)
	enum { IDD = IDD_FAVORITES_TAB_GENERAL };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	ccdbSuperCtrl m_MProjectID;
	ccdbSuperCtrl m_ParentItemID;
	ccdbSuperCtrl m_ItemID;
	ccdbSuperCtrl m_Name;
	ccdbSuperCtrl m_URL;
	//ccdbSuperCtrl m_DefaultBrowser;
	ccdbSuperCtrl m_Notes;
	ccdbSuperCtrl m_CreditGrade;
	ccdbSuperCtrl m_LastLogedOn;
	ccdbSuperCtrl m_LastChecked;
	ccdbSuperCtrl m_ValidSite;

// *** Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(cccFavoritesTABGeneral)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(cccFavoritesTABGeneral)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CCCFAVORITESTABGENERAL_H__0C9A87EC_281B_11D4_89A6_00609708DCFE__INCLUDED_)
