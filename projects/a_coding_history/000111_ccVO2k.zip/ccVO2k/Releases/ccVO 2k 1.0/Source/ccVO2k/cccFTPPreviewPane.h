#if !defined(AFX_CCCFTPPREVIEWPANE_H__5A42B219_2E62_11D4_823B_0001020E90A5__INCLUDED_)
#define AFX_CCCFTPPREVIEWPANE_H__5A42B219_2E62_11D4_823B_0001020E90A5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// cccFTPPreviewPane.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// cccFTPPreviewPane view

class cccFTPPreviewPane : public ccTabView
{
protected:
	cccFTPPreviewPane();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(cccFTPPreviewPane)

// Attributes
public:
	//
	//
	cccVODB* __getDB(void)			 { return m_oDB;				};
	void setDB( cccVODB* aoCCVO)	 { m_oDB = aoCCVO;				};

private:
	cccVODB  *m_oDB;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(cccFTPPreviewPane)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~cccFTPPreviewPane();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(cccFavoritesPreviewPane)
	afx_msg void OnSaveAndClose();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSave();	
	afx_msg void OnDeleteItem();
	afx_msg void OnLastItem();
	afx_msg void OnFirstItem();
	afx_msg void OnNextItem();
	afx_msg void OnPreviousItem();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CCCFTPPREVIEWPANE_H__5A42B219_2E62_11D4_823B_0001020E90A5__INCLUDED_)
