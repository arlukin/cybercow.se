// ccDLGQuestion.cpp : implementation file
//

#include "stdafx.h"
#include "ccvo2k.h"
#include "ccDLGQuestion.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// ccDLGQuestion dialog


ccDLGQuestion::ccDLGQuestion(CWnd* pParent /*=NULL*/)
	: CDialog(ccDLGQuestion::IDD, pParent)
{
	//{{AFX_DATA_INIT(ccDLGQuestion)
	m_answer = _T("");
	//}}AFX_DATA_INIT
}


void ccDLGQuestion::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(ccDLGQuestion)
	DDX_Text(pDX, IDC_ANSWER_TEXT, m_answer);
	DDV_MaxChars(pDX, m_answer, 50);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(ccDLGQuestion, CDialog)
	//{{AFX_MSG_MAP(ccDLGQuestion)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// ccDLGQuestion message handlers
CString ccDLGQuestion::getAnswer(LPCSTR strCaption)
{
	m_caption = strCaption;
	if ( DoModal() ==IDOK)
		return m_answer;
	else
		return "-1";
}

BOOL ccDLGQuestion::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	SetWindowText( m_caption );
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
