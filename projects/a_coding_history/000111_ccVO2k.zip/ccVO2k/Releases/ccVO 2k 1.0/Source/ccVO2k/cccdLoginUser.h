#if !defined(__CCCDLOGINUSER_H__)
#define __CCCDLOGINUSER_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// cccdLoginUser.h : header file
//


/////////////////////////////////////////////////////////////////////////////
// cccdLoginUser dialog

#include "resource.h"

class ccVOClient;
class cccdLoginUser : public CDialog
{
// Construction
public:
	cccdLoginUser(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(cccdLoginUser)
	enum { IDD = IDD_REG_OR_CONNECT_USER };
	CButton	m_ctrlAutoLogin;
	CString	m_userName;
	CString	m_password;
	BOOL	m_bSavePassword;
	BOOL	m_bAutoLogin;
	//}}AFX_DATA
	ccVOClient * m_theCCVOClient;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(cccdLoginUser)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(cccdLoginUser)
	afx_msg void OnNewUser();
	virtual void OnOK();
	afx_msg void OnAutologin();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(__CCCDLOGINUSER_H__)
