#ifndef __ccllGroup_H__
#define __ccllGroup_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ccllGroup.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// ccllGroup dialog

#include "resource.h"
// ccLinkedListGroup
class ccllGroup :  public CDialog, public ccddCtrlContainer
{
// *** Construction
public:
	virtual void OnOK( );
	virtual void OnCancel( );
	ccllGroup(UINT nIDTemplate, CWnd * aParent );

	void init( int nResource, CWnd * parent, int nCtrlResourceID, int x, int y, LPCSTR strCaption);

	// Build the menu who will be shown when pressing
	// Menu button.
	//
	virtual void OnBuildMenu(ccMenuButton *menuButton)  = 0;

	//
	//
	virtual void OnNewItem()    = 0;

	//
	//
	virtual void OnDeleteItem() = 0;

	//
	//
	virtual void OnChangedItem(bool bSave ) = 0;

protected:	
	int		m_nSelectedItem;
// *** Dialog Data
	//{{AFX_DATA(ccllGroup)	
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	ccMenuButton m_menuButton;

	CButtonST	 m_newButton;	
	CButtonST	 m_deleteButton;

	CButton		 m_group;

private:
	CString		m_caption;




// *** Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(ccllGroup)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL
	void OnMenuButton();

// *** Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(ccllGroup)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // __ccllGroup_H__
