// cccContactsTABHome.cpp : implementation file
//

#include "stdafx.h"
#include "ccvo2k.h"
#include "cccContactsTABHome.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccContactsTABHome dialog


cccContactsTABHome::cccContactsTABHome(CWnd *pParent, cccVODB *aoDB)
	: ccdbDialog(cccContactsTABHome::IDD, pParent, aoDB)
{
	//{{AFX_DATA_INIT(cccContactsTABPersonal)	
	//}}AFX_DATA_INIT
	Create(cccContactsTABHome::IDD, pParent);	
}

//

void cccContactsTABHome::DoDataExchange(CDataExchange* pDX)
{
	ccdbDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(cccContactsTABHome)
	DDX_Control(pDX, IDC_HOME_JUMP, m_homeJump);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(cccContactsTABHome, ccdbDialog)
	//{{AFX_MSG_MAP(cccContactsTABHome)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cccContactsTABHome message handlers

BOOL cccContactsTABHome::OnInitDialog() 
{	
	
	setDDServer( dd(m_ddContacts) );

	m_Home_Street.adddbField( &dd(m_ddContacts)->m_Home_Street  );
	m_Home_Street.setCaptionOffset(-80);
	m_Home_Street.SubclassDlgItem( IDC_HOME_STREET, this, this );

	m_Home_City.adddbField( &dd(m_ddContacts)->m_Home_City  );
	m_Home_City.setCaptionOffset(-80);
	m_Home_City.SubclassDlgItem( IDC_HOME_CITY, this, this );
	
	m_Home_State_Or_Province.adddbField( &dd(m_ddContacts)->m_Home_StateOrProvince  );
	m_Home_State_Or_Province.setCaptionOffset(-80);
	m_Home_State_Or_Province.SubclassDlgItem( IDC_HOME_STATE_OR_PROVINCE, this, this );

	m_Home_Zip_Or_PostalCode.adddbField( &dd(m_ddContacts)->m_Home_ZipOrPostalCode  );
	m_Home_Zip_Or_PostalCode.setCaptionOffset(-80);
	m_Home_Zip_Or_PostalCode.SubclassDlgItem( IDC_HOME_ZIP_OR_POSTALCODE, this, this );
	
	m_Home_Country_Or_Region.adddbField( &dd(m_ddContacts)->m_Home_CountryOrRegion  );
	m_Home_Country_Or_Region.setCaptionOffset(-80);
	m_Home_Country_Or_Region.SubclassDlgItem( IDC_HOME_COUNTRY_OR_REGION, this, this );

	m_Spouse_s_Name.adddbField( &dd(m_ddContacts)->m_SpousesName  );
	m_Spouse_s_Name.setCaptionOffset(-100);
	m_Spouse_s_Name.SubclassDlgItem( IDC_SPOUCE_S_NAME, this, this );

	m_SpousesInterests.adddbField( &dd(m_ddContacts)->m_SpousesInterests  );
	m_SpousesInterests.setCaptionOffset(-100);
	m_SpousesInterests.SubclassDlgItem( IDC_SPOUSESINTERSTS, this, this );

	m_Aniversary.adddbField( &dd(m_ddContacts)->m_Aniversary  );
	m_Aniversary.setCaptionOffset(-100);
	m_Aniversary.SubclassDlgItem( IDC_ANNIVERSARY, this, this );

	m_ChildrenNames.adddbField( &dd(m_ddContacts)->m_ChildrenNames  );
	m_ChildrenNames.setCaptionOffset(-100);
	m_ChildrenNames.SubclassDlgItem( IDC_CHILDREN_NAMES, this, this );

	m_Personal_Web_Page.adddbField( &dd(m_ddContacts)->m_Personal_WebPage1 );
	m_Personal_Web_Page.adddbField( &dd(m_ddContacts)->m_Personal_WebPage2 );
	m_Personal_Web_Page.setCaptionOffset(-77);
	m_Personal_Web_Page.SubclassDlgItem( IDC_WEB_PAGE, this, this );
	
	m_Personal_FTP_Page.adddbField( &dd(m_ddContacts)->m_Personal_FTPSite1 );
	m_Personal_FTP_Page.adddbField( &dd(m_ddContacts)->m_Personal_FTPSite2 );
	m_Personal_FTP_Page.setCaptionOffset(-77);
	m_Personal_FTP_Page.SubclassDlgItem( IDC_FTP_PAGE, this, this );
	
	m_Personal_Notes.adddbField( &dd(m_ddContacts)->m_PersonalNotes  );	
	m_Personal_Notes.setCaptionOffset(0,-15);
	m_Personal_Notes.SubclassDlgItem( IDC_PERSONAL_NOTES, this, this );

	m_PhotoGraph.adddbField( &dd(m_ddContacts)->m_Photo  );	
	m_PhotoGraph.setCaptionOffset(0,-15);
	m_PhotoGraph.SubclassDlgItem( IDC_PHOTOGRAPH, this, this );

	ccdbDialog::OnInitDialog();

	m_homeJump.Open( IDR_HOMEJUMP );
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
