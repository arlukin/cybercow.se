// cccFavoritesContainer.cpp : implementation file
//

#include "stdafx.h"
#include "ccvo2k.h"
#include "resource.h"
#include "cccFavoritesContainer.h"
#include "cccFavoritesView.h"
#include "cccEmptyContainer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccFavoritesContainer

IMPLEMENT_DYNCREATE(cccFavoritesContainer, CView)

cccFavoritesContainer::cccFavoritesContainer()
{
}

cccFavoritesContainer::~cccFavoritesContainer()
{
}


BEGIN_MESSAGE_MAP(cccFavoritesContainer, CView)
	//{{AFX_MSG_MAP(cccFavoritesContainer)
	ON_WM_CREATE()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cccFavoritesContainer drawing

void cccFavoritesContainer::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// cccFavoritesContainer diagnostics

#ifdef _DEBUG
void cccFavoritesContainer::AssertValid() const
{
	CView::AssertValid();
}

void cccFavoritesContainer::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// cccFavoritesContainer message handlers

int cccFavoritesContainer::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// Create splitters 
	//
	// The context information is passed on from the framework
	CCreateContext *pContext = (CCreateContext*)lpCreateStruct->lpCreateParams;

	// Create the splitter window with two columns
	if (!m_wndSplitter.CreateStatic(this, 2, 1))
	{
		TRACE0("Failed to create splitter window\n");
		return FALSE;
	}


	// Standard sizing for splitter
	if (!m_wndSplitter.CreateView(0,0,RUNTIME_CLASS(cccFavoritesView),
		CSize(0, 250), pContext))
	{
		m_wndSplitter.DestroyWindow();
		return -1;
	}

	// if (!m_wndSplitter.CreateView(1,0,RUNTIME_CLASS(cccContactsPreviewPane),
	if (!m_wndSplitter.CreateView(1,0,RUNTIME_CLASS(cccEmptyContainer),
		CSize(0, 0), pContext))
	{
		m_wndSplitter.DestroyWindow();
		return -1;
	}
	m_wndSplitter.HideRow(1);
		
	return 0;
}

//

void cccFavoritesContainer::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	if( m_wndSplitter.GetSafeHwnd())
	{
		int nCX = ::GetSystemMetrics( SM_CXEDGE );
		int nCY = ::GetSystemMetrics( SM_CYEDGE );
		
		// move and grow view to clip border
		m_wndSplitter.MoveWindow(-2, -2, cx+4, cy+4);	
	}
	
}
