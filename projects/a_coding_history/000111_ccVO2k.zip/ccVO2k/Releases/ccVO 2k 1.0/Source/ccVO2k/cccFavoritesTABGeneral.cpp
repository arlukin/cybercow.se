// cccFavoritesTABGeneral.cpp : implementation file
//

#include "stdafx.h"
#include "ccvo2k.h"

#include "cccFavoritesTABGeneral.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cccFavoritesTABGeneral dialog


cccFavoritesTABGeneral::cccFavoritesTABGeneral(CWnd *pParent, cccVODB *aoDB)
	: ccdbDialog(cccFavoritesTABGeneral::IDD, pParent, aoDB)
{
	//{{AFX_DATA_INIT(cccFavoritesTABGeneral)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	Create(cccFavoritesTABGeneral::IDD, pParent);	
}


void cccFavoritesTABGeneral::DoDataExchange(CDataExchange* pDX)
{
	ccdbDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(cccFavoritesTABGeneral)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(cccFavoritesTABGeneral, ccdbDialog)
	//{{AFX_MSG_MAP(cccFavoritesTABGeneral)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cccFavoritesTABGeneral message handlers

BOOL cccFavoritesTABGeneral::OnInitDialog() 
{
	setDDServer( dd(m_ddFavorites) );

	m_Name.adddbField( &dd(m_ddFavorites)->m_Name );
	m_Name.setCaptionOffset(-80);
	m_Name.SubclassDlgItem( IDC_NAME, this, this );

	m_URL.adddbField( &dd(m_ddFavorites)->m_URL );
	m_URL.setCaptionOffset(-80);
	m_URL.SubclassDlgItem( IDC_URL, this, this );

	/*
	m_DefaultBrowser.adddbField( &dd(m_ddFavorites)->m_DefaultBrowser );
	m_DefaultBrowser.setCaptionOffset(-80);
	m_DefaultBrowser.SubclassDlgItem( IDC_DEFAULTBROWSER, this, this );
	*/

	m_CreditGrade.adddbField( &dd(m_ddFavorites)->m_CreditGrade );
	m_CreditGrade.setCaptionOffset(-80);
	m_CreditGrade.SubclassDlgItem( IDC_CREDIT_GRADE, this, this );

	m_LastLogedOn.adddbField( &dd(m_ddFavorites)->m_LastLogedOn );
	m_LastLogedOn.setCaptionOffset(-80);
	m_LastLogedOn.SubclassDlgItem( IDC_LAST_LOGED_ON, this, this );

	m_LastChecked.adddbField( &dd(m_ddFavorites)->m_LastChecked );
	m_LastChecked.setCaptionOffset(-80);
	m_LastChecked.SubclassDlgItem( IDC_LAST_CHECKED, this, this );

	m_ValidSite.adddbField( &dd(m_ddFavorites)->m_ValidSite );
	m_ValidSite.setCaptionOffset(-80);
	m_ValidSite.SubclassDlgItem( IDC_VALID_SITE, this, this );

	m_Notes.adddbField( &dd(m_ddFavorites)->m_Notes );
	m_Notes.setCaptionOffset(-80);
	m_Notes.SubclassDlgItem( IDC_NOTES, this, this );

	ccdbDialog::OnInitDialog();

	// Set up the Email Container and dataDictonary	

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

