// ccFrameWnd.cpp : implementation file
//
/////////////////////////////////////////////////////////////////////////////

#include "StdAfx.h"
#include "Resource.h"
#include "ccFrameWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// ccFrameWnd

ccFrameWnd::ccFrameWnd()
{
	// TODO: add construction code here.
}

ccFrameWnd::~ccFrameWnd()
{
	// TODO: add destruction code here.
}

IMPLEMENT_DYNAMIC(ccFrameWnd, CCJFrameWnd)

BEGIN_MESSAGE_MAP(ccFrameWnd, CCJFrameWnd)
	//{{AFX_MSG_MAP(ccFrameWnd)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_MOVE()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// ccFrameWnd message handlers

void ccFrameWnd::setWinPlacementRegPath( LPCSTR sRegPath, LPCSTR sPlacementName)
{
	m_regPath = sRegPath;
	m_placmentName = sPlacementName;
}

//

void ccFrameWnd::loadWindowPlacement()
{
	try
	{		
		// Set Window Pos and Size
		ccRegistry reg;	
		reg.openCreate(HKEY_CURRENT_USER, m_regPath);
		reg.Read(m_placmentName, this);
		reg.Close();
	}
	catch(ccException *e) 
	{
		ccErr(*e,"","", MB_OK);
		exit(1);
	}
}

//

void ccFrameWnd::saveWindowPlacement()
{	
	try
	{
		ccRegistry reg;	
		reg.openCreate(HKEY_CURRENT_USER, m_regPath);							
		reg.Write(m_placmentName, this);
		reg.Close();	
	}
	catch(ccException *e) 
	{
		ccErr(*e,"","", MB_OK);
		exit(1);
	}
}

//

int ccFrameWnd::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CCJFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	loadWindowPlacement();
	
	return 0;
}

//

void ccFrameWnd::OnDestroy() 
{
	CCJFrameWnd::OnDestroy();
	
	saveWindowPlacement();	
}

//

void ccFrameWnd::OnMove(int x, int y) 
{
	CCJFrameWnd::OnMove(x, y);
	
	saveWindowPlacement();	
}

//

void ccFrameWnd::OnSize(UINT nType, int cx, int cy) 
{
	CCJFrameWnd::OnSize(nType, cx, cy);

	saveWindowPlacement();		
}
