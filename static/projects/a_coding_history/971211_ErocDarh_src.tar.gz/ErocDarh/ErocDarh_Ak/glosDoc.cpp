// glosDoc.cpp : implementation of the CGlosDoc class
//

#include "stdafx.h"
#include "glos.h"

#include "glosSet.h"
#include "glosDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGlosDoc

IMPLEMENT_DYNCREATE(CGlosDoc, CDocument)

BEGIN_MESSAGE_MAP(CGlosDoc, CDocument)
	//{{AFX_MSG_MAP(CGlosDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGlosDoc construction/destruction

CGlosDoc::CGlosDoc()
{
	// TODO: add one-time construction code here

}

CGlosDoc::~CGlosDoc()
{
}

BOOL CGlosDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CGlosDoc diagnostics

#ifdef _DEBUG
void CGlosDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CGlosDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGlosDoc commands

CDatabase* CGlosDoc::GetDatabase()
{
	TRY
	{
		if (!m_database.IsOpen())
			m_database.Open("GLOS;");
	}
	CATCH(CDBException, e)
	{
		AfxMessageBox(e->m_strError);
	}
	END_CATCH
	return &m_database;
}

////////////////////////////////////////////////////////////////////////////
// CUpdateHint

IMPLEMENT_DYNAMIC(CUpdateHint, CObject)

CUpdateHint::CUpdateHint()
{
}
