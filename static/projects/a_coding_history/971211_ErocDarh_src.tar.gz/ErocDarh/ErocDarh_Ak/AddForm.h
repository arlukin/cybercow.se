// AddForm.h: interface for the CAddForm class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ADDFORM_H__409607C7_6A73_11D1_9057_000000000000__INCLUDED_)
#define AFX_ADDFORM_H__409607C7_6A73_11D1_9057_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// addform.h : interface of the CAddForm class
//
/////////////////////////////////////////////////////////////////////////////

class CAddForm : public CRecordView
{
protected:
	CAddForm(UINT nIDTemplate);
	DECLARE_DYNAMIC(CAddForm)

protected:
	BOOL m_bNewRecord;

// Operations
public:
	virtual BOOL OnMove(UINT nIDMoveCommand);
	virtual BOOL RecordClear();
	virtual BOOL RecordRefresh();
	virtual BOOL RecordDelete();
	virtual BOOL RecordSave();
// Implementation
public:

	virtual ~CAddForm();
// Generated message map functions
protected:
	afx_msg void OnRecordClear();
	afx_msg void OnRecordSave();
	afx_msg void OnRecordRefresh();
	afx_msg void OnRecordDelete();	
	DECLARE_MESSAGE_MAP()
};

#endif // !defined(AFX_ADDFORM_H__409607C7_6A73_11D1_9057_000000000000__INCLUDED_)
