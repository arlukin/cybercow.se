// ForhorForm.cpp : implementation file
//

#include "stdafx.h"
#include "glos.h"


#include "glosSet.h"
#include "glosDoc.h"
#include "InMatForm.h"
#include "ForhorForm.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CForhorForm

IMPLEMENT_DYNCREATE(CForhorForm, CAddForm)

BEGIN_MESSAGE_MAP(CForhorForm, CAddForm)
	//{{AFX_MSG_MAP(CForhorForm)
	ON_BN_CLICKED(IDC_RADIO_SVENSKA, OnRadioSvenska)
	ON_BN_CLICKED(IDC_RADIO_ENGELSKA, OnRadioEngelska)
	ON_COMMAND(ID_RECORD_CLEAR, OnRecordClear)
	ON_BN_CLICKED(IDC_BUTTON_OK, OnButtonOk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CForhorForm::CForhorForm()
	: CAddForm(CForhorForm::IDD)
{
	//{{AFX_DATA_INIT(CForhorForm)
	m_pSet = NULL;
	//}}AFX_DATA_INIT
}

CForhorForm::~CForhorForm()
{
}

void CForhorForm::DoDataExchange(CDataExchange* pDX)
{
	CRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CForhorForm)
	DDX_Control(pDX, IDC_EDIT_FORHOR_ENGELSKA, m_ctlEngelska);
	DDX_Control(pDX, IDC_EDIT_FORHOR_SVENSKA, m_ctlSvenska);
	DDX_FieldText(pDX, IDC_EDIT_FORHOR_RATT, m_pSet->m_R_tt, m_pSet);
	DDX_FieldText(pDX, IDC_EDIT_FORHOR_ANTAL, m_pSet->m_Antal, m_pSet);
	//}}AFX_DATA_MAP

	if  (m_bOversattTillSvenska)
	{
		DDX_FieldText(pDX, IDC_EDIT_FORHOR_ENGELSKA, m_pSet->m_Engelska, m_pSet);
	}
	else
	{
		DDX_FieldText(pDX, IDC_EDIT_FORHOR_SVENSKA, m_pSet->m_Svenska, m_pSet);		
	}
}



/////////////////////////////////////////////////////////////////////////////
// CForhorForm diagnostics

#ifdef _DEBUG
void CForhorForm::AssertValid() const
{
	CAddForm::AssertValid();
}

void CForhorForm::Dump(CDumpContext& dc) const
{
	CAddForm::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CForhorForm message handlers

CRecordset* CForhorForm::OnGetRecordset()
{
	return m_pSet;
}

CGlosSet* CForhorForm::GetRecordset()
{
	CGlosSet* pData = (CGlosSet*) OnGetRecordset();
	ASSERT(pData == NULL || pData->IsKindOf(RUNTIME_CLASS(CGlosSet)));
	return pData;
}

void CForhorForm::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_glosSet;
	CRecordView::OnInitialUpdate();
}
void CForhorForm::OnRadioSvenska() 
{
	// TODO: Add your control notification handler code here
	RecordClear();
	m_ctlSvenska.SetFocus();
	m_ctlSvenska.SetReadOnly(FALSE);
	m_ctlEngelska.SetReadOnly(TRUE);
	m_bOversattTillSvenska = TRUE;
	OnMove(ID_RECORD_FIRST);
}

void CForhorForm::OnRadioEngelska() 
{
	// TODO: Add your control notification handler code here
	RecordClear();
	m_ctlEngelska.SetFocus();
	m_ctlSvenska.SetReadOnly(TRUE);
	m_ctlEngelska.SetReadOnly(FALSE);
	m_bOversattTillSvenska = FALSE;
	OnMove(ID_RECORD_FIRST);
}

int CForhorForm::SetDlgCtrlID(int nID)
{
	RecordClear();
	return CRecordView::SetDlgCtrlID(nID);
}

void CForhorForm::OnRecordClear() 
{
	CAddForm::RecordClear();
	m_ctlSvenska.SetWindowText(CString(""));	
	m_ctlEngelska.SetWindowText(CString(""));	
}

void CForhorForm::OnButtonOk()
{
CString l_translatedWord;		
CString l_rightAnswer;

	if (m_bOversattTillSvenska)
	{
		m_ctlSvenska.GetWindowText(l_translatedWord);	
		l_rightAnswer = m_pSet->m_Svenska;
	}
	else
	{
		m_ctlEngelska.GetWindowText(l_translatedWord);	
		l_rightAnswer = m_pSet->m_Engelska;
	}

	if (("" < l_translatedWord) && (l_rightAnswer > ""))
	{
		if (l_rightAnswer == l_translatedWord)		
		{				// R�tt svar	

			m_pSet->Edit();

			// Uppdatera f�lt i databasen
			m_pSet->m_Antal++;
			m_pSet->m_R_tt++;

			TRY
			{
				m_pSet->Update();
			}
			CATCH(CDBException, e)
			{
				AfxMessageBox(e->m_strError);				
			}
			END_CATCH
		}
		else
		{				// Fel svar
			
			if (m_bOversattTillSvenska)
				MessageBox(m_pSet->m_Svenska, "Felsvar", NULL);
			else
				MessageBox(m_pSet->m_Engelska, "Felsvar", NULL);
			m_pSet->Edit();

			// Uppdatera f�lt i databasen
			m_pSet->m_Antal++;			

			TRY
			{
				m_pSet->Update();
			}
			CATCH(CDBException, e)
			{
				AfxMessageBox(e->m_strError);				
			}
			END_CATCH
		}
		
		if (OnMove(ID_RECORD_NEXT))
		{
			UpdateData(FALSE);
		
			if (m_bOversattTillSvenska)
				m_ctlSvenska.SetWindowText(CString(""));	
			else
				m_ctlEngelska.SetWindowText(CString(""));	
		}
		else
		{
			MessageBox("Inga fler glosor", "Medelande", NULL);
			OnRecordClear();
		}
	}
}
