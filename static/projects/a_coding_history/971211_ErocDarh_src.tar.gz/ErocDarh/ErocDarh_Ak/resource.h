//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by glos.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_GLOS_FORM                   101
#define IDP_FAILED_OPEN_DATABASE        103
#define IDR_MAINFRAME                   128
#define IDR_GLOSTYPE                    129
#define IDD_GLOS_FORHOR                 131
#define IDB_LOGO                        132
#define IDC_EDIT_SVENSKA                1000
#define IDC_EDIT_ENGELSKA               1001
#define IDC_RADIO_SVENSKA               1001
#define IDC_EDIT_SIDA                   1002
#define IDC_RADIO_ENGELSKA              1002
#define IDC_EDIT_ANTAL_INMATADE_I_SES   1003
#define IDC_EDIT_FORHOR_ENGELSKA        1004
#define IDC_EDIT_FORHOR_RATT            1005
#define IDC_EDIT_FORHOR_ANTAL           1006
#define IDC_EDIT_FORHOR_SVENSKA         1010
#define IDC_STATIC_FORHOR_RATT          1011
#define IDC_STATIC_FORHOR_ANTAL         1012
#define IDC_BUTTON_OK                   1016
#define ID_RECORD_REFRESH               32772
#define ID_RECORD_DELETE                32773
#define ID_RECORD_SAVE                  32774
#define ID_FORM_FORHOR                  32775
#define ID_FORM_MATA_IN                 32776
#define ID_RECORD_CLEAR                 32777

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
