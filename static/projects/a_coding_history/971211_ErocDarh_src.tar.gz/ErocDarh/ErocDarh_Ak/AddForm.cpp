// AddForm.cpp: implementation of the CAddForm class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "glos.h"
#include "AddForm.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

IMPLEMENT_DYNAMIC(CAddForm, CRecordView)

BEGIN_MESSAGE_MAP(CAddForm, CRecordView)
	ON_COMMAND(ID_RECORD_REFRESH, OnRecordRefresh)
	ON_COMMAND(ID_RECORD_CLEAR, OnRecordClear)
	ON_COMMAND(ID_RECORD_SAVE, OnRecordSave)
	ON_COMMAND(ID_RECORD_DELETE, OnRecordDelete)
END_MESSAGE_MAP()

CAddForm::CAddForm(UINT nIDTemplate)
	: CRecordView(nIDTemplate)
{
	m_bNewRecord = FALSE;
}

CAddForm::~CAddForm()
{
}

BOOL CAddForm::OnMove(UINT nIDMoveCommand)
{
BOOL bRet = TRUE;
CRecordset* pSet = OnGetRecordset();
	m_bNewRecord = FALSE;

	switch (nIDMoveCommand)
	{
		case ID_RECORD_PREV:
			pSet->MovePrev();
			if (!pSet->IsBOF())
				break;
			bRet = FALSE;	// D�rf�r att den stegades f�rbi f�rsta posten.

		case ID_RECORD_FIRST:
			pSet->MoveFirst();
			break;

		case ID_RECORD_NEXT:
			pSet->MoveNext();
			if (!pSet->IsEOF())
				break;
			if (!pSet->CanScroll())
			{
				// clear out screen since we're sitting on EOF
				pSet->SetFieldNull(NULL);
				break;
			}
			bRet = FALSE;	// D�rf�r att den stegades f�rbi sissta posten.

		case ID_RECORD_LAST:
			pSet->MoveLast();
			break;

		default:
			// Unexpected case value
			ASSERT(FALSE);
	}

	// Show results of move operation
	UpdateData(FALSE);
	return bRet;
}

void CAddForm::OnRecordClear()
{
	RecordClear();
}

BOOL CAddForm::RecordClear()
{
	// If already in add mode, then complete previous new record
	OnGetRecordset()->AddNew();
	m_bNewRecord = TRUE;
	UpdateData(FALSE);
	return TRUE;
}


void CAddForm::OnRecordDelete()
{
	RecordDelete();
}

BOOL CAddForm::RecordDelete()
{
	CRecordset* pRecordset = OnGetRecordset();
	TRY
	{
		pRecordset->Delete();
	}
	CATCH(CDBException, e)
	{
		AfxMessageBox(e->m_strError);
		return FALSE;
	}
	END_CATCH

	// Update the recordset and move to next record, or first
	// record if anything is wrong.
	CRecordsetStatus lRecordsetStatus;
	pRecordset->GetStatus(lRecordsetStatus);	
	pRecordset->Requery();
	if (lRecordsetStatus.m_lCurrentRecord >0)
		pRecordset->Move(lRecordsetStatus.m_lCurrentRecord);
	else
		pRecordset->Move(0);

	// If we moved off the end of file, then move back to last record
	if (pRecordset->IsEOF())
		pRecordset->MoveLast();

	// If the recordset is now empty, then clear the fields
	// left over from the deleted record
	if (pRecordset->IsBOF())
		pRecordset->SetFieldNull(NULL);
	UpdateData(FALSE);
	return TRUE;
}

void CAddForm::OnRecordRefresh()
{
	RecordRefresh();
}

BOOL CAddForm::RecordRefresh()
{
	BOOL bRet = TRUE;
	CRecordset* pRecordset = OnGetRecordset();
	// Update the recordset and move to next record, or first
	// record if anything is wrong.
	CRecordsetStatus lRecordsetStatus;
	pRecordset->GetStatus(lRecordsetStatus);	
	pRecordset->Requery();
	if (lRecordsetStatus.m_lCurrentRecord >0)
		pRecordset->Move(lRecordsetStatus.m_lCurrentRecord);
	else
	{
		pRecordset->Move(0);
		bRet = FALSE;
	}

	m_bNewRecord = FALSE;

	// Copy fields from recordset to form, thus
	// overwriting any changes user may have made
	// on the form
	UpdateData(FALSE);

	return bRet;
}

void CAddForm::OnRecordSave()
{
	RecordSave();
}

BOOL CAddForm::RecordSave()
{
	CRecordset* pRecordset = OnGetRecordset();
	if (pRecordset->CanUpdate() && !pRecordset->IsDeleted())
	{
		if (!m_bNewRecord)
			pRecordset->Edit();
		
		if (!UpdateData())
			return FALSE;

		TRY
		{
			pRecordset->Update();
		}
		CATCH(CDBException, e)
		{
			AfxMessageBox(e->m_strError);
			return FALSE;
		}
		END_CATCH

		RecordRefresh();

		UpdateData(FALSE);
		m_bNewRecord = FALSE;
		return TRUE;
	}
	return FALSE;
}

