#if !defined(AFX_FORHORFORM_H__F020C7CE_6F04_11D1_905E_000000000000__INCLUDED_)
#define AFX_FORHORFORM_H__F020C7CE_6F04_11D1_905E_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ForhorForm.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CForhorForm record view

#include "glosSet.h"

class CGlosDoc;

class CForhorForm : public CAddForm
{
DECLARE_DYNCREATE(CForhorForm)
public:
	CForhorForm();           // protected constructor used by dynamic creation


// Form Data
public:
	//{{AFX_DATA(CForhorForm)
	enum { IDD = IDD_GLOS_FORHOR };
	CEdit	m_ctlEngelska;
	CEdit	m_ctlSvenska;
	CGlosSet* m_pSet;
	//}}AFX_DATA

// Attributes
public:
	CGlosDoc* GetDocument();
// Operations
public:
	bool m_bOversattTillSvenska;
	CGlosSet* GetRecordset();
int SetDlgCtrlID( int nID );

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CForhorForm)
		// NOTE - the ClassWizard will add and remove member functions here.
	public:
	virtual CRecordset* OnGetRecordset();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate();
	//}}AFX_VIRTUAL

// Implementation
protected:	
	virtual ~CForhorForm();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CForhorForm)
	afx_msg void OnRadioSvenska();
	afx_msg void OnRadioEngelska();
	afx_msg void OnRecordClear();
	afx_msg void OnButtonOk();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//#ifndef _DEBUG  // debug version in InMatForm.cpp
inline CGlosDoc* CForhorForm::GetDocument()
   { return (CGlosDoc*)m_pDocument; }
//#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FORHORFORM_H__F020C7CE_6F04_11D1_905E_000000000000__INCLUDED_)
