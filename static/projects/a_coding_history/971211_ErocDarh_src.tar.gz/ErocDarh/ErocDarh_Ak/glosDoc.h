// glosDoc.h : interface of the CGlosDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_GLOSDOC_H__409607B8_6A73_11D1_9057_000000000000__INCLUDED_)
#define AFX_GLOSDOC_H__409607B8_6A73_11D1_9057_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


#define HINT_ADD_GLOS 1
#define HINT_DELETE_GLOS 2

class CUpdateHint : public CObject
{
	DECLARE_DYNAMIC(CUpdateHint);
	CUpdateHint();
	CString m_svenska;
};

class CGlosDoc : public CDocument
{
protected: // create from serialization only
	CGlosDoc();
	DECLARE_DYNCREATE(CGlosDoc)

// Attributes
protected:
	CDatabase m_database;
public:
	CGlosSet m_glosSet;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGlosDoc)
	public:
	virtual BOOL OnNewDocument();
	//}}AFX_VIRTUAL

// Implementation
public:
	CDatabase* GetDatabase();
	virtual ~CGlosDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CGlosDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GLOSDOC_H__409607B8_6A73_11D1_9057_000000000000__INCLUDED_)
