// glosSet.cpp : implementation of the CGlosSet class
//

#include "stdafx.h"
#include "glos.h"
#include "glosSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGlosSet implementation

IMPLEMENT_DYNAMIC(CGlosSet, CRecordset)

CGlosSet::CGlosSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CGlosSet)
	m_ID = 0;
	m_Svenska = _T("");
	m_Engelska = _T("");
	m_Sida = 0;
	m_R_tt = 0;
	m_Antal = 0;
	m_nFields = 6;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}

CString CGlosSet::GetDefaultConnect()
{
	return _T("ODBC;DSN=GLOS");
}

CString CGlosSet::GetDefaultSQL()
{
	return _T("[GLOSOR]");
}

void CGlosSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CGlosSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[ID]"), m_ID);
	RFX_Text(pFX, _T("[Svenska]"), m_Svenska);
	RFX_Text(pFX, _T("[Engelska]"), m_Engelska);
	RFX_Long(pFX, _T("[Sida]"), m_Sida);
	RFX_Long(pFX, _T("[R�tt]"), m_R_tt);
	RFX_Long(pFX, _T("[Antal]"), m_Antal);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CGlosSet diagnostics

#ifdef _DEBUG
void CGlosSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CGlosSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
