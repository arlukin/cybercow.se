// InMatForm.cpp : implementation of the CInMatForm class
//

#include "stdafx.h"
#include "glos.h"

#include "glosSet.h"
#include "glosDoc.h"
#include "InMatForm.h"
#include "ForhorForm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CInMatForm
								
IMPLEMENT_DYNCREATE(CInMatForm, CAddForm)

BEGIN_MESSAGE_MAP(CInMatForm, CAddForm)
	//{{AFX_MSG_MAP(CInMatForm)
	ON_COMMAND(ID_RECORD_CLEAR, OnRecordClear)
	ON_COMMAND(ID_RECORD_DELETE, OnRecordDelete)
	ON_COMMAND(ID_RECORD_REFRESH, OnRecordRefresh)
	ON_COMMAND(ID_RECORD_SAVE, OnRecordSave)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CRecordView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CRecordView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CRecordView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInMatForm construction/destruction

CInMatForm::CInMatForm()
	: CAddForm(CInMatForm::IDD)
{
	//{{AFX_DATA_INIT(CInMatForm)
	m_pSet = NULL;
	m_antalInmatade = 0;
	//}}AFX_DATA_INIT
	// TODO: add construction code here

}

CInMatForm::~CInMatForm()
{
}

void CInMatForm::DoDataExchange(CDataExchange* pDX)
{
	CRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CInMatForm)
	DDX_Control(pDX, IDC_EDIT_SVENSKA, m_ctlSvenskaID);
	DDX_FieldText(pDX, IDC_EDIT_SVENSKA, m_pSet->m_Svenska, m_pSet);
	DDX_FieldText(pDX, IDC_EDIT_ENGELSKA, m_pSet->m_Engelska, m_pSet);
	DDX_FieldText(pDX, IDC_EDIT_SIDA, m_pSet->m_Sida, m_pSet);
	DDX_Text(pDX, IDC_EDIT_ANTAL_INMATADE_I_SES, m_antalInmatade);
	//}}AFX_DATA_MAP
}

BOOL CInMatForm::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CRecordView::PreCreateWindow(cs);
}

void CInMatForm::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_glosSet;
	
	m_antalInmatade=0;
	CRecordView::OnInitialUpdate();
}

/////////////////////////////////////////////////////////////////////////////
// CInMatForm printing

BOOL CInMatForm::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CInMatForm::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CInMatForm::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CInMatForm diagnostics

#ifdef _DEBUG
void CInMatForm::AssertValid() const
{
	CRecordView::AssertValid();
}

void CInMatForm::Dump(CDumpContext& dc) const
{
	CRecordView::Dump(dc);
}

CGlosDoc* CInMatForm::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGlosDoc)));
	return (CGlosDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CInMatForm database support
CRecordset* CInMatForm::OnGetRecordset()
{
	return m_pSet;
}


/////////////////////////////////////////////////////////////////////////////
// CInMatForm message handlers

void CInMatForm::OnRecordClear() 
{
	CAddForm::RecordClear();
	m_ctlSvenskaID.SetFocus();
}

void CInMatForm::OnRecordSave() 
{
	if (CAddForm::RecordSave())
	{		
		m_antalInmatade++;
		UpdateData(FALSE);
	}
	OnRecordClear();
}

void CInMatForm::OnRecordRefresh() 
{
	CAddForm::RecordRefresh();	
}

void CInMatForm::OnRecordDelete() 
{
	// The STDREG.MDB Student Registration database in Access Format
	// does not require a programmatic validation to
	// assure that a course is not deleted if any sections exist.
	// That is because the STDREG.MDB database has been pre-built with
	// such an referential integrity rule.  If the user tries to
	// delete a course that has a section, a CDBException will be
	// thrown, and ENROLL will display the SQL error message 
	// informing the user that the course cannot be deleted.  
	//
	// A Student Registration database initialized by the STDREG
	// tool will not have any such built-in referential integrity
	// rules.  For such databases, the following code assumes the
	// burden of assuring that the course is not deleted if a section
	// exists.  The reason that STDREG does not add referential
	// integrity checks to the Student Registration database is that
	// some databases such as SQL Server do not offer SQL, via ODBC,
	// for creating referential integrity rules such as "FOREIGN KEY".
	//
	// The deletion of a course is not the only place ENROLL 
	// needs a programmatic referential integrity check.  Another example
	// is a check that a duplicate course or seciton is not added.
	// For simplicity, ENROLL does not make these other checks.

	CUpdateHint hint;
	hint.m_svenska = m_pSet->m_Svenska;
	if (CAddForm::RecordDelete())
		GetDocument()->UpdateAllViews(this, HINT_DELETE_GLOS, &hint);
	
}
