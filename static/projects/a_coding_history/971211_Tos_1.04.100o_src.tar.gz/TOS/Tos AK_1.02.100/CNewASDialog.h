#if !defined(AFX_CNEWASDIALOG_H__3AA306EB_2F84_11D1_953B_000000000000__INCLUDED_)
#define AFX_CNEWASDIALOG_H__3AA306EB_2F84_11D1_953B_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// CNewASDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CNewASDialog dialog

class CNewASDialog : public CDialog
{
// Construction
public:
	CNewASDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CNewASDialog)
	enum { IDD = IDD_NEW_ANIMATED_SPRITE };
	BOOL	m_crawlEvent;
	BOOL	m_eastEvent;
	BOOL	m_jumpEvent;
	BOOL	m_northEvent;
	BOOL	m_northEastEvent;
	BOOL	m_northWestEvent;
	BOOL	m_shot1Event;
	BOOL	m_shot2Event;
	BOOL	m_southEvent;
	BOOL	m_southEastEvent;
	BOOL	m_southWestEvent;
	BOOL	m_westEvent;
	CString	m_resourceName;
	int		m_width;
	int		m_height;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNewASDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CNewASDialog)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CNEWASDIALOG_H__3AA306EB_2F84_11D1_953B_000000000000__INCLUDED_)
