// NewMTMDialog.cpp : implementation file
//

#include "stdafx.h"
#include "TOS.h"
#include "TOSDOC.h"
#include "NewMTMDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNewMTMDialog dialog


CNewMTMDialog::CNewMTMDialog(CTOSDoc* pDoc, CWnd* pParent /*=NULL*/)
	: CDialog(CNewMTMDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNewMTMDialog)
	m_MTMWidth = 64;
	m_MTMHeight = 64;
	m_tileMaxNumOfTiles = FALSE;
	m_resourceName = _T("MTM01");
	m_tosDoc = pDoc;
	m_STMResourceName = _T("Layer01");
	//}}AFX_DATA_INIT
}


void CNewMTMDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNewMTMDialog)
	DDX_Control(pDX, IDC_TREE1, m_tileListResourceTree);
	DDX_Text(pDX, IDC_EDIT_TILELIST_WIDTH, m_MTMWidth);
	DDV_MinMaxInt(pDX, m_MTMWidth, 1, 65536);
	DDX_Text(pDX, IDC_EDIT_TILELIST_HEIGHT, m_MTMHeight);
	DDV_MinMaxInt(pDX, m_MTMHeight, 1, 65536);
	DDX_Check(pDX, IDC_CHECK_MAX_NUM_OF_TILES, m_tileMaxNumOfTiles);
	DDX_Text(pDX, IDC_EDIT_RESOURCE_NAME, m_resourceName);
	DDV_MaxChars(pDX, m_resourceName, 80);
	DDX_Text(pDX, IDC_EDIT_RESOURCE_NAME_STM, m_STMResourceName);
	DDV_MaxChars(pDX, m_STMResourceName, 80);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNewMTMDialog, CDialog)
	//{{AFX_MSG_MAP(CNewMTMDialog)
	ON_NOTIFY(TVN_SELCHANGED, IDC_TREE1, OnSelchangedTree1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNewMTMDialog message handlers

void CNewMTMDialog::rebuildTileList()
{
 
	CTypedPtrList<CObList,CTileList*>& tileList = m_tosDoc->m_tileLists;
	POSITION pos = tileList.GetHeadPosition();
	while (pos != NULL)	
		NewTilesListTreeArm(tileList.GetNext(pos)->getResourceName());
	
	m_tileListResourceTree.Expand(hTreeTiles,TVE_EXPAND);
}

void CNewMTMDialog::NewTilesListTreeArm(CString pResourceName)
{			
	// Skapar tileslistans tr�d gren.
	TV_INSERTSTRUCT TreeCtrlItem;		
	TreeCtrlItem.hParent = hTreeTiles;
	TreeCtrlItem.item.mask = TVIF_TEXT | TVIF_PARAM;
	TreeCtrlItem.item.pszText = pResourceName.GetBuffer(80);
	TreeCtrlItem.item.lParam = 1010;
	m_tileListResourceTree.InsertItem(&TreeCtrlItem);	
	// Expanderar tiles grenen
}


void CNewMTMDialog::CreateTileListTree()
{
	// TODO: Add your specialized code here and/or call the base class

	TV_INSERTSTRUCT TreeCtrlItem;	
	
	TreeCtrlItem.hParent = TVI_ROOT;
	TreeCtrlItem.hInsertAfter = TVI_LAST;
	TreeCtrlItem.item.mask = TVIF_TEXT | TVIF_PARAM;


	TreeCtrlItem.item.pszText = "Tiles";
	TreeCtrlItem.item.lParam = 1000;
	hTreeTiles = m_tileListResourceTree.InsertItem(&TreeCtrlItem);

	m_tileListResourceTree.Expand(hTreeTiles,TVE_EXPAND);
}


BOOL CNewMTMDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	if (hTreeTiles != NULL)	
	   m_tileListResourceTree.DeleteAllItems();	

	CreateTileListTree();
	rebuildTileList();
	

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CNewMTMDialog::OnSelchangedTree1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;

	m_aktivTileListName = m_tileListResourceTree.GetItemText(pNMTreeView->itemNew.hItem);				

	*pResult = 0;
}

void CNewMTMDialog::OnOK() 
{
	// TODO: Add extra validation here
	if ((m_aktivTileListName == "Tiles") || (m_aktivTileListName == ""))
	{
		MessageBox("You must select a tile list", "Error", NULL);
		return;
	}
	
	CDialog::OnOK();
}
