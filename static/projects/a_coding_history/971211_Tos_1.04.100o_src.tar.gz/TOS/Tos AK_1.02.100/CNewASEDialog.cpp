// CNewASEDialog.cpp : implementation file
//

#include "stdafx.h"
#include "TOS.h"
#include "CNewASEDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNewASEDialog dialog


CNewASEDialog::CNewASEDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CNewASEDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNewASEDialog)
	m_eventName = _T("");
	//}}AFX_DATA_INIT
}


void CNewASEDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNewASEDialog)
	DDX_Text(pDX, IDC_EVENT_NAME, m_eventName);
	DDV_MaxChars(pDX, m_eventName, 80);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNewASEDialog, CDialog)
	//{{AFX_MSG_MAP(CNewASEDialog)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNewASEDialog message handlers
