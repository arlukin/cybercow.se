// CTile.cpp: implementation of the CTile class.
//
//////////////////////////////////////////////////////////////////////


#include "stdafx.h"
#include "TOS.h"
#include "CTile.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

static bool bBitmap;
// CTile commands
IMPLEMENT_SERIAL(CTile, CBitmap, 1)
CTile::CTile()
{
}

CTile::CTile(HBITMAP p_bitmap, HPALETTE p_palette)
: CDib(p_bitmap, p_palette)
{

}

CTile::~CTile()
{	
}


BOOL CTile::DrawTile(CDC* pDC, int p_xPos, int p_yPos, int p_width, int p_height)
{
	paint(pDC, p_xPos, p_yPos, p_width, p_height);

	return TRUE;
}