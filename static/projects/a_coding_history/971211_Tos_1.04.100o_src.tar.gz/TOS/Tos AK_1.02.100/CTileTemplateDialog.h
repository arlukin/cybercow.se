#if !defined(AFX_CTILETEMPLATEDIALOG_H__8B67752B_2D22_11D1_9538_000000000000__INCLUDED_)
#define AFX_CTILETEMPLATEDIALOG_H__8B67752B_2D22_11D1_9538_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CTOSDoc;


// CTileTemplateDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTileTemplateDialog dialog

class CTileTemplateDialog : public CDialog
{
// Construction
public:
	void drawMap(CDC * pDC);
	void drawTile(CDC* pDC, int p_xPos, int p_yPos);
	void drawTileMarker(CDC* pDC, CPoint point, tileMarkerFlag p_flags = CT_OLD_NEW);
	void insertTile(int p_xPos, int p_yPos, int p_tile);
	int m_oldMapHeight;
	int m_oldMapWidth;

	CTileTemplateDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTileTemplateDialog)
	enum { IDD = IDD_TILE_TEMPLATE };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTileTemplateDialog)
	public:
	virtual BOOL Create(CTOSDoc* p_Doc, UINT nIDTemplate, CWnd* pParentWnd = NULL);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CTOSDoc* m_tosDoc;
	CRect m_markerRect;
	// Generated message map functions
	//{{AFX_MSG(CTileTemplateDialog)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnMove(int x, int y);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CTILETEMPLATEDIALOG_H__8B67752B_2D22_11D1_9538_000000000000__INCLUDED_)
