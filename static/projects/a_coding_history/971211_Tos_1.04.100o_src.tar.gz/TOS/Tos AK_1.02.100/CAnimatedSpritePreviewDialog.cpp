// CAnimatedSpritePreviewDialog.cpp : implementation file
//

#include "stdafx.h"
#include "TOS.h"
#include "CAnimatedSpritePreviewDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAnimatedSpritePreviewDialog dialog


CAnimatedSpritePreviewDialog::CAnimatedSpritePreviewDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CAnimatedSpritePreviewDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAnimatedSpritePreviewDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CAnimatedSpritePreviewDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAnimatedSpritePreviewDialog)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAnimatedSpritePreviewDialog, CDialog)
	//{{AFX_MSG_MAP(CAnimatedSpritePreviewDialog)
	ON_WM_MOVE()
	ON_WM_SHOWWINDOW()
	ON_WM_TIMER()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAnimatedSpritePreviewDialog message handlers

BOOL CAnimatedSpritePreviewDialog::Create(CTOSDoc* p_Doc,  UINT nIDTemplate, CWnd* pParentWnd /*= NULL*/ ) 
{
	// TODO: Add your specialized code here and/or call the base class
	m_tosDoc = p_Doc;
	
	return CDialog::Create(IDD, pParentWnd);
}

void CAnimatedSpritePreviewDialog::OnMove(int x, int y) 
{
	CDialog::OnMove(x, y);
	
	// TODO: Add your message handler code here
	m_tosDoc->m_ASPreviewDialogXPos = x-3;
	m_tosDoc->m_ASPreviewDialogYPos = y-19;
	
	m_tosDoc->UpdateAllViews( NULL, NULL);		

	
}

void CAnimatedSpritePreviewDialog::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
	// TODO: Add your message handler code here
	setRightSize();
}

void CAnimatedSpritePreviewDialog::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default	
	if (nIDEvent == 1234)
	{

		CClientDC pDC(this);
		CAnimatedSprite* l_AS = m_tosDoc->getActiveAS();
		if (l_AS != NULL)
		{
			
			CAnimatedSpriteEvent* l_ASE = l_AS->getEvent( m_tosDoc->m_aktivResourceName );					
			
			if (l_ASE != NULL)
			{
				if (m_maxFrames != l_ASE->getMaxFrames())
				{
					m_crntFrame = 1;
					m_maxFrames = l_ASE->getMaxFrames();
					setRightSize();
				}
				
				m_crntFrame++;
				if (m_crntFrame > m_maxFrames)
					m_crntFrame = 1;

				l_ASE->drawFrame(&pDC, m_crntFrame);	
			}
		};
	};
	CDialog::OnTimer(nIDEvent);
}

void CAnimatedSpritePreviewDialog::setRightSize()
{
	CAnimatedSprite* l_AS = m_tosDoc->getActiveAS();
	if (l_AS != NULL)
	{	
		SetWindowPos(&wndBottom, 
					 m_tosDoc->m_ASPreviewDialogXPos,
					 m_tosDoc->m_ASPreviewDialogYPos,
					 l_AS->getSize().cx + 7,
					 l_AS->getSize().cy + 23,
					 SW_SHOWNOACTIVATE
					);	
	}
}