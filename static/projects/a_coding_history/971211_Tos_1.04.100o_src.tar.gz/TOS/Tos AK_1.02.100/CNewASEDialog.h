#if !defined(AFX_CNewASEDialog_H__022708E7_4318_11D1_9550_000000000000__INCLUDED_)
#define AFX_CNewASEDialog_H__022708E7_4318_11D1_9550_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// CNewASEDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CNewASEDialog dialog

class CNewASEDialog : public CDialog
{
// Construction
public:
	CNewASEDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CNewASEDialog)
	enum { IDD = IDD_NEW_ANIMATED_SPRITE_EVENT };
	CString	m_eventName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNewASEDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CNewASEDialog)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CNewASEDialog_H__022708E7_4318_11D1_9550_000000000000__INCLUDED_)
