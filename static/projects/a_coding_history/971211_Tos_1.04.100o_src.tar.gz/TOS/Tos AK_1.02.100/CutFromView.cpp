// CutFromView.cpp : implementation file
//

#include "stdafx.h"
#include "TOS.h"
#include "CutFromView.h"
#include "MainFrm.h"
#include "Dib\CDib.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCutFromView

IMPLEMENT_DYNCREATE(CCutFromView, CScrollView)

CCutFromView::CCutFromView()
{
}
					 

CCutFromView::~CCutFromView()
{
}


BEGIN_MESSAGE_MAP(CCutFromView, CScrollView)
	//{{AFX_MSG_MAP(CCutFromView)
	ON_MESSAGE(WM_DOREALIZE, OnDoRealize)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_KEYDOWN()
	ON_WM_HSCROLL()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCutFromView drawing


void CCutFromView::OnDraw(CDC* pDC)
{
	CTOSDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	pDC->GetClipBox(&m_screenRectClip);

	// Vilken typ av resource ska ritas ut p� sk�rmen... Efter valet i TreeView:n....
	switch (pDoc->m_aktivRoot)
	{

	case 1000: // 
		pDC->DrawText("No tile list marked", CRect(0, 0, 400, 20), DT_CENTER);
		break;

	case 1010 : // Draw the cut from bmp
		{
			if (pDoc->o_cutFromViewDIB != NULL)
				if (pDoc->o_cutFromViewDIB->isBitmap()) 
				{

					pDoc->o_cutFromViewDIB->paint(pDC, 0, 0);


					// Draw a grid
					if (pDoc->m_aktivResourceName != "")			
					{

						CTileList* pTileList = pDoc->getActiveTileList();
						if (pDoc->getActiveTileList() != NULL)
							if (pDoc->o_TOSPropertiesDialog.m_cutFromGrid)
							{
								CRect rectClip;
								GetClientRect(&rectClip);
												
								for (int yCounter = 0; yCounter <= rectClip.Height(); yCounter += pTileList->getSize().cy)
								{
									pDC->MoveTo(0, yCounter);
									pDC->LineTo(rectClip.Width(), yCounter);
								}
								for (int xCounter = 0; xCounter <= rectClip.Width(); xCounter += pTileList->getSize().cx)
								{
									pDC->MoveTo(xCounter, 0);
									pDC->LineTo(xCounter, rectClip.Height());
								}
							}
					}
				}			
			// Draw marked spot.
			pDC->InvertRect(m_markerRect);
		}
		break;

	case 2000: 
		pDC->DrawText("No MTM list selected", CRect(0, 0, 400, 20), DT_CENTER);
		break;

	case 2011: // Draw the Multi Tile Map
		drawTiles(pDC);
		pDC->InvertRect(m_markerRect); 		// Draw marked spot.
		break;

	case 3000:  
		pDC->DrawText("No Animated sprite selected", CRect(0, 0, 400, 20), DT_CENTER);
		break;

	case 3011: // Draw the Sprite events
			if (pDoc->o_cutFromViewDIB != NULL)
				if (pDoc->o_cutFromViewDIB->isBitmap()) 
					pDoc->o_cutFromViewDIB->paint(pDC, 0, 0);

			// Draw marked spot.
			pDC->InvertRect(m_markerRect);

		break;
	}
}

/////////////////////////////////////////////////////////////////////////////
// CCutFromView diagnostics

#ifdef _DEBUG
void CCutFromView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CCutFromView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CCutFromView message handlers

// Vet inte riktigt vad den h�r proceduren g�r... Ur kilppt fr�n DIBLook exemplet...
LRESULT CCutFromView::OnDoRealize(WPARAM wParam, LPARAM)
{	
	ASSERT(wParam != NULL);
	CTOSDoc* pDoc = GetDocument();

	if (pDoc->o_cutFromViewDIB == NULL)
		return 0L;  // no cutFromViewDIB exist.

	if (pDoc->o_cutFromViewDIB->isBitmap())
		return 0L;  // must be a new document

//	CPalette* pPal = pDoc->o_cutFromViewDIB->getHPALETTE();
//	if (pPal != NULL)
//	{
//		CMainFrame* pAppFrame = (CMainFrame*) AfxGetApp()->m_pMainWnd;
//		ASSERT_KINDOF(CMainFrame, pAppFrame);
//
//		CClientDC appDC(pAppFrame);
//		// All views but one should be a background palette.
//		// wParam contains a handle to the active view, so the SelectPalette
//		// bForceBackground flag is FALSE only if wParam == m_hWnd (this view)
//		CPalette* oldPalette = appDC.SelectPalette(pPal, ((HWND)wParam) != m_hWnd);
//
//		if (oldPalette != NULL)
//		{
//			UINT nColorsChanged = appDC.RealizePalette();
//			if (nColorsChanged > 0)
//				pDoc->UpdateAllViews(NULL);
//			appDC.SelectPalette(oldPalette, TRUE);
//		}
//		else
//		{
//			TRACE0("\tSelectPalette failed in CDibView::OnPaletteChanged\n");
//		}
//	}

	return 0L;
}

void CCutFromView::OnActivateView(BOOL bActivate, CScrollView* pActivateView, CScrollView* pDeactiveView) 
{
	CScrollView::OnActivateView(bActivate, pActivateView, pDeactiveView);
	
	if (bActivate)
	{
		ASSERT(pActivateView == this);
		OnDoRealize((WPARAM)m_hWnd, 0);   // same as SendMessage(WM_DOREALIZE);
	}
}


void CCutFromView::OnInitialUpdate()
{
	ASSERT(GetDocument() != NULL);	
	SetScrollSizes( MM_TEXT, GetDocument()->m_cutFromViewSize);

	CScrollView::OnInitialUpdate();
	m_markerRect.SetRectEmpty();	
}

void CCutFromView::OnMouseMove(UINT nFlags, CPoint point) 
{	
	// TODO: Add your message handler code here and/or call default
	CTOSDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	CClientDC dc(this);
	OnPrepareDC(&dc);
	
	// Vilken typ av resource ska anv�ndas... Efter valet i TreeView:n....
	switch (pDoc->m_aktivRoot)
	{
	case 1010: // Tiles List
		drawTileMarker(&dc, point);
		break;

	case 2011: // Multi Tile Map		
//			drawTileMarker(&dc, point);
		break;

	case 3011:	// Sprite		
		if (nFlags == MK_LBUTTON)
			getSprite();
		
		drawTileMarker(&dc, point);
		break;
	}
	CScrollView::OnMouseMove(nFlags, point);	
}

void CCutFromView::OnLButtonDown(UINT nFlags, CPoint point) 
{	
	CTOSDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	CClientDC dc(this);
	OnPrepareDC(&dc);
				
	
	// Vilken typ av resource ska anv�ndas... Efter valet i TreeView:n....
	switch (pDoc->m_aktivRoot)
	{
	case 1010: // Tiles List
		getTile();			
		break;

	case 2011: // Multi Tile Map		
			{				
				// Mark a tile to copy to STM.
				drawTileMarker(&dc, point);	
				
				CTileList* l_tileList = pDoc->getActiveMTM()->getSTM(pDoc->m_aktivResourceName)->getTileList();
					
				int tilesWidth  = (m_screenRectClip.Width()/l_tileList->getSize().cx);
				int tilesHeight = (m_screenRectClip.Height()/l_tileList->getSize().cy);
				
				pDoc->m_copyedTile = (m_markerRect.left / l_tileList->getSize().cx) +		
				  					 ((m_markerRect.top  / l_tileList->getSize().cy) * tilesWidth);
				
			}			
		break;

	case 3011:	// Sprite		
		getSprite();
		break;
	}
	
	CScrollView::OnLButtonDown(nFlags, point);
}

void CCutFromView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	CTOSDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);	
	
	if ((nChar == 'A') || (nChar == 'a'))	
	{
			
		switch (pDoc->m_aktivRoot)
		{
		case 1010: // Tiles List
			getTile();			
			break;

		case 2011: // Multi Tile Map		
			break;

		case 3011:	// Sprite		
			getSprite();
			break;
		}
	}	
	
	CScrollView::OnKeyDown(nChar, nRepCnt, nFlags);
}

bool CCutFromView::getTile()
{
	CTOSDoc* pDoc = GetDocument();		

	// Koll om det finns n�got att rita ut...
	if (pDoc->m_aktivResourceName == "")
	{		
		MessageBox("No tilelist marked", "Error", NULL);
		return false;
	}
	else
	{		
		HBITMAP  l_tileBitmap  = pDoc->o_cutFromViewDIB->cropBitmap(m_markerRect);
		HPALETTE l_tilePalette = pDoc->o_cutFromViewDIB->getHPALETTE();
		if (l_tileBitmap == NULL)
		{
			MessageBox("No bitmap to cut", "Error", NULL);
			return false;
		}
		else
			if (!pDoc->getActiveTileList()->addTile(l_tileBitmap, l_tilePalette))
			{
				MessageBox("Maximum numbers of tiles reached", "Error", NULL);
				return false;
			}
			else
			{
				 pDoc->UpdateAllViews( NULL, e_UPDATE_TOS_VIEW); 
				 pDoc->SetModifiedFlag();
			}
			 
	}	
	return true;
}

bool CCutFromView::getSprite()
{
	CTOSDoc* pDoc = GetDocument();		
	
	// Koll om det finns n�got att rita ut...
	if (pDoc->m_aktivResourceName == "")
	{		
		MessageBox("No sprite event marked", "Error", NULL);
		return false;
	}
	else
	{		
		HBITMAP  l_frameBitmap  = pDoc->o_cutFromViewDIB->cropBitmap(m_markerRect);
		HPALETTE l_framePalette = pDoc->o_cutFromViewDIB->getHPALETTE();
		if (l_frameBitmap == NULL)
		{
			MessageBox("No bitmap to cut", "Error", NULL);
			return false;
		}
		else
		{
			
			CAnimatedSpriteEvent* l_ASE;
			if (l_ASE = pDoc->getActiveASE())
			{
				if (!l_ASE->replaceFrame(l_frameBitmap, l_framePalette))
				{
					MessageBox("Can't create sprite frame", "Error", NULL);
					return false;
				}
				else
				{
					 pDoc->UpdateAllViews( NULL, e_UPDATE_TOS_VIEW); 
					 pDoc->SetModifiedFlag();
				}
			}
		}			 
	}
	return true;
}


void CCutFromView::drawTileMarker(CDC* pDC, CPoint point, tileMarkerFlag p_flags /*= CT_OLD_NEW*/)
{
	pDC->DPtoLP(&point);

	CTOSDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	if (pDoc->getActiveTileList() != NULL)
	{
		if ((p_flags == CT_OLD) || (p_flags == CT_OLD_NEW))
		{
			// Destroy old marked spot.				
			pDC->InvertRect(m_markerRect);			
			m_markerRect.SetRectEmpty();	
		}
			
		if ((p_flags == CT_NEW) || (p_flags == CT_OLD_NEW))
		{

			if (pDoc->o_TOSPropertiesDialog.m_cutFromGrid)
			{
				m_markerRect.left   = ((point.x / pDoc->getActiveTileList()->getSize().cy)*pDoc->getActiveTileList()->getSize().cy);
				m_markerRect.top    = ((point.y / pDoc->getActiveTileList()->getSize().cx )*pDoc->getActiveTileList()->getSize().cx);
				m_markerRect.right  = m_markerRect.left + pDoc->getActiveTileList()->getSize().cy;
				m_markerRect.bottom = m_markerRect.top  + pDoc->getActiveTileList()->getSize().cx;
			}
			else
			{
				m_markerRect.left   = point.x;
				m_markerRect.top    = point.y;
				m_markerRect.right  = m_markerRect.left + pDoc->getActiveTileList()->getSize().cy;
				m_markerRect.bottom = m_markerRect.top  + pDoc->getActiveTileList()->getSize().cx;
			}

			// Draw marked spot.		
			pDC->InvertRect(m_markerRect);			
		}
	} 				

	if (pDoc->getActiveMTM() != NULL)
	{
		if ((p_flags == CT_OLD) || (p_flags == CT_OLD_NEW))
		{
			// Destroy old marked spot.				
			pDC->InvertRect(m_markerRect);
		};

		if ((p_flags == CT_NEW) || (p_flags == CT_OLD_NEW))
		{
			CTileList* l_tileList = pDoc->getActiveMTM()->getSTM(pDoc->m_aktivResourceName)->getTileList();
				
			m_markerRect.left   = ((point.x / l_tileList->getSize().cy) * l_tileList->getSize().cy);
			m_markerRect.top    = ((point.y / l_tileList->getSize().cx ) * l_tileList->getSize().cx);
			m_markerRect.right  = m_markerRect.left + l_tileList->getSize().cy;
			m_markerRect.bottom = m_markerRect.top  + l_tileList->getSize().cx;

			// Draw marked spot.		
			pDC->InvertRect(m_markerRect);			
		};
	} 				

	if (pDoc->getActiveAS() != NULL)
	{
		if ((p_flags == CT_OLD) || (p_flags == CT_OLD_NEW))
		{
			// Destroy old marked spot.				
			pDC->InvertRect(m_markerRect);
		}

		if ((p_flags == CT_NEW) || (p_flags == CT_OLD_NEW))
		{
			if (pDoc->o_TOSPropertiesDialog.m_cutFromGrid)
			{
				m_markerRect.left   = ((point.x / pDoc->getActiveAS()->getSize().cx)*pDoc->getActiveAS()->getSize().cx);
				m_markerRect.top    = ((point.y / pDoc->getActiveAS()->getSize().cy)*pDoc->getActiveAS()->getSize().cy);
				m_markerRect.right  = m_markerRect.left + pDoc->getActiveAS()->getSize().cx;
				m_markerRect.bottom = m_markerRect.top  + pDoc->getActiveAS()->getSize().cy;

			}
			else
			{
				m_markerRect.left   = point.x;
				m_markerRect.top    = point.y;
				m_markerRect.right  = m_markerRect.left + pDoc->getActiveAS()->getSize().cx;
				m_markerRect.bottom = m_markerRect.top  + pDoc->getActiveAS()->getSize().cy;
			}			

			// Draw marked spot.		
			pDC->InvertRect(m_markerRect);			
		}

	} 				

}

void CCutFromView::drawTiles(CDC * pDC)
{
	CTOSDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// Koll om det finns n�got att rita ut...
	if (pDoc->m_aktivResourceName == "")
	{
		pDC->DrawText("No Tile list selected", CRect(0, 0, 400, 20), DT_CENTER);
		return;
	}
	else
	{
		// Draw the list of tiles.		
		pDoc->getActiveMTM()->getSTM(pDoc->m_aktivResourceName)->getTileList()->DrawTileList(pDC);
	}
}

void CCutFromView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	// TODO: Add your specialized code here and/or call the base class
	switch (lHint)
	{
	case NULL :
	case e_UPDATE_CUT_FROM_VIEW :
									m_markerRect.SetRectEmpty();

									Invalidate();
									break;

	default :					    break;
	};	
	//m_markerRect.SetRectEmpty();
}

void CCutFromView::OnPrepareDC(CDC* pDC, CPrintInfo* pInfo) 
{	
	CScrollView::OnPrepareDC(pDC, pInfo);

	CTOSDoc* pDoc = GetDocument();
	
	switch (pDoc->m_aktivRoot)
	{
	case 2011: // Multi Tile Map		
		//pDC->SetViewportOrg(0, pDC->GetViewportOrg().y);
		break;
	}
}

BOOL CCutFromView::OnScroll(UINT nScrollCode, UINT nPos, BOOL bDoScroll) 
{
	// TODO: Add your specialized code here and/or call the base class
//	OnUpdate(NULL, e_UPDATE_CUT_FROM_VIEW, NULL);	
	return CScrollView::OnScroll(nScrollCode, nPos, bDoScroll);
}

void CCutFromView::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	CTOSDoc* pDoc = GetDocument();
	
	switch (pDoc->m_aktivRoot)
	{
	case 2010:
	case 2011:
		break;
	default:		
			break;
	}	
	CScrollView::OnHScroll(nSBCode, nPos, pScrollBar);
}
