// CAnimatedSpriteController.cpp : implementation file
//

#include "stdafx.h"
#include "TOS.h"
#include "CAnimatedSpriteController.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAnimatedSpriteController dialog


CAnimatedSpriteController::CAnimatedSpriteController(CWnd* pParent /*=NULL*/)
	: CDialog(CAnimatedSpriteController::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAnimatedSpriteController)
	m_currentFrame = 0;
	m_height = 0;
	m_maxFrames = 0;
	m_width = 0;
	m_time = 200;
	//}}AFX_DATA_INIT
}


void CAnimatedSpriteController::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAnimatedSpriteController)
	DDX_Control(pDX, IDC_SLIDER_FRAME_SLIDER, m_frameSlider);
	DDX_Text(pDX, IDC_EDIT_CURRENT_FRAME, m_currentFrame);
	DDX_Text(pDX, IDC_EDIT_HEIGHT, m_height);
	DDX_Text(pDX, IDC_EDIT_MAX_FRAMES, m_maxFrames);
	DDX_Text(pDX, IDC_EDIT_WIDTH, m_width);
	DDX_Text(pDX, IDC_EDIT_TIME, m_time);
	DDV_MinMaxInt(pDX, m_time, 0, 10000);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAnimatedSpriteController, CDialog)
	//{{AFX_MSG_MAP(CAnimatedSpriteController)
	ON_WM_SHOWWINDOW()
	ON_WM_MOVE()
	ON_BN_CLICKED(IDC_BUTTON_FIRST, OnButtonFirst)
	ON_BN_CLICKED(IDC_BUTTON_LAST, OnButtonLast)
	ON_BN_CLICKED(IDC_BUTTON_NEXT, OnButtonNext)
	ON_BN_CLICKED(IDC_BUTTON_PLAY, OnButtonPlay)
	ON_BN_CLICKED(IDC_BUTTON_PREVIOUS, OnButtonPrevious)
	ON_BN_CLICKED(IDC_BUTTON_STOP, OnButtonStop)
	ON_BN_CLICKED(IDC_BUTTON_DELETE, OnButtonDelete)
	ON_BN_CLICKED(IDC_BUTTON_ADD, OnButtonAdd)
	ON_EN_KILLFOCUS(IDC_EDIT_TIME, OnKillfocusEditTime)
	ON_WM_KEYDOWN()
	ON_WM_KILLFOCUS()
	ON_WM_MOUSEMOVE()
	ON_EN_CHANGE(IDC_EDIT_TIME, OnChangeEditTime)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAnimatedSpriteController message handlers

void CAnimatedSpriteController::OnShowWindow(BOOL bShow, UINT nStatus) 
{	
	CDialog::OnShowWindow(bShow, nStatus);

	LPRECT lpRect;
	GetWindowRect(lpRect);
	SetWindowPos(&wndBottom, 
				 m_tosDoc->m_ASCtrlDialogXPos,
				 m_tosDoc->m_ASCtrlDialogYPos,
				 lpRect->right-lpRect->left,
				 lpRect->bottom-lpRect->top,
				  SW_SHOWNOACTIVATE
				);	
}

BOOL CAnimatedSpriteController::Create(CTOSDoc* p_Doc,  UINT nIDTemplate, CWnd* pParentWnd /*= NULL*/ ) 
{
	m_tosDoc = p_Doc;

	return CDialog::Create(nIDTemplate, pParentWnd);
}

void CAnimatedSpriteController::OnMove(int x, int y) 
{
	CDialog::OnMove(x, y);
			  	
	m_tosDoc->m_ASCtrlDialogXPos = x-3;
	m_tosDoc->m_ASCtrlDialogYPos = y-19;
	
	m_tosDoc->UpdateAllViews( NULL, NULL );		
}

void CAnimatedSpriteController::setData(ASControllerData p_ASCD)
{
	m_currentFrame = p_ASCD.m_currentFrame;
	m_maxFrames	   = p_ASCD.m_maxFrames;
	m_height	   = p_ASCD.m_height;
	m_width		   = p_ASCD.m_width;
	UpdateData(FALSE); 	
}

void CAnimatedSpriteController::OnButtonFirst() 
{
	// TODO: Add your control notification handler code here
	if (m_maxFrames > 0)
		m_currentFrame = 1;

	else 
		m_currentFrame = 0;

	UpdateData(FALSE); 	
	updateASEvent(m_currentFrame);
}

void CAnimatedSpriteController::OnButtonLast() 
{
	// TODO: Add your control notification handler code here	
	m_currentFrame = m_maxFrames;

	UpdateData(FALSE); 	
	updateASEvent(m_currentFrame);
}

void CAnimatedSpriteController::OnButtonNext() 
{
	// TODO: Add your control notification handler code here
	if (m_maxFrames > 0)
	{
		m_currentFrame++;
		if (m_currentFrame > m_maxFrames)
			m_currentFrame--;
	}
	else 
		m_currentFrame = 0;		


	UpdateData(FALSE); 	
	updateASEvent(m_currentFrame);
}

void CAnimatedSpriteController::OnButtonPrevious() 
{
	// TODO: Add your control notification handler code here
	if (m_maxFrames > 0)
	{
		m_currentFrame--;
		if (m_currentFrame < 1)
			m_currentFrame++;
	}
	else 
		m_currentFrame = 0;	

	UpdateData(FALSE); 	
	updateASEvent(m_currentFrame);
}

void CAnimatedSpriteController::OnButtonPlay() 
{
	// TODO: Add your control notification handler code here
	m_tosDoc->m_ASPreviewDialog.ShowWindow(SW_SHOW | SW_SHOWNOACTIVATE);

	CAnimatedSpriteEvent* l_ASE;
	if (l_ASE = getEvent())
	{
		if (m_time != l_ASE->getTime())
		{

			m_currentFrame = l_ASE->getCrntFrame();
			m_maxFrames	   = l_ASE->getMaxFrames();
			m_time         = l_ASE->getTime();
			UpdateData(false);
		};

		m_tosDoc->m_ASPreviewDialog.SetTimer(1234, m_time, NULL);
	}
}

void CAnimatedSpriteController::OnButtonStop() 
{
	// TODO: Add your control notification handler code here
	m_tosDoc->m_ASPreviewDialog.KillTimer(1234);	
	m_tosDoc->m_ASPreviewDialog.ShowWindow(SW_HIDE);
}

void CAnimatedSpriteController::OnButtonDelete() 
{
	// TODO: Add your control notification handler code here
	CAnimatedSpriteEvent* l_ASE;
	if (l_ASE = getEvent())
	{
		m_maxFrames = l_ASE->deleteFrame(m_currentFrame);			
			OnButtonPrevious();					
	}
}

void CAnimatedSpriteController::OnButtonAdd() 
{
	// TODO: Add your control notification handler code here
	CAnimatedSpriteEvent* l_ASE;
	if (l_ASE = getEvent())
	{
		l_ASE->addFrame();
		m_maxFrames = l_ASE->getMaxFrames();

		m_tosDoc->UpdateAllViews(NULL, e_UPDATE_TOS_VIEW);
	}	
}

void CAnimatedSpriteController::updateASEvent(int m_currentFrame)
{
	CAnimatedSpriteEvent* l_ASE;
	if (l_ASE = getEvent())
	{
		l_ASE->setCrntFrame(m_currentFrame);	
		m_maxFrames = l_ASE->getMaxFrames();		
		m_tosDoc->UpdateAllViews(NULL, e_UPDATE_TOS_VIEW);
	}
}

void CAnimatedSpriteController::OnKillfocusEditTime() 
{
	// TODO: Add your control notification handler code here
	if (m_tosDoc->m_ASPreviewDialog.KillTimer(1234))
	{
		m_tosDoc->m_ASPreviewDialog.SetTimer(1234, m_time, NULL);

		CAnimatedSpriteEvent* l_ASE;
		if (l_ASE = getEvent())
			l_ASE->setTime(m_time);
	}
}


void CAnimatedSpriteController::OnChangeEditTime() 
{
}

void CAnimatedSpriteController::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
}

void CAnimatedSpriteController::OnKillFocus(CWnd* pNewWnd) 
{
}

CAnimatedSpriteEvent* CAnimatedSpriteController::getEvent()
{
	CAnimatedSprite* l_AS = m_tosDoc->getActiveAS();
	if (l_AS > NULL)
	{
		CAnimatedSpriteEvent* l_ASE = l_AS->getEvent( m_tosDoc->m_aktivResourceName );
		if (l_ASE > NULL)
		{
			return l_ASE;
		}				
	}

	return NULL;
}
