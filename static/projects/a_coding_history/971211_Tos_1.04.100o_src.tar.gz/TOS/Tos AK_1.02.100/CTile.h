// CTile.h: interface for the CTile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CTile_H__3AA306EC_2F84_11D1_953B_000000000000__INCLUDED_)
#define AFX_CTile_H__3AA306EC_2F84_11D1_953B_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CTile : public CDib
{        
// Operations
public:	
	CTile(HBITMAP p_bitmap, HPALETTE p_palette);
	CTile();
	DECLARE_SERIAL(CTile)
	BOOL		 DrawTile(CDC* pDC, int p_xPos, int p_yPos, int p_width, int p_height);
	virtual      ~CTile(); 
protected:	
      
};
#endif // !defined(AFX_CTile_H__3AA306EC_2F84_11D1_953B_000000000000__INCLUDED_)
