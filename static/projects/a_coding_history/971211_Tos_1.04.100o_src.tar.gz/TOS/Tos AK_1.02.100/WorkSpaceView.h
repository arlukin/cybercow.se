#if !defined(AFX_WORKSPACEVIEW_H__5AB13183_01FA_11D1_94E4_000000000000__INCLUDED_)
#define AFX_WORKSPACEVIEW_H__5AB13183_01FA_11D1_94E4_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "TOSDoc.h"

// WorkSpaceView.h : header file
//
/////////////////////////////////////////////////////////////////////////////
// CWorkSpaceView view

class CWorkSpaceView : public CTreeView
{
protected:
	CWorkSpaceView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CWorkSpaceView)

// Attributes
public:

// Operations
public:	
	HTREEITEM NewASTreeArm(CString pResourceName);
	
	
	void CreateTOSTree();
	void rebuildTreeArms();	
	HTREEITEM  NewMTMTreeArm(CString pResourceName);
	void NewTilesListTreeArm(CString pResourceName);		
	HTREEITEM newTreeArm(CString pResourceName, HTREEITEM p_treeItem, int p_treeType);
	
	HTREEITEM hTreeTop;	
	HTREEITEM hTreeTiles;
	HTREEITEM hTreeMTM;
	HTREEITEM hTreeAS;

	CTOSDoc* GetDocument();
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWorkSpaceView)
	public:
	virtual void OnInitialUpdate();
	protected:	
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CWorkSpaceView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	void showTileTMPLDialog(int p_flag);
	//{{AFX_MSG(CWorkSpaceView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSelchanged(NMHDR* pNMHDR, LRESULT* pResult);	
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WORKSPACEVIEW_H__5AB13183_01FA_11D1_94E4_000000000000__INCLUDED_)
