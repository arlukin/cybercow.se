// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "TOS.h"

#include "MainFrm.h"

#include "WorkSpaceView.h"
#include "cBrowseView.h"
#include "CutFromView.h"
#include "CNewTileList.h"
#include "NewMTMDialog.h"
#include "CNewSTMDialog.h"
#include "CNewASDialog.h"
#include "CNewASEDialog.h"
#include "CSTM.H"
#include "CTileTemplateDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_TILES, OnTiles)
	ON_COMMAND(ID_TESTSPLITTERWINDOW, OnTestsplitterwindow)
	ON_COMMAND(ID_TOS_PROPERTIES, OnTosProperties)
	ON_COMMAND(ID_OPEN_CUT_FROM_PICTURE, OnOpenCutFromPicture)
	ON_COMMAND(ID_INSERT_MTM, OnInsertMtm)
	ON_COMMAND(ID_MULTI_TILE_MAPS_Insert_Layer, OnMTMInsertLayer )
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_KEYDOWN()
	ON_COMMAND(ID_INSERT_ANIMATED_SPRITES, OnInsertAnimatedSprites)
	ON_COMMAND(ID_INSERT_EVENT, OnInsertEvent)
	//}}AFX_MSG_MAP
	// Global help commands
	ON_COMMAND(ID_HELP_FINDER, CFrameWnd::OnHelpFinder)
	ON_COMMAND(ID_HELP, CFrameWnd::OnHelp)
	ON_COMMAND(ID_CONTEXT_HELP, CFrameWnd::OnContextHelp)
	ON_COMMAND(ID_DEFAULT_HELP, CFrameWnd::OnHelpFinder)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.Create(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Remove this if you don't want tool tips or a resizeable toolbar
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	return 0;
}

BOOL CMainFrame::OnCreateClient( LPCREATESTRUCT /*lpcs*/,
	CCreateContext* pContext)
{
/*
   m_wndSplitter.Create( this, 2, 2, CSize(10, 10), pContext,  
						 WS_CHILD | WS_VISIBLE |WS_HSCROLL | 
						 WS_VSCROLL | SPLS_DYNAMIC_SPLIT
					   );

	if (!m_wndSplitter.CreateView(1, 2,
	pContext->m_pNewViewClass, CSize(250, 240), pContext))
	{
		TRACE0("Failed to create first pane\n");
		return FALSE;
	}
*/
	//	   m_wndSplitter.SplitRow(80);


	m_wndSplitter.CreateStatic( this, 2, 2, WS_VSCROLL | WS_HSCROLL | WS_CHILD | WS_VISIBLE );


	// add the WorkSpace splitter pane - an input view in column 0 row 0
	if (!m_wndSplitter.CreateView(0, 0,
		RUNTIME_CLASS(CWorkSpaceView), CSize(250, 240), pContext))
	{
		TRACE0("Failed to create second pane\n");
		return FALSE;
	}

	// add the WorkArea splitter pane - the default view in column 1 row 0
	if (!m_wndSplitter.CreateView(0, 1,
		pContext->m_pNewViewClass, CSize(250, 240), pContext))
	{
		TRACE0("Failed to create first pane\n");
		return FALSE;
	}

	
	// add the second splitter pane - an input view in column 0 row 1
	if (!m_wndSplitter.CreateView(1, 0,		
		RUNTIME_CLASS(CBrowseView), CSize(250, 40), pContext))
	{
		TRACE0("Failed to create second pane\n");
		return FALSE;
	}


	if (!m_wndSplitter.CreateView(1, 1,
		RUNTIME_CLASS(CCutFromView), CSize(250, 40), pContext))
	{
		TRACE0("Failed to create second pane\n");
		return FALSE;
	}	


	return( TRUE );
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	
	return CFrameWnd::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}


#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers



void CMainFrame::OnTestsplitterwindow() 
{
	CTOSDoc*	pDoc = ((CTOSDoc*) GetActiveDocument());
}


void CMainFrame::OnTiles() 
{	
	CTOSDoc*	    pDoc			= ((CTOSDoc*) GetActiveDocument());
	CWorkSpaceView* poWorkSpaceView = ((CWorkSpaceView*)m_wndSplitter.GetPane (0,0));	
	

	CNewTileList newTileList;
	if (newTileList.DoModal() == IDOK)
	{

		// Kontrollerar om det finns en tiles gren med det namnet redan.
		CTypedPtrList<CObList,CTileList*>& tileList = pDoc->m_tileLists;
		POSITION pos = tileList.GetHeadPosition();
		CTileList* pTileList;
		while (pos != NULL)
		{
			
			pTileList = tileList.GetNext(pos);
			if (pTileList->getResourceName() == newTileList.m_tileListFileName)
			{	
				MessageBox("The name already exist", "Error", NULL);				
				return;
			};
		}	

		// Skapar tileslistan 
		pDoc->NewTilesList(newTileList.m_tileListFileName, 
		       			    newTileList.m_tileListWidth,
						    newTileList.m_tileListHeight,
						    newTileList.m_tileListNumOfTiles
						   );

		poWorkSpaceView->NewTilesListTreeArm(newTileList.m_tileListFileName);	
		pDoc->UpdateAllViews(NULL, NULL);
	}


}

void CMainFrame::OnInsertMtm() 
{
	CTOSDoc*	    pDoc			= ((CTOSDoc*) GetActiveDocument());
	CWorkSpaceView* poWorkSpaceView = ((CWorkSpaceView*)m_wndSplitter.GetPane (0,0));	
	

	CNewMTMDialog newMTMDialog(pDoc);
	if (newMTMDialog.DoModal() == IDOK)
	{

		// Kontrollerar om det finns en MTM gren med det namnet redan.
		CTypedPtrList<CObList,CMTM*>& MTM = pDoc->m_MTM;
		POSITION pos = MTM.GetHeadPosition();
		CMTM* pMTM;
		while (pos != NULL)
		{			
			pMTM = MTM.GetNext(pos);
			if (pMTM->getResourceName() == newMTMDialog.m_resourceName)
			{	
				MessageBox("The name already exist", "Error", NULL);				
				return;
			};
		}	


		HTREEITEM l_treeLeaf = poWorkSpaceView->NewMTMTreeArm(newMTMDialog.m_resourceName);	

		// Skapar MTM listan 
		CMTM* l_MTM = pDoc->NewMTMList(newMTMDialog.m_resourceName, newMTMDialog.m_MTMWidth, newMTMDialog.m_MTMHeight, 
								    	newMTMDialog.m_tileMaxNumOfTiles, l_treeLeaf);

		// Skapar STM lager 1
		poWorkSpaceView->newTreeArm(newMTMDialog.m_STMResourceName, l_treeLeaf, 2011);
		l_MTM->insertMTMLayer(newMTMDialog.m_STMResourceName, pDoc->getTileList(newMTMDialog.getTileList()));
		
		pDoc->UpdateAllViews(NULL, NULL);
	}	
}

void CMainFrame::OnMTMInsertLayer() 
{
	CTOSDoc*	    pDoc			= ((CTOSDoc*) GetActiveDocument());
	CWorkSpaceView* poWorkSpaceView = ((CWorkSpaceView*)m_wndSplitter.GetPane (0,0));	
	
	if (pDoc->m_aktivMTMResourceName != "")
	{	
		CNewSTMDialog newSTMDialog(pDoc);
		if (newSTMDialog.DoModal() == IDOK)
		{
			//pDoc->m_aktivResourceName = GetTreeCtrl().GetItemText(pNMTreeView->itemNew.hItem);		

			// Kontrollerar om det finns en MTM gren med det namnet redan.


			if (pDoc->getActiveMTM()->getSTM(newSTMDialog.m_resourceName) != NULL)
			{
				MessageBox("The name already exist", "Error", NULL);				
				return;
			}

			// Skapar STM listan 

			pDoc->getActiveMTM()->insertMTMLayer(newSTMDialog.m_resourceName, pDoc->getTileList(newSTMDialog.getTileList()));

			poWorkSpaceView->newTreeArm(newSTMDialog.m_resourceName, pDoc->getActiveMTM()->getTreeLeaf(), 2011);	
			pDoc->UpdateAllViews(NULL, NULL);
		}		
	}
	else
	{
		MessageBox("You must select a MTM", "Error", NULL);
	}

}

void CMainFrame::OnTosProperties() 
{	
	CTOSDoc*	pDoc = ((CTOSDoc*) GetActiveDocument());
	pDoc->o_TOSPropertiesDialog.DoModal();

	pDoc->UpdateAllViews(NULL, NULL);
}

void CMainFrame::OnOpenCutFromPicture() 
{

CString l_browseFileName;
CTOSDoc*	    pDoc			= ((CTOSDoc*) GetActiveDocument());
static char BASED_CODE szFilter[] = "BMP Files (*.bmp)|*.bmp|All Files (*.*)|*.*||";

	CFileDialog fileDialog(TRUE, "*.bmp", NULL,
	OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_LONGNAMES | OFN_PATHMUSTEXIST,
	szFilter);

	if (fileDialog.DoModal() == IDOK)
	{
		l_browseFileName = fileDialog.GetPathName();

		if (!l_browseFileName.IsEmpty())
		{
			// Check if file exist
			CFileFind FileFind;
			if (FileFind.FindFile(l_browseFileName))
			{
				if (pDoc->o_cutFromViewDIB == NULL)
					pDoc->o_cutFromViewDIB = new CDib();

				pDoc->o_cutFromViewDIB->clear();
				pDoc->o_cutFromViewDIB->loadBMP(l_browseFileName);	
				pDoc->m_cutFromViewSize = pDoc->o_cutFromViewDIB->getSize();
			}
			else	
			{
				MessageBox("Can't find file", "Error", NULL);
				//TODODEL 
				// Aktiverar browseFileName formen.
			}
		}
	}
	Invalidate();       // Repaint the entire form view.
	pDoc->UpdateAllViews( NULL, e_UPDATE_CUT_FROM_VIEW );
}

void CMainFrame::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CTOSDoc*	pDoc = ((CTOSDoc*) GetActiveDocument());
		
	switch (pDoc->m_aktivRoot)
	{
	case 2011: 

		break;

	default :	
		break;
	}	
	
	CFrameWnd::OnLButtonDown(nFlags, point);
}

void CMainFrame::OnMouseMove(UINT nFlags, CPoint point) 
{
	CTOSDoc*	pDoc = ((CTOSDoc*) GetActiveDocument());
		
	switch (pDoc->m_aktivRoot)
	{
	case 2011: 
		break;

	default :	
		break;
	}	
	
	CFrameWnd::OnMouseMove(nFlags, point);
}

void CMainFrame::OnLButtonUp(UINT nFlags, CPoint point) 
{
	CTOSDoc*	pDoc = ((CTOSDoc*) GetActiveDocument());
		
	switch (pDoc->m_aktivRoot)
	{
	case 2011: 
		break;

	default :	
		break;
	}	
	
	CFrameWnd::OnLButtonUp(nFlags, point);
}

void CMainFrame::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{	
	CFrameWnd::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CMainFrame::OnInsertAnimatedSprites() 
{
	CTOSDoc*	    pDoc			= ((CTOSDoc*) GetActiveDocument());
	CWorkSpaceView* poWorkSpaceView = ((CWorkSpaceView*)m_wndSplitter.GetPane (0,0));	
	

	CNewASDialog newASDialog;
	if (newASDialog.DoModal() == IDOK)
	{
		// Kontrollerar om det finns en AS gren med det namnet redan.
		CTypedPtrList<CObList,CAnimatedSprite*>& AS = pDoc->m_AS;
		POSITION pos = AS.GetHeadPosition();
		CAnimatedSprite* pAS;
		while (pos != NULL)
		{			
			pAS = AS.GetNext(pos);
			if (pAS->getResourceName() == newASDialog.m_resourceName)
			{	
				MessageBox("The name already exist", "Error", NULL);				
				return;
			};
		}	


		HTREEITEM l_treeLeaf = poWorkSpaceView->NewASTreeArm(newASDialog.m_resourceName);	

		// Create AS list 
		CAnimatedSprite* l_AS = pDoc->NewASList(newASDialog.m_resourceName, newASDialog.m_width, newASDialog.m_height, l_treeLeaf);

		// Create all events list

		if (newASDialog.m_crawlEvent == TRUE)
		{
			poWorkSpaceView->newTreeArm("Crawl", l_treeLeaf, 3011);
			l_AS->insertASEvent("Crawl");
		}

		if (newASDialog.m_eastEvent == TRUE)
		{
			poWorkSpaceView->newTreeArm("East", l_treeLeaf, 3011);
			l_AS->insertASEvent("East");
		}

		if (newASDialog.m_jumpEvent == TRUE)
		{
			poWorkSpaceView->newTreeArm("Jump", l_treeLeaf, 3011);
			l_AS->insertASEvent("Jump");
		}

		if (newASDialog.m_northEvent == TRUE)
		{
			poWorkSpaceView->newTreeArm("North", l_treeLeaf, 3011);
			l_AS->insertASEvent("North");
		}

		if (newASDialog.m_northEastEvent == TRUE)
		{
			poWorkSpaceView->newTreeArm("NorthEast", l_treeLeaf, 3011);
			l_AS->insertASEvent("NorthEast");
		}

		if (newASDialog.m_northWestEvent == TRUE)
		{
			poWorkSpaceView->newTreeArm("NorthWest", l_treeLeaf, 3011);
			l_AS->insertASEvent("NorthWest");
		}

		if (newASDialog.m_shot1Event == TRUE)
		{
			poWorkSpaceView->newTreeArm("Shot1", l_treeLeaf, 3011);
			l_AS->insertASEvent("Shot1");
		}

		if (newASDialog.m_shot2Event == TRUE)
		{
			poWorkSpaceView->newTreeArm("Shot2", l_treeLeaf, 3011);
			l_AS->insertASEvent("Shot2");
		}

		if (newASDialog.m_southEvent == TRUE)
		{
			poWorkSpaceView->newTreeArm("South", l_treeLeaf, 3011);
			l_AS->insertASEvent("South");
		}

		if (newASDialog.m_southEastEvent == TRUE)
		{
			poWorkSpaceView->newTreeArm("SouthEast", l_treeLeaf, 3011);
			l_AS->insertASEvent("SouthEast");
		}

		if (newASDialog.m_southWestEvent == TRUE)
		{
			poWorkSpaceView->newTreeArm("SouthWest", l_treeLeaf, 3011);
			l_AS->insertASEvent("SouthWest");
		}

		if (newASDialog.m_westEvent == TRUE)
		{
			poWorkSpaceView->newTreeArm("West", l_treeLeaf, 3011);
			l_AS->insertASEvent("West");
		}
		
		pDoc->UpdateAllViews(NULL, NULL);
	}		
}

void CMainFrame::OnInsertEvent() 
{
	CTOSDoc*	    pDoc			= ((CTOSDoc*) GetActiveDocument());
	CWorkSpaceView* poWorkSpaceView = ((CWorkSpaceView*)m_wndSplitter.GetPane (0,0));	
	
	if (pDoc->m_aktivASResourceName != "")
	{	

		CNewASEDialog newASEDialog;
		if (newASEDialog.DoModal() == IDOK)
		{
			// Kontrollerar om det finns en ASE gren med det namnet redan.

			CAnimatedSprite* pAS = pDoc->getActiveAS();
			if (pAS->getEvent(newASEDialog.m_eventName) == NULL)
			{	

				// Skapar ASE killen			
				pAS->insertASEvent(newASEDialog.m_eventName);
	
				poWorkSpaceView->newTreeArm(newASEDialog.m_eventName, pAS->m_treeLeaf, 3011);
							
				pDoc->UpdateAllViews(NULL, NULL);
			}
			else
			{
				MessageBox("The name already exist", "Error", NULL);
			}
		}
	}
	else
	{
		MessageBox("You must select an AS", "Error", NULL);
	}
}
