#if !defined(AFX_CNEWTILELIST_H__7FA066BC_0F69_11D1_94FD_000000000000__INCLUDED_)
#define AFX_CNEWTILELIST_H__7FA066BC_0F69_11D1_94FD_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// CNewTileList.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CNewTileList dialog

class CNewTileList : public CDialog
{
// Construction
public:
	CNewTileList(CWnd* pParent = NULL);   // standard constructor
	

// Dialog Data
	//{{AFX_DATA(CNewTileList)
	enum { IDD = IDD_NEW_TILELIST };
	CString	m_tileListFileName;
	int		m_tileListHeight;
	int		m_tileListWidth;
	int		m_tileListNumOfTiles;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNewTileList)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CNewTileList)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CNEWTILELIST_H__7FA066BC_0F69_11D1_94FD_000000000000__INCLUDED_)
