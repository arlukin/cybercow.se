// CNewTileList.cpp : implementation file
//

#include "stdafx.h"
#include "TOS.h"
#include "CNewTileList.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNewTileList dialog


CNewTileList::CNewTileList(CWnd* pParent /*=NULL*/)
	: CDialog(CNewTileList::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNewTileList)
	m_tileListFileName = _T("TileList01");
	m_tileListHeight = 32;
	m_tileListWidth = 32;
	m_tileListNumOfTiles = 255;
	//}}AFX_DATA_INIT
}


void CNewTileList::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNewTileList)
	DDX_Text(pDX, IDC_EDIT_TILELIST_FILENAME, m_tileListFileName);
	DDV_MaxChars(pDX, m_tileListFileName, 80);
	DDX_Text(pDX, IDC_EDIT_TILELIST_HEIGHT, m_tileListHeight);
	DDV_MinMaxUInt(pDX, m_tileListHeight, 1, 256);
	DDX_Text(pDX, IDC_EDIT_TILELIST_WIDTH, m_tileListWidth);
	DDV_MinMaxUInt(pDX, m_tileListWidth, 1, 256);
	DDX_Text(pDX, IDC_EDIT_TILELIST_NUMOFTILES, m_tileListNumOfTiles);
	DDV_MinMaxInt(pDX, m_tileListNumOfTiles, 1, 65536);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNewTileList, CDialog)
	//{{AFX_MSG_MAP(CNewTileList)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNewTileList message handlers
