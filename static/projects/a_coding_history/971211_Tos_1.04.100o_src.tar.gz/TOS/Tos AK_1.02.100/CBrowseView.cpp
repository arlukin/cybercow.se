// CBrowseView.cpp : implementation file
//

#include "stdafx.h"
#include "TOS.h"
#include "CBrowseView.h"
#include "tosdoc.h"
#include "dib\CDib.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBrowseView

IMPLEMENT_DYNCREATE(CBrowseView, CFormView)

CBrowseView::CBrowseView()
	: CFormView(CBrowseView::IDD)
{
	//{{AFX_DATA_INIT(CBrowseView)
	//}}AFX_DATA_INIT
}

CBrowseView::~CBrowseView()
{
}


BEGIN_MESSAGE_MAP(CBrowseView, CFormView)
	//{{AFX_MSG_MAP(CBrowseView)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBrowseView diagnostics

#ifdef _DEBUG
void CBrowseView::AssertValid() const
{
	CFormView::AssertValid();
}

void CBrowseView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CBrowseView message handlers

