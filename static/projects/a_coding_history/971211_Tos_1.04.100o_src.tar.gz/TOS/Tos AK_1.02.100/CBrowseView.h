#if !defined(AFX_CBROWSEVIEW_H__8DAE1BDF_1CC1_11D1_9516_000000000000__INCLUDED_)
#define AFX_CBROWSEVIEW_H__8DAE1BDF_1CC1_11D1_9516_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// CBrowseView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBrowseView form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CBrowseView : public CFormView
{
protected:
	CBrowseView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CBrowseView)

// Form Data
public:
	//{{AFX_DATA(CBrowseView)
	enum { IDD = IDD_BROWSE_VIEW };
	//}}AFX_DATA

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBrowseView)
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CBrowseView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CBrowseView)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CBROWSEVIEW_H__8DAE1BDF_1CC1_11D1_9516_000000000000__INCLUDED_)
