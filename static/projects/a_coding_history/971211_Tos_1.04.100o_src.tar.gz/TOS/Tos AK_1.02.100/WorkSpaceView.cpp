// WorkSpaceView.cpp : implementation file
//

#include "stdafx.h"
#include "TOS.h"
#include "TOSDOC.h"
#include "WorkSpaceView.h"
#include "CNewTileList.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWorkSpaceView

IMPLEMENT_DYNCREATE(CWorkSpaceView, CTreeView)

CWorkSpaceView::CWorkSpaceView()
{
	hTreeTop      = NULL;	
	hTreeTiles	  = NULL;	
	hTreeMTM	  = NULL;
	hTreeAS		  = NULL;
}

CWorkSpaceView::~CWorkSpaceView()
{
}


BEGIN_MESSAGE_MAP(CWorkSpaceView, CTreeView)
	//{{AFX_MSG_MAP(CWorkSpaceView)
	ON_WM_CREATE()
	ON_NOTIFY_REFLECT(TVN_SELCHANGED, OnSelchanged)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CWorkSpaceView diagnostics

#ifdef _DEBUG
void CWorkSpaceView::AssertValid() const
{
	CTreeView::AssertValid();
}

void CWorkSpaceView::Dump(CDumpContext& dc) const
{
	CTreeView::Dump(dc);
}

#endif //_DEBUG
CTOSDoc* CWorkSpaceView::GetDocument()// non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTOSDoc)));
	return (CTOSDoc*)m_pDocument;
}


/////////////////////////////////////////////////////////////////////////////
// CWorkSpaceView message handlers

BOOL CWorkSpaceView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CTreeView::PreCreateWindow(cs))
	return FALSE;

	cs.style = WS_CHILD | WS_VISIBLE | WS_BORDER | TVS_LINESATROOT |
				TVS_HASLINES | TVS_SHOWSELALWAYS | TVS_HASBUTTONS |
				TVS_DISABLEDRAGDROP;
	return TRUE;

}

int CWorkSpaceView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CTreeView::OnCreate(lpCreateStruct) == -1)
		return -1;

	#ifdef _MARCOC_OLD

		RECT rect ;
		rect.top    = lpCreateStruct->y ;
		rect.left   = lpCreateStruct->x ;
		rect.bottom = lpCreateStruct->cy ;
		rect.right  = lpCreateStruct->cx ;
 
		if (!GetTreeCtrl().Create(  WS_CHILD | WS_VISIBLE |
									WS_BORDER | 
									TVS_LINESATROOT |
									TVS_HASLINES | 
	                                TVS_SHOWSELALWAYS |
									TVS_HASBUTTONS |
									TVS_DISABLEDRAGDROP,
									rect, this, ID_TREEVIEW ))
		{
			TRACE( _T("Tree control failed to create!") ) ;
			return -1 ;
		}
	#endif


	return 0;
}

void CWorkSpaceView::OnInitialUpdate() 
{	
	CTreeView::OnInitialUpdate();	

	if (hTreeTop != NULL)	
		GetTreeCtrl().DeleteAllItems();	

	CTOSDoc* pDoc = GetDocument();

	pDoc->m_copyedTileTMPLDialog.DestroyWindow();
	pDoc->m_copyedTileTMPLDialog.Create(pDoc, IDD_TILE_TEMPLATE);

	pDoc->m_ASCtrlDialog.DestroyWindow();
	pDoc->m_ASCtrlDialog.Create(pDoc, IDD_ANIMATED_SPRITE_CONTROLLER);

	pDoc->m_ASPreviewDialog.DestroyWindow();
	pDoc->m_ASPreviewDialog.Create(pDoc, IDD_ANIMATED_SPRITE_PREVIEW);

	CreateTOSTree();
	rebuildTreeArms();
}


void CWorkSpaceView::OnSelchanged(NMHDR* pNMHDR, LRESULT* pResult) 
{

	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;	
	// TODO: Add your control notification handler code here
	CTOSDoc* pDoc = GetDocument();
	int l_data = GetTreeCtrl().GetItemData(pNMTreeView->itemNew.hItem);


	pDoc->m_aktivTileList = NULL;
	pDoc->m_aktivMTM = NULL;
	pDoc->m_aktivASList = NULL;	

	if ((l_data == 1000) || (l_data == 2000) || (l_data == 3000))		// Tiles huvud menyn
	{
		pDoc->m_aktivRoot = l_data;
		pDoc->m_aktivResourceName.Empty();
	}
	else 
	{
		pDoc->m_aktivRoot = GetTreeCtrl().GetItemData(pNMTreeView->itemNew.hItem);
		pDoc->m_aktivResourceName = GetTreeCtrl().GetItemText(pNMTreeView->itemNew.hItem);		
	};


	if (l_data == 2010)
	{
		pDoc->m_aktivMTMResourceName = pDoc->m_aktivResourceName;
		pDoc->m_copyedTileTMPLDialog.ShowWindow(SW_HIDE);
	}
	else
		if (l_data == 2011)
		{		
			pDoc->m_aktivMTMResourceName = GetTreeCtrl().GetItemText(GetTreeCtrl().GetNextItem( pNMTreeView->itemNew.hItem, TVGN_PARENT));
			if (pDoc->o_TOSPropertiesDialog.m_useTileTemplate)
				pDoc->m_copyedTileTMPLDialog.ShowWindow(SW_SHOW | SW_SHOWNOACTIVATE);			
		}
		else
		{			
			pDoc->m_aktivMTMResourceName = "";			
			pDoc->m_copyedTileTMPLDialog.ShowWindow(SW_HIDE);
		}

	if (l_data == 3010)
	{	
		pDoc->m_aktivASResourceName = pDoc->m_aktivResourceName;
		pDoc->m_ASCtrlDialog.ShowWindow(SW_HIDE);
		pDoc->m_ASPreviewDialog.ShowWindow(SW_HIDE);
	}
	else
		if (l_data == 3011)
		{	
			pDoc->m_aktivASResourceName = GetTreeCtrl().GetItemText(GetTreeCtrl().GetNextItem( pNMTreeView->itemNew.hItem, TVGN_PARENT));
			pDoc->m_ASCtrlDialog.ShowWindow(SW_SHOW | SW_SHOWNOACTIVATE);
			//pDoc->m_ASPreviewDialog.ShowWindow(SW_SHOW | SW_SHOWNOACTIVATE);	
		}
		else
		{			
			pDoc->m_aktivASResourceName = "";
			pDoc->m_ASCtrlDialog.ShowWindow(SW_HIDE);
			pDoc->m_ASPreviewDialog.ShowWindow(SW_HIDE);
		}


	if(pNMTreeView->itemNew.lParam == 0)
	{
		UpdateData(FALSE);
	}
	else
	{
		UpdateData(FALSE);
	}	
	pDoc->UpdateAllViews(NULL, NULL);

	*pResult = 0;
}


void CWorkSpaceView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{	
	// TODO: Add your specialized code here and/or call the base class
	// TODODEL verkar lite konstigt tror jag ska den vara h�r...
	switch(lHint)
	{
	case NULL :
	case e_UPDATE_WORK_SPACE_VIEW :
									 //Invalidate();	
									 break;
	default :						 break;
	}
}

void CWorkSpaceView::NewTilesListTreeArm(CString pResourceName)
{			
	newTreeArm(pResourceName, hTreeTiles, 1010);
}

HTREEITEM CWorkSpaceView::NewMTMTreeArm(CString pResourceName)
{
	return 	newTreeArm(pResourceName, hTreeMTM, 2010);
}

HTREEITEM CWorkSpaceView::NewASTreeArm(CString pResourceName)
{
	return 	newTreeArm(pResourceName, hTreeAS, 3010);
}


HTREEITEM CWorkSpaceView::newTreeArm(CString pResourceName, HTREEITEM p_treeItem, int p_treeType)
{
	// Skapar tileslistans tr�d gren.
	TV_INSERTSTRUCT TreeCtrlItem;		
	TreeCtrlItem.hParent = p_treeItem;
	TreeCtrlItem.item.mask = TVIF_TEXT | TVIF_PARAM;
	TreeCtrlItem.item.pszText = pResourceName.GetBuffer(80);
	TreeCtrlItem.item.lParam = p_treeType;
	HTREEITEM l_newTreeItem = GetTreeCtrl().InsertItem(&TreeCtrlItem);
	GetTreeCtrl().Expand(p_treeItem,TVE_EXPAND);

	// TODODEL
	// Markerar den nya MTM:en.
	//pDoc->m_aktivResourceName = newTileList.m_tileListFileName;
	//pDoc->m_aktivRoot = 1;
	// GetTreeCtrl().Select(TreeCtrlItem.item.hItem, TVGN_CARET);
	return l_newTreeItem;
}



void CWorkSpaceView::CreateTOSTree()
{
	// TODO: Add your specialized code here and/or call the base class

	TV_INSERTSTRUCT TreeCtrlItem;	
	
	TreeCtrlItem.hParent = TVI_ROOT;
	TreeCtrlItem.hInsertAfter = TVI_LAST;
	TreeCtrlItem.item.mask = TVIF_TEXT | TVIF_PARAM;


	TreeCtrlItem.item.pszText = "Tos File";
	TreeCtrlItem.item.lParam = 0;
	hTreeTop = GetTreeCtrl().InsertItem(&TreeCtrlItem);


	// Inserts the Tiles root
	TreeCtrlItem.hParent = hTreeTop;
	TreeCtrlItem.item.pszText = "Tiles";
	TreeCtrlItem.item.lParam = 1000;
	hTreeTiles = GetTreeCtrl().InsertItem(&TreeCtrlItem);

	// Inserts the Multi Tile Map root
	TreeCtrlItem.hParent = hTreeTop;
	TreeCtrlItem.item.pszText = "Multi Tile Maps";
	TreeCtrlItem.item.lParam = 2000;
	hTreeMTM = GetTreeCtrl().InsertItem(&TreeCtrlItem);

	// Inserts The Animated Sprites Root
	TreeCtrlItem.hParent = hTreeTop;
	TreeCtrlItem.item.pszText = "Animated Sprites";
	TreeCtrlItem.item.lParam = 3000;
	hTreeAS = GetTreeCtrl().InsertItem(&TreeCtrlItem);

    GetTreeCtrl().Expand(hTreeTop,TVE_EXPAND);
	GetTreeCtrl().Expand(hTreeTiles,TVE_EXPAND);
	GetTreeCtrl().Expand(hTreeMTM,TVE_EXPAND);
	GetTreeCtrl().Expand(hTreeAS,TVE_EXPAND);
}

void CWorkSpaceView::rebuildTreeArms()
{	
	CTOSDoc* poDoc = ((CTOSDoc*)m_pDocument);
 
	// Rebuild Tile List Arm
	CTypedPtrList<CObList,CTileList*>& tileList = poDoc->m_tileLists;
	POSITION pos = tileList.GetHeadPosition();
	
	while (pos != NULL)				
		NewTilesListTreeArm(tileList.GetNext(pos)->getResourceName());


	// Rebuild MTM List Arm
	CTypedPtrList<CObList,CMTM*>& MTM = poDoc->m_MTM;
	
	pos = MTM.GetHeadPosition();
	CMTM* pMTM;
	while (pos != NULL)				
	{
		pMTM = MTM.GetNext(pos);
		pMTM->setTreeLeaf( NewMTMTreeArm(pMTM->getResourceName()) );
		
		{
			const CTypedPtrList<CObList, CSTM*>& STM = pMTM->getSTM();
			POSITION STMPos = STM.GetHeadPosition();		
			while (STMPos != NULL)	
			{
				CString dd = STM.GetNext(STMPos)->getResourceName();
				newTreeArm(dd, pMTM->getTreeLeaf(), 2011);
			}
		} 
	}

	// Rebuild AnimatedSprite List Arm	
	CTypedPtrList<CObList, CAnimatedSprite*>& AS = poDoc->m_AS;		
	
	pos = AS.GetHeadPosition();
	CAnimatedSprite* pAS;
	CAnimatedSpriteEvent* pASE;
	CString tempResourceName;
	while (pos != NULL)				
	{
		pAS = AS.GetNext(pos);
		pAS->m_treeLeaf = NewASTreeArm(pAS->getResourceName());
		
		for(int eventCounter = 1; eventCounter <= pAS->getNumbersOfEvents(); eventCounter++)
		{
			pASE = pAS->getEvent(eventCounter);
			if (pASE != NULL)
			{
				tempResourceName = pASE->getResourceName();
			}
			else
			{
				tempResourceName = "Error";
			}

			newTreeArm(tempResourceName , pAS->m_treeLeaf, 3011);  
			
		}
		
	}

}


void CWorkSpaceView::showTileTMPLDialog(int p_flag)
{
	CTOSDoc* pDoc = GetDocument();
	
//	if ((pDoc->o_TOSPropertiesDialog.m_useTileTemplate == TRUE) || (p_flag == SW_SHOW))
//		pDoc->m_copyedTileTMPLDialog->ShowWindow(SW_SHOW | SW_SHOWNOACTIVATE);
//	else
//		pDoc->m_copyedTileTMPLDialog->ShowWindow(SW_HIDE);
}
