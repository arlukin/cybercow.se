// CAnimatedSprite.cpp: implementation of the CAnimatedSprite class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TOS.h"
#include "CAnimatedSprite.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

IMPLEMENT_SERIAL(CAnimatedSprite, CObject, 1)

CAnimatedSprite::CAnimatedSprite()
{
	Clear();	 
}

CAnimatedSprite::CAnimatedSprite(CString p_resourceName, int p_width, int p_height, HTREEITEM p_treeLeaf)
{	
	Clear();
	m_resourceName = p_resourceName;
	m_size.cx = p_width;
	m_size.cy = p_height;
	m_treeLeaf = p_treeLeaf;	
}

CAnimatedSprite::~CAnimatedSprite()
{
	Clear();
}

void CAnimatedSprite::insertASEvent(CString p_resourceName)
{
	CAnimatedSpriteEvent* l_event;
	l_event = new CAnimatedSpriteEvent(p_resourceName);		
	
	m_eventList.SetAtGrow(m_numbersOfEvents, l_event);	
	m_numbersOfEvents++;
} 

CAnimatedSpriteEvent* CAnimatedSprite::getEvent(CString p_resourceName)
{
	for(int eventCounter = 0; eventCounter < m_numbersOfEvents; eventCounter++)
	{
		if (m_eventList[eventCounter]->getResourceName() == p_resourceName)
		  return m_eventList[eventCounter];

	}
	return NULL;
}

CAnimatedSpriteEvent* CAnimatedSprite::getEvent(int p_event)
{
	if (isValidEvent(p_event))
	{
		return m_eventList[p_event-1];
	}
	else
		return NULL;
}


void CAnimatedSprite::Clear()
{
	m_eventList.RemoveAll();	
	m_resourceName.IsEmpty();
	m_size.cx = 0;
	m_size.cy = 0;
	m_numbersOfEvents = 0;
}

void CAnimatedSprite::Serialize(CArchive & ar)
{
	if (ar.IsStoring())
	{
		ar << m_numbersOfEvents;
		ar << m_resourceName;
		ar << m_size;		

		for (int i=0; i < m_numbersOfEvents; i++)
			m_eventList[i]->Serialize(ar);	

	}
	else
	{
		ar >> m_numbersOfEvents;
		ar >> m_resourceName;
		ar >> m_size;		

		for (int i=0; i < m_numbersOfEvents; i++)
		{			
			CAnimatedSpriteEvent* pASE = new CAnimatedSpriteEvent();
			pASE->Serialize(ar);							
			m_eventList.SetAtGrow(i, pASE);
		}	
	}	
}

bool CAnimatedSprite::isValidEvent(int p_event)
{
	if ((p_event <= m_numbersOfEvents) && (p_event > 0))
		return true;
	else
		return false;
}