// CTileTemplateDialog.cpp : implementation file
//

#include "stdafx.h"
#include "TOS.h"
#include "CTileTemplateDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTileTemplateDialog dialog


CTileTemplateDialog::CTileTemplateDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CTileTemplateDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTileTemplateDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CTileTemplateDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTileTemplateDialog)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTileTemplateDialog, CDialog)
	//{{AFX_MSG_MAP(CTileTemplateDialog)
	ON_WM_LBUTTONDOWN()
	ON_WM_PAINT()
	ON_WM_SHOWWINDOW()
	ON_WM_MOVE()
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTileTemplateDialog message handlers

void CTileTemplateDialog::OnLButtonDown(UINT nFlags, CPoint point) 
{			
	CRect m_screenRectClip;
	GetClientRect(&m_screenRectClip);
	CTileList* pTileList = m_tosDoc->getActiveTileList();
	CTileList* l_tileList = m_tosDoc->getActiveMTM()->getSTM(m_tosDoc->m_aktivResourceName)->getTileList();
	
	CClientDC pDC(this);		

	int tilesWidth  = (m_screenRectClip.Width()/l_tileList->getSize().cx);
	int tilesHeight = (m_screenRectClip.Height()/l_tileList->getSize().cy);

	int l_xPos = (m_markerRect.left / l_tileList->getSize().cx);		
	int l_yPos = (m_markerRect.top  / l_tileList->getSize().cy) ;
				
	insertTile(l_xPos, l_yPos, m_tosDoc->m_copyedTile);

	// draw the new tile.
	drawTileMarker(&pDC, point, CT_OLD);
	drawTile(&pDC, l_xPos, l_yPos);
	drawTileMarker(&pDC, point, CT_NEW);				

	
	CDialog::OnLButtonDown(nFlags, point);
}

BOOL CTileTemplateDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_markerRect.SetRectEmpty();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CTileTemplateDialog::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	if (m_tosDoc->getActiveMTM() != NULL)
	{
		CTileList* l_tileList;
		l_tileList = m_tosDoc->getActiveMTM()->getSTM(m_tosDoc->m_aktivResourceName)->getTileList();

		CRect rectClip;
		GetClientRect(&rectClip);
					
		for (int yCounter = 0; yCounter <= rectClip.Height(); yCounter += l_tileList->getSize().cy)
		{
			dc.MoveTo(0, yCounter);
			dc.LineTo(rectClip.Width(), yCounter);
		}
		for (int xCounter = 0; xCounter <= rectClip.Width(); xCounter += l_tileList->getSize().cx)
		{
			dc.MoveTo(xCounter, 0);
			dc.LineTo(xCounter, rectClip.Height());
		}

		drawMap(&dc);
		dc.InvertRect(m_markerRect);			
	}
	
	// Do not call CDialog::OnPaint() for painting messages
}

BOOL CTileTemplateDialog::Create(CTOSDoc* p_Doc,  UINT nIDTemplate, CWnd* pParentWnd /*= NULL*/ ) 
{	
	m_tosDoc = p_Doc;

	m_oldMapWidth  = -1;
	m_oldMapHeight = -1;

	return CDialog::Create(nIDTemplate, pParentWnd);
}



void CTileTemplateDialog::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	if (m_tosDoc->o_TOSPropertiesDialog.m_useTileTemplate)
	{
		CDialog::OnShowWindow(bShow, nStatus);		

		int p_tileWidth;
		int p_tileHeight;

		if (bShow)
		{
			p_tileWidth = m_tosDoc->getActiveMTM()->getSTM(m_tosDoc->m_aktivResourceName)->getTileList()->getSize().cy;
			p_tileHeight= m_tosDoc->getActiveMTM()->getSTM(m_tosDoc->m_aktivResourceName)->getTileList()->getSize().cx;
		}
		else 
		{
			p_tileWidth = 32;
			p_tileHeight= 32;
		}


		int l_newMapWidth  = m_tosDoc->o_TOSPropertiesDialog.m_tileTemplateDialogWidth;
		int l_newMapHeight = m_tosDoc->o_TOSPropertiesDialog.m_tileTemplateDialogHeight;
		int l_mapSize = (l_newMapWidth * l_newMapHeight)+50;
						

		if ((l_newMapWidth != m_oldMapWidth) || (l_newMapHeight != m_oldMapHeight))
		{
			m_oldMapWidth  = l_newMapWidth;
			m_oldMapHeight = l_newMapHeight;

			m_tosDoc->m_copyedTileMapWord.SetSize(l_mapSize);
			for (int l_counter = 0; l_counter < (l_mapSize); l_counter++)
				m_tosDoc->m_copyedTileMapWord[l_counter] = 0;
		};

		

		SetWindowPos(&wndBottom, 
					 m_tosDoc->m_tileTemplateDialogXPos,
					 m_tosDoc->m_tileTemplateDialogYPos,
					 (l_newMapWidth  * p_tileWidth)+7,
					 (l_newMapHeight * p_tileHeight)+23,
					  SW_SHOWNOACTIVATE
					);	
	}
	else
	{
		CDialog::OnShowWindow(FALSE, SW_PARENTCLOSING);
		SetWindowPos(&wndBottom, 
					 0,
					 0,
					 100,
					 100,
					 SW_SHOWNOACTIVATE | SW_HIDE
					);	
	}
} 

void CTileTemplateDialog::OnMove(int x, int y) 
{

	CDialog::OnMove(x, y);
	m_tosDoc->m_tileTemplateDialogXPos = x-3;
	m_tosDoc->m_tileTemplateDialogYPos = y-19;
	
	m_tosDoc->UpdateAllViews( NULL, NULL);	
}

void CTileTemplateDialog::insertTile(int p_xPos, int p_yPos, int p_tile)
{
	m_tosDoc->m_copyedTileMapWord[(p_yPos* m_tosDoc->o_TOSPropertiesDialog.m_tileTemplateDialogWidth)+p_xPos] = p_tile;							
}

void CTileTemplateDialog::drawTileMarker(CDC * pDC, CPoint point, tileMarkerFlag p_flags /*= CT_OLD_NEW*/)
{
	int tilesWidth  = m_tosDoc->getActiveMTM()->getSTM(m_tosDoc->m_aktivResourceName)->getTileList()->getSize().cy;
	int tilesHeight = m_tosDoc->getActiveMTM()->getSTM(m_tosDoc->m_aktivResourceName)->getTileList()->getSize().cx;

	if ((p_flags == CT_OLD) || (p_flags == CT_OLD_NEW))
	{
		// Destroy old marked spot.				
		pDC->InvertRect(m_markerRect);
	}

	if ((p_flags == CT_NEW) || (p_flags == CT_OLD_NEW))
	{

		// Destroy old marked spot.				
		m_markerRect.left   = ((point.x / tilesHeight)*tilesHeight);
		m_markerRect.top    = ((point.y / tilesWidth)*tilesWidth);
		m_markerRect.right  = m_markerRect.left + tilesHeight;
		m_markerRect.bottom = m_markerRect.top  + tilesHeight;

		// Draw marked spot.		
		pDC->InvertRect(m_markerRect);			
	}
}

void CTileTemplateDialog::drawTile(CDC * pDC, int p_xPos, int p_yPos)
{
	// R�kna ut hur m�nga tiles det f�r rum p� br�dden och h�jden.
	CRect rectClip;
	pDC->GetClipBox(&rectClip);
	int tilesWidth  = m_tosDoc->o_TOSPropertiesDialog.m_tileTemplateDialogWidth;
	int tilesHeight = m_tosDoc->o_TOSPropertiesDialog.m_tileTemplateDialogHeight;

	CTileList* l_tileList = m_tosDoc->getActiveMTM()->getSTM(m_tosDoc->m_aktivResourceName)->getTileList();
	int l_mapWidth = m_tosDoc->o_TOSPropertiesDialog.m_tileTemplateDialogWidth;

	if (l_tileList->IsTileExisting(m_tosDoc->m_copyedTileMapWord[(p_yPos*l_mapWidth)+p_xPos]))
		l_tileList->getTile(m_tosDoc->m_copyedTileMapWord[(p_yPos*l_mapWidth)+p_xPos])->DrawTile( pDC, p_xPos*l_tileList->getSize().cx, p_yPos*l_tileList->getSize().cy, l_tileList->getSize().cx, l_tileList->getSize().cy);
	else				
		l_tileList->DrawPsychoTile( pDC, p_xPos*l_tileList->getSize().cx, p_yPos*l_tileList->getSize().cy, l_tileList->getSize().cx, l_tileList->getSize().cy);
}


void CTileTemplateDialog::drawMap(CDC * pDC)
{
	int tilesWidth  = m_tosDoc->o_TOSPropertiesDialog.m_tileTemplateDialogWidth;
	int tilesHeight = m_tosDoc->o_TOSPropertiesDialog.m_tileTemplateDialogHeight;

	for (int yPos = 0; yPos < tilesHeight; yPos++)
		for (int xPos = 0; xPos < tilesWidth; xPos++)			
			drawTile(pDC, yPos, xPos);
}

void CTileTemplateDialog::OnMouseMove(UINT nFlags, CPoint point) 
{
	CClientDC pDC(this);		
	
	if (nFlags == MK_LBUTTON)
	{
		CRect m_screenRectClip;
		GetClientRect(&m_screenRectClip);
		CTileList* pTileList = m_tosDoc->getActiveTileList();
		CTileList* l_tileList = m_tosDoc->getActiveMTM()->getSTM(m_tosDoc->m_aktivResourceName)->getTileList();
		
		int tilesWidth  = (m_screenRectClip.Width()/l_tileList->getSize().cx);
		int tilesHeight = (m_screenRectClip.Height()/l_tileList->getSize().cy);

		int l_xPos = (m_markerRect.left / l_tileList->getSize().cx);		
		int l_yPos = (m_markerRect.top  / l_tileList->getSize().cy) ;
					
		insertTile(l_xPos, l_yPos, m_tosDoc->m_copyedTile);

		// draw the new tile.
		drawTileMarker(&pDC, point, CT_OLD);
		drawTile(&pDC, l_xPos, l_yPos);
		drawTileMarker(&pDC, point, CT_NEW);				
	}
	else
		drawTileMarker(&pDC, point);
	
	
	CDialog::OnMouseMove(nFlags, point);	
}
