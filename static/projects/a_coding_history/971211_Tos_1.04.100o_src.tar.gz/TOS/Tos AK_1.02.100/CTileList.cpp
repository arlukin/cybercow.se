// CTileList.cpp: implementation of the CTileList class.
//
//////////////////////////////////////////////////////////////////////


#include "stdafx.h"
#include "TOS.h"
#include "CTileList.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
// CTileList

IMPLEMENT_SERIAL(CTileList, CObject, 3)

CTileList::CTileList()
{    
	m_resourceName.Empty();
	m_maxNumOfTiles = 0;
	m_currentNumOfTiles = 0;
	m_size.cx  = 0;
	m_size.cy = 0;
}

CTileList::CTileList(CString p_fileName, int p_width, int p_height, int p_numOfTiles)
{	
	m_resourceName	 = p_fileName;
	m_size.cx  = p_width;
	m_size.cy = p_height;
	m_maxNumOfTiles = p_numOfTiles;
	m_currentNumOfTiles = 0;
	m_tileList.SetSize(m_maxNumOfTiles);
}

CTileList::~CTileList()
{
	DeleteContents();
}

void CTileList::Serialize(CArchive& ar)
{	
    if (ar.IsStoring())
    {
		ar << m_resourceName;
		ar << m_maxNumOfTiles;	
		ar << m_currentNumOfTiles;
		ar << m_size.cy;	
		ar << m_size.cx;	
		for (int i=0; i < m_currentNumOfTiles; i++)
			m_tileList[i]->Serialize(ar);	
    }
    else
    {
		ar >> m_resourceName;
		ar >> m_maxNumOfTiles;	
		ar >> m_currentNumOfTiles;		
		ar >> m_size.cy;	
		ar >> m_size.cx;	
		m_tileList.SetSize(m_maxNumOfTiles);

		for (int i=0; i < m_currentNumOfTiles; i++)
		{
			
			CTile* ptileItem = new CTile();
			ptileItem->Serialize(ar);							
			m_tileList.SetAtGrow(i, ptileItem);
		}	
    }	
}

BOOL CTileList::DrawTileList(CDC* pDC)
{
	if ((pDC != NULL) && (m_currentNumOfTiles != 0))
	{

		CRect rectClip;
		pDC->GetClipBox(&rectClip);		
		int yScrollPos	= pDC->GetViewportOrg().y*-1;					// In pixel..
		int xScrollPos	= pDC->GetViewportOrg().x*-1 ;					// In pixel..
		
		int width		= m_size.cx;									// Widht of a tile... in pixel...
		int height		= m_size.cy;									// Height of a tile... in pixel...
		int xPos		= 0;											// Start position in pixel,, where to draw the tile.....
		int yPos		= (yScrollPos - (yScrollPos % height));			// Start position in pixel,, where to draw the tile.....
		

		int maxTilesOnX = (rectClip.Width() /width );					// How man tiles in a view, horizontal...
		int maxTilesOnY = (rectClip.Height()/height);					// How man tiles in a view, vertical...
		int startTile	= (yPos / height * maxTilesOnX);				// Tile to start to draw...		

		int maxViewWidth  = maxTilesOnX*width+xPos;				//	Max postion to draw on... in pixel... horizontal...				
		int maxViewHeight = (maxTilesOnY*height)+yPos+(5*height);		// Max postion to draw on... in pixel... vertical... // ((5*height very strange))
		
		for (int i=startTile; i < m_currentNumOfTiles; i++)
		{			
			m_tileList[i]->DrawTile( pDC, xPos, yPos, width, height);
			xPos+= width;
			if (xPos == maxViewWidth)
			{ 
				xPos=0;
				yPos+=height;
			}
			
			// MFC vill tydligen att jag ska rita ut alltingen i DC:n och sedan v�ljer MFC ut vad den vill skriva till sk�rmen
			//if (yPos == maxViewHeight)
			//	break;					
		}
	}

	return 0;
}

void CTileList::DeleteContents()
{
	int i = 0;
	while (i < m_tileList.GetSize() )
	{
		delete m_tileList.GetAt( i++ );
	}	
	m_tileList.RemoveAll();
	m_currentNumOfTiles = 0;
}

bool CTileList::addTile(HBITMAP p_bitmap, HPALETTE p_palette)
{
	if (m_maxNumOfTiles != m_currentNumOfTiles)
	{	
		CTile* ptileItem = new CTile(p_bitmap, p_palette);
		
		m_tileList.SetAt(m_currentNumOfTiles, ptileItem);
		m_currentNumOfTiles++;
		return true;
	}
	return false;
}

bool CTileList::deleteTile(int p_tile)
{		 
	
	if (!IsTileExisting(p_tile)) 
	{
		MessageBox(NULL, "Tile doesn't exist", "Error", NULL);
		return false;
	}			

	m_currentNumOfTiles--;
	m_tileList.RemoveAt(p_tile);
	return true;	
}



bool CTileList::IsTileExisting(int p_tile)
{
	if ((p_tile < 0) || (p_tile >= m_currentNumOfTiles))
		return false;
	return true;
}

bool CTileList::DrawPsychoTile(CDC * pDC, int p_xPos, int p_yPos, int p_width, int p_height)
{
	CBitmap* l_bitmap;
	l_bitmap = new CBitmap;
	l_bitmap->LoadBitmap(IDB_NO_TILE);
	
	CDC dcMem ;

	dcMem.CreateCompatibleDC(pDC);
	dcMem.SelectObject(l_bitmap);

	return ( pDC->StretchBlt(p_xPos, p_yPos, p_width, p_height,
							 &dcMem, 0, 0, p_width, p_height, SRCCOPY
  		   )
		   ? 1 : 0);  		
}

CSize CTileList::getDocSize(CSize screenSize)
{
	int maxTilesOnX = (screenSize.cx /m_size.cx );		
	int maxTilesOnY = (getMaxNumOfTiles()/maxTilesOnX+1);

	CSize docSize;
	docSize.cx = maxTilesOnX*m_size.cx;
	docSize.cy = maxTilesOnY*m_size.cy;
	return docSize;
}