// TOSView.h : interface of the CTOSView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TOSVIEW_H__8DD1431B_011C_11D1_94E3_000000000000__INCLUDED_)
#define AFX_TOSVIEW_H__8DD1431B_011C_11D1_94E3_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CTOSView : public CScrollView
{
protected: // create from serialization only
	CTOSView();
	DECLARE_DYNCREATE(CTOSView)

// Attributes
public:
	CTOSDoc* GetDocument();

// Implementation
public:
	void pasteCopyedTile(CPoint point);
	
	bool deleteTile(CPoint point);
	void drawTiles(CDC* pDC);

	void drawTileMarker(CDC * pDC, CPoint point, tileMarkerFlag p_flag = CT_OLD_NEW);

	LRESULT OnDoRealize(WPARAM wParam, LPARAM);	
	virtual ~CTOSView();

protected:
	CRect m_screenRectClip;
	CRect m_markerRect;


public:
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

// Operations
public:
	void drawAnimatedSprite(CDC* pDC, CTOSDoc* pDoc);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTOSView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);	
	virtual void OnActivateView(BOOL bActivate, CScrollView* pActivateView, CScrollView* pDeactiveView);
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	virtual BOOL OnScrollBy(CSize sizeScroll, BOOL bDoScroll = TRUE);
	//}}AFX_VIRTUAL

// Generated message map functions
protected:
	//{{AFX_MSG(CTOSView)
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in TOSView.cpp
inline CTOSDoc* CTOSView::GetDocument()
   { return (CTOSDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TOSVIEW_H__8DD1431B_011C_11D1_94E3_000000000000__INCLUDED_)
