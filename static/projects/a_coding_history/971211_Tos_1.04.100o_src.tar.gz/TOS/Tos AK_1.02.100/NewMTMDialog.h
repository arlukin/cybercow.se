#if !defined(AFX_NEWMTMDIALOG_H__94FD0085_2AD2_11D1_9535_000000000000__INCLUDED_)
#define AFX_NEWMTMDIALOG_H__94FD0085_2AD2_11D1_9535_000000000000__INCLUDED_

#include "TOSDoc.h"	// Added by ClassView
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// NewMTMDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CNewMTMDialog dialog

class CNewMTMDialog : public CDialog
{
// Construction
public:

	CNewMTMDialog(CTOSDoc* pDoc, CWnd* pParent = NULL);   // standard constructor	

	void CreateTileListTree();
	void rebuildTileList();
	void NewTilesListTreeArm(CString pResourceName);

protected:
	CTOSDoc* m_tosDoc;
	HTREEITEM hTreeTiles;
	CString m_aktivTileListName;							// Det namn som st�r i tr�det. 
public:	
	
	CString& getTileList()
	{ return m_aktivTileListName;};

	

// Dialog Data
	//{{AFX_DATA(CNewMTMDialog)
	enum { IDD = IDD_NEW_MTM };
	CTreeCtrl	m_tileListResourceTree;	
	int		m_MTMWidth;
	int		m_MTMHeight;
	BOOL	m_tileMaxNumOfTiles;
	CString	m_resourceName;
	CString	m_STMResourceName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNewMTMDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support	
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CNewMTMDialog)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangedTree1(NMHDR* pNMHDR, LRESULT* pResult);
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NEWMTMDIALOG_H__94FD0085_2AD2_11D1_9535_000000000000__INCLUDED_)
