// CAnimatedSpriteEvent.cpp: implementation of the CAnimatedSpriteEvent class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TOS.h"
#include "CAnimatedSpriteEvent.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CAnimatedSpriteEvent::CAnimatedSpriteEvent()
{
	clear();
}

IMPLEMENT_SERIAL(CAnimatedSpriteEvent, CObject, 1)

CAnimatedSpriteEvent::CAnimatedSpriteEvent(CString p_resourceName)
{
	clear();
	m_resourceName = p_resourceName;
}

CAnimatedSpriteEvent::~CAnimatedSpriteEvent()
{
	clear();
}

bool CAnimatedSpriteEvent::replaceFrame(HBITMAP p_bitmap, HPALETTE p_palette)
{
	if (isValidFrame(m_crntFrame))
	{
		if (m_frameList[m_crntFrame-1] != NULL)
		{
			delete m_frameList[m_crntFrame-1];
			m_frameList[m_crntFrame-1] = NULL;
		}

		CDib* pDib = new CTile(p_bitmap, p_palette);
		
		m_frameList[m_crntFrame-1]= pDib;

		return true;
	}
	return false;
}

bool CAnimatedSpriteEvent::addFrame ()
{	
	m_frameList.SetAtGrow(m_maxFrames, NULL);

	m_crntFrame = ++m_maxFrames;	
	return true;
}

void CAnimatedSpriteEvent::drawActiveFrame(CDC * pDC)
{
	if (isValidFrame(m_crntFrame))
	{
		if (m_frameList[m_crntFrame-1] != NULL)
			m_frameList[m_crntFrame-1]->paint(pDC, 0, 0);
	}
}

void CAnimatedSpriteEvent::drawFrame(CDC * pDC, int p_frame)
{
	if (isValidFrame(p_frame))
	{
		if (m_frameList[p_frame-1] != NULL)
			m_frameList[p_frame-1]->paint(pDC, 0, 0);
	}
}

int CAnimatedSpriteEvent::deleteFrame(int p_frame)
{	
	if (isValidFrame(p_frame))
	{
		m_frameList.RemoveAt(p_frame-1);
		m_maxFrames--;
	}
	return m_maxFrames;
}

void CAnimatedSpriteEvent::Serialize(CArchive & ar)
{
	if (ar.IsStoring())
	{		
		ar << m_crntFrame;
		ar << m_maxFrames;
		ar << m_resourceName;
		ar << m_time;
		for (int i=0; i < m_maxFrames; i++)
			m_frameList[i]->Serialize(ar);	

	}
	else
	{
		ar >> m_crntFrame;
		ar >> m_maxFrames;
		ar >> m_resourceName;
		ar >> m_time;

		for (int i=0; i < m_maxFrames; i++)
		{			
			CDib* pDib = new CDib();
			pDib->Serialize(ar);							
			m_frameList.SetAtGrow(i, pDib);
		}	
	}	
}

void CAnimatedSpriteEvent::clear()
{
	m_crntFrame = 0;
	m_maxFrames = 0;
	m_time		= 200;
	m_resourceName.Empty();	
	m_frameList.RemoveAll();
}


CDib* CAnimatedSpriteEvent::getFrame(int p_frame)
{
	if (isValidFrame(p_frame))
	{
		return m_frameList[p_frame-1];
	}
	else
		return NULL;
}

bool CAnimatedSpriteEvent::setCrntFrame(int p_frame)
{
	// TODO: Add your control notification handler code here
	if ((isValidFrame(p_frame)) || (p_frame == 0))
	{
		m_crntFrame = p_frame;
		return true;
	}
	return false;
}

bool CAnimatedSpriteEvent::isValidFrame(int p_frame)
{
	if ((p_frame > 0) && (p_frame <= m_maxFrames))
		return true;
	else
		return false;
}

