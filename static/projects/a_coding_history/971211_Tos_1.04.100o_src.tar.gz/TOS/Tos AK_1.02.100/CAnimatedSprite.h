// CAnimatedSprite.h: interface for the CAnimatedSprite class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CANIMATEDSPRITE_H__3AA306EC_2F84_11D1_953B_000000000000__INCLUDED_)
#define AFX_CANIMATEDSPRITE_H__3AA306EC_2F84_11D1_953B_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CAnimatedSprite : public CObject  
{
public:

	HTREEITEM m_treeLeaf;
	virtual void Serialize(CArchive& ar);				 

	void Clear();
	void insertASEvent(CString p_resourceName);
	
	CAnimatedSprite(CString p_resourceName, int p_width, int p_height, HTREEITEM p_treeLeaf);

	CAnimatedSprite();
	DECLARE_SERIAL(CAnimatedSprite)
	virtual ~CAnimatedSprite();
	
	
	bool isValidEvent(int p_event);

	CSize& getSize()							{	return m_size;				}
	CString& getResourceName()					{	return m_resourceName;		}
	int getNumbersOfEvents()					{	return m_numbersOfEvents;	} 
	CAnimatedSpriteEvent* getEvent(int p_event);
	CAnimatedSpriteEvent* getEvent(CString p_resourceName);

protected:
	//CMap<int, int, CAnimatedSpriteEvent*, CAnimatedSpriteEvent*&>  m_event;
	CArray<CAnimatedSpriteEvent*, CAnimatedSpriteEvent*> m_eventList;

	CString m_resourceName;
	CSize m_size;
	int m_numbersOfEvents;									// Means m_numberOfEvents == 0; no event in the eventlist
															// Means m_numberOfEvents == 1; m_eventList[1];
};

#endif // !defined(AFX_CANIMATEDSPRITE_H__3AA306EC_2F84_11D1_953B_000000000000__INCLUDED_)
