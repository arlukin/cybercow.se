// CTileList.h: interface for the CTileList class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CTileList_H__3AA306EC_2F84_11D1_953B_000000000000__INCLUDED_)
#define AFX_CTileList_H__3AA306EC_2F84_11D1_953B_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CTileList : public CObject
{
public:
    CTileList();
	CTileList(CString p_fileName, int p_width,int p_height, int p_numOfTiles);
    DECLARE_SERIAL(CTileList)

	 ~CTileList();	

// Operations
public:
	CSize getDocSize(CSize screenSize);
    BOOL DrawTileList(CDC* pDC);
	bool  DrawPsychoTile(CDC* pDC, int p_xPos, int p_yPos, int p_width, int p_height);

	bool deleteTile(int p_tile);
	bool addTile(HBITMAP p_bitmap, HPALETTE p_palette);	

	void DeleteContents();	
    virtual void Serialize(CArchive& ar);
	
	bool IsTileExisting(int p_tile);

	int		getMaxNumOfTiles()		{	return m_maxNumOfTiles;		}
	int		getCurrentNumOfTiles()	{	return m_currentNumOfTiles;	}
	CSize	getSize()				{	return m_size;				}
	CString getResourceName()		{	return m_resourceName;		}
	CTile*  getTile(int p_tile)		{	return m_tileList[p_tile]; };

// Attributes
protected:		
	int   m_maxNumOfTiles;		
	int   m_currentNumOfTiles;
	CSize m_size;					// Height and Width of a tile
	CString m_resourceName;

	//CTypedPtrList<CObList, CTile*> m_tileList;		// Tiles listan
	CArray<CTile*, CTile*>  m_tileList;
};
#endif // !defined(AFX_CTileList_H__3AA306EC_2F84_11D1_953B_000000000000__INCLUDED_)
