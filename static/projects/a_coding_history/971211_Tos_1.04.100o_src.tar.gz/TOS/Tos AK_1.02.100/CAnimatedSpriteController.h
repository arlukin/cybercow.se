#if !defined(AFX_CANIMATEDSPRITECONTROLLER_H__06200BE5_3046_11D1_953C_000000000000__INCLUDED_)
#define AFX_CANIMATEDSPRITECONTROLLER_H__06200BE5_3046_11D1_953C_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CTOSDoc;


// CAnimatedSpriteController.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAnimatedSpriteController dialog

class CAnimatedSpriteController : public CDialog
{
// Construction
public:		
	void setData(ASControllerData p_ASCD);
	CTOSDoc* m_tosDoc;
	CAnimatedSpriteController(CWnd* pParent = NULL);   // standard constructor

protected:
// Dialog Data
	//{{AFX_DATA(CAnimatedSpriteController)
	enum { IDD = IDD_ANIMATED_SPRITE_CONTROLLER };
	CSliderCtrl	m_frameSlider;
	int		m_currentFrame;
	int		m_height;
	int		m_maxFrames;
	int		m_width;
	int		m_time;
	//}}AFX_DATA
public:
	CAnimatedSpriteEvent* getEvent();


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAnimatedSpriteController)
	public:
	virtual BOOL Create(CTOSDoc* p_Doc,  UINT nIDTemplate, CWnd* pParentWnd = NULL );
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void updateASEvent(int m_currentFrame);
	// Generated message map functions
	//{{AFX_MSG(CAnimatedSpriteController)
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnMove(int x, int y);
	afx_msg void OnButtonFirst();
	afx_msg void OnButtonLast();
	afx_msg void OnButtonNext();
	afx_msg void OnButtonPlay();
	afx_msg void OnButtonPrevious();
	afx_msg void OnButtonStop();
	afx_msg void OnButtonDelete();
	afx_msg void OnButtonAdd();
	afx_msg void OnKillfocusEditTime();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnChangeEditTime();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CANIMATEDSPRITECONTROLLER_H__06200BE5_3046_11D1_953C_000000000000__INCLUDED_)
