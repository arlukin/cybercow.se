#if !defined(AFX_CANIMATEDSPRITEPREVIEWDIALOG_H__E736B09D_40EF_11D1_9548_000000000000__INCLUDED_)
#define AFX_CANIMATEDSPRITEPREVIEWDIALOG_H__E736B09D_40EF_11D1_9548_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// CAnimatedSpritePreviewDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAnimatedSpritePreviewDialog dialog

class CAnimatedSpritePreviewDialog : public CDialog
{
// Construction
public:
	void setRightSize();

	CAnimatedSpritePreviewDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CAnimatedSpritePreviewDialog)
	enum { IDD = IDD_ANIMATED_SPRITE_PREVIEW };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAnimatedSpritePreviewDialog)
	public:
	virtual BOOL Create(CTOSDoc* p_Doc,  UINT nIDTemplate, CWnd* pParentWnd = NULL);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CTOSDoc* m_tosDoc;
	int m_maxFrames;
	int m_crntFrame;

	// Generated message map functions
	//{{AFX_MSG(CAnimatedSpritePreviewDialog)
	afx_msg void OnMove(int x, int y);
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnTimer(UINT nIDEvent);	
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CANIMATEDSPRITEPREVIEWDIALOG_H__E736B09D_40EF_11D1_9548_000000000000__INCLUDED_)
