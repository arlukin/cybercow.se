// CNewASDialog.cpp : implementation file
//

#include "stdafx.h"
#include "TOS.h"
#include "CNewASDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNewASDialog dialog


CNewASDialog::CNewASDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CNewASDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNewASDialog)
	m_crawlEvent = FALSE;
	m_eastEvent = FALSE;
	m_jumpEvent = FALSE;
	m_northEvent = FALSE;
	m_northEastEvent = FALSE;
	m_northWestEvent = FALSE;
	m_shot1Event = FALSE;
	m_shot2Event = FALSE;
	m_southEvent = FALSE;
	m_southEastEvent = FALSE;
	m_southWestEvent = FALSE;
	m_westEvent = FALSE;
	m_resourceName = _T("AnimatedSprite01");
	m_width = 32;
	m_height = 32;
	//}}AFX_DATA_INIT
}


void CNewASDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNewASDialog)
	DDX_Check(pDX, IDC_CHECK_CRAWL, m_crawlEvent);
	DDX_Check(pDX, IDC_CHECK_EAST, m_eastEvent);
	DDX_Check(pDX, IDC_CHECK_JUMP, m_jumpEvent);
	DDX_Check(pDX, IDC_CHECK_NORTH, m_northEvent);
	DDX_Check(pDX, IDC_CHECK_NORTH_EAST, m_northEastEvent);
	DDX_Check(pDX, IDC_CHECK_NORTH_WEST, m_northWestEvent);
	DDX_Check(pDX, IDC_CHECK_SHOT_1, m_shot1Event);
	DDX_Check(pDX, IDC_CHECK_SHOT_2, m_shot2Event);
	DDX_Check(pDX, IDC_CHECK_SOUTH, m_southEvent);
	DDX_Check(pDX, IDC_CHECK_SOUTH_EAST, m_southEastEvent);
	DDX_Check(pDX, IDC_CHECK_SOUTH_WEST, m_southWestEvent);
	DDX_Check(pDX, IDC_CHECK_WEST, m_westEvent);
	DDX_Text(pDX, IDC_EDIT_RESOURCE_NAME, m_resourceName);
	DDX_Text(pDX, IDC_EDIT_WIDTH, m_width);
	DDV_MinMaxInt(pDX, m_width, 1, 2056);
	DDX_Text(pDX, IDC_EDIT_HEIGHT, m_height);
	DDV_MinMaxInt(pDX, m_height, 1, 2056);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNewASDialog, CDialog)
	//{{AFX_MSG_MAP(CNewASDialog)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNewASDialog message handlers
