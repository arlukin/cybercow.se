// CTOSPropertiesDialog.cpp : implementation file
//

#include "stdafx.h"
#include "TOS.h"
#include "CTOSPropertiesDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTOSPropertiesDialog dialog


CTOSPropertiesDialog::CTOSPropertiesDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CTOSPropertiesDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTOSPropertiesDialog)
	m_cutFromGrid = FALSE;
	m_useTileTemplate = FALSE;
	m_tileTemplateDialogHeight = 3;
	m_tileTemplateDialogWidth = 3;
	//}}AFX_DATA_INIT
}


void CTOSPropertiesDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTOSPropertiesDialog)
	DDX_Check(pDX, IDC_CHECK_CUT_FROM_GRID, m_cutFromGrid);
	DDX_Check(pDX, IDC_CHECK_TILE_TEMPLATE, m_useTileTemplate);
	DDX_Text(pDX, IDC_EDIT_TILE_TEMPLATE_HEIGHT, m_tileTemplateDialogHeight);
	DDV_MinMaxInt(pDX, m_tileTemplateDialogHeight, 1, 256);
	DDX_Text(pDX, IDC_EDIT_TILE_TEMPLATE_WIDTH, m_tileTemplateDialogWidth);
	DDV_MinMaxInt(pDX, m_tileTemplateDialogWidth, 1, 256);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTOSPropertiesDialog, CDialog)
	//{{AFX_MSG_MAP(CTOSPropertiesDialog)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTOSPropertiesDialog message handlers
