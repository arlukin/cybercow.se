// cNewSTMDialog.cpp : implementation file
//

#include "stdafx.h"
#include "TOS.h"
#include "cNewSTMDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNewSTMDialog dialog


CNewSTMDialog::CNewSTMDialog(CTOSDoc* pDoc, CWnd* pParent /*=NULL*/)
	: CDialog(CNewSTMDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNewSTMDialog)
	m_tileMaxNumOfTiles = pDoc->getActiveMTM()->get256Tiles();
	m_resourceName = _T("Layer01");
	m_STMHeight = pDoc->getActiveMTM()->getSize().cx;
	m_STMWidth = pDoc->getActiveMTM()->getSize().cy;
	m_tosDoc = pDoc;
	//}}AFX_DATA_INIT
}


void CNewSTMDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNewSTMDialog)
	DDX_Control(pDX, IDC_TREE_TILES_LIST_STM, m_tileListResourceTree);
	DDX_Check(pDX, IDC_CHECK_MAX_NUM_OF_TILES_STM, m_tileMaxNumOfTiles);
	DDX_Text(pDX, IDC_EDIT_RESOURCE_NAME_STM, m_resourceName);
	DDX_Text(pDX, IDC_EDIT_TILELIST_HEIGHT_STM, m_STMHeight);
	DDX_Text(pDX, IDC_EDIT_TILELIST_WIDTH_STM, m_STMWidth);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNewSTMDialog, CDialog)
	//{{AFX_MSG_MAP(CNewSTMDialog)
	ON_NOTIFY(TVN_SELCHANGED, IDC_TREE_TILES_LIST_STM, OnSelchangedTreeTilesListStm)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNewSTMDialog message handlers

void CNewSTMDialog::OnSelchangedTreeTilesListStm(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;

	m_aktivTileListName = m_tileListResourceTree.GetItemText(pNMTreeView->itemNew.hItem);				
	
	*pResult = 0;
}

BOOL CNewSTMDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	if (hTreeTiles != NULL)	
	   m_tileListResourceTree.DeleteAllItems();	

	CreateTileListTree();	
	RebuildTileListTree();
	

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE


}

void CNewSTMDialog::OnOK() 
{
	// TODO: Add extra validation here
	
	CDialog::OnOK();
}

void CNewSTMDialog::CreateTileListTree()
{
	// TODO: Add your specialized code here and/or call the base class

	TV_INSERTSTRUCT TreeCtrlItem;	
	
	TreeCtrlItem.hParent = TVI_ROOT;
	TreeCtrlItem.hInsertAfter = TVI_LAST;
	TreeCtrlItem.item.mask = TVIF_TEXT | TVIF_PARAM;


	TreeCtrlItem.item.pszText = "Tiles";
	TreeCtrlItem.item.lParam = 1000;
	hTreeTiles = m_tileListResourceTree.InsertItem(&TreeCtrlItem);

	m_tileListResourceTree.Expand(hTreeTiles,TVE_EXPAND);
}

void CNewSTMDialog::RebuildTileListTree()
{
	CTypedPtrList<CObList,CTileList*>& tileList = m_tosDoc->m_tileLists;
	POSITION pos = tileList.GetHeadPosition();
	while (pos != NULL)	
		NewTilesListTreeArm(tileList.GetNext(pos)->getResourceName());
	
	m_tileListResourceTree.Expand(hTreeTiles,TVE_EXPAND);
}

void CNewSTMDialog::NewTilesListTreeArm(CString pResourceName)
{
	// Skapar tileslistans tr�d gren.
	TV_INSERTSTRUCT TreeCtrlItem;		
	TreeCtrlItem.hParent = hTreeTiles;
	TreeCtrlItem.item.mask = TVIF_TEXT | TVIF_PARAM;
	TreeCtrlItem.item.pszText = pResourceName.GetBuffer(80);
	TreeCtrlItem.item.lParam = 1010;
	m_tileListResourceTree.InsertItem(&TreeCtrlItem);	
	// Expanderar tiles grenen
}
