// CAnimatedSpriteEvent.h: interface for the CAnimatedSpriteEvent class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CANIMATEDSPRITEEVENT_H__06200BE6_3046_11D1_953C_000000000000__INCLUDED_)
#define AFX_CANIMATEDSPRITEEVENT_H__06200BE6_3046_11D1_953C_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CAnimatedSpriteEvent : public CObject  
{
public:	
	void drawFrame(CDC*pDC, int p_frame);

	DECLARE_SERIAL(CAnimatedSpriteEvent)
	CAnimatedSpriteEvent();
	CAnimatedSpriteEvent(CString p_resourceName);

	virtual ~CAnimatedSpriteEvent();		
	virtual void Serialize(CArchive & ar);	

	void drawActiveFrame(CDC * pDC);

	bool addFrame();
	bool replaceFrame(HBITMAP p_bitmap, HPALETTE p_palette);
	int  deleteFrame(int p_frame);
	void clear();	

	bool isValidFrame(int p_frame);

	CDib* getFrame(int p_frame);
	CString& getResourceName()		{	return m_resourceName;	};
	int  getCrntFrame()				{	return m_crntFrame;		};
	bool setCrntFrame(int p_frame);
	int  getMaxFrames()				{	return m_maxFrames;		};
	int  getTime()					{	return m_time;			};
	void setTime(int p_time)		{	m_time = p_time;		};	
	
protected:
	CArray<CDib*, CDib*> m_frameList;
	CString m_resourceName;
	int m_crntFrame;								// m_crntFrame == 0 means no frames in the list
													// m_crntFrame == 1 means one frame in the list and m_frameList[0];
	int m_maxFrames;
	int m_time;
	

};

#endif // !defined(AFX_CANIMATEDSPRITEEVENT_H__06200BE6_3046_11D1_953C_000000000000__INCLUDED_)
