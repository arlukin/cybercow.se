// TOSView.cpp : implementation of the CTOSView class
//

#include "stdafx.h"
#include "TOS.h"

#include "TOSDoc.h"
#include "TOSView.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTOSView

IMPLEMENT_DYNCREATE(CTOSView, CScrollView)

BEGIN_MESSAGE_MAP(CTOSView, CScrollView)	
	//{{AFX_MSG_MAP(CTOSView)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_KEYDOWN()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_MESSAGE(WM_DOREALIZE, OnDoRealize)
	ON_WM_HSCROLL()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTOSView construction/destruction

CTOSView::CTOSView()
{
	// TODO: add construction code here
}

CTOSView::~CTOSView()
{
}

BOOL CTOSView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CScrollView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTOSView drawing

void CTOSView::OnDraw(CDC* pDC)
{		
	CTOSDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	pDC->GetClipBox(&m_screenRectClip);

	// Vilken typ av resource ska ritas ut p� sk�rmen... Efter valet i TreeView:n....
	switch (pDoc->m_aktivRoot)
	{
	case 1000 : 
		drawTiles(pDC);
		break;

	case 1010 : // Draw the list of tiles.
		drawTiles(pDC);
		pDC->InvertRect(m_markerRect);			
		break;

	case 2000: 
		pDC->DrawText("No MTM selected", CRect(0, 0, 400, 20), DT_CENTER);
		break;

	case 2010: // Draw the Multi Tile Map
		//pDoc->getActiveMTM()->drawMTM(pDC);
		break;

	case 2011: // Draw the Multi Tile Map Layers 
		if (pDoc->getActiveMTM() != NULL)
		{
			pDoc->getActiveMTM()->drawSTM(pDC, pDoc->m_aktivResourceName);
			pDC->InvertRect(m_markerRect);						
		}
		break;

	case 3000:	
		pDC->DrawText("No Animated Sprite seleted", CRect(0, 0, 400, 20), DT_CENTER);
		break;

	case 3010:	// Draw sprite information
		pDC->DrawText("Soon you will see sprite information here.", CRect(0, 0, 400, 20), DT_CENTER);
		break;

	case 3011:	// Draw the Sprite events
			drawAnimatedSprite(pDC, pDoc);
		break;

	}
}

/////////////////////////////////////////////////////////////////////////////
// CTOSView printing

BOOL CTOSView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CTOSView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CTOSView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CTOSView diagnostics

#ifdef _DEBUG
void CTOSView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CTOSView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CTOSDoc* CTOSView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTOSDoc)));
	return (CTOSDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTOSView message handlers


void CTOSView::drawTiles(CDC * pDC)
{
	CTOSDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// Koll om det finns n�got att rita ut...
	if (pDoc->m_aktivResourceName == "")
	{
		pDC->DrawText("No Tile list selected", CRect(0, 0, 400, 20), DT_CENTER);
		return;
	}
	else
	{
		// Draw the list of tiles.
		pDoc->getActiveTileList()->DrawTileList(pDC);	
	}

}

void CTOSView::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CTOSDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	CClientDC dc(this);
	OnPrepareDC(&dc);
	
	// Vilken typ av resource ska anv�ndas... Efter valet i TreeView:n....
	switch (pDoc->m_aktivRoot)
	{
	case 1010: // Tiles List
			drawTileMarker(&dc, point);
		break;

	case 2011: // Multi Tile Map		
		
		if (nFlags == MK_LBUTTON)
			pasteCopyedTile(point);
		else
			drawTileMarker(&dc, point);
		break;

	case 3011:	// Sprite events
		break;
	}

	CScrollView::OnMouseMove(nFlags, point);
}

void CTOSView::OnInitialUpdate() 
{
	ASSERT(GetDocument() != NULL);
	SetScrollSizes( MM_TEXT, GetDocument()->m_TosViewSize);
	m_markerRect.SetRectEmpty();
	CScrollView::OnInitialUpdate();	
}

void CTOSView::OnLButtonDblClk(UINT nFlags, CPoint point) 
{	
	CScrollView::OnLButtonDblClk(nFlags, point);
}

void CTOSView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CTOSDoc* pDoc = GetDocument();	
 
		
	switch (pDoc->m_aktivRoot)
	{

	case 1010 : // Delete on marked tile
		deleteTile(point);
		break;

	case 2011: 
		pasteCopyedTile(point);
		break;

	case 3011:	
		// deleteAnimatedSprite()
		break;
	}	
	
	CScrollView::OnLButtonDown(nFlags, point);
}

void CTOSView::OnLButtonUp(UINT nFlags, CPoint point) 
{

	
	CScrollView::OnLButtonUp(nFlags, point);
}



bool CTOSView::deleteTile(CPoint point)
{
	CTOSDoc* pDoc = GetDocument();	
	
	if (pDoc->m_aktivResourceName == "")
	{		
		MessageBox("No tiles to delete.", "Error", NULL);
		return false;
	}
	else
	{	
		int tilesWidth  = (m_screenRectClip.Width()/pDoc->getActiveTileList()->getSize().cx);
		int tilesHeight = (m_screenRectClip.Height()/pDoc->getActiveTileList()->getSize().cy);

		int p_tileNumber = (m_markerRect.left / pDoc->getActiveTileList()->getSize().cx) +		
				  		   ((m_markerRect.top  / pDoc->getActiveTileList()->getSize().cy) * tilesWidth);

		if (p_tileNumber < pDoc->getActiveTileList()->getCurrentNumOfTiles())
		{
			if (!pDoc->getActiveTileList()->deleteTile(p_tileNumber))
				return false;			
			pDoc->SetModifiedFlag();
		}
		else
		{
			MessageBox("No tile to delete on this place.", "Error", NULL);
			return false;
		}
			

		pDoc->UpdateAllViews( NULL, e_UPDATE_TOS_VIEW, NULL); 		

		CClientDC pDC(this);
		OnPrepareDC(&pDC);		
		drawTileMarker(&pDC, point, CT_NEW);
	}
	return true;
}

void CTOSView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	
	CScrollView::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CTOSView::OnActivateView(BOOL bActivate, CScrollView* pActivateView, CScrollView* pDeactiveView) 
{
	CScrollView::OnActivateView(bActivate, pActivateView, pDeactiveView);
	
	if (bActivate)
	{
		ASSERT(pActivateView == this);
		OnDoRealize((WPARAM)m_hWnd, 0);   // same as SendMessage(WM_DOREALIZE);
	}	
}

LRESULT CTOSView::OnDoRealize(WPARAM wParam, LPARAM)
{
	ASSERT(wParam != NULL);
	CTOSDoc* pDoc = GetDocument();

	if (pDoc->o_cutFromViewDIB == NULL)
		return 0L;  // no cutFromViewDIB exist.

	if (pDoc->o_cutFromViewDIB->isBitmap())
		return 0L;  // must be a new document

	CPalette* pPal = new CPalette;
	pPal->Attach(pDoc->getActiveTileList()->getTile(0)->getHPALETTE());

	if (pPal != NULL)
	{
		CMainFrame* pAppFrame = (CMainFrame*) AfxGetApp()->m_pMainWnd;
		ASSERT_KINDOF(CMainFrame, pAppFrame);

		CClientDC appDC(pAppFrame);
		// All views but one should be a background palette.
		// wParam contains a handle to the active view, so the SelectPalette
		// bForceBackground flag is FALSE only if wParam == m_hWnd (this view)
		CPalette* oldPalette = appDC.SelectPalette(pPal, ((HWND)wParam) != m_hWnd);

		if (oldPalette != NULL)
		{
			UINT nColorsChanged = appDC.RealizePalette();
			if (nColorsChanged > 0)
				pDoc->UpdateAllViews(NULL, NULL);
			appDC.SelectPalette(oldPalette, TRUE);
		}
		else
		{
			TRACE0("\tSelectPalette failed in CDibView::OnPaletteChanged\n");
		}
	}

	return 0L;
}

void CTOSView::drawTileMarker(CDC * pDC, CPoint point, tileMarkerFlag p_flags /*= CT_OLD_NEW*/)
{
	pDC->DPtoLP(&point);
	CTOSDoc* pDoc = GetDocument();

	// drawTilemarker for tileList mode
	if (pDoc->getActiveTileList() != NULL)
	{
		if ((p_flags == CT_OLD) || (p_flags == CT_OLD_NEW))
		{
			// Destroy old marked spot.				
			pDC->InvertRect(m_markerRect);
		}

		if ((p_flags == CT_NEW) || (p_flags == CT_OLD_NEW))
		{
				
			m_markerRect.left   = ((point.x / pDoc->getActiveTileList()->getSize().cy)*pDoc->getActiveTileList()->getSize().cy);
			m_markerRect.top    = ((point.y / pDoc->getActiveTileList()->getSize().cx )*pDoc->getActiveTileList()->getSize().cx);
			m_markerRect.right  = m_markerRect.left + pDoc->getActiveTileList()->getSize().cy;
			m_markerRect.bottom = m_markerRect.top  + pDoc->getActiveTileList()->getSize().cx;

			// Draw marked spot.		
			pDC->InvertRect(m_markerRect);			
		}
	} 

	// drawTilemarker for MTM mode
	if (pDoc->getActiveMTM() != NULL)
	{
		if ((p_flags == CT_OLD) || (p_flags == CT_OLD_NEW))
		{
			// Destroy old marked spot.				
			pDC->InvertRect(m_markerRect);
		}


		if ((p_flags == CT_NEW) || (p_flags == CT_OLD_NEW))
		{
			CTileList* l_tileList = pDoc->getActiveMTM()->getSTM(pDoc->m_aktivResourceName)->getTileList();					
				
			m_markerRect.left   = ((point.x / l_tileList->getSize().cy) * l_tileList->getSize().cy);
			m_markerRect.top    = ((point.y / l_tileList->getSize().cx ) * l_tileList->getSize().cx);


			if (pDoc->o_TOSPropertiesDialog.m_useTileTemplate)
			{
				int l_tilesOnTheHeight = pDoc->o_TOSPropertiesDialog.m_tileTemplateDialogHeight;
				int l_tilesOnTheWidth  = pDoc->o_TOSPropertiesDialog.m_tileTemplateDialogWidth;

				m_markerRect.right  = m_markerRect.left + (l_tileList->getSize().cy * l_tilesOnTheWidth);
				m_markerRect.bottom = m_markerRect.top  + (l_tileList->getSize().cx * l_tilesOnTheHeight );
			}
			else
			{
				m_markerRect.right  = m_markerRect.left + l_tileList->getSize().cy;
				m_markerRect.bottom = m_markerRect.top  + l_tileList->getSize().cx;
			}

			// Draw marked spot.		
			pDC->InvertRect(m_markerRect);			
		}

	} 
}

void CTOSView::pasteCopyedTile(CPoint point)
{
	CTOSDoc* pDoc = GetDocument();	
	
	CSTM* pSTM = pDoc->getActiveMTM()->getSTM(pDoc->m_aktivResourceName);
	if (pSTM != NULL)		
	
	{
		CClientDC pDC(this);
		OnPrepareDC(&pDC);

		CTileList* l_tileList = pSTM->getTileList();
		int tilesWidth  = (m_screenRectClip.Width()/l_tileList->getSize().cx);
		int tilesHeight = (m_screenRectClip.Height()/l_tileList->getSize().cy);

		int l_xPos = (m_markerRect.left / l_tileList->getSize().cx);		
		int l_yPos = (m_markerRect.top  / l_tileList->getSize().cy) ;
		
		
		drawTileMarker(&pDC, point, CT_OLD);
		if (pDoc->o_TOSPropertiesDialog.m_useTileTemplate)
		{
			int l_tilesOnTheHeight = pDoc->o_TOSPropertiesDialog.m_tileTemplateDialogHeight;
			int l_tilesOnTheWidth  = pDoc->o_TOSPropertiesDialog.m_tileTemplateDialogWidth;

			for (int l_mapYPos = 0; l_mapYPos < l_tilesOnTheHeight; l_mapYPos++)
				for (int l_mapXPos = 0; l_mapXPos < l_tilesOnTheWidth   ; l_mapXPos++)
				{
					pSTM->insertTile(l_xPos + l_mapXPos, 
									 l_yPos + l_mapYPos, 
									 pDoc->m_copyedTileMapWord[l_mapXPos + (l_mapYPos*l_tilesOnTheWidth)] 
									);
					pSTM->drawTile(&pDC, l_xPos + l_mapXPos, l_yPos + l_mapYPos) ;
				}
		}
		else
		{
			pSTM->insertTile(l_xPos, l_yPos, pDoc->m_copyedTile );
			pSTM->drawTile(&pDC, l_xPos, l_yPos) ;
		}

		pDoc->SetModifiedFlag(); 				
		
		drawTileMarker(&pDC, point, CT_NEW);
	}		
}

void CTOSView::drawAnimatedSprite(CDC * pDC, CTOSDoc * pDoc)
{
	CAnimatedSpriteEvent* l_ASE;
	if (l_ASE = pDoc->getActiveASE())
	{
		CAnimatedSprite* l_AS = pDoc->getActiveAS();

		struct ASControllerData l_ASCD;
		l_ASCD.m_currentFrame = l_ASE->getCrntFrame();
		l_ASCD.m_maxFrames	  = l_ASE->getMaxFrames();	
		l_ASCD.m_height		  = l_AS->getSize().cy;
		l_ASCD.m_width		  = l_AS->getSize().cx;

		pDoc->m_ASCtrlDialog.setData( l_ASCD );
		
		COLORREF l_color = 0x00232323;
		CBrush* l_brush = new CBrush(l_color);
		pDC->FrameRect( CRect(0, 0, 
							  l_AS->getSize().cx,
							  l_AS->getSize().cy
							  ),
						l_brush
					   );
			
		l_ASE->drawActiveFrame(pDC);
	}	
}

void CTOSView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	switch(lHint)
	{
	case NULL :
	case e_UPDATE_TOS_VIEW :
							m_markerRect.SetRectEmpty();
							Invalidate();			
							break;
	default :				break;
	}
	m_markerRect.SetRectEmpty();	
}

void CTOSView::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default

	CTOSDoc* pDoc = GetDocument();
	
	switch (pDoc->m_aktivRoot)
	{
	case 1010: 		
		break;
	default:
			CScrollView::OnHScroll(nSBCode, nPos, pScrollBar);
			break;
	}
}

BOOL CTOSView::OnScrollBy(CSize sizeScroll, BOOL bDoScroll) 
{
	// TODO: Add your specialized code here and/or call the base class
	//OnUpdate(NULL, e_UPDATE_TOS_VIEW, NULL);	
	//Invalidate();
	return CScrollView::OnScrollBy(sizeScroll, bDoScroll);
}
