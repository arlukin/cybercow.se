#if !defined(AFX_CUTFROMVIEW_H__8DAE1BE0_1CC1_11D1_9516_000000000000__INCLUDED_)
#define AFX_CUTFROMVIEW_H__8DAE1BE0_1CC1_11D1_9516_000000000000__INCLUDED_

#include "TOSDoc.h"
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// CutFromView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCutFromView view


class CCutFromView : public CScrollView
{
protected:
	CCutFromView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CCutFromView)
// Attributes
public:

// Operations
public:	
	bool getSprite();
	CRect m_screenRectClip;
	void drawTiles(CDC* pDC);
	
	void drawTileMarker(CDC* pDC, CPoint point, tileMarkerFlag p_flags = CT_OLD_NEW);
	bool getTile();
	CRect m_markerRect;

	CTOSDoc* GetDocument()
	{
		ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTOSDoc)));
		return (CTOSDoc*) m_pDocument;
	}
	

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCutFromView)
	public:
	virtual void OnPrepareDC(CDC* pDC, CPrintInfo* pInfo = NULL);
	virtual BOOL OnScroll(UINT nScrollCode, UINT nPos, BOOL bDoScroll = TRUE);
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual void OnActivateView(BOOL bActivate, CScrollView* pActivateView, CScrollView* pDeactiveView);	
	virtual void OnInitialUpdate();
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL
		

// Implementation
protected:
	virtual ~CCutFromView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CCutFromView)
	afx_msg LRESULT OnDoRealize(WPARAM wParam, LPARAM lParam);  // user message	
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CUTFROMVIEW_H__8DAE1BE0_1CC1_11D1_9516_000000000000__INCLUDED_)
