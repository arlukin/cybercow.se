// TOSDoc.h : interface of the CTOSDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TOSDOC_H__8DD14319_011C_11D1_94E3_000000000000__INCLUDED_)
#define AFX_TOSDOC_H__8DD14319_011C_11D1_94E3_000000000000__INCLUDED_

#include "CAnimatedSpriteEvent.h"	// Added by ClassView
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// class CTOSDoc
//

class CTOSDoc : public CDocument
{
protected: // create from serialization only
	CTOSDoc();
	DECLARE_DYNCREATE(CTOSDoc)

// Attributes
public:

// Implementation
public:	
	void InitDocument();
	virtual ~CTOSDoc();

// Public Variables
	CTOSPropertiesDialog o_TOSPropertiesDialog;			
	int m_aktivRoot;									// Den aktiva tr�d rooten.
														// 0 = TOSMenyn
														// 1000 = Tiles huvud menyn
														// 1010 = Tiles resourcerna
														// 2000 = MTM huvud menyn
														// 2010 = MTM resourcerna
														// 2011 = MTM layers
														// 3000 = Sprites huvud menyn
														// 3010 = Sprites resourcerna
														// 3011 = Sprites events
	CString m_aktivResourceName;						// Namn p� den resource som visas nu

//  Document size for scrollbars.
	CSize m_cutFromViewSize;
	CSize m_TosViewSize;	
	
	void setDocumentSize(int p_flag, CRect screenSize = CRect(0,0,0,0));/* This Funcion is not used, cause it fucked up */


// ----------------- Tile Mode -------------------
	// Functions
	POSITION NewTilesList(CString p_fileName, int p_width, int p_height, int p_numOfTiles);	
	CTileList* getActiveTileList();
	CTileList* getTileList(CString p_tileListName);

	// CCutFromView
	CDib* o_cutFromViewDIB;

	// CTosView
	CTypedPtrList<CObList, CTileList*> m_tileLists;		// The list with the tilelists
	CTileList* m_aktivTileList;
	

// ----------------- MTM Mode --------------------
	// Functions
	CMTM* NewMTMList(CString p_resourceName, int p_width, int p_height, int p_numOfTiles, HTREEITEM p_treeLeaf);
	CMTM* getActiveMTM();


	// CCutFromView
		
	// CTosView
	CTypedPtrList<CObList, CMTM*> m_MTM;				// The list with all the Multi Tile Maps
	CMTM* m_aktivMTM;
	CString m_aktivMTMResourceName;						// Anv�nds av STM.

	// Copying from CCutFromViw To CTosView
	int m_copyedTile;									// Temp variabel som anv�nds f�r att drag and droppa tiles fr�n
														// cutfrom vyn till ctosvyn.

	CTileTemplateDialog m_copyedTileTMPLDialog;			// A dialog box in which there are tile templates who will be copyed instead	
														// of m_copyedTile in the Ctos view in MTM mode
	unsigned int m_tileTemplateDialogXPos;						
	unsigned int m_tileTemplateDialogYPos;

    CWordArray  m_copyedTileMapWord;					// Temp array som anv�nds ist�llt f�r m_copyedTile variabeln n�r man anv�nder tile
														// templates..
			
// ------------Animated Sprite Mode --------------
	CAnimatedSprite* NewASList(CString p_resourceName, int p_width, int p_height, HTREEITEM p_treeLeaf);
	CAnimatedSprite* getActiveAS();
	CAnimatedSpriteEvent* getActiveASE();
	
	CString m_aktivASResourceName;

	CAnimatedSpriteController m_ASCtrlDialog;			// This dialog box is like a remote controll for the Animated Sprites.
	unsigned int m_ASCtrlDialogXPos;
	unsigned int m_ASCtrlDialogYPos;

	CAnimatedSpritePreviewDialog m_ASPreviewDialog;		// In this dialog box the Animated Sprite will be played..
	unsigned int m_ASPreviewDialogXPos;
	unsigned int m_ASPreviewDialogYPos;
	
	// CTosView
	CTypedPtrList<CObList, CAnimatedSprite*> m_AS;		// The list with all Animated Sprites	

	CAnimatedSprite* m_aktivASList;

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

// Operations
public:		
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTOSDoc)
	public:
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnNewDocument();
	virtual void DeleteContents();	
	//}}AFX_VIRTUAL

// Generated message map functions
protected:
	//{{AFX_MSG(CTOSDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TOSDOC_H__8DD14319_011C_11D1_94E3_000000000000__INCLUDED_)
