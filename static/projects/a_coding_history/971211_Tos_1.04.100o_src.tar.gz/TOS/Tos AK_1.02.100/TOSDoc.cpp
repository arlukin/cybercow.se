// TOSDoc.cpp : implementation of the CTOSDoc class
//

#include "stdafx.h"
#include "TOS.h"

#include "TOSDoc.h"
#include "dib\CDib.h"
#include "WorkSpaceView.h"
#include "CutFromView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTOSDoc

IMPLEMENT_DYNCREATE(CTOSDoc, CDocument)

BEGIN_MESSAGE_MAP(CTOSDoc, CDocument)
	//{{AFX_MSG_MAP(CTOSDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTOSDoc construction/destruction

CTOSDoc::CTOSDoc()
{
	o_cutFromViewDIB = NULL;	
} 

CTOSDoc::~CTOSDoc()
{
	MessageBox(NULL, "destroy tos doc", "444sss", NULL);
}


void CTOSDoc::DeleteContents() 
{
	delete o_cutFromViewDIB;
	o_cutFromViewDIB = NULL;
	
	while (!m_tileLists.IsEmpty())
        delete m_tileLists.RemoveHead();

	while (!m_MTM.IsEmpty())
        delete m_MTM.RemoveHead();

	while (!m_AS.IsEmpty())
        delete m_AS.RemoveHead();


	CDocument::DeleteContents();
}

/////////////////////////////////////////////////////////////////////////////
// CTOSDoc serialization

void CTOSDoc::Serialize(CArchive& ar)
{
	
	if (ar.IsStoring())
	{	
		// TOS Properties
		ar << o_TOSPropertiesDialog.m_cutFromGrid;	

		ar << o_TOSPropertiesDialog.m_useTileTemplate;
		ar << o_TOSPropertiesDialog.m_tileTemplateDialogWidth;
		ar << o_TOSPropertiesDialog.m_tileTemplateDialogHeight;
		ar << m_tileTemplateDialogXPos;
		ar << m_tileTemplateDialogYPos;

		ar << m_ASCtrlDialogXPos;
		ar << m_ASCtrlDialogYPos;

		ar << m_ASPreviewDialogXPos;
		ar << m_ASPreviewDialogYPos;

		// CutFromView:ens variabler... 			
		ar << o_cutFromViewDIB->getFileName();				
		
	}	
	else
	{
		// TOS Properties
		CString l_cutFromFileName;
		// TOS Properties
		ar >> o_TOSPropertiesDialog.m_cutFromGrid;	

		ar >> o_TOSPropertiesDialog.m_useTileTemplate;
		ar >> o_TOSPropertiesDialog.m_tileTemplateDialogWidth;
		ar >> o_TOSPropertiesDialog.m_tileTemplateDialogHeight;
		ar >> m_tileTemplateDialogXPos;
		ar >> m_tileTemplateDialogYPos;		

		ar >> m_ASCtrlDialogXPos;
		ar >> m_ASCtrlDialogYPos;

		ar >> m_ASPreviewDialogXPos;
		ar >> m_ASPreviewDialogYPos;

		// CutFromView:ens variabler...
		ar >> l_cutFromFileName;
		if (o_cutFromViewDIB == NULL)
			o_cutFromViewDIB = new CDib();

		if (!l_cutFromFileName.IsEmpty())				
			if (o_cutFromViewDIB->loadBMP(l_cutFromFileName))
			{
				delete o_cutFromViewDIB;
				o_cutFromViewDIB = NULL;
			}		
		
		m_aktivTileList = NULL;
		m_aktivMTM = NULL;
		m_aktivASList = NULL;
		m_aktivRoot = 0;	
		m_aktivResourceName.IsEmpty();	
		m_aktivMTMResourceName.IsEmpty();
	}
	
	m_tileLists.Serialize(ar);

	m_MTM.Serialize(ar);	

	m_AS.Serialize(ar);
}

/////////////////////////////////////////////////////////////////////////////
// CTOSDoc diagnostics

#ifdef _DEBUG
void CTOSDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CTOSDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTOSDoc commands

/////////////////////////////////////////////////////////////////////////////


POSITION CTOSDoc::NewTilesList(CString p_fileName, int p_width, int p_height, int p_numOfTiles)
{
	CTileList* ptileList    = new CTileList(p_fileName, p_width, p_height, p_numOfTiles);

	return m_tileLists.AddTail(ptileList);
}

CMTM* CTOSDoc::NewMTMList(CString p_resourceName, int p_width, int p_height, int p_numOfTiles, HTREEITEM p_treeLeaf)
{
	CMTM* pMTM    = new CMTM(p_resourceName, p_width, p_height, p_numOfTiles, p_treeLeaf);

	m_MTM.AddTail(pMTM);
	return pMTM;
}

CAnimatedSprite* CTOSDoc::NewASList(CString p_resourceName, int p_width, int p_height, HTREEITEM p_treeLeaf)
{
	CAnimatedSprite* pAS  = new CAnimatedSprite(p_resourceName, p_width, p_height, p_treeLeaf);

	m_AS.AddTail(pAS);
	return pAS;
}

void CTOSDoc::InitDocument()
{		
	m_aktivResourceName.Empty();						// Ingen resource �r aktiv nu.
	m_aktivRoot = 0;		
	m_aktivTileList = NULL;
	m_aktivMTM = NULL;
	m_aktivASList = NULL;

	m_tileTemplateDialogXPos = 0;
 	m_tileTemplateDialogYPos = 0;		

	m_ASCtrlDialogXPos = 0;
	m_ASCtrlDialogYPos = 0;

	m_ASPreviewDialogXPos = 0;
	m_ASPreviewDialogYPos = 0;

	m_cutFromViewSize.cx = 256*32;
	m_cutFromViewSize.cy = 256*32;
	m_TosViewSize.cx = 256*32;
	m_TosViewSize.cy = 256*32;


	
	if (o_cutFromViewDIB == NULL)	
		o_cutFromViewDIB = new CDib();	
}

BOOL CTOSDoc::OnNewDocument() 
{		
	InitDocument();
	if (!CDocument::OnNewDocument())
		return false;
	
	return true;
}

CMTM* CTOSDoc::getActiveMTM()
{
	if (m_aktivMTM == NULL)
	{
		CTypedPtrList<CObList,CMTM*>& MTM = m_MTM;
		POSITION pos = MTM.GetHeadPosition();
		CMTM* pMTM;
		while (pos != NULL)
		{
			
			pMTM = MTM.GetNext(pos);
			if (pMTM->getResourceName() == m_aktivMTMResourceName)			
			{
				m_aktivMTM = pMTM;	
				return m_aktivMTM;
				break;
			}
		} 		
		return NULL;
	}
	return m_aktivMTM;

}


CTileList* CTOSDoc::getTileList(CString p_tileListName)
{
	CTypedPtrList<CObList,CTileList*>& tileList = m_tileLists;
	POSITION pos = tileList.GetHeadPosition();
	CTileList* pTileList;
	while (pos != NULL)
	{		
		pTileList = tileList.GetNext(pos);
		if (pTileList->getResourceName() == p_tileListName)
			return pTileList;			
	}		
	return NULL;	
}

CTileList* CTOSDoc::getActiveTileList()
{
	return getTileList(m_aktivResourceName);
}


CAnimatedSprite* CTOSDoc::getActiveAS()
{
	if (m_aktivASList == NULL)
	{
		CTypedPtrList<CObList,CAnimatedSprite*>& AS = m_AS;
		POSITION pos = AS.GetHeadPosition();
		CAnimatedSprite* pAS;
		while (pos != NULL)
		{			
			pAS = AS.GetNext(pos);
			if (pAS->getResourceName() == m_aktivASResourceName)
			{
				m_aktivASList = pAS;	
				return m_aktivASList;				
			}
		} 	
		return NULL;
	}
	return m_aktivASList;
}

CAnimatedSpriteEvent* CTOSDoc::getActiveASE()
{
	CAnimatedSprite* l_AS = getActiveAS();
	if (l_AS > NULL)
	{
		CAnimatedSpriteEvent* l_ASE = l_AS->getEvent( m_aktivResourceName );
		if (l_ASE > NULL)
		{
			return l_ASE;
		}				
	}

	return NULL;
}

/* This Funcion is not used, cause it fucked up */
void CTOSDoc::setDocumentSize(int p_flag, CRect screenSize /*=CRect(0,0,0,0)*/)
{
	if (p_flag == 0)
	{ 
		m_cutFromViewSize.cx = 0;
		m_cutFromViewSize.cy = 0;
		m_TosViewSize.cx = 0;
		m_TosViewSize.cy = 0;
		return;
	}
	CSize docSize;
	CSize oldDocSize;
	CSize newDocSize;
	
	oldDocSize = m_cutFromViewSize;


	if (p_flag == 1)
	{
		switch (m_aktivRoot)
		{
			case 1010 :		
				newDocSize     = getActiveTileList()->getDocSize(CSize(screenSize.Width(), screenSize.Height()));				
				break;	
			case 2011: 		
				newDocSize     = getActiveMTM()->getDocSize(m_aktivResourceName);							
				break;
			case 3011:	
				newDocSize     = getActiveAS()->getSize();				
			break;
		}		

	} 
	else 
		if (p_flag == 2)
		{
			switch (m_aktivRoot)
			{
				case 1010 :						
					newDocSize = o_cutFromViewDIB->getSize();										
					break;			
				case 2011: 		
					newDocSize = getActiveTileList()->getDocSize(CSize(screenSize.Width(), screenSize.Height()));;
					break;
				case 3011:						
					newDocSize = o_cutFromViewDIB->getSize();
				break;
			}		

		}
		else
			MessageBox(NULL, "This option can't be used, contact Cyber Cow", "Error", NULL);
		

	if (newDocSize.cx > oldDocSize.cx)
		docSize.cx = newDocSize.cx;
	else
		docSize.cx = oldDocSize.cx;

	if (newDocSize.cy > oldDocSize.cy)
		docSize.cy = newDocSize.cy;
	else
		newDocSize.cy = oldDocSize.cy;

	m_cutFromViewSize = docSize;
	m_TosViewSize = docSize;	
}

