// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "TOS.h"
#include "TOSDoc.h"

#include "CCPictureDlg.h"
#include "CCCutFromDlg.h"

#include "CCResourceTreeCtrl.h"
#include "TreeBar.h"

#include "CCPropertySheet.h"
#include "MainFrm.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMRCMDIFrameWndSizeDock)

BEGIN_MESSAGE_MAP(CMainFrame, CMRCMDIFrameWndSizeDock)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_QUERYNEWPALETTE()
	ON_WM_PALETTECHANGED()
	ON_COMMAND(IDM_DEBUG_SETSTYLE, OnDebugSetstyle)
	ON_COMMAND(IDM_DEBUG_SETSTYLE2, OnDebugSetstyle2)
	ON_COMMAND(ID_FILE_TOS_SAVE, OnFileTosSave)
	ON_COMMAND(ID_FILE_TOS_SAVE_AS, OnFileTosSaveAs)
	ON_COMMAND(ID_FILE_TOS_OPEN, OnFileTosOpen)
    ON_UPDATE_COMMAND_UI(ID_VIEW_TREEBAR, OnUpdateControlBarMenu)
	ON_COMMAND_EX(ID_VIEW_TREEBAR, OnBarCheck)
	ON_UPDATE_COMMAND_UI(ID_PICTURE_DLG, OnUpdateControlBarMenu)
	ON_COMMAND_EX(ID_PICTURE_DLG, OnBarCheck)
    ON_UPDATE_COMMAND_UI(ID_CUT_FROM_DLG, OnUpdateControlBarMenu)
	ON_COMMAND_EX(ID_CUT_FROM_DLG, OnBarCheck)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	m_treeBarWnd    = NULL;	
	m_mglCtrl	    = NULL;
	m_cutFromDlg	= NULL;
	m_pictureDlg    = NULL;
	m_propertySheet = NULL;
}

CMainFrame::~CMainFrame()
{
	MGL_exit();
	delete m_treeBarWnd;
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{

	if (CMRCMDIFrameWndSizeDock::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.Create(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Remove this if you don't want tool tips or a resizeable toolbar
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

    // TOS: 

	/////////////////////////////////////////
	// Create the CCCMGL,,, graphix wrapper,,
	m_mglCtrl = new CCCMGL;
	m_mglCtrl->initMGL();
	m_mglCtrl->createMGLDeviceContexts(this);

	// Property Sheet
	m_propertySheet = new CCCPropertySheet(this);


	///////////////////
    // WorkSpace Window
	m_treeBarWnd = new CTreeBar(this);
    CRect treeBarRect(0,0, 50, 580);	
    if (!m_treeBarWnd->Create( NULL, "Tree Bar", WS_VISIBLE | WS_CHILD | CBRS_TOP ,
							   treeBarRect, this, ID_VIEW_TREEBAR, NULL))
    {
		TRACE0("Failed to create m_treeBarWnd\n");
		return -1;      
    }
    m_treeBarWnd->EnableDocking(CBRS_ALIGN_ANY);
    DockControlBar(m_treeBarWnd, AFX_IDW_DOCKBAR_TOP);

	m_treeBarWnd->m_HorzDockSize.cx = 220;			
	m_treeBarWnd->m_HorzDockSize.cy = 350;


	///////////////
	// Cut From Wnd
	m_cutFromDlg = new CCCCutFromDlg;
	if (!m_cutFromDlg->Create(this))
	{
		TRACE0("Failed to create m_cutFromDlg\n");
		return -1;      
	} 
			
	m_cutFromDlg->EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(m_cutFromDlg, AFX_IDW_DOCKBAR_TOP);


	///////////////
	// m_pictureDlg
	m_pictureDlg = new CCCPictureDlg(this, m_mglCtrl);
	if (!m_pictureDlg->Create(this))
	{
		TRACE0("Failed to create m_pictureDlg\n");
		return -1;      
	} 

	m_pictureDlg->EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(m_pictureDlg, AFX_IDW_DOCKBAR_TOP);


	///////////////////////////////
	// Organize the docking windows
	DockControlBarLeftOf(m_pictureDlg, m_treeBarWnd);
	DockControlBarLeftOf(m_cutFromDlg, m_treeBarWnd);

	OnBarCheck(ID_CUT_FROM_DLG);
	OnBarCheck(ID_PICTURE_DLG);			
	TileDockedBars();
	RecalcLayout();			
	setLayoutStyle(DO_TILE_LIST_MODE);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	cs.style = WS_OVERLAPPED | WS_CAPTION | FWS_ADDTOTITLE
	| WS_THICKFRAME | WS_SYSMENU | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_MAXIMIZE;

	return CMRCMDIFrameWndSizeDock::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMRCMDIFrameWndSizeDock::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMRCMDIFrameWndSizeDock::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

static eTOSDockingStyle currentTOSDockingStyle = DO_NONE_MODE;

BOOL CMainFrame::setLayoutStyle(eTOSDockingStyle p_iStyle)
{
	
	if (currentTOSDockingStyle != p_iStyle)
	{
		//close all old docking views.
		switch (currentTOSDockingStyle)
		{
			// First Time,,
		case NONE:
			break;

		case DO_TILE_LIST_MODE:
			OnBarCheck(ID_PICTURE_DLG);			
			break;

		case DO_MTM_MODE:
			OnBarCheck(ID_CUT_FROM_DLG);			
			break;

		case DO_ANIMATED_SPRITE_MODE :
			break;

		default :
			{
				// Error, layoutStyle Doesn't exist
				TRACE( "Error, layoutStyle doesn't exist" );
				return TRUE;
			}
		}

		currentTOSDockingStyle = p_iStyle;

		switch (p_iStyle)
		{
		case DO_TILE_LIST_MODE:
			{
				OnBarCheck(ID_PICTURE_DLG);
				if (!m_pictureDlg->IsProbablyFloating())
					DockControlBarLeftOf(m_pictureDlg, m_treeBarWnd);
				TileDockedBars();	
			}
			break;
		case DO_MTM_MODE:
			{
				OnBarCheck(ID_CUT_FROM_DLG);
				if (!m_cutFromDlg->IsProbablyFloating())
					DockControlBarLeftOf(m_cutFromDlg, m_treeBarWnd);
				TileDockedBars();
			}
			break;

		case DO_ANIMATED_SPRITE_MODE:
			break;

		default :
			{
				// Error, layoutStyle Doesn't exist
				TRACE( "Error, layoutStyle doesn't exist" );
				return TRUE;
			}
		};		
	}
	return FALSE;
}

void CMainFrame::OnSize(UINT nType, int cx, int cy) 
{
	CMRCMDIFrameWndSizeDock::OnSize(nType, cx, cy);
	
//	setLayoutStyle(1);
}

BOOL CMainFrame::OnQueryNewPalette() 
{
	// TODO: Add your message handler code here and/or call default
	if (m_mglCtrl)
		return m_mglCtrl->OnQueryNewPalette((CWnd*)this);	

	return CMRCMDIFrameWndSizeDock::OnQueryNewPalette();
}

void CMainFrame::OnPaletteChanged(CWnd* pFocusWnd) 
{
	CMRCMDIFrameWndSizeDock::OnPaletteChanged(pFocusWnd);
	
	// TODO: Add your message handler code here
	OnQueryNewPalette();		
}

void CMainFrame::OnDebugSetstyle() 
{	
	setLayoutStyle(DO_TILE_LIST_MODE);
}

void CMainFrame::OnDebugSetstyle2() 
{
	setLayoutStyle(DO_MTM_MODE);

}


void CMainFrame::DeleteContents() 
{
	// TODO: Add your specialized code here and/or call the base class
	m_mglCtrl->DeleteContents();    
	m_treeBarWnd->getResourceTreeCtrl()->DeleteAllItems();
	m_treeBarWnd->getResourceTreeCtrl()->InitializeTreeCtrl();
	m_pictureDlg->DeleteContents();

}

void CMainFrame::OnFileTosSave() 
{	
	m_mglCtrl->Save();
}

void CMainFrame::OnFileTosSaveAs() 
{
	m_mglCtrl->SaveAs();    		
}

void CMainFrame::OnFileTosOpen() 
{
	m_mglCtrl->Open();	
}
