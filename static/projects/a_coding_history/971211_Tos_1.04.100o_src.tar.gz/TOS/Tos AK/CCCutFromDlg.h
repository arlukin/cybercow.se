#if !defined(AFX_CCUTFROMDLG_H__4FCFB339_AECA_11D1_90A6_000000000000__INCLUDED_)
#define AFX_CCUTFROMDLG_H__4FCFB339_AECA_11D1_90A6_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// CCutFromDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCCCutFromDlg dialog

class CCCCutFromDlg : public CMRCSizeControlBar
{
// Construction
public:	
	virtual void OnSizedOrDocked(int cx, int cy, BOOL bFloating, int flags);
	BOOL Create(CWnd * pParentWnd);
	CCCCutFromDlg();   // standard constructor

	CScrollBar CVerticalScrollBar;
	CScrollBar CHorizontalScrollBar;


// Dialog Data
	//{{AFX_DATA(CCCCutFromDlg)
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCCCutFromDlg)
	protected:
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCCCutFromDlg)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct);
	afx_msg void OnPaint();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CCUTFROMDLG_H__4FCFB339_AECA_11D1_90A6_000000000000__INCLUDED_)
