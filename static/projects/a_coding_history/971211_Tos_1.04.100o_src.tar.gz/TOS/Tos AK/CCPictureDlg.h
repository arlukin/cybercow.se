#if !defined(AFX_CCPictureDlg_H__4FCFB339_AECA_11D1_90A6_000000000000__INCLUDED_)
#define AFX_CCPictureDlg_H__4FCFB339_AECA_11D1_90A6_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// CCPictureDlg.h : header file
//
class CMainFrame;
/////////////////////////////////////////////////////////////////////////////
// CCCPictureDlg dialog

class CCCPictureDlg : public CMRCSizeControlBar
{
// Construction
public:	
	CCCPictureDlg(CMainFrame * p_mainFrame, CCCMGL * p_mgl);
	~CCCPictureDlg();

	 void calcSizes();
	 
	virtual void OnSizedOrDocked(int cx, int cy, BOOL bFloating, int flags);
	BOOL Create(CWnd * pParentWnd);	

inline CMainFrame * getMainFrame()
	{ return m_mainFrame; }

inline const CString * getFileName()
	{ return &m_mglBmpName; };


inline CRect getSize()
{
	CRect bmpRect;
	if (!m_mglBmpName.IsEmpty())
		m_mgl->getSize(&m_mglBmpName, &bmpRect);
	else
		bmpRect = CRect(0,0,0,0);
	return bmpRect;
}

void loadMGLBmp (const CString * const p_mglBmpName);
// Dialog Data
	//{{AFX_DATA(CCCPictureDlg)
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCCPictureDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
	
protected:

	CCCMGL *m_mgl;
	CString m_mglBmpName;
	int		m_xPos;				// The position for the picture in the client,, that will say the visible part of the picture
	int		m_yPos;
	int		m_width;			// The size for the picture in the client.. that will say the visible part of the picture
	int		m_height;

	int		m_cropLeft;			// Crop values in pixel for the picture,,,,
	int		m_cropTop;
	int		m_cropRight;
	int		m_cropBottom;

	int		m_stretchX;			// Percent to stretch the picture,,
	int		m_stretchY;

	BOOL	m_stretchOn;		// If this flag is true it's possible to stretch the image with right mouse button.

	CMainFrame * m_mainFrame;

	CScrollBar oVertScrollBar;
	CScrollBar oHorzScrollBar;
public:	
	BOOL OnInitializePictureDialog();
	BOOL DeleteContents();
	// Dialog Boxes are mapped to those
	bool	m_isGrid;			//
	int		m_gridX;			// Those variables controls the position and size of the grid,,
	int		m_gridY;
	int		m_gridWidth;
	int		m_gridHeight;

	BOOL updateGrid();
	// Generated message map functions
	//{{AFX_MSG(CCCPictureDlg)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnPaint();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnPaletteChanged(CWnd* pFocusWnd);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnMButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMove(int x, int y);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CCPictureDlg_H__4FCFB339_AECA_11D1_90A6_000000000000__INCLUDED_)
