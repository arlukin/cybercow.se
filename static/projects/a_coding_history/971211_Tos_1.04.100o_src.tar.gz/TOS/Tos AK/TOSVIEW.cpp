// TOSView.cpp : implementation of the CTOSView class
//

#include "stdafx.h"
#include "TOS.h"
#include "TOSDoc.h"
#include "MainFrm.h"

#include "CCResourceTreeCtrl.h"

#include "CCCutFromDlg.h"
#include "CCPictureDlg.h"

#include "CCPropertySheet.h"



#include "TreeBar.h"
#include "TOSView.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTOSView

IMPLEMENT_DYNCREATE(CTOSView, CView)

BEGIN_MESSAGE_MAP(CTOSView, CView)
	//{{AFX_MSG_MAP(CTOSView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTOSView construction/destruction

CTOSView::CTOSView()
{
	// TODO: add construction code here
	m_mainFrame = NULL;

}

CTOSView::~CTOSView()
{
}

BOOL CTOSView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTOSView drawing

void CTOSView::OnDraw(CDC* pDC)
{
	CTOSDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	getMainFrame()->m_mglCtrl->createMGLDeviceContexts(this);
	if (getMainFrame()->m_mglCtrl)
	{
		CCCResourceTreeCtrl * l_resTreeCtrl = getMainFrame()->m_treeBarWnd->getResourceTreeCtrl();
		HTREEITEM hSelectedTreeItem;

		hSelectedTreeItem = l_resTreeCtrl->GetSelectedItem();
		
		if (hSelectedTreeItem)
			switch (LOWORD(l_resTreeCtrl->GetItemData(hSelectedTreeItem)))
			{		
			case IDCC_RESOURCE_ROOT				  :
			case IDCC_ANIMATED_SPRITE_LIST_ROOT   :
			case IDCC_ANIMATED_SPRITE_LIST_LEAF   :
			case IDCC_MTM_LIST_ROOT               :
			case IDCC_MTM_LIST_LEAF               : 
			case IDCC_TILE_LIST_ROOT              :
				break;

			case IDCC_TILE_LIST_LEAF              :
				getMainFrame()->m_mglCtrl->DrawTileList(pDC);
				break;

			default :
				break;
		}

	}
}

/////////////////////////////////////////////////////////////////////////////
// CTOSView printing

BOOL CTOSView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CTOSView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CTOSView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CTOSView diagnostics

#ifdef _DEBUG
void CTOSView::AssertValid() const
{
	CView::AssertValid();
}

void CTOSView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CTOSDoc* CTOSView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTOSDoc)));
	return (CTOSDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTOSView message handlers

CMainFrame* CTOSView::getMainFrame()
{
	ASSERT(GetDocument()->getMainFrame());
	return GetDocument()->getMainFrame();
}
