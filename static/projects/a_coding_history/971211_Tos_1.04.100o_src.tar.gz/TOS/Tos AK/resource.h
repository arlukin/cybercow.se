//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TOS.rc
//
#define IDT_RESOURCE_TAB                0
#define IDT_INFO_TAB                    1
#define IDCC_RESOURCE_ROOT              10
#define IDCC_ANIMATED_SPRITE_LIST_ROOT  11
#define IDCC_ANIMATED_SPRITE_LIST_LEAF  12
#define IDCC_MTM_LIST_ROOT              13
#define IDCC_MTM_LIST_LEAF              14
#define IDCC_TILE_LIST_ROOT             15
#define IDCC_TILE_LIST_LEAF             16
#define IDD_ABOUTBOX                    100
#define IDM_ADD_ANIMATED_SPRITE_LIST    101
#define IDM_ADD_MTM_LIST                102
#define IDM_ADD_TILE_LIST               103
#define IDM_SEPARATOR                   104
#define IDM_PROPERTIES                  106
#define IDM_PICTURE_DLG_LOAD            107
#define IDC_PROPERTYSHEET               108
#define IDR_MAINFRAME                   128
#define IDR_TOSTYPE                     129
#define IDD_SIZEDIALOGBAR               130
#define IDB_TREEBAR                     131
#define IDD_CALENDARBAR                 131
#define IDB_MFLOGO                      134
#define IDD_DIALOG1                     137
#define IDD_PASTE_TO_WND                141
#define IDD_CUT_FROM_WND                142
#define IDD_ESABDNAMURD_DIALOG          143
#define IDD_PROP_PAGE_PICTURE_DLG       152
#define IDD_PROP_PAGE_TILE              153
#define IDD_PROP_PAGE_EMPTY             154
#define IDD_PROP_PAGE_PICTURE_DLG_STYLES 156
#define IDD_PROP_PAGE_RESOURCE_TILE_GENERAL 158
#define IDC_BUTTON1                     1000
#define IDC_LIST1                       1001
#define IDC_PICTURE                     1004
#define IDC_CALENDAR1                   1006
#define IDC_TREE1                       1012
#define IDC_CHECK1                      1016
#define IDC_WIDTH                       1024
#define IDC_HEIGHT                      1025
#define IDC_FILE_NAME                   1026
#define IDC_GRID                        1026
#define IDC_STATIC_POS                  1027
#define IDC_STATIC_HEIGHT               1028
#define IDC_POSX                        1029
#define IDC_POSY                        1030
#define IDC_NUMBERS_OF_TILES            1032
#define IDC_STATIC_WIDTH                1035
#define IDC_STATIC_HEIGHT2              1036
#define IDC_COMBO_COLOR                 1037
#define IDC_RESOURCE_NAME               1038
#define IDC_EDIT1                       1039
#define ID_SNOPP                        32775
#define ID_CUT_FROM_DLG                 32776
#define ID_VIEW_TILEDOCKBARS            32777
#define ID_PASTE_TO_DLG                 32778
#define ID_PICTURE_DLG                  32779
#define IDM_DEBUG_SETSTYLE              32780
#define IDM_DEBUG_SETSTYLE2             32781
#define ID_FILE_TOS_SAVE                32782
#define ID_FILE_TOS_SAVE_AS             32783
#define ID_FILE_TOS_OPEN                32784
#define ID_VIEW_TREEBAR                 0xE804
#define ID_VIEW_SIZEDIALOG              0xE805
#define ID_VIEW_TEST                    0xE806
#define ID_VIEW_CALENDARBAR             0xE807

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        164
#define _APS_NEXT_COMMAND_VALUE         32785
#define _APS_NEXT_CONTROL_VALUE         1040
#define _APS_NEXT_SYMED_VALUE           109
#endif
#endif
