// CCTile.h: interface for the CCCTile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CCTILE_H__3AA4C962_B2E1_11D1_90AA_000000000000__INCLUDED_)
#define AFX_CCTILE_H__3AA4C962_B2E1_11D1_90AA_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CCCTile : public CObject  
{
public:
	 CCCTile(bitmap_t * p_bitmapST);
	CCCTile();
	virtual ~CCCTile();

	bitmap_t * m_bitmapST;
};

#endif // !defined(AFX_CCTILE_H__3AA4C962_B2E1_11D1_90AA_000000000000__INCLUDED_)
