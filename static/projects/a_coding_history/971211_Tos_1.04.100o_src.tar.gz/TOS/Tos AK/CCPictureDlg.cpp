// CCPictureDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TOS.h"
#include "TOSDoc.h"

#include "CCResourceTreeCtrl.H"
#include "TreeBar.h"

#include "CCPropertySheet.h"

#include "CCResourceTreeCtrl.h"
#include "TreeBar.h"

#include "CCCutFromDlg.h"

#include "MainFrm.h"
#include "CCPictureDlg.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define SCROLLBARSIZE 20

/////////////////////////////////////////////////////////////////////////////
// CCCPictureDlg dialog
BEGIN_MESSAGE_MAP(CCCPictureDlg, CMRCSizeControlBar)
	//{{AFX_MSG_MAP(CCCPictureDlg)	
	ON_WM_CREATE()
	ON_WM_PAINT()
	ON_WM_HSCROLL()
	ON_WM_PALETTECHANGED()
	ON_WM_MOUSEMOVE()
	ON_WM_MBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONUP()
	ON_WM_MOVE()
	ON_WM_SETCURSOR()
	ON_WM_VSCROLL()
	ON_WM_CONTEXTMENU()
	ON_WM_LBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

//IMPLEMENT_DYNAMIC(CCCPictureDlg, CMRCSizeControlBar);

CCCPictureDlg::CCCPictureDlg(CMainFrame * p_mainFrame, CCCMGL * p_mgl)
	: CMRCSizeControlBar(SZBARF_STDMOUSECLICKS | SZBARF_ALLOW_MDI_FLOAT)
{
	//{{AFX_DATA_INIT(CCCPictureDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	// Use the Master MGLDC for this object,
	m_mgl = p_mgl;

	m_mainFrame = p_mainFrame;	

	m_xPos  = 10;
	m_yPos  = 0;
	m_width = 200;
	m_height = 200;

	OnInitializePictureDialog();
}

CCCPictureDlg::~CCCPictureDlg()
{
}

/////////////////////////////////////////////////////////////////////////////
// CCCPictureDlg message handlers

BOOL CCCPictureDlg::Create(CWnd * pParentWnd)
{
	// register a window class for the control bar
	static CString strWndClass;
	if (strWndClass.IsEmpty())
	{
		strWndClass = AfxRegisterWndClass(CS_DBLCLKS);
	}
	
	return CMRCSizeControlBar::Create(strWndClass,
									   "Picture dlg",
									   WS_VISIBLE | WS_CHILD | CBRS_BOTTOM | WS_CLIPCHILDREN,
									   CFrameWnd::rectDefault,
									   pParentWnd, ID_PICTURE_DLG);
}

int CCCPictureDlg::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CMRCSizeControlBar::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	CRect rect;
	GetClientRect(&rect);

	// shrink rectangle if we're docked
	if (IsProbablyFloating())
		rect.InflateRect(-2, -2);		// shrink for border when floating
	else
		rect.InflateRect(-4, -4);

	oVertScrollBar.Create(SBS_VERT | WS_VISIBLE , rect, this, NULL);
	oVertScrollBar.SetScrollRange(0,0, TRUE);
	oVertScrollBar.EnableScrollBar();
	oVertScrollBar.SetScrollPos(0);


	oHorzScrollBar.Create(SBS_HORZ |WS_VISIBLE, rect, this, NULL);
	oHorzScrollBar.SetScrollRange(0,0, TRUE);
	oHorzScrollBar.EnableScrollBar();

	
	return 0;
}
	
void CCCPictureDlg::OnSizedOrDocked(int cx, int cy, BOOL bFloating, int flags)
{
	CRect rect(0, 0, cx, cy);		// rectangle for client area
		
	// shrink rectangle if we're docked
	if (IsProbablyFloating())
		rect.InflateRect(-2, -2);		// shrink for border when floating
	else
		rect.InflateRect(-4, -4);

	m_width  = cx - SCROLLBARSIZE;
	m_height = cy - SCROLLBARSIZE;	
	calcSizes();

	oVertScrollBar.SetWindowPos(NULL, rect.right-SCROLLBARSIZE+4, rect.top,SCROLLBARSIZE,rect.bottom-rect.top-SCROLLBARSIZE,
									  SWP_NOZORDER );

	oHorzScrollBar.SetWindowPos(NULL, rect.left, rect.bottom-SCROLLBARSIZE+4, rect.right - rect.left - SCROLLBARSIZE, SCROLLBARSIZE,
									  SWP_NOZORDER );


	OnHScroll(SB_THUMBTRACK, 0, &oHorzScrollBar) ;
	OnVScroll(SB_THUMBTRACK, 0, &oVertScrollBar) ;
	
	Invalidate();
}

void CCCPictureDlg::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	CRect rect;
	GetClientRect(&rect);
	if (IsProbablyFloating())
		rect.InflateRect(-2, -2);		// shrink for border when floating
	else
		rect.InflateRect(-4, -4);

	// Paint the picture


	if (!m_mglBmpName.IsEmpty())
	{
		m_mgl->createMGLDeviceContexts(this);
		if (m_mgl)
		{
			m_mgl->paint(&m_mglBmpName);				
		}
	}
}

void CCCPictureDlg::OnPaletteChanged(CWnd* pFocusWnd) 
{
	CMRCSizeControlBar::OnPaletteChanged(pFocusWnd);
	
	// TODO: Add your message handler code here
	OnQueryNewPalette();	
}

void CCCPictureDlg::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default

	// Move The Picture
	static int ls_mouseX=0;
	static int ls_mouseY=0;

	if (m_mgl)
	{
		if (nFlags == MK_LBUTTON)
		{
			if (ls_mouseX==0)
				ls_mouseX = point.x;

			if (ls_mouseY==0)
				ls_mouseY = point.y;
		
			if ((ls_mouseX != point.x) || (ls_mouseY != point.y))
			{
				m_cropLeft		+= (ls_mouseX-point.x);
				m_cropTop		+= (ls_mouseY-point.y);
				m_cropRight		-= (ls_mouseX-point.x);
				m_cropBottom	-= (ls_mouseY-point.y);

				CRect bmpRect; 
				m_mgl->getSize(&m_mglBmpName, &bmpRect);

				CRect clientRect;
				GetClientRect(&clientRect);
				clientRect.DeflateRect(0,0,SCROLLBARSIZE,SCROLLBARSIZE);

				if (m_cropLeft > bmpRect.right - clientRect.right)
					m_cropLeft = bmpRect.right - clientRect.right;

				if (bmpRect.right < clientRect.right)
					m_cropLeft = 0;

				if (m_cropLeft < 0)
					m_cropLeft = 0;

				if (m_cropTop > bmpRect.bottom - clientRect.bottom)
					m_cropTop = bmpRect.bottom - clientRect.bottom;

				if (bmpRect.bottom < clientRect.bottom)
					m_cropTop = 0;

				if (m_cropTop < 0)
					m_cropTop = 0;


				if (m_mgl)
					m_mgl->crop(&m_mglBmpName, m_cropLeft, m_cropTop, m_cropRight, m_cropBottom);

				if (!m_mglBmpName.IsEmpty())
					if (m_mgl)
					{
						m_mgl->createMGLDeviceContexts(this);
						m_mgl->paint(&m_mglBmpName);				
					};

				ls_mouseX = point.x;
				ls_mouseY = point.y;
				oHorzScrollBar.SetScrollPos(m_cropLeft);	
				oVertScrollBar.SetScrollPos(m_cropTop);	
			}
		}
		else
		{
			ls_mouseX=0;
			ls_mouseY=0;		
		};	
		// Stretch the picture,, minimize/maximize
		static int ls_stretchMouseX=0;
		static int ls_stretchMouseY=0;

		if (nFlags == MK_RBUTTON && (m_stretchOn))
		{
			if (ls_stretchMouseX==0)
				ls_stretchMouseX = point.x;

			if (ls_stretchMouseY==0)
				ls_stretchMouseY = point.y;
			
			if ((ls_stretchMouseX != point.x) || (ls_stretchMouseY != point.y))
			{
				m_stretchX      += (ls_stretchMouseX-point.x);
				m_stretchY		+= (ls_stretchMouseY-point.y);
				if (m_mgl)
					m_mgl->stretch(&m_mglBmpName, m_stretchX, m_stretchY);

				if (!m_mglBmpName.IsEmpty())
					if (m_mgl)
					{
						m_mgl->createMGLDeviceContexts(this);
						m_mgl->paint(&m_mglBmpName);				
					};

				ls_stretchMouseX = point.x;
				ls_stretchMouseY = point.y;
			}
		}
		else
		{
			ls_stretchMouseX=0;
			ls_stretchMouseY=0;		
		};	

		m_mgl->paintTileMarker(&m_mglBmpName,point);
	}

	
	CMRCSizeControlBar::OnMouseMove(nFlags, point);
}

void CCCPictureDlg::OnMButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	m_cropLeft	    = 0;
	m_cropTop		= 0;
	m_cropRight		= 0;
	m_cropBottom	= 0;

	m_stretchX		= 0;
	m_stretchY		= 0;	

	if (m_stretchOn)
		if (m_mgl)
			m_mgl->stretch(&m_mglBmpName, m_stretchX, m_stretchY);

	if (m_mgl)
		m_mgl->crop(&m_mglBmpName, m_cropLeft, m_cropTop, m_cropRight, m_cropBottom);
	calcSizes();
	Invalidate();
	
	
	CMRCSizeControlBar::OnMButtonDown(nFlags, point);
}

void CCCPictureDlg::OnLButtonUp(UINT nFlags, CPoint point) 
{ 
	// TODO: Add your message handler code here and/or call default
//	Invalidate();		
	CMRCSizeControlBar::OnLButtonUp(nFlags, point);
}


void CCCPictureDlg::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	getMainFrame()->m_propertySheet->changeToPropertyPictureDlg();
	
	CMRCSizeControlBar::OnLButtonDown(nFlags, point);
}


void CCCPictureDlg::OnRButtonUp(UINT nFlags, CPoint point) 
{	
	// TODO: Add your message handler code here and/or call default
	// This Functions is moved to PreTranslateMessage(MSG* pMsg) 	
	
	CMRCSizeControlBar::OnRButtonUp(nFlags, point);
}

void CCCPictureDlg::OnMove(int x, int y) 
{
	CMRCSizeControlBar::OnMove(x, y);
	
//	m_xPos = x;
//	m_yPos = y;	
	calcSizes();	
	Invalidate();
}


BOOL CCCPictureDlg::PreTranslateMessage(MSG* pMsg) 
{	
	// Stops the docking window functions on mouse buttons.. 
	// within the client area, except for a status bar at left..
	if (pMsg->hwnd == m_hWnd)
	{
	CRect wndRect;
		GetWindowRect(&wndRect);
		wndRect.DeflateRect(10,0,0,0);

		if (wndRect.PtInRect(pMsg->pt))
		{

			if (pMsg->message == WM_LBUTTONDOWN)
			{								
				getMainFrame()->m_propertySheet->changeToPropertyPictureDlg();
	
				return TRUE;
			}
		}
	}
	
	return CMRCSizeControlBar::PreTranslateMessage(pMsg);
}

void CCCPictureDlg::loadMGLBmp(const CString * const p_mglBmpName)
{
	// if it's already a bitmap with the name of the loading bitmap,, destroy it,,,
	m_mgl->deleteBitmap(&m_mglBmpName);
	
	m_mglBmpName = *p_mglBmpName;	
	
	m_mgl->loadBmp(&m_mglBmpName);
	
	m_cropLeft	    = 0;
	m_cropTop		= 0;
	m_cropRight		= 0;
	m_cropBottom	= 0;

	m_stretchX		= 0;
	m_stretchY		= 0;

	if (m_stretchOn)
		m_mgl->stretch(&m_mglBmpName, m_stretchX, m_stretchY);

	m_mgl->crop(&m_mglBmpName, m_cropLeft, m_cropTop, m_cropRight, m_cropBottom);
	calcSizes();
	updateGrid();
	Invalidate();
}

void CCCPictureDlg::calcSizes()
{
	if (m_mgl)
	{
		CRect childRect;
		GetClientRect(&childRect);
		m_xPos = childRect.left;
		m_yPos = childRect.top;
		if (m_mgl->getBmp(&m_mglBmpName))
		{
			m_mgl->setPosition(&m_mglBmpName , m_xPos, m_yPos );
			m_mgl->setSize(&m_mglBmpName , m_width, m_height);

		}
		CRect bmpRect; 
		m_mgl->getSize(&m_mglBmpName, &bmpRect);

		CRect clientRect;
		GetClientRect(&clientRect);
		clientRect.DeflateRect(0,0,SCROLLBARSIZE,SCROLLBARSIZE);

		oVertScrollBar.SetScrollRange(0,bmpRect.bottom - clientRect.bottom, TRUE);
		oVertScrollBar.EnableScrollBar();
		oVertScrollBar.SetScrollPos(0);

		oHorzScrollBar.SetScrollRange(0,bmpRect.right - clientRect.right, TRUE);
		oHorzScrollBar.EnableScrollBar();
		oHorzScrollBar.SetScrollPos(0);
	}
}

BOOL CCCPictureDlg::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	// TODO: Add your message handler code here and/or call default
    HCURSOR hPrevCursor = SetCursor(LoadCursor(NULL, IDC_SIZEALL));
		
	return CMRCSizeControlBar::OnSetCursor(pWnd, nHitTest, message);
}

void CCCPictureDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	int farStep = 1;
	int lineScrollStep = 10;
	int pageScrollStep = 50;

	switch (nSBCode)
	{
	case	SB_LEFT :
		pScrollBar->SetScrollPos(pScrollBar->GetScrollPos()-farStep);
		break;

	case	SB_RIGHT :
		pScrollBar->SetScrollPos(pScrollBar->GetScrollPos()+farStep);
		break;

	case	SB_LINELEFT :
		pScrollBar->SetScrollPos(pScrollBar->GetScrollPos()-lineScrollStep );
		break;

	case	SB_LINERIGHT :
		pScrollBar->SetScrollPos(pScrollBar->GetScrollPos()+lineScrollStep );
		break;

	case	SB_PAGELEFT :
		pScrollBar->SetScrollPos(pScrollBar->GetScrollPos()-pageScrollStep );
		break;

	case	SB_PAGERIGHT :
		pScrollBar->SetScrollPos(pScrollBar->GetScrollPos()+pageScrollStep );
		break;


	case	SB_THUMBPOSITION ://���Scroll to absolute position. The current position is specified by the nPos parameter.
		pScrollBar->SetScrollPos(nPos);
		break;


	case	SB_THUMBTRACK ://���Drag scroll box to specified position. The current position is specified by the nPos parameter
		pScrollBar->SetScrollPos(nPos);				
		m_cropLeft		= pScrollBar->GetScrollPos();		
		m_cropRight		= 0;
		
		if (m_mgl)
			m_mgl->crop(&m_mglBmpName, m_cropLeft, m_cropTop, m_cropRight, m_cropBottom);

		if (!m_mglBmpName.IsEmpty())
			if (m_mgl)
			{
				m_mgl->createMGLDeviceContexts(this);
				m_mgl->paint(&m_mglBmpName);	
			};
		break;

	case	SB_ENDSCROLL :		
		m_cropLeft		= pScrollBar->GetScrollPos();			
		m_cropRight		= 0;
		
		if (m_mgl)
			m_mgl->crop(&m_mglBmpName, m_cropLeft, m_cropTop, m_cropRight, m_cropBottom);

		Invalidate();
		break;
	}	
	
	CMRCSizeControlBar::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CCCPictureDlg::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	int farStep = 1;
	int lineScrollStep = 10;
	int pageScrollStep = 50;

	switch (nSBCode)
	{
	case	SB_LEFT :
		pScrollBar->SetScrollPos(pScrollBar->GetScrollPos()-farStep);
		break;

	case	SB_RIGHT :
		pScrollBar->SetScrollPos(pScrollBar->GetScrollPos()+farStep);
		break;

	case	SB_LINELEFT :
		pScrollBar->SetScrollPos(pScrollBar->GetScrollPos()-lineScrollStep );
		break;

	case	SB_LINERIGHT :
		pScrollBar->SetScrollPos(pScrollBar->GetScrollPos()+lineScrollStep );
		break;

	case	SB_PAGELEFT :
		pScrollBar->SetScrollPos(pScrollBar->GetScrollPos()-pageScrollStep );
		break;

	case	SB_PAGERIGHT :
		pScrollBar->SetScrollPos(pScrollBar->GetScrollPos()+pageScrollStep );
		break;


	case	SB_THUMBPOSITION ://���Scroll to absolute position. The current position is specified by the nPos parameter.
		pScrollBar->SetScrollPos(nPos);
		break;


	case	SB_THUMBTRACK ://���Drag scroll box to specified position. The current position is specified by the nPos parameter
		pScrollBar->SetScrollPos(nPos);						
		m_cropTop		= pScrollBar->GetScrollPos();
		m_cropBottom	= 0;
		
		if (m_mgl)
			m_mgl->crop(&m_mglBmpName, m_cropLeft, m_cropTop, m_cropRight, m_cropBottom);

		if (!m_mglBmpName.IsEmpty())
			if (m_mgl)
			{
				m_mgl->createMGLDeviceContexts(this);
				m_mgl->paint(&m_mglBmpName);	
			}
		break;

	case	SB_ENDSCROLL :				
		m_cropTop		= pScrollBar->GetScrollPos();
		m_cropBottom	= 0;
		
		if (m_mgl)
			m_mgl->crop(&m_mglBmpName, m_cropLeft, m_cropTop, m_cropRight, m_cropBottom);

		Invalidate();
		break;
	}
	
	CMRCSizeControlBar::OnVScroll(nSBCode, nPos, pScrollBar);
}

void CCCPictureDlg::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	CMenu menu;	
	if (menu.CreatePopupMenu())
	{		
		LPPOINT lpPoint;
		lpPoint = new CPoint;
		*lpPoint = point;
		ScreenToClient(lpPoint);

		
		menu.AppendMenu(MF_STRING, IDM_PICTURE_DLG_LOAD, CString("Load BMP"));
		menu.AppendMenu(MF_SEPARATOR, IDM_SEPARATOR);
		OnAddContextMenuItems(0, (LPARAM)menu.m_hMenu);	
		menu.AppendMenu(MF_SEPARATOR, IDM_SEPARATOR);
		menu.AppendMenu(MF_STRING, IDM_PROPERTIES, CString("Properties"));
		
		if ((point.x == -1) && (point.y == -1))
		{
			LPRECT lpRect;
			lpRect = new RECT;
			GetWindowRect(lpRect);
			point.x = lpRect->left;
			point.y = lpRect->top;
		};


		menu.TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y, this);
	}		
}

BOOL CCCPictureDlg::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	switch (LOWORD(wParam))
	{
	
	case IDM_PICTURE_DLG_LOAD :
		{
			static char BASED_CODE szFilter[] = "Bitmap Files (*.bmp)|*.bmp|JPEG Files (*.jpg)|*.jpg|PCX Files (*.pcx)|*.pcx|All Files (*.*)|*.*||";

			CFileDialog oFileDialog(TRUE, "*.bmp", NULL, OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_LONGNAMES ,szFilter, this);
			
			switch (oFileDialog.DoModal())
			{
			case IDOK:				
				loadMGLBmp(&oFileDialog.GetPathName());
				getMainFrame()->m_propertySheet->updateData();
				break;
			case IDCANCEL:
				break;
			}
		}
		break;

	case IDM_PROPERTIES :
		{
			getMainFrame()->m_propertySheet->createSheet(PROPERTIESPICTUREDLG);
		}
		break;
	}
	
	return CMRCSizeControlBar::OnCommand(wParam, lParam);
}

BOOL CCCPictureDlg::updateGrid()
{	
	if (!getFileName()->IsEmpty())
	{
		m_mainFrame->m_mglCtrl->setGridPosition(getFileName(), m_isGrid, m_gridX, m_gridY, m_gridWidth, m_gridHeight);
	}
	return TRUE;
}

BOOL CCCPictureDlg::DeleteContents()
{

	OnInitializePictureDialog();
	Invalidate();
	return TRUE;
}

BOOL CCCPictureDlg::OnInitializePictureDialog()
{
	m_mglBmpName.Empty();

	m_cropLeft		= 0;
	m_cropTop		= 0;
	m_cropRight		= 0;
	m_cropBottom	= 0;

	m_stretchX		= 0;
	m_stretchY		= 0;
	m_stretchOn		= FALSE;

	m_isGrid		= FALSE;	
	m_gridX			= 0;	
	m_gridY			= 0;
	m_gridWidth		= 30;
	m_gridHeight	= 30;

	if (m_hWnd)
	{
		oVertScrollBar.SetScrollRange(0,0, TRUE);
		oHorzScrollBar.SetScrollRange(0,0, TRUE);
	}
	return TRUE;
}
