// TreeBar.cpp : implementation file
//

#include "stdafx.h"
#include "TOS.h"
#include "TOSDoc.h"
#include "CCResourceTreeCtrl.h"

#include "CCCutFromDlg.h"
#include "CCPictureDlg.h"

#include "CCPropertySheet.h"

#include "mainfrm.h"
#include "TreeBar.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


#define IDC_TREEBAR_TAB     100


/////////////////////////////////////////////////////////////////////////////
// CTreeBar

CTreeBar::CTreeBar(CMainFrame * p_mainFrame)
{
	m_mainFrame = p_mainFrame;
	pResourceTreeCtrl = NULL;
}

CTreeBar::~CTreeBar()
{
}


BEGIN_MESSAGE_MAP(CTreeBar, CMRCSizeControlBar)
	//{{AFX_MSG_MAP(CTreeBar)
	ON_WM_CREATE()
	ON_WM_DESTROY()
    ON_NOTIFY(TCN_SELCHANGE,   IDC_TREEBAR_TAB, OnTabChanged)
	ON_WM_CONTEXTMENU()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CTreeBar message handlers

int CTreeBar::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{	
	if (CMRCSizeControlBar::OnCreate(lpCreateStruct) == -1)
		return -1;
	
    CRect rect(0,0,0,0);
    // create a tab control with tree controls inside it....
    if (!m_TabCtrl.Create(WS_CHILD | WS_VISIBLE | TCS_BOTTOM | TCS_MULTILINE,
                        rect, this, IDC_TREEBAR_TAB))
    {
        TRACE("Failed to create Tab control\n");
        return -1;
    }

    m_ImgList.Create( IDB_TREEBAR, 16, 1, RGB(192, 192, 192));
    
    m_TabCtrl.SetFont(CFont::FromHandle((HFONT)GetStockObject(DEFAULT_GUI_FONT)));
    m_TabCtrl.SetImageList(&m_ImgList);

      
    
	// Create "Resources" Tab Page and Tree control
	TC_ITEM TCI;
    TCI.mask = TCIF_TEXT | TCIF_PARAM | TCIF_IMAGE;

	pResourceTreeCtrl = new CCCResourceTreeCtrl(getMainFrame());
    TCI.pszText = (char *)_T("Resources");
    TCI.lParam = (LPARAM)pResourceTreeCtrl;
    TCI.iImage = 0;
    VERIFY(m_TabCtrl.InsertItem(IDT_RESOURCE_TAB, &TCI) != -1);


	// Create "Info" Tab Page and Tree control
	pInfoTreeCtrl = new CTreeCtrl;	
	DWORD dwStyle = WS_BORDER | WS_CHILD | TVS_HASLINES | TVS_HASBUTTONS | TVS_LINESATROOT;
    if (!pInfoTreeCtrl->Create(dwStyle, rect, this, 2))
		return -1;      // failed to create tree control
    pInfoTreeCtrl->ModifyStyleEx(0, WS_EX_CLIENTEDGE);

    
    TCI.pszText = (char *)_T("Info");
    TCI.lParam = (LPARAM)pInfoTreeCtrl;
    TCI.iImage = 1;
    VERIFY(m_TabCtrl.InsertItem(IDT_INFO_TAB, &TCI) != -1);

    // insert some items into the tree control.
    hInfoTreeCtrlRoot = pInfoTreeCtrl->InsertItem( _T("Info") );

	pInfoTreeCtrl->InsertItem(CString("Generel") , hInfoTreeCtrlRoot);
	pInfoTreeCtrl->InsertItem(CString("About") , hInfoTreeCtrlRoot);	


    ShowSelTabWindow();

	return 0;
}


CWnd * CTreeBar::GetTabWindow(int nTab)
{
    TC_ITEM TCI;
    TCI.mask = TCIF_PARAM; 
    m_TabCtrl.GetItem(nTab, &TCI);
    CWnd * pWnd = (CWnd *)TCI.lParam;
    ASSERT(pWnd != NULL && pWnd->IsKindOf(RUNTIME_CLASS(CWnd)));
    return pWnd;
}


void CTreeBar::OnSizedOrDocked(int cx, int cy, BOOL bFloating, int flags)
{
    CRect rect(0, 0, cx, cy);
    if (IsProbablyFloating())
        rect.InflateRect(-2, -2);       // give space around controls.
    else
        rect.InflateRect(-4, -4);       // give space around controls.

    // reposition the tab control.
    m_TabCtrl.MoveWindow(&rect);
    m_TabCtrl.AdjustRect(FALSE, &rect);

    for (int i = 0; i < m_TabCtrl.GetItemCount(); i++)
    {
        GetTabWindow(i)->MoveWindow(&rect);
    }
}


afx_msg void CTreeBar::OnTabChanged( NMHDR * pNM, LRESULT * pResult )
// hide all the windows - except the one with the currently selected tab
{
    ShowSelTabWindow();
    *pResult = TRUE;
}


void CTreeBar::ShowSelTabWindow()
{    
    m_TabCtrl.GetCurSel();        
    int nSel = m_TabCtrl.GetCurSel();   
    ASSERT(nSel != -1);
    
    for (int i = 0; i < m_TabCtrl.GetItemCount(); i++)
    {
        GetTabWindow(i)->ShowWindow(i == nSel ? SW_SHOW : SW_HIDE);
    }
}

void CTreeBar::OnDestroy() 
{
    // delete the CWnd object belonging to the child window
    for (int i = 0; i < m_TabCtrl.GetItemCount(); i++)
    {
        delete GetTabWindow(i);
    }
    
    CMRCSizeControlBar::OnDestroy();
}

void CTreeBar::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	CMenu menu;	
	if (menu.CreatePopupMenu())
	{		
		LPPOINT lpPoint;
		lpPoint = new CPoint;
		*lpPoint = point;
		ScreenToClient(lpPoint);

		if (m_TabCtrl.GetCurFocus() == IDT_RESOURCE_TAB)
		{			

			pResourceTreeCtrl->OnAddContextMenuItems(0, (LPARAM)menu.m_hMenu, *lpPoint);
		}

		if (m_TabCtrl.GetCurFocus() == IDT_INFO_TAB)
		{			
			menu.AppendMenu(MF_SEPARATOR, IDM_SEPARATOR);
		}

		OnAddContextMenuItems(0, (LPARAM)menu.m_hMenu);	
		menu.AppendMenu(MF_SEPARATOR, IDM_SEPARATOR);
		menu.AppendMenu(MF_STRING, IDM_PROPERTIES, CString("Properties"));
		
		if ((point.x == -1) && (point.y == -1))
		{
			LPRECT lpRect;
			lpRect = new RECT;
			GetWindowRect(lpRect);
			point.x = lpRect->left;
			point.y = lpRect->top;
		};


		menu.TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y, this);
	}	
}

BOOL CTreeBar::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	if (m_TabCtrl.GetCurFocus() == IDT_RESOURCE_TAB)
	{		
		pResourceTreeCtrl->CCOnCommand(wParam);
	}

	if (m_TabCtrl.GetCurFocus() == IDT_INFO_TAB)
	{			
	}

	return CMRCSizeControlBar::OnCommand(wParam, lParam);
}

CMainFrame * CTreeBar::getMainFrame()
{
	ASSERT(m_mainFrame);
	return m_mainFrame;
}

CCCResourceTreeCtrl * CTreeBar::getResourceTreeCtrl()
{
	return pResourceTreeCtrl;
}
