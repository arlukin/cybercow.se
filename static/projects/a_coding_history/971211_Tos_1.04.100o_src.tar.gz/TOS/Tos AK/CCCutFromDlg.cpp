// CCutFromDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TOS.h"
#include "CCCutFromDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCCCutFromDlg dialog
BEGIN_MESSAGE_MAP(CCCCutFromDlg, CMRCSizeControlBar)
	//{{AFX_MSG_MAP(CCCCutFromDlg)	
	ON_WM_CREATE()
	ON_WM_DRAWITEM()
	ON_WM_PAINT()
	ON_WM_HSCROLL()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

//IMPLEMENT_DYNAMIC(CCCCutFromDlg, CMRCSizeControlBar);

CCCCutFromDlg::CCCCutFromDlg()
	: CMRCSizeControlBar(SZBARF_STDMOUSECLICKS | SZBARF_ALLOW_MDI_FLOAT)
{
	//{{AFX_DATA_INIT(CCCCutFromDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

/////////////////////////////////////////////////////////////////////////////
// CCCCutFromDlg message handlers

BOOL CCCCutFromDlg::Create(CWnd * pParentWnd)
{
	// register a window class for the control bar
	static CString strWndClass;
	if (strWndClass.IsEmpty())
	{
		strWndClass = AfxRegisterWndClass(CS_DBLCLKS);
	}
	
	return CMRCSizeControlBar::Create(strWndClass,
									   "Cut from dlg",
									   WS_VISIBLE | WS_CHILD | CBRS_BOTTOM | WS_CLIPCHILDREN,
									   CFrameWnd::rectDefault,
									   pParentWnd, ID_CUT_FROM_DLG);

}

void CCCCutFromDlg::OnSizedOrDocked(int cx, int cy, BOOL bFloating, int flags)
{
	CRect rect(0, 0, cx, cy);		// rectangle for client area
		
	// shrink rectangle if we're docked
	if (IsProbablyFloating())
		rect.InflateRect(-2, -2);		// shrink for border when floating
	else
		rect.InflateRect(-4, -4);

	CVerticalScrollBar.SetWindowPos(NULL, rect.right-20,rect.top,20,rect.bottom-rect.top-18,
									  SWP_NOZORDER );

	CHorizontalScrollBar.SetWindowPos(NULL, rect.left, rect.bottom-20, rect.right - rect.left - 18, 20,
									  SWP_NOZORDER );

}

int CCCCutFromDlg::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CMRCSizeControlBar::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	CRect rect;
	GetClientRect(&rect);

	// shrink rectangle if we're docked
	if (IsProbablyFloating())
		rect.InflateRect(-2, -2);		// shrink for border when floating
	else
		rect.InflateRect(-4, -4);


	CVerticalScrollBar.Create(SBS_VERT | WS_VISIBLE , rect, this, NULL);
	CVerticalScrollBar.SetScrollRange(0,100, TRUE);
	CVerticalScrollBar.EnableScrollBar(ESB_ENABLE_BOTH);
	CVerticalScrollBar.SetScrollPos(30);


	CHorizontalScrollBar.Create(SBS_HORZ |WS_VISIBLE, rect, this, NULL);
	CHorizontalScrollBar.SetScrollRange(0,100, TRUE);
	CHorizontalScrollBar.EnableScrollBar();
	

	return 0;
}
	

void CCCCutFromDlg::OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	// TODO: Add your message handler code here and/or call default
	
	CMRCSizeControlBar::OnDrawItem(nIDCtl, lpDrawItemStruct);
}

void CCCCutFromDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	CRect rect;
	GetClientRect(&rect);
	if (IsProbablyFloating())
		rect.InflateRect(-2, -2);		// shrink for border when floating
	else
		rect.InflateRect(-4, -4);


	dc.FillSolidRect(CRect(rect.left, rect.top, rect.right-20,rect.bottom-20), COLORREF(0X00FF00FF));
	// Do not call CMRCSizeControlBar::OnPaint() for painting messages
}

void CCCCutFromDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	if (nSBCode ==SB_PAGERIGHT)	
		pScrollBar->SetScrollPos(pScrollBar->GetScrollPos()+10);
	
	
	CMRCSizeControlBar::OnHScroll(nSBCode, nPos, pScrollBar);
}
