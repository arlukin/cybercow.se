// TOSDoc.cpp : implementation of the CTOSDoc class
//

#include "stdafx.h"
#include "TOS.h"

#include "CCPictureDlg.h"
#include "CCCutFromDlg.h"

#include "CCResourceTreeCtrl.h"
#include "TreeBar.h"

#include "CCPropertySheet.h"
#include "MainFrm.h"

#include "TOSDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTOSDoc

IMPLEMENT_DYNCREATE(CTOSDoc, CDocument)

BEGIN_MESSAGE_MAP(CTOSDoc, CDocument)
	//{{AFX_MSG_MAP(CTOSDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTOSDoc construction/destruction

CTOSDoc::CTOSDoc()
{
	// TODO: add one-time construction code here

}

CTOSDoc::~CTOSDoc()
{
}

BOOL CTOSDoc::OnNewDocument()
{	
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CTOSDoc serialization

void CTOSDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CTOSDoc diagnostics

#ifdef _DEBUG
void CTOSDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CTOSDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTOSDoc commands

BOOL CTOSDoc::setMainFrame(CMainFrame * p_mainFrame)
{
	m_mainFrame = p_mainFrame;
	return TRUE;
}

CMainFrame* CTOSDoc::getMainFrame()
{
	ASSERT(m_mainFrame);
	return m_mainFrame;
}
