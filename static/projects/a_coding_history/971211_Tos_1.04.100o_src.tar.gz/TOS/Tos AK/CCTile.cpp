// CCTile.cpp: implementation of the CCCTile class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TOS.h"
#include "CCTile.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCCTile::CCCTile()
{
	m_bitmapST = NULL;

}

CCCTile::~CCCTile()
{

}

CCCTile::CCCTile(bitmap_t * p_bitmapST)
{
	m_bitmapST = p_bitmapST;
}
