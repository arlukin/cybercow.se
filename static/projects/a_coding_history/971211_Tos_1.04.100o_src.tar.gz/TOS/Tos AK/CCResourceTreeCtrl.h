#if !defined(AFX_CCRESOURCETREECTRL_H__5DEC795E_98EC_11D1_908F_000000000000__INCLUDED_)
#define AFX_CCRESOURCETREECTRL_H__5DEC795E_98EC_11D1_908F_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// CCResourceTreeCtrl.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCCResourceTreeCtrl window


class CTreeBar;
class CMainFrame;

class CCCResourceTreeCtrl : public CTreeCtrl
{
// Construction
public:
	CCCResourceTreeCtrl(CMainFrame * p_mainFrame);

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCCResourceTreeCtrl)
	protected:	
	//}}AFX_VIRTUAL

// Implementation
public:	
	BOOL InitializeTreeCtrl();
	BOOL changePropertyPage();
	CMainFrame * getMainFrame();
	BOOL CCOnCommand(WPARAM wParam);
	LONG OnAddContextMenuItems(WPARAM wParam, LPARAM lParam, CPoint point);
	virtual ~CCCResourceTreeCtrl();


	// Generated message map functions
protected:
	//{{AFX_MSG(CCCResourceTreeCtrl)
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnEndlabeledit(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnBeginlabeledit(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDblclk(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnSelchanged(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
private:
	UINT m_TileListResourceCounter;
	UINT m_MultiTileMapListResourceCounter;
	UINT m_AnimatedSpriteListResourceCounter;
	HTREEITEM hResourceTreeCtrlRoot;
	HTREEITEM hTilesListRoot;
	HTREEITEM hMultiTileMapListRoot;
	HTREEITEM hAnimatedSpriteListRoot;
		
	CMainFrame * m_mainFrame;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CCRESOURCETREECTRL_H__5DEC795E_98EC_11D1_908F_000000000000__INCLUDED_)
