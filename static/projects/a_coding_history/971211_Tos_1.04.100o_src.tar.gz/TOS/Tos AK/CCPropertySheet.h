#if !defined(AFX_CCPROPERTYSHEET_H__D80B1565_B52B_11D1_90AF_000000000000__INCLUDED_)
#define AFX_CCPROPERTYSHEET_H__D80B1565_B52B_11D1_90AF_000000000000__INCLUDED_

#include "MainFrm.h"	// Added by ClassView
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// CCPropertySheet.h : header file
//

#define NONE							0
#define PROPERTIESNO					1
#define	PROPERTIESPICTUREDLG			2	
#define PROPERTIES_TILE_RESOURCE		3
#define PROPERTIES_RESOURCE_TILE_LEAF	4

/////////////////////////////////////////////////////////////////////////////
// CCCPropertySheet
class   CTreeBar;
class	CCCPropPageTile;
class	CCCPropPageEmpty;
class	CCCPropPagePictureDlg;
class	CCCPropPagePictureDlgStyles;
class	CMainFrame;


/////////////////////////////////////////////////////////////////////////////
// Name: CCCPropertySheet
// Descrition: Handels all Property Dialog Boxes (Wizards)
/////////////////////////////////////////////////////////////////////////////
class CCCPropertySheet : public CPropertySheet
{
	DECLARE_DYNAMIC(CCCPropertySheet)

// Construction
public:

	/////////////////////////////////////////////////////////////////////////////
	// Name: CCCPropPageEmpty
	// Descrition: This will be shown if no other valid prop dialog i available
	/////////////////////////////////////////////////////////////////////////////
	class CCCPropPageEmpty : public CPropertyPage
	{
	//	DECLARE_DYNCREATE(CCCPropPageEmpty)

	// Construction
	public:
		CCCPropPageEmpty(CMainFrame * p_mainFrame);
		~CCCPropPageEmpty();

	// Dialog Data
		//{{AFX_DATA(CCCPropPageEmpty)
		enum { IDD = IDD_PROP_PAGE_EMPTY };
		//}}AFX_DATA


	// Overrides
		// ClassWizard generate virtual function overrides
		//{{AFX_VIRTUAL(CCCPropPageEmpty)
		protected:
		virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
		//}}AFX_VIRTUAL

	// Implementation
	protected:
		CMainFrame * m_mainFrame;
		// Generated message map functions
		//{{AFX_MSG(CCCPropPageEmpty)
		//}}AFX_MSG
		DECLARE_MESSAGE_MAP()

	};

	/////////////////////////////////////////////////////////////////////////////
	// Name: CCCPropPageTile
	// Descrition: roperties for the Tile Root in the resource dock wnd
	/////////////////////////////////////////////////////////////////////////////
	class CCCPropPageTile : public CPropertyPage
	{
	//	DECLARE_DYNCREATE(CCCPropPageTile)

	// Construction
	public:
		CCCPropPageTile(CMainFrame * p_mainFrame);
		~CCCPropPageTile();

	// Dialog Data
		//{{AFX_DATA(CCCPropPageTile)
		enum { IDD = IDD_PROP_PAGE_TILE };
			// NOTE - ClassWizard will add data members here.
			//    DO NOT EDIT what you see in these blocks of generated code !
		//}}AFX_DATA


	// Overrides
		// ClassWizard generate virtual function overrides
		//{{AFX_VIRTUAL(CCCPropPageTile)
		protected:
		virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
		//}}AFX_VIRTUAL

	// Implementation
	protected:
		CMainFrame * m_mainFrame;
		// Generated message map functions
		//{{AFX_MSG(CCCPropPageTile)
			// NOTE: the ClassWizard will add member functions here
		//}}AFX_MSG
		DECLARE_MESSAGE_MAP()

	};
	
	/////////////////////////////////////////////////////////////////////////////
	// Name: CCCPropPageResourceTileLeaf
	// Descrition: Properties for the Tile Leaf in the resource dock wnd
	/////////////////////////////////////////////////////////////////////////////
	class CCCPropPageResourceTileLeaf : public CPropertyPage
	{

	// Construction
	public:	
		CCCPropPageResourceTileLeaf(CMainFrame * p_mainFrame);
		~CCCPropPageResourceTileLeaf();
		BOOL InitialData();

		bool m_bModal;					// True if the PropertySheet is Modal

	// Dialog Data
		//{{AFX_DATA(CCCPropPageResourceTileLeaf)
	enum { IDD = IDD_PROP_PAGE_RESOURCE_TILE_GENERAL };
		CEdit	m_widthCtrl;
		CEdit	m_resourceNameCtrl;
		CEdit	m_heightCtrl;
		CString	m_resourceName;
		int		m_numbersOfTiles;
		int		m_height;
		int		m_width;
	//}}AFX_DATA


	// Overrides
		// ClassWizard generate virtual function overrides
		//{{AFX_VIRTUAL(CCCPropPageResourceTileLeaf)
		protected:
		virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
		//}}AFX_VIRTUAL

	// Implementation
	protected:
		// Generated message map functions
		//{{AFX_MSG(CCCPropPageResourceTileLeaf)
			afx_msg void OnSetFocusHeight();				
			afx_msg void OnSetFocusWidth();
			afx_msg void OnKillFocusHeight();				
			afx_msg void OnKillFocusWidth();			
		//}}AFX_MSG
		DECLARE_MESSAGE_MAP()

	private:
		CMainFrame * m_mainFrame;

		inline CCCMGL * getMGLCtrl( void ) { return m_mainFrame->m_mglCtrl; };

	};


	/////////////////////////////////////////////////////////////////////////////
	// Name: CCCPropPagePictureDlg
	// Descrition: General Properties for the CutFrom CCCPictureDlg
	/////////////////////////////////////////////////////////////////////////////
	class CCCPropPagePictureDlg : public CPropertyPage
	{
	//	DECLARE_DYNCREATE(CCCPropPagePictureDlg)

	// Construction
	public:
		CCCPropPagePictureDlg(CMainFrame *  p_mainFrame);
		~CCCPropPagePictureDlg();

	// Dialog Data
		//{{AFX_DATA(CCCPropPagePictureDlg)
		enum { IDD = IDD_PROP_PAGE_PICTURE_DLG };
		CString	m_fileName;
		int		m_width;
		int		m_height;
		//}}AFX_DATA


	// Overrides
		// ClassWizard generate virtual function overrides
		//{{AFX_VIRTUAL(CCCPropPagePictureDlg)
		protected:
		virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
		//}}AFX_VIRTUAL

	// Implementation
	protected:
		CMainFrame * m_mainFrame;
		// Generated message map functions
		//{{AFX_MSG(CCCPropPagePictureDlg)
			// NOTE: the ClassWizard will add member functions here
		//}}AFX_MSG
		DECLARE_MESSAGE_MAP()
	};

	/////////////////////////////////////////////////////////////////////////////
	// Name: CCCPropPagePictureDlgStyles
	// Descrition: Styles Properties for the CutFrom CCCPictureDlg
	/////////////////////////////////////////////////////////////////////////////
	class CCCPropPagePictureDlgStyles : public CPropertyPage
	{
	//	DECLARE_DYNCREATE(CCCPropPagePictureDlgStyles)

	// Construction
	public:

		CCCPropPagePictureDlgStyles(CMainFrame * p_mainFrame);
		~CCCPropPagePictureDlgStyles();

	// Dialog Data
		//{{AFX_DATA(CCCPropPagePictureDlgStyles)
		enum { IDD = IDD_PROP_PAGE_PICTURE_DLG_STYLES };
		CEdit	m_posXCtrl;
		CEdit	m_posYCtrl;
		CEdit	m_widthCtrl;
		CEdit	m_heightCtrl;
		//}}AFX_DATA


	// Overrides
		// ClassWizard generate virtual function overrides
		//{{AFX_VIRTUAL(CCCPropPagePictureDlgStyles)
		protected:
		virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
		//}}AFX_VIRTUAL

	// Implementation
	protected:
		CMainFrame * m_mainFrame;
		// Generated message map functions
		//{{AFX_MSG(CCCPropPagePictureDlgStyles)
		afx_msg void OnGrid();
		afx_msg void OnChangePosX();
		afx_msg void OnChangePosY();
		afx_msg void OnChangeWidth();
		afx_msg void OnChangeHeight();
		//}}AFX_MSG
		DECLARE_MESSAGE_MAP()

	};

/////////////////////////////////////////////////////////////////////////////
// Name:
// Descrition:
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////


	CCCPropertySheet(CMainFrame * p_mainFrame);
	CCCPropertySheet(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	CCCPropertySheet(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCCPropertySheet)
	public:
	virtual BOOL DestroyWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	BOOL doPropPageResourceTileLeafDataModal(CString & p_resourceName, int & p_width, int & p_height);
	
	BOOL updateData();
		
	BOOL createSheet(int p_sheet);	
	int  doModalSheet(int p_sheet);
	BOOL removeAllPages();

	BOOL changeToPropertyTileResource(); 	
	BOOL changeToPropertyResourceTileLeaf();
	BOOL changeToPropertyPictureDlg();
	BOOL changeToPropertyNo();
	virtual ~CCCPropertySheet();


	// Generated message map functions
protected:

	CMainFrame	* m_mainFrame;
	int  m_numbersOfActivePages;
	BOOL isActive;
	int	 m_activeSheet;

	CCCPropPagePictureDlg		* m_propPagePicture;
	CCCPropPagePictureDlgStyles	* m_propPagePictureSize;
	CCCPropPageTile				* m_propPageTile;
	CCCPropPageEmpty			* m_propPageEmpty;	
	CCCPropPageResourceTileLeaf * m_propPageTileLeaf;


	//{{AFX_MSG(CCCPropertySheet)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CCPROPERTYSHEET_H__D80B1565_B52B_11D1_90AF_000000000000__INCLUDED_)
