// TOSView.h : interface of the CTOSView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TOSVIEW_H__10B67B9A_85D7_11D1_BAA0_006097DA5345__INCLUDED_)
#define AFX_TOSVIEW_H__10B67B9A_85D7_11D1_BAA0_006097DA5345__INCLUDED_

#include "MainFrm.h"	// Added by ClassView
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CMainFrame;

class CTOSView : public CView
{
	
protected: // create from serialization only
	CTOSView();
	DECLARE_DYNCREATE(CTOSView)

// Attributes
public:
	CTOSDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTOSView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	CMainFrame* getMainFrame();
	virtual ~CTOSView();


#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:

	CMainFrame * m_mainFrame;

	//{{AFX_MSG(CTOSView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in TOSView.cpp
inline CTOSDoc* CTOSView::GetDocument()
   { return (CTOSDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TOSVIEW_H__10B67B9A_85D7_11D1_BAA0_006097DA5345__INCLUDED_)
