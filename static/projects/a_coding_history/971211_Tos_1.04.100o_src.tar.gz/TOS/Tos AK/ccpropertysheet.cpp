// CCPropertySheet.cpp : implementation file
//

#include "stdafx.h"
#include "TOS.h"

#include "CCResourceTreeCtrl.H"
#include "TreeBar.h"

#include "CCPictureDlg.h"

#include "CCPropertySheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCCPropertySheet

IMPLEMENT_DYNAMIC(CCCPropertySheet, CPropertySheet)

CCCPropertySheet::CCCPropertySheet(CMainFrame* p_mainFrame)
	:CPropertySheet()
{
	m_mainFrame = p_mainFrame;	
	isActive = FALSE;
	m_numbersOfActivePages = 0;
	m_activeSheet == NONE;
	SetTitle("", PSH_PROPTITLE);

	m_propPagePicture		= NULL;
	m_propPagePictureSize	= NULL;
	m_propPageTile			= NULL;
	m_propPageEmpty			= NULL;
	m_propPageTileLeaf		= NULL;
}

CCCPropertySheet::CCCPropertySheet(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
	isActive = FALSE;
}

CCCPropertySheet::CCCPropertySheet(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
	isActive = FALSE;
}

CCCPropertySheet::~CCCPropertySheet()
{
	isActive = FALSE;
	m_activeSheet = NONE;
	removeAllPages();
}


BEGIN_MESSAGE_MAP(CCCPropertySheet, CPropertySheet)
	//{{AFX_MSG_MAP(CCCPropertySheet)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCCPropertySheet message handlers



BOOL CCCPropertySheet::createSheet(int p_sheet)
{
	if (!isActive)
	{
		isActive = TRUE;

		switch (p_sheet)
		{
		case PROPERTIESPICTUREDLG :
			changeToPropertyPictureDlg();
			break;

		case PROPERTIES_TILE_RESOURCE :
			changeToPropertyTileResource();
			break;

		case PROPERTIES_RESOURCE_TILE_LEAF :
			changeToPropertyResourceTileLeaf();
			break;

		case PROPERTIESNO:
		default :
			changeToPropertyNo();
			break;
		}

		Create((CWnd*)m_mainFrame);
	}	
	return TRUE;
}

int CCCPropertySheet::doModalSheet(int p_sheet)
{
	switch (p_sheet)
	{
	case PROPERTIESPICTUREDLG :
		changeToPropertyPictureDlg();
		break;

	case PROPERTIES_TILE_RESOURCE :
		changeToPropertyTileResource();
		break;

	case PROPERTIES_RESOURCE_TILE_LEAF :
		changeToPropertyResourceTileLeaf();
		break;

	case PROPERTIESNO:
	default :
		changeToPropertyNo();
		break;
	}

	return DoModal();
}


BOOL CCCPropertySheet::changeToPropertyPictureDlg()
{
	if (isActive)
	{
		if (m_activeSheet != PROPERTIESPICTUREDLG)
		{		
			m_activeSheet = PROPERTIESPICTUREDLG;			
			SetTitle("Picture", PSH_PROPTITLE);
			m_propPagePicture		= new CCCPropPagePictureDlg(m_mainFrame);
			m_propPagePictureSize	= new CCCPropPagePictureDlgStyles(m_mainFrame);			

			AddPage(m_propPagePicture);
			AddPage(m_propPagePictureSize);
			m_numbersOfActivePages+2;
			
			removeAllPages();
		}
		else
			updateData();

	}
	return TRUE;
}
BOOL CCCPropertySheet::changeToPropertyTileResource()
{
	if (isActive)
	{
		if (m_activeSheet != PROPERTIES_TILE_RESOURCE)		
		{
			m_activeSheet = PROPERTIES_TILE_RESOURCE;			
			m_propPageTile  = new CCCPropPageTile(m_mainFrame);

			SetTitle("Tile", PSH_PROPTITLE);

			AddPage(m_propPageTile);
			m_numbersOfActivePages++;			
			removeAllPages();			
		}
		else
			updateData();
	}

	return TRUE;
}

BOOL CCCPropertySheet::changeToPropertyResourceTileLeaf()
{
	if (isActive)
	{
		if (m_activeSheet != PROPERTIES_RESOURCE_TILE_LEAF)		
		{
			m_activeSheet = PROPERTIES_RESOURCE_TILE_LEAF;
			m_propPageTileLeaf  = new CCCPropPageResourceTileLeaf(m_mainFrame);

			SetTitle("Tile Leaf", PSH_PROPTITLE);

			AddPage(m_propPageTileLeaf);
			m_numbersOfActivePages++;			
			removeAllPages();			
		}
		else
			updateData();
	}
	return TRUE;
}

BOOL CCCPropertySheet::changeToPropertyNo()
{
	if (isActive)
	{
		if (m_activeSheet != PROPERTIESNO)
		{
			m_activeSheet = PROPERTIESNO;
			m_propPageEmpty  = new CCCPropPageEmpty(m_mainFrame);

			SetTitle("Empty", PSH_PROPTITLE);

			AddPage(m_propPageEmpty);
			m_numbersOfActivePages++;
			removeAllPages();			
		}
		else
			updateData();
	}

	return TRUE;
}


BOOL CCCPropertySheet::DestroyWindow() 
{
//	isActive = FALSE;
//	m_activeSheet = NONE;
//	removeAllPages();
	
	return CPropertySheet::DestroyWindow();
}

BOOL CCCPropertySheet::removeAllPages()
{	
	if ((m_propPagePicture) && (m_activeSheet != PROPERTIESPICTUREDLG))
	{
		RemovePage(m_propPagePicture);
		delete m_propPagePicture;
		m_propPagePicture = NULL;
		m_numbersOfActivePages--;
	}

	if ((m_propPagePictureSize) && (m_activeSheet != PROPERTIESPICTUREDLG))
	{
		RemovePage(m_propPagePictureSize);
		delete m_propPagePictureSize;
		m_propPagePictureSize = NULL;
		m_numbersOfActivePages--;
	};
	

	if ((m_propPageTile) && (m_activeSheet != PROPERTIES_TILE_RESOURCE))
	{
		RemovePage(m_propPageTile);
		delete m_propPageTile;
		m_propPageTile = NULL;
		m_numbersOfActivePages--;
	}

	if ((m_propPageTileLeaf) && (m_activeSheet != PROPERTIES_RESOURCE_TILE_LEAF))
	{
		RemovePage(m_propPageTileLeaf);
		delete m_propPageTileLeaf;
		m_propPageTileLeaf = NULL;
		m_numbersOfActivePages--;
	}


	if ((m_propPageEmpty) && (m_activeSheet != PROPERTIESNO))
	{
		RemovePage(m_propPageEmpty);
		delete m_propPageEmpty;
		m_propPageEmpty = NULL;
		m_numbersOfActivePages--;
	}
	return TRUE;
}	

BOOL CCCPropertySheet::updateData()
{	
	if ((m_propPagePicture) && (m_activeSheet == PROPERTIESPICTUREDLG) && (m_propPagePicture->m_hWnd)) 
	{
		m_propPagePicture->UpdateData(FALSE);		
	}
		
	if ((m_propPagePictureSize) && (m_activeSheet == PROPERTIESPICTUREDLG) && (m_propPagePictureSize->m_hWnd))
	{
		m_propPagePictureSize->UpdateData(FALSE);
	}

	if ((m_propPageTile) && (m_activeSheet == PROPERTIES_TILE_RESOURCE) && (m_propPageTile->m_hWnd))
	{
		m_propPageTile->UpdateData(FALSE);		
	}

	if ((m_propPageTileLeaf) && (m_activeSheet == PROPERTIES_RESOURCE_TILE_LEAF) && (m_propPageTileLeaf->m_hWnd))
	{		

		m_propPageTileLeaf->InitialData();
		m_propPageTileLeaf->UpdateData(FALSE);		
	}

	if ((m_propPageEmpty) && (m_activeSheet == PROPERTIESNO) && (m_propPageEmpty->m_hWnd))
	{		
		m_propPageEmpty->UpdateData(FALSE);		
	}	
	return TRUE;
}

BOOL CCCPropertySheet::doPropPageResourceTileLeafDataModal(CString & p_resourceName, int & p_width, int & p_height)
{
	// Create the Property sheet
	isActive = TRUE;
	m_activeSheet = NONE;

	changeToPropertyResourceTileLeaf();

	// Set default variables

	m_propPageTileLeaf->m_resourceName			= p_resourceName;
	m_propPageTileLeaf->m_height				= p_height;	
	m_propPageTileLeaf->m_width					= p_width;

	m_propPageTileLeaf->m_bModal = TRUE;	
	BOOL bRetVal = DoModal();
	m_propPageTileLeaf->m_bModal = FALSE;

	p_resourceName			= m_propPageTileLeaf->m_resourceName;
	p_height				= m_propPageTileLeaf->m_height;
	p_width					= m_propPageTileLeaf->m_width;

	isActive = FALSE;
	return bRetVal;
}

	/////////////////////////////////////////////////////////////////////////////
	// Name: CCCPropPageEmpty
	// Descrition: This will be shown if no other valid prop dialog i available
	/////////////////////////////////////////////////////////////////////////////





/////////////////////////////////////////////////////////////////////////////
// CCCPropPageResourceTileLeaf message handlers

CCCPropertySheet::CCCPropPageEmpty::CCCPropPageEmpty(CMainFrame * p_mainFrame) 
	: CPropertyPage(CCCPropPageEmpty::IDD)
{
	//{{AFX_DATA_INIT(CCCPropPageEmpty)
	//}}AFX_DATA_INIT
	m_mainFrame = p_mainFrame;
}

CCCPropertySheet::CCCPropPageEmpty::~CCCPropPageEmpty()
{
}

void CCCPropertySheet::CCCPropPageEmpty::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCCPropPageEmpty)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCCPropertySheet::CCCPropPageEmpty, CPropertyPage)
	//{{AFX_MSG_MAP(CCCPropPageEmpty)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()






	/////////////////////////////////////////////////////////////////////////////
	// Name: CCCPropPageTile
	// Descrition: roperties for the Tile Root in the resource dock wnd
	/////////////////////////////////////////////////////////////////////////////






CCCPropertySheet::CCCPropPageTile::CCCPropPageTile(CMainFrame * p_mainFrame) 
	: CPropertyPage(CCCPropPageTile::IDD)
{
	//{{AFX_DATA_INIT(CCCPropPageTile)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_mainFrame = p_mainFrame;
}

CCCPropertySheet::CCCPropPageTile::~CCCPropPageTile()
{
}

void CCCPropertySheet::CCCPropPageTile::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCCPropPageTile)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCCPropertySheet::CCCPropPageTile, CPropertyPage)
	//{{AFX_MSG_MAP(CCCPropPageTile)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()







	/////////////////////////////////////////////////////////////////////////////
	// Name: CCCPropPageResourceTileLeaf
	// Descrition: Properties for the Tile Leaf in the resource dock wnd
	/////////////////////////////////////////////////////////////////////////////

	
	
	
	
	
CCCPropertySheet::CCCPropPageResourceTileLeaf::CCCPropPageResourceTileLeaf(CMainFrame * p_mainFrame) 
	: CPropertyPage(CCCPropPageResourceTileLeaf::IDD)
{
	m_mainFrame = p_mainFrame;
	m_bModal = FALSE;
	//{{AFX_DATA_INIT(CCCPropPageResourceTileLeaf)
	m_resourceName = _T("");
	m_numbersOfTiles = 0;
	m_height = 0;
	m_width = 0;
	//}}AFX_DATA_INIT
}

CCCPropertySheet::CCCPropPageResourceTileLeaf::~CCCPropPageResourceTileLeaf()
{
}

void  CCCPropertySheet::CCCPropPageResourceTileLeaf::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);

	//{{AFX_DATA_MAP(CCCPropPageResourceTileLeaf)
	DDX_Control(pDX, IDC_WIDTH, m_widthCtrl);
	DDX_Control(pDX, IDC_RESOURCE_NAME, m_resourceNameCtrl);
	DDX_Control(pDX, IDC_HEIGHT, m_heightCtrl);
	DDX_Text(pDX, IDC_RESOURCE_NAME, m_resourceName);
	DDX_Text(pDX, IDC_NUMBERS_OF_TILES, m_numbersOfTiles);	
	DDX_Text(pDX, IDC_HEIGHT, m_height);
	DDV_MinMaxInt(pDX, m_height, 1, 10000);
	DDX_Text(pDX, IDC_WIDTH, m_width);
	DDV_MinMaxInt(pDX, m_width, 1, 10000);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCCPropertySheet::CCCPropPageResourceTileLeaf, CPropertyPage)
	//{{AFX_MSG_MAP(CCCPropPageResourceTileLeaf)
	ON_EN_SETFOCUS(IDC_HEIGHT, CCCPropertySheet::CCCPropPageResourceTileLeaf::OnSetFocusHeight)
	ON_EN_SETFOCUS(IDC_WIDTH, CCCPropertySheet::CCCPropPageResourceTileLeaf::OnSetFocusWidth)
	ON_EN_KILLFOCUS(IDC_HEIGHT, CCCPropertySheet::CCCPropPageResourceTileLeaf::OnKillFocusHeight)
	ON_EN_KILLFOCUS(IDC_WIDTH, CCCPropertySheet::CCCPropPageResourceTileLeaf::OnKillFocusWidth)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


void CCCPropertySheet::CCCPropPageResourceTileLeaf::OnSetFocusHeight()
{
}

void CCCPropertySheet::CCCPropPageResourceTileLeaf::OnSetFocusWidth()
{
}

void CCCPropertySheet::CCCPropPageResourceTileLeaf::OnKillFocusHeight()
{
	UpdateData(TRUE);	
	getMGLCtrl()->setTileListSize(m_width, m_height);	
}

void CCCPropertySheet::CCCPropPageResourceTileLeaf::OnKillFocusWidth()
{
	UpdateData(TRUE);	
	getMGLCtrl()->setTileListSize(m_width, m_height);
}

///////////////////////////////7
// Updates the data in the proppage from the CCCMGL obejct
BOOL CCCPropertySheet::CCCPropPageResourceTileLeaf::InitialData() 
{
	if (m_bModal == FALSE)
	{

 		m_resourceName   = *getMGLCtrl()->getTileListResourceName();	
		m_resourceNameCtrl.EnableWindow(FALSE);
		m_numbersOfTiles = getMGLCtrl()->getTileListCurrentNumOfTiles();

		int l_height = getMGLCtrl()->getTileListSize()->cy;
		m_heightCtrl.EnableWindow(FALSE);
		m_height = l_height;

		int l_width = getMGLCtrl()->getTileListSize()->cx;
		m_widthCtrl.EnableWindow(FALSE);
		m_width = l_width;
		UpdateData(FALSE);	
	}

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


	/////////////////////////////////////////////////////////////////////////////
	// Name: CCCPropPagePictureDlg
	// Descrition: General Properties for the CutFrom CCCPictureDlg
	/////////////////////////////////////////////////////////////////////////////






CCCPropertySheet::CCCPropPagePictureDlg::CCCPropPagePictureDlg(CMainFrame * p_mainFrame) 
	: CPropertyPage(CCCPropPagePictureDlg::IDD)
{
	m_mainFrame = p_mainFrame;
	//{{AFX_DATA_INIT(CCCPropPagePictureDlg)
	m_fileName = _T("");
	m_width = 0;
	m_height = 0;
	//}}AFX_DATA_INIT
}

CCCPropertySheet::CCCPropPagePictureDlg::~CCCPropPagePictureDlg()
{
}

void CCCPropertySheet::CCCPropPagePictureDlg::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	m_fileName = *m_mainFrame->m_pictureDlg->getFileName();
	CRect l_rect = *m_mainFrame->m_pictureDlg->getSize();
	m_height = l_rect.Height();
	m_width  = l_rect.Width();
	
	//{{AFX_DATA_MAP(CCCPropPagePictureDlg)	
	DDX_Text(pDX, IDC_FILE_NAME, m_fileName);
	DDX_Text(pDX, IDC_WIDTH, m_width);
	DDX_Text(pDX, IDC_HEIGHT, m_height);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCCPropertySheet::CCCPropPagePictureDlg, CPropertyPage)
	//{{AFX_MSG_MAP(CCCPropPagePictureDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()






	/////////////////////////////////////////////////////////////////////////////
	// Name: CCCPropPagePictureDlgStyles
	// Descrition: Styles Properties for the CutFrom CCCPictureDlg
	/////////////////////////////////////////////////////////////////////////////






CCCPropertySheet::CCCPropPagePictureDlgStyles::CCCPropPagePictureDlgStyles(CMainFrame * p_mainFrame)
	 : CPropertyPage(CCCPropPagePictureDlgStyles::IDD)
{
	m_mainFrame = p_mainFrame;
	//{{AFX_DATA_INIT(CCCPropPagePictureDlgStyles)
	//}}AFX_DATA_INIT
}

CCCPropertySheet::CCCPropPagePictureDlgStyles::~CCCPropPagePictureDlgStyles()
{
}

void CCCPropertySheet::CCCPropPagePictureDlgStyles::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCCPropPagePictureDlgStyles)
	DDX_Control(pDX, IDC_POSX, m_posXCtrl);
	DDX_Control(pDX, IDC_POSY, m_posYCtrl);
	DDX_Control(pDX, IDC_WIDTH, m_widthCtrl);
	DDX_Control(pDX, IDC_HEIGHT, m_heightCtrl);
	DDX_Check(pDX, IDC_GRID, m_mainFrame->m_pictureDlg->m_isGrid);
	DDX_Text(pDX, IDC_WIDTH, m_mainFrame->m_pictureDlg->m_gridWidth);
	DDX_Text(pDX, IDC_HEIGHT, m_mainFrame->m_pictureDlg->m_gridHeight);
	DDX_Text(pDX, IDC_POSX, m_mainFrame->m_pictureDlg->m_gridX);
	DDX_Text(pDX, IDC_POSY, m_mainFrame->m_pictureDlg->m_gridY);

	//}}AFX_DATA_MAP

	m_posXCtrl.EnableWindow(m_mainFrame->m_pictureDlg->m_isGrid);
	m_posYCtrl.EnableWindow(m_mainFrame->m_pictureDlg->m_isGrid);	
	m_widthCtrl.EnableWindow(m_mainFrame->m_pictureDlg->m_isGrid);
	m_heightCtrl.EnableWindow(m_mainFrame->m_pictureDlg->m_isGrid);	

}


BEGIN_MESSAGE_MAP(CCCPropertySheet::CCCPropPagePictureDlgStyles, CPropertyPage)
	//{{AFX_MSG_MAP(CCCPropPagePictureDlgStyles)
	ON_BN_CLICKED(IDC_GRID, CCCPropertySheet::CCCPropPagePictureDlgStyles::OnGrid)
	ON_EN_CHANGE(IDC_POSX, CCCPropertySheet::CCCPropPagePictureDlgStyles::OnChangePosX)
	ON_EN_CHANGE(IDC_POSY, CCCPropertySheet::CCCPropPagePictureDlgStyles::OnChangePosY)
	ON_EN_CHANGE(IDC_WIDTH, CCCPropertySheet::CCCPropPagePictureDlgStyles::OnChangeWidth)
	ON_EN_CHANGE(IDC_HEIGHT, CCCPropertySheet::CCCPropPagePictureDlgStyles::OnChangeHeight)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCCPropPagePictureDlgStyles message handlers

void CCCPropertySheet::CCCPropPagePictureDlgStyles::OnGrid() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_posXCtrl.EnableWindow(m_mainFrame->m_pictureDlg->m_isGrid);
	m_posYCtrl.EnableWindow(m_mainFrame->m_pictureDlg->m_isGrid);	
	m_widthCtrl.EnableWindow(m_mainFrame->m_pictureDlg->m_isGrid);
	m_heightCtrl.EnableWindow(m_mainFrame->m_pictureDlg->m_isGrid);	
		
	m_mainFrame->m_pictureDlg->updateGrid();
	m_mainFrame->m_pictureDlg->Invalidate();
}

void CCCPropertySheet::CCCPropPagePictureDlgStyles::OnChangeWidth() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CPropertyPage::OnInitDialog()
	// function to send the EM_SETEVENTMASK message to the control
	// with the ENM_CHANGE flag ORed into the lParam mask.
	
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);		
		
	m_mainFrame->m_pictureDlg->updateGrid();
	m_mainFrame->m_pictureDlg->Invalidate();
}

void CCCPropertySheet::CCCPropPagePictureDlgStyles::OnChangeHeight() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CPropertyPage::OnInitDialog()
	// function to send the EM_SETEVENTMASK message to the control
	// with the ENM_CHANGE flag ORed into the lParam mask.
	
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);	
	m_mainFrame->m_pictureDlg->updateGrid();
	m_mainFrame->m_pictureDlg->Invalidate();
}

void CCCPropertySheet::CCCPropPagePictureDlgStyles::OnChangePosX() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CPropertyPage::OnInitDialog()
	// function to send the EM_SETEVENTMASK message to the control
	// with the ENM_CHANGE flag ORed into the lParam mask.
	
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);	
	m_mainFrame->m_pictureDlg->updateGrid();
	m_mainFrame->m_pictureDlg->Invalidate();
}

void CCCPropertySheet::CCCPropPagePictureDlgStyles::OnChangePosY() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CPropertyPage::OnInitDialog()
	// function to send the EM_SETEVENTMASK message to the control
	// with the ENM_CHANGE flag ORed into the lParam mask.
	
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);	
	m_mainFrame->m_pictureDlg->updateGrid();
	m_mainFrame->m_pictureDlg->Invalidate();
}
