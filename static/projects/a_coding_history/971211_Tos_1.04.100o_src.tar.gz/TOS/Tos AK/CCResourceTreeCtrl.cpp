// CCResourceTreeCtrl.cpp : implementation file
//


#include "stdafx.h"
#include "tos.h"
#include "TOSDoc.h"

#include "CCResourceTreeCtrl.h"
#include "treebar.h"
#include "CCCutFromDlg.h"
#include "CCPictureDlg.h"

#include "CCPropertySheet.h"

#include "mainfrm.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CCCResourceTreeCtrl

CCCResourceTreeCtrl::CCCResourceTreeCtrl(CMainFrame * p_mainFrame)
{

	
	m_TileListResourceCounter = 1;
	m_MultiTileMapListResourceCounter = 1;
	m_AnimatedSpriteListResourceCounter = 1;


	m_mainFrame = p_mainFrame;

	DWORD dwStyle = WS_BORDER | WS_CHILD | TVS_HASLINES | TVS_HASBUTTONS | TVS_LINESATROOT | TVS_EDITLABELS | TVS_SHOWSELALWAYS ;
	// Create "Resources" Tree control
	
    if (!Create(dwStyle, CRect(0,0,0,0), (CWnd*)getMainFrame()->m_treeBarWnd, 1))
		MessageBox("failed to create tree control", "Error", NULL);      // failed to create tree control

    ModifyStyleEx(0, WS_EX_CLIENTEDGE);
    
	InitializeTreeCtrl();	// insert some items into the tree control.
	
}

CCCResourceTreeCtrl::~CCCResourceTreeCtrl()
{
}


BEGIN_MESSAGE_MAP(CCCResourceTreeCtrl, CTreeCtrl)
	//{{AFX_MSG_MAP(CCCResourceTreeCtrl)
	ON_WM_RBUTTONDOWN()
	ON_NOTIFY_REFLECT(TVN_ENDLABELEDIT, OnEndlabeledit)
	ON_NOTIFY_REFLECT(TVN_BEGINLABELEDIT, OnBeginlabeledit)
	ON_NOTIFY_REFLECT(NM_DBLCLK, OnDblclk)
	ON_WM_LBUTTONDBLCLK()
	ON_WM_LBUTTONDOWN()
	ON_NOTIFY_REFLECT(TVN_SELCHANGED, OnSelchanged)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCCResourceTreeCtrl message handlers

void CCCResourceTreeCtrl::OnRButtonDown(UINT nFlags, CPoint point) 
{
	//Code Moved to pretranslateMessage

}

LONG CCCResourceTreeCtrl::OnAddContextMenuItems(WPARAM wParam, LPARAM lParam, CPoint point)
{
	point.y -=6;												// TODO; get the modal rect width,,,

	UINT* pFlags;
	pFlags = new UINT;
	HTREEITEM hTreeItem = HitTest(point, pFlags);

	
	if (hTreeItem != NULL)
	{
		SelectItem(hTreeItem);
	}

	hTreeItem = GetSelectedItem();
	if (hTreeItem != NULL)
	{
		HMENU hMenu = (HMENU)lParam;		// handle of menu.
		CMenu menu;
		menu.Attach(hMenu);
		
		switch (LOWORD(GetItemData(hTreeItem)))
		{
		case IDCC_RESOURCE_ROOT				  :
			menu.AppendMenu(MF_STRING, IDM_ADD_TILE_LIST, CString("Add Tile List"));
			menu.AppendMenu(MF_STRING, IDM_ADD_MTM_LIST, CString("Add Multi Tile Map List"));
			menu.AppendMenu(MF_STRING, IDM_ADD_ANIMATED_SPRITE_LIST, CString("Add Animated Sprite List"));				
			menu.AppendMenu(MF_SEPARATOR, IDM_SEPARATOR);
			break;

		case IDCC_ANIMATED_SPRITE_LIST_ROOT   :
			menu.AppendMenu(MF_STRING, IDM_ADD_ANIMATED_SPRITE_LIST, CString("Add Animated Sprite List"));		
			menu.AppendMenu(MF_SEPARATOR, IDM_SEPARATOR);
			break;

		case IDCC_ANIMATED_SPRITE_LIST_LEAF   :
			break;

		case IDCC_MTM_LIST_ROOT               :
			menu.AppendMenu(MF_STRING, IDM_ADD_MTM_LIST, CString("Add Multi Tile Map List"));
			menu.AppendMenu(MF_SEPARATOR, IDM_SEPARATOR);
			break;

		case IDCC_MTM_LIST_LEAF               :
			break;
			
		case IDCC_TILE_LIST_ROOT              :
			menu.AppendMenu(MF_STRING, IDM_ADD_TILE_LIST, CString("Add Tile List"));		
			menu.AppendMenu(MF_SEPARATOR, IDM_SEPARATOR);
			break;

		case IDCC_TILE_LIST_LEAF              :
			break;

		}	
		menu.Detach();	// detatch MFC object
		return FALSE;
	}
	else
		return TRUE;
}

//
// Take care of the menu commands,,
//
BOOL CCCResourceTreeCtrl::CCOnCommand(WPARAM wParam)
{
	switch (LOWORD(wParam))
	{
	
	case IDM_ADD_TILE_LIST :
		{


			char cBuffer[5];
			itoa(m_TileListResourceCounter, cBuffer, 10);
			CString	l_resourceName			= CString("TileList") + cBuffer;			
			int    	l_height				= 32;
			int    	l_width					= 32;

			CCCPropertySheet oPropertySheet(getMainFrame());
			if (oPropertySheet.doPropPageResourceTileLeafDataModal(l_resourceName, l_height, l_width) == IDOK)
			{	
				m_TileListResourceCounter++;

				HTREEITEM hNewLeaf = InsertItem(l_resourceName, hTilesListRoot);
				Expand(hTilesListRoot, TVE_EXPAND);				
				SelectItem(hNewLeaf);
				SetItemData(hNewLeaf, IDCC_TILE_LIST_LEAF + (m_TileListResourceCounter * 65536));

				getMainFrame()->m_mglCtrl->addTileList( &l_resourceName, &l_width, &l_height);				
				for (int i = 0; i<150;i++)
					getMainFrame()->m_mglCtrl->addTile(&l_resourceName);				
				getMainFrame()->m_mglCtrl->setActiveTileList( &GetItemText( GetSelectedItem()) );
				
				changePropertyPage();	// First time change the property page...,
				changePropertyPage();	// Secend initialize it with proper data..
			}
		}
		break;

	case IDM_ADD_MTM_LIST :
		{
            char cBuffer[5];
			itoa(m_MultiTileMapListResourceCounter, cBuffer, 10);
			m_MultiTileMapListResourceCounter++;


			HTREEITEM hNewLeaf = InsertItem(CString("MTMList") + cBuffer, hMultiTileMapListRoot);
			Expand(hMultiTileMapListRoot, TVE_EXPAND);
			EditLabel(hNewLeaf);			
			SelectItem(hNewLeaf);
			SetItemData(hNewLeaf, IDCC_MTM_LIST_LEAF  + (m_MultiTileMapListResourceCounter * 65536));
		}
		break;

	case IDM_ADD_ANIMATED_SPRITE_LIST :
		{
            char cBuffer[5];
			itoa(m_AnimatedSpriteListResourceCounter, cBuffer, 10);
			m_AnimatedSpriteListResourceCounter++;


			HTREEITEM hNewLeaf = InsertItem(CString("AnimatedSprite") + cBuffer, hAnimatedSpriteListRoot);
			Expand(hAnimatedSpriteListRoot, TVE_EXPAND);
			EditLabel(hNewLeaf);		
			SelectItem(hNewLeaf);
			SetItemData(hNewLeaf, IDCC_ANIMATED_SPRITE_LIST_LEAF + (m_AnimatedSpriteListResourceCounter * 65536));
		}
		break;

	case IDM_PROPERTIES :
		HTREEITEM hTreeItem;

		hTreeItem = GetSelectedItem();
		
		if (hTreeItem)
			switch (LOWORD(GetItemData(hTreeItem)))
			{		
			case IDCC_RESOURCE_ROOT				  :
			case IDCC_ANIMATED_SPRITE_LIST_ROOT   :
			case IDCC_ANIMATED_SPRITE_LIST_LEAF   :
			case IDCC_MTM_LIST_ROOT               :
			case IDCC_MTM_LIST_LEAF               : 
				getMainFrame()->m_propertySheet->createSheet(PROPERTIESNO);
				break;
			case IDCC_TILE_LIST_ROOT              :
				getMainFrame()->m_propertySheet->createSheet(PROPERTIES_TILE_RESOURCE);
				break;

			case IDCC_TILE_LIST_LEAF              :
				getMainFrame()->m_propertySheet->createSheet(PROPERTIES_RESOURCE_TILE_LEAF);
				break;



			default :
				getMainFrame()->m_propertySheet->createSheet(PROPERTIESNO);
			}
		else
			getMainFrame()->m_propertySheet->createSheet(PROPERTIESNO);
		break;
	}	
	return FALSE;
}

BOOL CCCResourceTreeCtrl::changePropertyPage()
{
	HTREEITEM hTreeItem;// = HitTest(point, &nFlags);

	hTreeItem = GetSelectedItem();
	if (hTreeItem)
		switch (LOWORD(GetItemData(hTreeItem)))
		{		

		case IDCC_RESOURCE_ROOT				  :
			getMainFrame()->m_propertySheet->changeToPropertyNo();
			break;

		case IDCC_ANIMATED_SPRITE_LIST_ROOT   :
			getMainFrame()->m_propertySheet->changeToPropertyNo();
			break;

		case IDCC_ANIMATED_SPRITE_LIST_LEAF   :
			getMainFrame()->m_propertySheet->changeToPropertyNo();
			break;

		case IDCC_MTM_LIST_ROOT               :
			getMainFrame()->m_propertySheet->changeToPropertyNo();
			break;

		case IDCC_MTM_LIST_LEAF               : 
			getMainFrame()->m_propertySheet->changeToPropertyNo();
			break;

		case IDCC_TILE_LIST_ROOT              :
			getMainFrame()->m_propertySheet->changeToPropertyTileResource();
			break;

		case IDCC_TILE_LIST_LEAF              :
			getMainFrame()->m_propertySheet->changeToPropertyResourceTileLeaf();
			break;

		default :
			getMainFrame()->m_propertySheet->changeToPropertyNo();
			break;
		}
	else
		getMainFrame()->m_propertySheet->changeToPropertyNo();

	return TRUE;
}

//
// Set the new name to the leaf
//

void CCCResourceTreeCtrl::OnEndlabeledit(NMHDR* pNMHDR, LRESULT* pResult) 
{
	TV_DISPINFO		*ptvinfo;

	ptvinfo = (TV_DISPINFO *)pNMHDR;

	if (ptvinfo->item.pszText != NULL)
	{
		ptvinfo->item.mask = TVIF_TEXT;
		SetItem(&ptvinfo->item);
	}
	*pResult = TRUE;
}

//
// Disable the possiblity to rename the root leafs of the tree.
//
void CCCResourceTreeCtrl::OnBeginlabeledit(NMHDR* pNMHDR, LRESULT* pResult) 
{	
	TV_DISPINFO* pTVDispInfo = (TV_DISPINFO*)pNMHDR;

	switch (LOWORD(GetItemData(pTVDispInfo->item.hItem)))
	{		

	case IDCC_RESOURCE_ROOT :
		*pResult = 1;
		break;

	case IDCC_ANIMATED_SPRITE_LIST_ROOT   :
		*pResult = 1;
		break;

	case IDCC_ANIMATED_SPRITE_LIST_LEAF   :
		*pResult = 0;
		break;

	case IDCC_MTM_LIST_ROOT               :
		*pResult = 1;
		break;

	case IDCC_MTM_LIST_LEAF               : 
		*pResult = 0;
		break;

	case IDCC_TILE_LIST_ROOT              :
		*pResult = 1;
		break;

	case IDCC_TILE_LIST_LEAF              :
		*pResult = 0;
		break;
	}		
}

void CCCResourceTreeCtrl::OnDblclk(NMHDR* pNMHDR, LRESULT* pResult) 
{		
	*pResult = 0;
}


void CCCResourceTreeCtrl::OnLButtonDblClk(UINT nFlags, CPoint point) 
{

	switch (LOWORD(GetItemData(GetSelectedItem())))
	{		

	case IDCC_RESOURCE_ROOT				  :
		break;
	case IDCC_TILE_LIST_ROOT              :
	case IDCC_TILE_LIST_LEAF              :
		getMainFrame()->setLayoutStyle(DO_TILE_LIST_MODE);
		break;

	case IDCC_MTM_LIST_ROOT               :
	case IDCC_MTM_LIST_LEAF               :
		getMainFrame()->setLayoutStyle(DO_MTM_MODE);
		break;

	case IDCC_ANIMATED_SPRITE_LIST_ROOT   :
	case IDCC_ANIMATED_SPRITE_LIST_LEAF   :
		break;
	}	


	
	CTreeCtrl::OnLButtonDblClk(nFlags, point);
}

CMainFrame * CCCResourceTreeCtrl::getMainFrame()
{
	ASSERT(m_mainFrame);
	return m_mainFrame;
}

void CCCResourceTreeCtrl::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	switch (LOWORD(GetItemData(GetSelectedItem())))
	{		

	case IDCC_RESOURCE_ROOT				  :
		break;
	case IDCC_TILE_LIST_ROOT              :
		break;
	case IDCC_TILE_LIST_LEAF              :
	getMainFrame()->m_mglCtrl->setActiveTileList( &GetItemText( GetSelectedItem()) );	
		break;

	case IDCC_MTM_LIST_ROOT               :
	case IDCC_MTM_LIST_LEAF               :
	case IDCC_ANIMATED_SPRITE_LIST_ROOT   :
	case IDCC_ANIMATED_SPRITE_LIST_LEAF   :
		break;
	}	


	CTreeCtrl::OnLButtonDown(nFlags, point);

	// Change all mouse clicked tree resources
	changePropertyPage();
}

void CCCResourceTreeCtrl::OnSelchanged(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	
	// Change all keyboard selected tree resources,,,
	getMainFrame()->m_mglCtrl->setActiveTileList( &GetItemText( GetSelectedItem()) );
	changePropertyPage();

	*pResult = 0;
}

BOOL CCCResourceTreeCtrl::InitializeTreeCtrl()
{

    hResourceTreeCtrlRoot = InsertItem( _T("Resources") );	
	SetItemData(hResourceTreeCtrlRoot, IDCC_RESOURCE_ROOT);
    
	hTilesListRoot = InsertItem(CString("Tiles") , hResourceTreeCtrlRoot);
	SetItemData(hTilesListRoot, IDCC_TILE_LIST_ROOT);

	hMultiTileMapListRoot = InsertItem(CString("Multi Tile Map") , hResourceTreeCtrlRoot);
	SetItemData(hMultiTileMapListRoot, IDCC_MTM_LIST_ROOT);

	hAnimatedSpriteListRoot = InsertItem(CString("Animated Sprites") , hResourceTreeCtrlRoot);    
	SetItemData(hAnimatedSpriteListRoot, IDCC_ANIMATED_SPRITE_LIST_ROOT);

	Expand(hResourceTreeCtrlRoot, TVE_EXPAND);

	SelectItem(hResourceTreeCtrlRoot);
	return TRUE;
}
