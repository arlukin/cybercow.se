UpdateWorkSpaceView()
{

   POSITION pos = GetFirstViewPosition();
   while (pos != NULL)
   {
      CView* pView = GetNextView(pos);
	  if (pView->IsKindOf(RUNTIME_CLASS(CWorkSpaceView))
	  {
		pView->UpdateWindow();
		return
	  }
   }
}



	CWorkSpaceView* poWorkSpaceView = ((CWorkSpaceView*)m_wndSplitter.GetPane (0,0));	












	CTOSDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	// Vilken typ av resource ska anv�ndas... Efter valet i TreeView:n....
	switch (pDoc->m_aktivRoot)
	{
	case 0: // TosFile
		break;

	case 1000: // Tiles List				
		break;

	case 1010: // Tiles List
		getTile();	
		break;

	case 2000: // Multi Tile Map		
		break;

	case 2010: // Multi Tile Map		
		break;

	case 3000:	// Sprite	
		break;

	case 3010:	// Sprite		
		break;
	default :	// Error should never come to this....
		break;
	}










//***********************************************************************
// Function: CDynaMDIChildWnd::RefreshColorMenu()
//
// Purpose:
//    RefreshColorMenu updates the Color submenu so that it only
//    contains the text colors which are enabled for the active document.
//
//    The Color submenu is located by searching for a submenu with
//    ID_COLOR_OPTIONS as its first menu item.
//
// Parameters:
//    none
//
// Returns:
//    none
//
// Comments:
//    none
//
//***********************************************************************
void CMainFrame::RefreshColorMenu()
{
	// Get the active document
	CTOSDoc* pDoc = (CTOSDoc*)GetActiveDocument();
	ASSERT_KINDOF(CTOSDoc, pDoc);

	// Locate the color submenu
	CMenu* pColorMenu = NULL;
	CMenu* pTopMenu = AfxGetMainWnd()->GetMenu();
	int iPos;
	for (iPos = pTopMenu->GetMenuItemCount()-1; iPos >= 0; iPos--)
	{
		CMenu* pMenu = pTopMenu->GetSubMenu(iPos);
		if (pMenu && pMenu->GetMenuItemID(0) == ID_COLOR_OPTIONS)
		{
			pColorMenu = pMenu;
			break;
		}
	}
	ASSERT(pColorMenu != NULL);

	// Update the color submenu to reflect the text colors available to
	// the active document

	// First, delete all items but ID_COLOR_OPTIONS at position 0
	for (iPos = pColorMenu->GetMenuItemCount()-1; iPos > 0; iPos--)
		pColorMenu->DeleteMenu(iPos, MF_BYPOSITION);

	// Then, add a separator and an item for each available text color
	BOOL bNeedSeparator = TRUE;
	for (int i = 0; i < NUM_TEXTCOLOR; i++)
	{
		if (pDoc->m_abAllowColor[i] == TRUE)
		{
			if (bNeedSeparator)
			{
				pColorMenu->AppendMenu(MF_SEPARATOR);
				bNeedSeparator = FALSE;
			}
			CString strColor;
			strColor.LoadString(pDoc->m_aColorDef[i].m_nString);
			pColorMenu->AppendMenu(MF_STRING,
				pDoc->m_aColorDef[i].m_nID, strColor);
		}
	}
}