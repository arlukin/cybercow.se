
/*
   FILE: GRAPHIX.C

   COMMENT: Graphix functions, not object oriented.

   CODER: ThE sHaDdOw

   DATE:  96-03-19 19:31 first editing
          96-03-19 19:31 last editing

   COMPILERS: Watcom 10.0



Copyright (C), 1995 CyBeR tEcH

                                 HISTORY:
DATE     TIME  VERSION COMMENT
96-03-19 19:31 0.01    Get generel graphix files.
*/

//��������������������������� Pragma direcives ���������������������������

//��������������������������� Include files ������������������������������
#include <stdio.h>
#include <stdlib.h>
#include "mgraph.h"
#include "graphix.h"
#include "error.h"
//��������������������������� Data Structures ����������������������������

//��������������������������� Function Prototypes ������������������������
PRIVATE void InitFatalError(void);
MGLDC *InitGraphics(int modeNum);
//�����������������������������  Functions �������������������������������

//-------------------------------------------------------------------
// FUNCTION:  InitFatalError
// DESCRIPTION: Write out an error message and exit the program.
// PARAMS: None
//
// RETURNS: None
// SIDEKICKS: None
// NOTES: None
//-------------------------------------------------------------------

PRIVATE void InitFatalError(void)
/*=============================*/
{
    char    buf[80];
    sprintf(buf,"Graphics error: %s\n",MGL_errorMsg(MGL_result()));
    MGL_fatalError(buf);
}

//-------------------------------------------------------------------
// FUNCTION: InitGraphics
// DESCRIPTION: Initialises the MGL and creates an appropriate display
//              device context to be used by the GUI. This creates and
//              apropriate device context depending on the system being
//              compile for, and should be the only place where system
//              specific code is required.
// PARAMS: modeNum - Video mode number to start
//
// RETURNS: Pointer to the MGL device context to use for the application
// SIDEKICKS: None
// NOTES: None
//-------------------------------------------------------------------

MGLDC *InitGraphics(int modeNum)
/*==============================*/
{
    MGLDC   *dc;

    /* Start the MGL and create a display device context */
    MGL_registerAllDispDrivers(useLinear);
    MGL_registerAllMemDrivers();
    if (!MGL_init(&driver,&modeNum,""))
        InitFatalError();
    if ((dc = MGL_createDisplayDC(false)) == NULL)
        InitFatalError();
    MGL_makeCurrentDC(dc);

    /* Turn off identity palette checking for maximum speed */
    MGL_checkIdentityPalette(false);
    return dc;
}

//-------------------------------------------------------------------
// FUNCTION: Draw
// DESCRIPTION: Draw an integer string on screen
// PARAMS: (int x, int y, int number)
//
// RETURNS: None
// SIDEKICKS: None
// NOTES: None
//-------------------------------------------------------------------

void Draw(int x, int y, int number)
/*===============================*/
{
attributes_t *backup_attributes;
    backup_attributes = new attributes_t;
    MGL_getAttributes( backup_attributes );

font_t *text_font;
    /* Load the font for name bar */
    text_font = MGL_loadFont("helv13.fnt");
    if (text_font == NULL)
    {
       char    buf[80];
       sprintf(buf,"Font doesn�t exist: \n");
       MGL_fatalError(buf);
    };


   if (!MGL_useFont(text_font))
      {
         char    buf[80];
         sprintf(buf,"Font doesn�t exist: \n");
         MGL_fatalError(buf);
      };

MGL_setColor(0);
   MGL_fillRectCoord(x,y,x+100,y+10);

MGL_setColor(0x20);
char buffer[20];
   MGL_drawStrXY(x, y,itoa(number, buffer, 10));
   MGL_restoreAttributes(backup_attributes);
};

//-------------------------------------------------------------------
// FUNCTION: LoadBitmapIntoMemDC
// DESCRIPTION: Loads the specified bitmap into a memory DC with the
//              same dimensions as the bitmap on disk, but with the same
//              pixel depth and format used by the display DC (for maximum
//              blt performance). The MGL automatically handles pixel
//              format conversion for us when we load the bitmap into our
//              memory DC.
// PARAMS: dc          - Display dc
//         bitmapName  - Name of bitmap file to load
//
// RETURNS: Pointer to valid memory DC with bitmap loaded
// SIDEKICKS: None
// NOTES: None
//-------------------------------------------------------------------

MGLDC *LoadBitmapIntoMemDc(MGLDC *dc,char *bitmapName)
/*==================================================*/
{
    palette_t       pal[256];
    int             width,height,bitsPerPixel;
    pixel_format_t  pf;
    MGLDC           *memDC;

    /* Get dimensions of bitmap image on disk */
    if (!MGL_getBitmapSize(bitmapName,&width,&height,&bitsPerPixel,&pf)) {
        MGL_exit();
        printf("Graphics error: %s\n",MGL_errorMsg(MGL_result()));
        exit(1);
        }

    /* Load into Memory DC with same pixel depth and format as the display */
    bitsPerPixel = MGL_getBitsPerPixel(dc);
    MGL_getPixelFormat(dc,&pf);

    /* Create the memory DC and load the bitmap file into it */
    if ((memDC = MGL_createMemoryDC(width,height,bitsPerPixel,&pf)) == NULL) {
        MGL_exit();
        printf("Not enough memory to load bitmap!\n");
        exit(1);
        }
    if (!MGL_loadBitmapIntoDC(memDC,bitmapName,0,0,true)) {
        MGL_exit();
        printf("\nGraphics error: %s\n",MGL_errorMsg(MGL_result()));
        exit(1);
        }

    /* If this is an 8 bits per pixel video mode, then set the physical
     * palette to that used by the bitmap we just loaded
     */
    if (MGL_getBitsPerPixel(dc) == 8) {
        MGL_getPalette(memDC,pal,MGL_getPaletteSize(memDC),0);
        MGL_setPalette(dc,pal,MGL_getPaletteSize(memDC),0);
        MGL_realizePalette(dc,MGL_getPaletteSize(memDC),0,true);
        }

    return memDC;
};

//-------------------------------------------------------------------
// FUNCTION: FileAvailable
// DESCRIPTION: Check if the file exist, if don�t show an eerror mesage.
// PARAMS: char *filename
//
// RETURNS: true if exist.
// SIDEKICKS: None
// NOTES: None
//-------------------------------------------------------------------

bool FileAvailable(char* file)
/*==========================*/

{
   if (MGL_availableBitmap(file))
      return TRUE;

   char    buf[80];
   sprintf(buf,"Cant�t find file: %s.", file);
   class error c_error(buf);
   c_error.Main();
   return FALSE;
};

//-------------------------------------------------------------------
// FUNCTION: SaveScreen
// DESCRIPTION:
// PARAMS: None
//
// RETURNS: None
// SIDEKICKS: None
// NOTES: None
//-------------------------------------------------------------------

void SaveScreen( char *filename )
/*=============================*/

{
   MGL_saveBitmapFromDC(dc, filename, 0,0,639,479);
};
