<?php
/**
* Unit test for all functions in Array.php.
*
*	@author Daniel Lindh <daniel@fareoffice.com>
* @ingroup unittests
*/
class utArray extends foUnitTestBase
{
	public function doTest()
	{
		$this->_testArray();
	}

	private function _testArray()
	{
		$this->setSectionLabel('getHtmlArray');

		$arr = array();
		$arr['contact']['first_name'] = 'Daniel';
		$arr['contact']['last_name'] = 'Lindh';
		$arr['contact']['address'] = '';
		$arr['contact']['age'] = 32;
		$arr['contact']['parent_contact'] = NULL;
		$arr['contact']['has_icq'] = false;
		$arr['contact']['phone_numbers'] = array();
		$arr['orders'][0]['id'] = 32;
		$arr['orders'][0]['description'] = 'Honda Fireblade 929 - 99';
		$arr['orders'][0]['price'] = '45000';
		$arr['orders'][0]['currency'] = 'SEK';
		$arr['orders'][1]['id'] = 33;
		$arr['orders'][1]['description'] = 'Computer';
		$arr['orders'][1]['price'] = '2000';
		$arr['orders'][1]['currency'] = 'SEK';

		eval($this->needEqual('getHtmlArray($arr)', '"<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\"><tr><td colspan=\"4\">Count:0</td></tr><tr><td>key</td><td>value</td><td>type</td><td>size</td></tr><tr><td>contact</td><td colspan=\"3\"><table border=\"1\" cellspacing=\"0\" cellpadding=\"3\"><tr><td colspan=\"4\">Count:0</td></tr><tr><td>key</td><td>value</td><td>type</td><td>size</td></tr><tr><td>first_name</td><td>Daniel</td><td>string</td><td>6</td></tr><tr><td>last_name</td><td>Lindh</td><td>string</td><td>5</td></tr><tr><td>address</td><td>EMPTY</td><td>string</td><td>0</td></tr><tr><td>age</td><td>32</td><td>integer</td><td>1</td></tr><tr><td>parent_contact</td><td>NULL</td><td>NULL</td><td>0</td></tr><tr><td>has_icq</td><td>FALSE</td><td>boolean</td><td>1</td></tr><tr><td>phone_numbers</td><td colspan=\"3\"><table border=\"1\" cellspacing=\"0\" cellpadding=\"3\"><tr><td colspan=\"4\">Count:0</td></tr><tr><td>key</td><td>value</td><td>type</td><td>size</td></tr></table></td></tr></table></td></tr><tr><td>orders</td><td colspan=\"3\"><table border=\"1\" cellspacing=\"0\" cellpadding=\"3\"><tr><td colspan=\"4\">Count:0</td></tr><tr><td>key</td><td>value</td><td>type</td><td>size</td></tr><tr><td>0</td><td colspan=\"3\"><table border=\"1\" cellspacing=\"0\" cellpadding=\"3\"><tr><td colspan=\"4\">Count:0</td></tr><tr><td>key</td><td>value</td><td>type</td><td>size</td></tr><tr><td>id</td><td>32</td><td>integer</td><td>1</td></tr><tr><td>description</td><td>Honda Fireblade 929 - 99</td><td>string</td><td>24</td></tr><tr><td>price</td><td>45000</td><td>string</td><td>5</td></tr><tr><td>currency</td><td>SEK</td><td>string</td><td>3</td></tr></table></td></tr><tr><td>1</td><td colspan=\"3\"><table border=\"1\" cellspacing=\"0\" cellpadding=\"3\"><tr><td colspan=\"4\">Count:0</td></tr><tr><td>key</td><td>value</td><td>type</td><td>size</td></tr><tr><td>id</td><td>33</td><td>integer</td><td>1</td></tr><tr><td>description</td><td>Computer</td><td>string</td><td>8</td></tr><tr><td>price</td><td>2000</td><td>string</td><td>4</td></tr><tr><td>currency</td><td>SEK</td><td>string</td><td>3</td></tr></table></td></tr></table></td></tr></table>"'));
		eval($this->needEqual('getHtmlArrayPhp($arr)', '"array<br/>(<br/>&nbsp;&nbsp;\'contact\' => array<br/>&nbsp;&nbsp;(<br/>&nbsp;&nbsp;&nbsp;&nbsp;\'first_name\' => \'Daniel\',<br/>&nbsp;&nbsp;&nbsp;&nbsp;\'last_name\' => \'Lindh\',<br/>&nbsp;&nbsp;&nbsp;&nbsp;\'address\' => \'\',<br/>&nbsp;&nbsp;&nbsp;&nbsp;\'age\' => 32,<br/>&nbsp;&nbsp;&nbsp;&nbsp;\'parent_contact\' => NULL,<br/>&nbsp;&nbsp;&nbsp;&nbsp;\'has_icq\' => FALSE,<br/>&nbsp;&nbsp;&nbsp;&nbsp;\'phone_numbers\' => array<br/>&nbsp;&nbsp;&nbsp;&nbsp;(<br/><br/>&nbsp;&nbsp;&nbsp;&nbsp;)<br/>&nbsp;&nbsp;),<br/>&nbsp;&nbsp;\'orders\' => array<br/>&nbsp;&nbsp;(<br/>&nbsp;&nbsp;&nbsp;&nbsp;\'0\' => array<br/>&nbsp;&nbsp;&nbsp;&nbsp;(<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\'id\' => 32,<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\'description\' => \'Honda Fireblade 929 - 99\',<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\'price\' => \'45000\',<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\'currency\' => \'SEK\'<br/>&nbsp;&nbsp;&nbsp;&nbsp;),<br/>&nbsp;&nbsp;&nbsp;&nbsp;\'1\' => array<br/>&nbsp;&nbsp;&nbsp;&nbsp;(<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\'id\' => 33,<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\'description\' => \'Computer\',<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\'price\' => \'2000\',<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\'currency\' => \'SEK\'<br/>&nbsp;&nbsp;&nbsp;&nbsp;)<br/>&nbsp;&nbsp;)<br/>)"'));

		$arr2 = $arr;
		$arr2['diff_key']['key_diff'] = 'value';
		$arr['orders'][1]['description'] = 'Compute';
		eval($this->needEqual('array_diff_assoc_recursive($arr, $arr2)', 'array(\'orders\'=>array(\'1\'=>array(\'description\'=>\'Compute\')))'));
		eval($this->needEqual('array_diff_assoc_recursive($arr2, $arr)', 'array(\'orders\'=>array(\'1\'=>array(\'description\'=>\'Computer\')),\'diff_key\'=>array(\'key_diff\'=>\'value\'))'));
	}
}
?>
