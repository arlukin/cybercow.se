<?php
/**
 * Unit tests for all classes/functions in fareofficelib.
 *
 * This file/module is the starting point of the Fareoffice Unit Test GUI.
 * Which handles the execution of all unit test classes.
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @defgroup unittests Unit Tests - Unit tests for all classes/functions in fareofficelib.
 */

include_once('FareOfficeLib/FareOfficeLib.php');
$testSuite = &new foUnitTest('./');
$testSuite->writeTestSuiteGui();

?>
