<?php
/**
 * Global constans and defines.
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @version 1.0
 * @package Lib
 * @subpackage Constant
 */

	/**
	 * Unix syntax of a new line
	 *
	 */
	DEFINE('NEWLINE', "\r\n");
?>