<?php
/**
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @version 1.0
 * @package Lib
 * @subpackage Config
 */

/**
 * Holds login information to the database server.
 *
 * @package Lib
 * @subpackage Config
 */
class DbConfig
{
	/**
	 * Constructor
	 *
	 * Sets all different database configs.
	 *
	 * @access public
	 */
	public function __construct()
	{
		//dbConfig::setDSN('foMaster', 					'mysql', '192.168.4.250', 'faredbuser', 'COWUPSIDEDOWN', 'foMasterProduction');
		//dbConfig::setDSN('foVanguardUnicode', 'mysql', '192.168.4.250', 'faredbuser', 'COWUPSIDEDOWN', 'foVanguardUnicodeProduction');
		//dbConfig::setDSN('foStatistic', 			'mysql', '192.168.4.250', 'faredbuser', 'COWUPSIDEDOWN', 'foStatisticProduction');
		//dbConfig::setDSN('foSlave', 					'mysql', '192.168.4.250', 'faredbuser', 'COWUPSIDEDOWN', 'foMasterProduction');
		//dbConfig::setDSN('pureftpd', 					'mysql', '192.168.4.250', 'pureftpdw',  'oou9Saur',      'pureftpd');

		// Live server
		dbConfig::setDSN('foMaster', 					'mysql', '10.100.12.11', 'diagnostic', '1QKb9fj}TsH)JXC_PdNn', 'foMasterProduction');
		dbConfig::setDSN('foVanguardUnicode', 'mysql', '10.100.12.11', 'diagnostic', '1QKb9fj}TsH)JXC_PdNn', 'foVanguardUnicodeProduction');
		dbConfig::setDSN('foStatistic', 			'mysql', '10.100.12.11', 'diagnostic', '1QKb9fj}TsH)JXC_PdNn', 'foStatisticProduction');
		dbConfig::setDSN('foSlave', 					'mysql', '10.100.22.11', 'diagnostic', '1QKb9fj}TsH)JXC_PdNn', 'foMasterProduction');		
	}

	/**
   * Set the database dsn:s that can be used.
	 *
	 * @param string 	$configName_
	 * 								Name of the configuration, doesn't need to be the same as the database name.
	 *
	 * @param string 	$dbType_
	 * 								The database server type.
	 *
	 * @param string 	$hostip_
	 * 								The ip number (or domain name) to the database server.
	 *
	 * @param string 	$username_
	 * 								Username to the datbase server.
	 *
	 * @param string 	$password_
	 * 								Password to the datbase server.
	 *
	 * @param string	$dbName_
	 * 								The name of the database in the database server.
	 *
	 * @access public
	 */
	public function setDSN($configName_, $dbType_, $hostip_, $username_, $password_, $dbName_)
	{
		$configName_ = strtolower($configName_);
		dbConfig::$configurations[$configName_] = array
		(
			'phptype'  => $dbType_,
      'hostspec' => $hostip_,
      'username' => $username_,
      'password' => $password_,
      'database' => $dbName_
		);
	}

	/**
	 * Get the dsn name to the database.
	 *
	 * @param string 	$configName_
	 * 								The name of the database configuration.
	 * 								For more information see {@link dbConfig::setDSN()}
	 *
	 * @return array	An array with DB DSN info.
	 *								{@link DbConfig::$configurations}
	 *
	 * @access public
	 */
	public function getDSN($configName_)
	{
		$configName_ = strtolower($configName_);
		return dbConfig::$configurations[$configName_];
	}

	/**
	 * Array list with dsn information.
	 *
	 * $configurations['fomaster']['phptype']  = 'mysql;
	 * $configurations['fomaster']['hostspec'] = '192.168.2.250';
	 * $configurations['fomaster']['username'] = 'username';
	 * $configurations['fomaster']['password'] = 'xxx';
	 * $configurations['fomaster']['database'] = 'foMaster';
	 * @var array
	 * @static
	 */
	static private $configurations;
}
?>
