<?php
/**
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @version 1.0
 * @package Lib
 * @subpackage Config
 */

/**
 * Environment settings for a site.
 *
 * Each directory under /opt/RootLive/Site is a Site. This
 * class will have a representation object for each Site. The
 * representation is created by {@link Config}
 *
 * @package Lib
 * @subpackage Config
 */
class SiteConfig
{
	/**
	 * Constructor
	 *
	 * Will set the site directory.
	 *
	 * @param string $siteDir_
	 * 								Site directory.
	 * @access public
	 */
	public function __construct($siteDir_)
	{
		$this->_siteDir = $siteDir_;
	}

	/**
	 * Get the log file directory for this site.
	 *
	 * @return string
	 * @access public
	 */
	public function getLogDir()
	{
		return $this->_siteDir . 'Temp/Log/';
	}

 /**
	 * Get the cache file directory for this site.
	 *
	 * @return string
	 * @access public
	 */
	public function getCacheDir()
	{
		return $this->_siteDir . 'Temp/Cache/';
	}

	/**
	 * The site directory.
	 *
	 * Example
	 * <code>
	 * /opt/RootLive/Site/DistSysOpProduction
	 * </code>
	 *
	 * @var string
	 * @access private
	 */
	private $_siteDir;
}
?>