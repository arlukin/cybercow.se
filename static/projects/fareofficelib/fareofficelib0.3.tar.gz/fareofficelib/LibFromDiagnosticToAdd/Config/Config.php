<?php
/**
 * Classes that handles general configuration of the systems.
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @version 1.0
 * @package Lib
 * @subpackage Config
 */

/**
 * Include files
 *
 */
require_once('OnCall/Lib/Utils/Files.php');
require_once('OnCall/Lib/Config/SiteConfig.php');
require_once('OnCall/Lib/Config/DbConfig.php');

/**
 * Environment settings for the application server.
 *
 * @static
 *
 * @package Lib
 * @subpackage Config
 */
class Config
{
	const DEVELOP = FALSE;

	/**
	 * Returns the directory where the application is installed.
	 *
	 * Ie. '/opt/RootLive/'
	 *
	 * @return string
	 * @access public
	 * @static
	 */
	static public function getEnvironmentDir()
	{
		return '/opt/RootLive/';
	}

	/**
	 * Returns the directory where the general log files are saved.
	 *
	 * Ie. '/opt/RootLive/Log/'
	 *
	 * @return string
	 * @access public
	 * @static
	 */
	static public function getLogDir()
	{
		return Config::getEnvironmentDir() . 'Log/';
	}

	/**
	 * Returns the directory where all sites/dists are installed.
	 *
	 * Ie. '/opt/RootLive/Site/'
	 *
	 * @return string
	 * @access public
	 * @static
	 */
	static public function getSiteDir()
	{
		return Config::getEnvironmentDir() . 'Site/';
	}

	/**
	 * Get a list with SiteConfig objects, one for each installed site/dist.
	 *
	 * @return SiteConfig	Returns an array with {@link SiteConfig} objects.
	 * @access public
	 * @static
	 */
	static public function getSites()
	{
		if (!is_array(Config::$sites))
		{
			Config::$sites = array();
			foreach(fileList(Config::getSiteDir(), 'DIR', FALSE) as $site)
			{
				Config::$sites[] = new SiteConfig($site);
			}
		}
		return Config::$sites;
	}

	/**
	 * Get the dsn name to the database.
	 *
	 * @param string 	$configName_
	 * 								The name of the database configuration.
	 * 								For more information see {@link DbConfig::setDSN()}
	 *
	 * @return array	An array with DB DSN info.
	 * 								arr['phptype']  = 'mysql;
	 * 								arr['hostspec'] = '192.168.2.250';
	 * 								arr['username'] = 'username';
	 * 								arr['password'] = 'xxx';
	 * 								arr['database'] = 'foMaster';
	 * @access public
	 * @static
	 */
	static public function getDBDSN($configName_)
	{
		return Config::getDbConfig()->getDSN($configName_);
	}

	/**
	 * Get a DbConfig object.
	 *
	 * The {@link DbConfig} object holds all database configurations.
	 *
	 * @return dbConfig
	 */
	static public function getDbConfig()
	{
		if (!is_object(Config::$dbConfig))
		{
			Config::$dbConfig = new DbConfig();
		}

		return Config::$dbConfig;
	}

	/**
	 * Holds a DbConfig instance for {@link Config::getDbConfig()}
	 *
	 * With this variable getDbConfig() don't need to recreate
	 * the instance at each call.
	 *
	 * @staticvar DbConfig
	 * @access public
	 */
	static private $dbConfig;

	/**
	 * A list of SiteConfig objects.
	 *
	 * @staticvar array
	 * @access private
	 */
	static private $sites;
}

?>