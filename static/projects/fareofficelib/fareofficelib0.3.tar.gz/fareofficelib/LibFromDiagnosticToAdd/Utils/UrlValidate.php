<?php
/**
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @version 1.0
 * @package Lib
 * @subpackage Utils
 */

/**
 * Include files
 */
require_once('OnCall/Lib/Utils/Date.php');

/**
 * Used to get variables from the url. Will validate
 * variables to prevent variable injection. The urlValidates
 * should be executed very early in the script. If they fail
 * the script will be terminated.
 *
 * <code>
 * 	urlValidate::dateTime('startTime');
 *	main(urlValidate::get('startTime'));
 * </code>
 *
 * @package Lib
 * @subpackage Utils
 * $static
 */
class UrlValidate
{
	/**
	 * Return the argument from the url.
	 *
	 * @param string $attributeName_
	 * @return mixed
	 */
	static public function get($attributeName_)
	{
		return $_GET[$attributeName_];
	}

	/**
	 * Retrives a GET variable and validate it to be a date or date time.
	 *
	 * dateTime variable   The variable is requiered to be a date or datetime.
	 *
	 * @param dateTime $attributeName_
	 */
	static public function getDateTime($attributeName_)
	{
		if (!isValidDate($_GET[$attributeName_]))
		{
			die('Invalid argument: ' . $_GET[$attributeName_]);
		}
		else
		{
			return $_GET[$attributeName_];
		}
	}

	/**
	 * Retrives a GET variable and validate it to be a boolean.
	 *
	 * A valid boolean is case insensitive true, false, yes, no, 1 and 0.
	 *
	 * If nothing is entered in the parameter false will be returned.
	 *
	 * @param bool $attributeName_
	 */
	static public function getBool($attributeName_)
	{
		if (array_key_exists($attributeName_, $_GET))
		{
			switch (strtolower($_GET[$attributeName_]))
			{
				case 'true':
				case 'yes':
				case '1':
					return true;

				case 'false':
				case 'no':
				case '0':
					return false;
				default:
					die('Invalid parameter for ' . $attributeName_);
			}
		}
		else
		{
			return false;
		}
	}

	/**
	 * Retrives a GET variable and validate it to be a string.
	 *
	 * If nothing is entered in the parameter NULL will be returned.
	 *
	 * @param string $attributeName_
	 *
	 */
	static public function getString($attributeName_)
	{
		if (array_key_exists($attributeName_, $_GET))
		{
			return $_GET[$attributeName_];
		}
		else
		{
			return null;
		}
	}
}

?>