<?php
/**
 * Main class for diagnostic server.
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @version 1.0
 * @package Lib
 * @subpackage Utils
 */

/**
 * Scheduling functionality similiar to the unix crontab.
 *
 * This class used to set a time period when something should be executed.
 * This class needs to be combined with other code that will trigger the
 * {@link PhpCronTab::isTimeToExecute()} atleast once a minute.
 *
 */
class PhpCronTab
{
	const EVERY_MINUTE 		= '*/1 * * * *';
	const EVERY_5_MINUTE 	= '*/5 * * * *';
	const EVERY_15_MINUTE = '*/15 * * * *';
	const EVERY_30_MINUTE = '*/30 * * * *';
	const EVERY_HOUR 			= '* */1 * * *';
	const EVERY_DAY 			= '0 21 * * *';
	const EVERY_WEEK 			= '0 22 * * 1';

	/**
	 * Constructor
	 *
	 * @access public
	 */
	public function __construct()
	{
		$this->scheduleList = array();
	}

	/**
	 * Add a new schedule time period.
	 *
	 * Each add follows a particular format as a series of fields, separated
	 * by spaces and/or tabs. Each field can have a single value or a series of values.
	 *
	 * OPERATORS
	 * There are several ways of specifying multiple date/time values in a field:
	 *
	 * - The comma (',') operator specifies a list of values, for example: "1,3,4,7,8"
	 * - The dash ('-') operator specifies a range of values, for example: "1-6", which is
	 *   equivalent to "1,2,3,4,5,6"
	 * - The asterisk ('*') operator specifies all possible values for a field. For example,
	 *   an asterisk in the hour time field would be equivalent to 'every hour'.
	 * - There is also an operator which some extended versions of cron support, the slash ('/')
	 *   operator, which can be used to skip a given number of values. For example,
	 *   "* /3" in the hour time field is equivalent to "0,3,6,9,12,15,18,21";
	 *   "*" specifies 'every hour' but the "/3" means that only the first, fourth, seventh...
	 *   and such values given by "*" are used.
	 *
	 * Fields
	 * <code>
	 * +---------------- minute (0 - 59)
	 * |  +------------- hour (0 - 23)
	 * |  |  +---------- day of month (1 - 31)
	 * |  |  |  +------- month (1 - 12)
	 * |  |  |  |  +---- day of week (0 - 7) (Sunday=0 or 7)
	 * |  |  |  |  |
	 * *  *  *  *  *
	 * </code>
	 *
	 * Each of the patterns from the five fields may be either * (an asterisk), meaning all legal
	 * values, or a list of elements separated by commas.
	 *
	 * For "day of the week" (field 5), 0 are considered Sunday.
	 *
	 * Counterintuitively, if both "day of month" (field 3) and "day of week" (field 5) are
	 * present on the same line, then the command is executed when either is true.
	 *
	 * @param string 	$defined_
	 * 								See the function comment.
	 * @access public
	 */
	public function addUnixFormat($defined_)
	{
		$arr = explode(' ', $defined_);

		assertLog(count($arr) == 5, EL_LEVEL_3, ECAT_DIAGNOSTIC, 'Not the right number of arguments: ' . count($arr) . ' ' . $defined_);

		$this->scheduleList[] = array
		(
			'minute' 				=> $arr[0],
			'hour' 					=> $arr[1],
			'day_of_month' 	=> $arr[2],
			'month' 				=> $arr[3],
			'day_of_week'	 	=> $arr[4]
		);
	}

	/**
	 * Check if it's time to execute the program.
	 *
	 * @return bool
	 * @access public
	 */
	public function isTimeToExecute()
	{
		if (!empty($this->scheduleList))
		{
			// Current time without leading zeroes and zero based.
			// Hour is between 0-23 for example.
			$currentTime = time();
			$hour = date('G', $currentTime);
			$minute = ltrim(date('i', $currentTime), '0');
			$dayOfMonth = date('d', $currentTime);
			$month = date('n', $currentTime);
			$dayOfWeek = date('w', $currentTime);

			foreach ($this->scheduleList as $schedule)
			{
				$schedule['minute'] = ltrim($schedule['minute'], '0');
				$schedule['hour'] = ltrim($schedule['hour'], '0');
				$schedule['day_of_month'] = ltrim($schedule['day_of_month'], '0');
				$schedule['month'] = ltrim($schedule['month'], '0');
				$schedule['day_of_week'] = ltrim($schedule['day_of_week'], '0');

				if
				(
					$this->_checkClock($minute, $schedule['minute']) &&
					$this->_checkClock($hour, $schedule['hour']) &&
					$this->_checkDayOfMonth($dayOfMonth, $schedule['day_of_month']) &&
					$this->_checkMonth($month, $schedule['month']) &&
					$this->_checkDayOfWeek($dayOfWeek, $schedule['day_of_week'])
				)
				{
					return true;
				}
			}
			return false;
		}
		else
		{
			// If no sceduleList are configured, always execute
			return true;
		}
	}

	/**
	 * Check the hour and minute field regarding to crontab syntax.
	 *
	 * @param string 	$currentClock_
	 * 								Either the current hour or current minute.
	 * 								Should not begin with 0.
	 *
	 * @param string 	$testClock_
	 * 								The hour or minute when the execution should start.
	 *
	 * @return bool		true if execution should be done.
	 * @access private
	 */
	private function _checkClock($currentClock_, $testClock_)
	{
		$testClockArr = array();

		// * always execute this.
		if ($testClock_ == '*')
		{
			return true;
		}

		// If same value
		elseif ($currentClock_ == $testClock_)
		{
			return true;
		}

		// Ranged values, 1-10 means all values from 1 to 10.
		elseif (strpos($testClock_, '-') !== false)
		{
			$numberRange = explode('-', $testClock_);
			if
			(
				count($numberRange) == 2 &&
				$currentClock_ >= $numberRange[0] &&
				$currentClock_ <= $numberRange[1]
			)
			{
				return true;
			}
		}

		// Will rebuild to real values in an array.
		// */3 will be 0,3,6,9,12,15,18,21 etc.
		elseif (strpos($testClock_, '/') !== false)
		{
			$skipNumber = explode('/', $testClock_);
			if ($skipNumber[0] == '*')
			{
				for($i = 0; $i < 60; $i+=$skipNumber[1])
				{
					$testClockArr[$i] = true;
				}
			}
		}

		// 1,3,7,9 will be expanded to an array.
		elseif (strpos($testClock_, ',') !== false)
		{
			$testClockArr = explode(',', $testClock_);
			$testClockArr = array_flip($testClockArr);
		}

		//
		if (!empty($testClockArr) && !empty($testClockArr[$currentClock_]))
		{
			return true;
		}

		return false;
	}

	/**
	 * Check if current day of month matches with the scheduled day of month.
	 *
	 * @param string 	$dayOfMonth_
	 * 								Current day of month, 0-6, 0 is sunday.
	 *
	 * @param string 	$scheduleDayOfMonth_
	 * 								The scheduled day of month.
	 *
	 * @return bool		true if execution should be done.
	 * @access private
	 */
	private function _checkDayOfMonth($dayOfMonth_, $scheduleDayOfMonth_)
	{
		if ('*' == $scheduleDayOfMonth_ || $dayOfMonth_ == $scheduleDayOfMonth_)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * Check if current month matches with scheduled month.
	 *
	 * @param string 	$currentMonth_
	 * 								Current month
	 *
	 * @param string 	$scheduleDMonth_
	 * 								The scheduled month.
	 *
	 * @return bool		true if execution should be done.
	 * @access private
	 */
	private function _checkMonth($currentMonth_, $scheduleDMonth_)
	{
		if ('*' == $scheduleDMonth_ || $currentMonth_ == $scheduleDMonth_)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * Check if current day of week matches with the scheduled day of week.
	 *
	 * @param string 	$dayOfWeek_
	 * 								Current day of week, 0-6, 0 is sunday.
	 *
	 * @param string 	$scheduledDayOfWeek_
	 * 								The scheduled day of week.
	 *
	 * @return bool		true if execution should be done.
	 * @access private
	 */
	private function _checkDayOfWeek($dayOfWeek_, $scheduledDayOfWeek_)
	{
		if ('*' == $scheduledDayOfWeek_ || $dayOfWeek_ == $scheduledDayOfWeek_)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * List of scheduled times.
	 *
	 * @var array
	 * @access private
	 */
	private $scheduleList;
}

?>