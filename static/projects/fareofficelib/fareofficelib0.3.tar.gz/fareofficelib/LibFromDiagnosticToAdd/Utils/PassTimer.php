<?php
/**
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @version 1.0
 * @package Lib
 * @subpackage Utils
 */

/**
 * Functions to benchmark how long time some other code has taken to execute.
 *
 * <code>
 * $timer = new PassTimer();
 * $timer->start();
 * // dom some stuff;
 * $timer->stop();
 * echo $timer->getElapsedTime();
 * </code>
 *
 * @package Lib
 * @subpackage Utils
 */
class PassTimer
{
	/**
	 * Constructor
	 *
	 * Set the time zone to Sweden/Stockholm.
	 *
	 * @access public
	 */
	public function __construct()
	{
		date_default_timezone_set('Europe/Stockholm');
		$this->_startAt = NULL;
		$this->stopAt = NULL;
	}

	/**
	 * Start the timer.
	 *
	 * @access public
	 */
	public function start()
	{
		$this->_stopAt = NULL;
		$this->_startAt = time();
	}


	/**
	 * Stop the timer.
	 *
	 * @return int 	The elapsed time measured in the number of seconds
	 * 							since the Unix Epoch (January 1 1970 00:00:00 GMT).
	 * @access public
	 */
	public function stop()
	{
		$this->_stopAt = time();
		return $this->_stopAt - $this->_startAt;
	}

	/**
	 * Get the start time.
	 *
	 * @return date
	 * @access public
	 */
	public function getStartTime()
	{
		return date('dMY H:i:s', $this->_startAt);
	}

	/**
	 * Get the stop time.
	 *
	 * @return date
	 * @access public
	 */
	public function getStopTime()
	{
		return date('dMY H:i:s', $this->_stopAt);
	}

	/**
	 * Get the elapsed time between start and stop.
	 *
	 * @return string
	 * @access public
	 */
	public function getElapsedTime()
	{
		$totalSeconds = ($this->_stopAt - $this->_startAt);
		$hours = floor($totalSeconds / 3600);
		$minutes = floor(($totalSeconds % 60) / 60);
		$seconds = ($totalSeconds % 3600);
		return str_pad($hours, 2, '0', STR_PAD_LEFT).':'.str_pad($minutes, 2, '0', STR_PAD_LEFT).':'.str_pad($seconds, 2, '0', STR_PAD_LEFT);
	}

	/**
	 * The start time measured in the number of seconds since the Unix Epoch (1970).
	 *
	 * @var int
	 * @access  private
	 */
	private $_startAt;

	/**
	 * The stop time measured in the number of seconds since the Unix Epoch (1970).
	 *
	 * @var int
	 * @access  private
	 */
	private $_stopAt;
}


?>