<?php
/**
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @version 1.0
 * @package Lib
 * @subpackage Utils
 */

/**
 * Declare the interface 'iLock'
 *
 * @package Lib
 * @subpackage Utils
 */
interface iLock
{
	/**
	 * Check if a file variable is locked or not.
	 *
	 * A file with the name $lockTitle_ are saved to the file system,
	 * if that file is older then $lockTime_ seconds this function returns
	 * true.
	 *
	 * This is used to see how long ago a certatin operation was done.
	 * Example, If it's more then 1 minute since we last did send
	 * an SMS message we can now send a new.
	 *
	 * @param	string	$lockName_
	 * 								The name of the lock/variable/file.
	 *
	 * @param	string	$lockTime_
	 * 								Seconds the lockTitle is locked.
	 *
	 * @param	string	$compressName_
	 * 								true - An md5 will be done on the filename/lockName_.
	 *
	 * @return	boolean
	 *
	 * @access	private
	 */
	public function isLockExpired
	(
		$lockName_,
		$lockTime_ = 60,
		$compressName_ = true
	);
}
?>