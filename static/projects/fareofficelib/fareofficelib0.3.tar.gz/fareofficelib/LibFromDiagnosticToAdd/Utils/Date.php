<?php
/**
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @version 1.0
 * @package Lib
 * @subpackage Utils
 */

/**
 * Validates a date or datetime, returns
 * true if valid. An empty date is a valid
 * date.
 *
 * <code>
 * 	isValidDate('2006-01-01');
 * 	isValidDate('');
 * 	isValidDate('2006-01-01 21:02:02');
 * </code>
 *
 * @param dateTime $date_
 * 									The date to validate.
 * @return boolean
 */
function isValidDate(&$date_)
{
	if (!empty($date_))
	{
		$time = strtotime($date_);
		if ($time === -1)
		{
			return false;
		}
	}

	return true;
}

/**
 * Validates a time, returns  true if valid.
 * 	- An empty time is a valid time.
 *  - Need to have all parts of the time hh:mm:ss
 *
 * <code>
 * 	isValidTime('');
 * 	isValidTime('21:02');
 * </code>
 *
 * @param string $time_
 * @return unknown
 */
function isValidTime(&$time_)
{
	if (!empty($time_))
	{
		$matches = NULL;
		preg_match('/([0-9]{1,2})[:]([0-9]{2})/', $time_, $matches);

		if
		(
			$matches[1] < 0 ||
			$matches[1] >= 24 ||
			$matches[2] < 0 ||
			$matches[2] >= 60
		)
		{
			return false;
		}
	}

	return true;
}

?>