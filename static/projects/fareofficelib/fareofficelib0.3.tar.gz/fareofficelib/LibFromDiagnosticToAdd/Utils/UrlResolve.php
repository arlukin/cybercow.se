<?php
/**
 * Those functions are based on
 * http://www.chrsen.dk/fundanemt/files/scripter/php/misc/rfc3986.php
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @version 1.0
 * @package Lib
 * @subpackage Utils
 */

  /**
   * These functiones implements rfc3986 an allows you to transform a relative uri
   * into its target uri. Read more at <http://rfc.net/rfc3986.html> section 5.2
   **/
  function absUrl( $base, $url )
  {
  	static $urlCache = array();

  	$urlKey = md5($base. '___' . $url);
  	if (!array_key_exists($urlKey, $urlCache))
  	{
			preg_match("/^(([^:\/?#]+):)?(\/\/([^\/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?/",$url,$urlComp);
		  list(,,$Rscheme,,$Rauthority,$Rpath,,$Rquery,,$Rfragment) = $urlComp;


		  if ( isset($Rscheme) && !empty($Rscheme) )
		  {
		    $Tscheme    = $Rscheme;
		    $Tauthority = $Rauthority;
		    $Tpath      = removeDotSegments($Rpath);
		    $Tquery     = $Rquery;

		  }
		  else
		  {
	      if ( isset($Rauthority) && !empty($Rauthority) )
	      {
	          $Tauthority = $Rauthority;
	          $Tpath      = removeDotSegments($Rpath);
	          $Tquery     = $Rquery;

	      }
	      else
	      {
					preg_match("/^(([^:\/?#]+):)?(\/\/([^\/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?/",$base,$baseComp);
				  list(,,$Bscheme,,$Bauthority,$Bpath,,$Bquery,,$Bfragment) = $baseComp;

		      if ( $Rpath == "")
		      {
		        $Tpath = $Bpath;
		        if ( isset($Rquery) && !empty($Rquery) )
		        {
		        	$Tquery = $Rquery;
		        }
		        else
		        {
		        	$Tquery = $Bquery;
		        }
		      }
		      else
		      {
		        if ( preg_match("/^\//", $Rpath) )
		        {
		        	$Tpath = removeDotSegments($Rpath);
		        }
		        else
		        {
		          $Tpath = merge($Bpath,$Bauthority,$Rpath);
		        	$Tpath = removeDotSegments($Tpath);
		        }// preg_match("/^//", $Rpath)

		        $Tquery = $Rquery;
		      }//if $Rpath == ""

		      $Tauthority = $Bauthority;
	      }// isset($Rauthority) && !empty($Rauthority)

	      $Tscheme = $Bscheme;

		  }// isset($Rscheme) && !empty($Rscheme)

		  $Tfragment = $Rfragment;

		  $result = "";

		  if ( isset($Tscheme) && !empty($Tscheme) )
		  {
		  	$result .= $Tscheme . ":";
		  }

		  if ( isset($Tauthority) && !empty($Tauthority) )
		  {
		  	$result .= "//" . $Tauthority;
		  }

		  $result .= $Tpath;

		  if ( isset($Tquery) && !empty($Tquery) )
		  {
		  	$result .= "?" . $Tquery;
		  }

		  if ( isset($Tfragment) && !empty($Tfragment) )
		  {
		  	$result .= "#" . $Tfragment;
		  }

		  $urlCache[$urlKey] = $result;
  	}

  	return $urlCache[$urlKey];
  }//function


  function removeDotSegments($path)
  {
		/*
		   1.  The input buffer is initialized with the now-appended path
		       components and the output buffer is initialized to the empty
		       string.
		*/
    $bInput = $path;
    $bOutput = "";
		/*
		   2.  While the input buffer is not empty, loop as follows:
		*/
    while( !empty($bInput) )
    {
			/*
			       A.  If the input buffer begins with a prefix of "../" or "./",
			           then remove that prefix from the input buffer; otherwise,
			*/
      if ( preg_match("/^(\.\.\/|\.\/)/", $bInput, $match) )
      {
      	$bInput = preg_replace("/^" . preg_quote($match[1], "/") . "/","",$bInput);
      }
			/*
			       B.  if the input buffer begins with a prefix of "/./" or "/.",
			           where "." is a complete path segment, then replace that
			           prefix with "/" in the input buffer; otherwise,
			*/
      else if ( preg_match("/^(\/\.\/|\/\.$)/",$bInput, $match) )
      {
      	$bInput = preg_replace("/^" . preg_quote($match[1], "/") . "/","/",$bInput);
      }

			/*
			       C.  if the input buffer begins with a prefix of "/../" or "/..",
			           where ".." is a complete path segment, then replace that
			           prefix with "/" in the input buffer and remove the last
			           segment and its preceding "/" (if any) from the output
			           buffer; otherwise,
			*/
      else if ( preg_match("/^(\/\.\.\/|\/\.\.$)/",$bInput, $match) )
      {
	    	$bInput = preg_replace ( "/^" . preg_quote($match[0], "/") . "/","/",$bInput);
        $bOutput = preg_replace ( "/\/?[^\/]+$/", "", $bOutput);
      }
			/*
			       D.  if the input buffer consists only of "." or "..", then remove
			           that from the input buffer; otherwise,
			*/
      else if ( preg_match("/^(\.\.|\.)$/",$bInput, $match) )
      {
      	$bInput = preg_replace("/^" . preg_quote($match[1], "/") . "/","",$bInput);
      }
			/*
			       E.  move the first path segment in the input buffer to the end of
			           the output buffer, including the initial "/" character (if
			           any) and any subsequent characters up to, but not including,
			           the next "/" character or the end of the input buffer.
			*/
      else
      {
	      preg_match("/^\/?[^\/]*/",$bInput,$match);
	      $bInput = preg_replace("/^" . preg_quote($match[0], "/") . "/","",$bInput);
	      $bOutput .= $match[0];
      }
    }//while
		/*
		   3.  Finally, the output buffer is returned as the result of
		       removeDotSegments.
		*/
    return $bOutput;
  }


  function merge($Bpath,$Bauthority,$Rpath)
  {
	  if ( isset($Bauthority) && !empty($Bauthority) && empty($Bpath) )
	  {
	  	return "/" . $Rpath;
	  }
	  else
	  {
	  	return preg_replace("/[^\/]*$/","",$Bpath) . $Rpath;
	  }//else
  }//merge

  function UrlResolveUnitTest()
  {
    //test
    $test = array
    (
        "g:h"           =>  "g:h",
        "g"             =>  "http://a/b/c/g",
        "./g"           =>  "http://a/b/c/g",
        "g/"            =>  "http://a/b/c/g/",
        "/g"            =>  "http://a/g",
        "//g"           =>  "http://g",
        "?y"            =>  "http://a/b/c/d;p?y",
        "g?y"           =>  "http://a/b/c/g?y",
        "#s"            =>  "http://a/b/c/d;p?q#s",
        "g#s"           =>  "http://a/b/c/g#s",
        "g?y#s"         =>  "http://a/b/c/g?y#s",
        ";x"            =>  "http://a/b/c/;x",
        "g;x"           =>  "http://a/b/c/g;x",
        "g;x?y#s"       =>  "http://a/b/c/g;x?y#s",
        ""              =>  "http://a/b/c/d;p?q",
        "."             =>  "http://a/b/c/",
        "./"            =>  "http://a/b/c/",
        ".."            =>  "http://a/b/",
        "../"           =>  "http://a/b/",
        "../g"          =>  "http://a/b/g",
        "../.."         =>  "http://a/",
        "../../"        =>  "http://a/",
        "../../g"       =>  "http://a/g",
        "../../../g"    =>  "http://a/g",
        "../../../../g" =>  "http://a/g",
        "/./g"          =>  "http://a/g",
        "/../g"         =>  "http://a/g",
        "g."            =>  "http://a/b/c/g.",
        ".g"            =>  "http://a/b/c/.g",
        "g.."           =>  "http://a/b/c/g..",
        "..g"           =>  "http://a/b/c/..g",
        "./../g"        =>  "http://a/b/g",
        "./g/."         =>  "http://a/b/c/g/",
        "g/./h"         =>  "http://a/b/c/g/h",
        "g/../h"        =>  "http://a/b/c/h",
        "g;x=1/./y"     =>  "http://a/b/c/g;x=1/y",
        "g;x=1/../y"    =>  "http://a/b/c/y",
        "g?y/./x"       =>  "http://a/b/c/g?y/./x",
        "g?y/../x"      =>  "http://a/b/c/g?y/../x",
        "g#s/./x"       =>  "http://a/b/c/g#s/./x",
        "g#s/../x"      =>  "http://a/b/c/g#s/../x",
    );

    foreach ($test as $key=>$value)
    {
	    $absurl = absUrl("http://a/b/c/d;p?q",$key);
	    print $key . " = " . $value . " = " . $absurl . " ";
	    print $absurl == $value ? "<br>" : "<font color=red>!!!</font><br>";
    }//foreach
  }
?>