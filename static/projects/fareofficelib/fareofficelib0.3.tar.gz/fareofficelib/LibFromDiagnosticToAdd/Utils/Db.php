<?php
/**
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @version 1.0
 * @package Lib
 * @subpackage Utils
 */

/**
 * Include files
 */
require_once 'creole/Creole.php';
require_once 'OnCall/Lib/Config/Config.php';

/**
 * Functions to communicate with the database server.
 *
 * This is a wrapper class for creole.
 *
 * @package Lib
 * @subpackage Utils
 */
class Db
{
	/**
	 * Execute a database query.
	 *
	 * @param string	$sql
	 * 								The sql query.
	 *
	 * @return ResultSet
	 */
	static function executeQuery($sql_)
	{
		$conn = db::getConnection();
		return $conn->executeQuery($sql_);
	}

	/**
	 * Get a creole database Connection.
	 *
	 * @return Connection
	 */
	static function getConnection()
	{
		$dsn = Config::getDBDSN(db::getConfigName());

		return  Creole::getConnection($dsn);
	}

	/**
	 * Set database config name.
	 *
	 * @param string 	$configName
	 * 								A config name.
	 * 								Ie foMaster
	 */
	static public function setConfigName($configName_)
	{
		db::$configName = $configName_;
	}

	/**
	 * Get current config name that is used.
	 *
	 * @return string
	 */
	static public function getConfigName()
	{
		return db::$configName;
	}

	/**
	 * Set a new datbase config name, and save the old one on a stack.
	 *
	 * @param string 	$configName
	 * 								A config name.
	 * 								Ie foMaster
	 */
	static public function pushConfigName($configName_)
	{
		array_push(db::$configNameStack, db::$configName);
		db::$configName = $configName_;
	}

	/**
	 * Set the last pushed config name.
	 *
	 */
	static public function popConfigName()
	{
		db::$configName = array_pop(db::$configNameStack);
	}

	/**
	 * The current used database config name.
	 *
	 * @var string A config name, Ie foMaster
	 */
	static private $configName = 'foMaster';

	/**
	 * An array used as a stack with config names.
	 *
	 * @see Db::pushConfigName()
	 * @var array
	 * @access private
	 * @static
	 */
	static private $configNameStack = array();
}
?>