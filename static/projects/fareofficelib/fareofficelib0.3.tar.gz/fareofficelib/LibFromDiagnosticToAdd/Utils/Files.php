<?php
/**
 * Functions that manipulates with the file system.
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @version 1.0
 * @package Lib
 * @subpackage Files
 */

/**
 * List all files in one directory.
 *
 * @param string	$directory_
 * 								The directory to list files from.
 * 								Doesn't matter if it ends on / or not.
 * 								Ie. /opt/RootLive/Sites
 *
 * @param	string	$type_
 * 								Can be ALL/FILE/DIR, and defines which type of
 * 								entries to collect.
 * 								FILE - List files in directory.
 * 								DIR	 - List directories in directory.
 * 								ALL  - List both FILE and DIR
 *
 * @param	boolean	$recursive_
 * 								Go through all directories recursively.
 *
 * @param boolean	$sort_
 * 								Sort all the result.
 *
 * @return array	listOffiles
 * 								List of all the files, not the directories.
 * 								listOffiles[] = '/opt/RootLive/Sites/HtDocs/Admin/Admin.php';
 * 								listOffiles[] = '/opt/RootLive/Sites/Phpinc/Content/Content.php';
 */
function fileList($directory_, $type_ = 'ALL', $recursive_ = true, $sort_ = true)
{
	assertLog($type_ == 'ALL' || $type_ == 'FILE' || $type_ == 'DIR' , EL_LEVEL_3, ECAT_DIAGNOSTIC, 'fileList invalid type: ' . $type_);

	$directory_ = rtrim($directory_, '/');
	$type_ = strtoupper($type_);

	$result = array();
	if(is_dir($directory_))
	{
		$thisDir = dir($directory_);

		while(!empty($thisDir) && $entry = $thisDir->read())
		{
			if (($entry != '.') && ($entry != '..'))
			{
				$path = $directory_.'/'.$entry;
				if (is_file($path) && ($type_ == 'ALL' || $type_ == 'FILE'))
				{
					$result[] =	$path;
				}
				elseif (is_dir($path))
				{
					if (($type_ == 'ALL' || $type_ == 'DIR'))
					{
						$result[] =	$path;
					}

					if ($recursive_)
					{
						$result = array_merge($result, fileList($path, true, false));
					}
				}
			}
		}
	}

	if (!empty($result) && $sort_)
	{
		asort($result);
	}

	return $result;
}

?>
