<?php

/**
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @version 1.0
 * @package Lib
 * @subpackage Utils
 */

/**
 * Include files
 *
 */
require_once('OnCall/3dPart/htmlMimeMail-2.5.1/htmlMimeMail.php');

/**
 * Sends SMS and Email messages.
 *
 * Example:
 * <code>
 * 	<?php
 *		$sendLock = new Lock('/opt/RootLive/Site/DistOnCall/Temp/Cache/Locks/');
 *		$communication = new Communication($sendLock);
 * 		$communication->sendSms('monitor.fareoffice.com', '0736265449', 'Hello world);
 * 	?>
 * </code>
 *
 * @package Lib
 * @subpackage Utils
 */
class Communication
{
	/**
	 * Constructor
	 *
	 * @param iLock	$sendLock_
	 * 							A lock object that will handle how often
	 * 							an SMS can be sent.
	 *
	 * @return Communication
	 * @access public
	 */
	public function Communication(iLock $sendLock_)
	{
		$this->sendLock = $sendLock_;
	}

	/**
	 * Send an email.
	 *
	 * Supports both plain text and html messages.
	 * Using the internal PHP "mail" function.
	 *
	 * @param string $from_
	 * 								The from email address.
	 * 								Ie. monitor@fareoffice.com
	 *
	 * @param array  $toArr_
	 * 								The to email addresses, can be many.
	 * 								$toArr_[] = 'daniel@fareoffice.com';
	 * 								$toArr_[] = 'alert@fareoffice.com';
	 *
	 * @param string $subject_
	 * 								The email subject.
	 *
	 * @param string $text_
	 * 								The text part of the email.
	 *
	 * 								An email can have both a text and html part,
	 * 								the html part will be read of the email client
	 * 								supports html, or else the text part will be used.
	 * 								All clients are assumed they can handle text messages.
	 *
	 * 								This argument and/or $html needs to be used,
	 * 								if this argument is empty the $html_
	 * 								will be used for the text part of the message
	 * 								but with striped html tags.
	 *
	 * @param string $html_
	 * 								The HTML part of the email.
	 * 								See $text_ for more information.
	 *
	 * @return string errorMessage
	 * 								If sendEmail fails, an error message will be returned.
	 * 								If sendEmail succededs, false will be returned.
	 * @access public
	 */
	public function sendEmail($from_, $toArr_, $subject_, $text_, $html_ = NULL)
	{
		if (!empty($from_) && !empty($toArr_) && !empty($subject_) && (!empty($text_) || !empty($html_)))
		{
			$mail = new htmlMimeMail();

			if (!empty($html_))
			{
				if (empty($text_))
				{
					$text_ = strip_tags($html_);
				}

				$mail->setHtml($html_, $text_);
			}
			else
			{
				$mail->setText($text_);
			}

			$mail->setReturnPath('www1mailer@fareoffice.com');
			$mail->setFrom($from_);
			$mail->setSubject($subject_);
			$mail->setHeader('X-Mailer', 'www.fareoffice.com / HTML Mime mail class (http://www.phpguru.org)');

			$mailResult = $mail->send($toArr_);

			if (!$mailResult)
			{
				return 'Failed to send mail';
			}
			else
			{
				return false;
			}
		}
		else
		{
			return 'Failed to send mail, one or more parameters wasn\'t entered.';
		}
	}

	/**
	 * Sends an SMS message to a mobile phone.
	 *
	 * The function uses the @esms.nu service.
	 *
	 * @param string 		$from_
	 * 							 		An email address that the message will
	 * 							 		be sent from.
	 * 							 		Ie. monitor@fareoffice.com
	 *
	 * @param string 		$toArr_
	 * 							 		A list of cell phone numbers that will recieve the
	 * 							 		message.
	 * 								 	Ie. 0736265449
	 *
	 * @param string 		$message_
	 * 							 		The text that will be sent on the sms.
	 * 									The message will be truncated to 160 chars.
	 *
	 * @param integer 	$repeatTime_
	 * 									The number of seconds to wait until next
	 * 									sms can be sent. To prevent sms flooding.
	 *
	 * @return string  	$errorMessage
	 * 								 	If sendEmail fails, an error message will be returned.
	 * 								 	If sendEmail succededs, false will be returned.
	 *
	 * @access public
	 */
	public function sendSms($from_, $toArr_, $message_, $repeatTime_ = 60)
	{
		if (!empty($message_))
		{
			$message_ = substr($message_, 0, 160);
			if (!empty($this->sendLock) || $this->sendLock->isLockExpired('SMS', $repeatTime_, false))
			{
				$cellPhoneArr = array();
				foreach ($toArr_ as $cellPhone)
				{
					$cellPhoneArr[] = $cellPhone . '@esms.nu';
				}
				return $this->sendEmail($from_, $cellPhoneArr, $from_, $message_);
			}
			else
			{
				return 'Failed to send sms, to many at to short time.';
			}
		}
	}

	/**
	 * A lock object that will handle how often
	 * an SMS can be sent.
	 *
	 * @var iLock
	 * @access private
	 */
	private $sendLock;
}

?>