<?php
/**
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @version 1.0
 * @package Lib
 * @subpackage Utils
 */

/**
 * Include files
 */
	require_once('OnCall/Lib/Utils/iLock.php');

/**
 * Does a server global lock on a lock name.
 *
 * A file with the lock name are saved to the file system,
 * if that file is older then $lockTime_ seconds this function returns
 * true.
 *
 * This is used to see how long ago a certatin operation was done.
 * Example, If it's more then 15 minutes since we last did send
 * and SMS message we can now send a new.
 *
 * If no valid lockPath is set, the lock name will never be locked.
 *
 * Example:
 * <code
 * <?php
 * 	$lock = new Lock('/opt/RootLive/Site/DistAlamo/Temp/Cache/Locks/');
 *		if ($lock->_isLockExpired('SMS'))
 * 		{
 * 			// Send SMS
 * 		}
 * ?>
 * </code>
 *
 * @package Lib
 * @subpackage Utils
 */
class FileLock implements iLock
{
	/**
	 * Constructor
	 *
	 * @param string 	$lockPath_
	 * 								The path to where to save the lock files.
	 * 								Ie. /opt/RootLive/Site/DistAlamo/Temp/Cache/Locks/
	 * @return Lock
	 */
	function Lock($lockPath_)
	{
		$this->setLockPath($lockPath_);
	}

	/**
	 * Set the lock path.
	 *
	 * If no valid lockPath is set, the lock name will never be locked.
	 *
	 * @param string 	$lockPath_
	 * 								The path to where to save the lock files.
	 * 								Ie. /opt/RootLive/Site/DistAlamo/Temp/Cache/Locks/
	 */
	public function setLockPath($lockPath_)
	{
		$this->lockPath = $lockPath_;

		if (!file_exists($this->lockPath))
		{
			if (!@mkdir($this->lockPath, 0755, true))
			{
				assertLog(false, EL_LEVEL_3, ECAT_DIAGNOSTIC, 'Couldnt create lockPath: ' . $this->lockPath);

				echo('Couldnt create path');
				$this->lockPath = '';
			}
		}
	}

	/**
	 * Get the lock path.
	 *
	 * @return string lockPath
	 * 								The path to where to save the lock files.
	 * 								Ie. /opt/RootLive/Site/DistAlamo/Temp/Cache/Locks/
	 */
	public function getLockPath()
	{
		assertLog(!empty($this->lockPath), EL_LEVEL_3, ECAT_DIAGNOSTIC, 'Couldnt create lockPath: ' . $this->lockPath);
		return $this->lockPath;
	}

	/**
	 * Check if a file variable is locked or not.
	 *
	 * A file with the name $lockTitle_ are saved to the file system,
	 * if that file is older then $lockTime_ seconds this function returns
	 * true.
	 *
	 * This is used to see how long ago a certatin operation was done.
	 * Example, If it's more then 1 minute since we last did send
	 * an SMS message we can now send a new.
	 *
	 * @param	string	$lockName_
	 * 								The name of the lock/variable/file.
	 *
	 * @param	string	$lockTime_
	 * 								Seconds the lockTitle is locked.
	 *
	 * @param	string	$compressName_
	 * 								true - An md5 will be done on the filename/lockName_.
	 *
	 * @return	boolean	expired
	 * 									True if the lock has expired.
	 * 									False if the lockName is still locked.
	 *
	 * @access	public
	 */
	public function isLockExpired
	(
		$lockName_,
		$lockTime_ = 60,
		$compressName_ = true
	)
	{
		$path = $this->getLockPath();
		if (empty($path))
		{
			return true;
		}

		if ($compressName_)
		{
			$fileName = $path . md5($lockName_);
		}
		else
		{
			$fileName = $path . $lockName_;
		}

		$retVal = false;
		if
		(
			!file_exists($fileName) ||
			filemtime($fileName) < (time() - $lockTime_)
		)
		{
			$handle = @fopen($fileName, 'w');

			if ($handle !== false)
			{
				fwrite($handle, $lockName_);
				$retVal = true;
				fclose($handle);
			}
		}

		return $retVal;
	}

	/**
	 * The path to where to save the lock files.
	 * Ie. /opt/RootLive/Site/DistAlamo/Temp/Cache/Locks/
	 *
	 * @var string
	 * @access private
	 */
	private $lockPath;
}

?>