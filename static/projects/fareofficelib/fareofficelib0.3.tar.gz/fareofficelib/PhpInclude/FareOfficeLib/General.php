<?php
/**
* General PHP functionality such as string, db and array manipulations.
*
*	@author Daniel Lindh <daniel@fareoffice.com>
*	@defgroup general General
*/

include_once('General/String.php');
include_once('General/Array.php');
include_once('General/Db.php');
?>
