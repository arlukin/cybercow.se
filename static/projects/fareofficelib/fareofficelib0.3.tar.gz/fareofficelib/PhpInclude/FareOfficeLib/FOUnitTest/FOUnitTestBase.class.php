<?php
/**
*	Abstract base class for all unit test classes. Has test case functions
* like needEqual, needTrue etc.
*
* @code
* // File: utFOUnitTestBase.php
*	class utFOUnitTestBase extends foUnitTestBase
*	{
*		public function doTest()
*		{
*			$this->_testNeedEmpty();
*		}
*
*		private function _testNeedEmpty()
*		{
*			$this->setSectionLabel('needEmpty');
*			$this->addSectionText('Will check FOUnitTestBase::needEmpty().');
*
*			// Will succeed
*			eval($this->needEmpty('""'));
*
*			$nullVar = NULL;
*			eval($this->needEmpty('$nullVar'));
*
*			$emptyArray = array();
*			eval($this->needEmpty('$emptyArray'));
*		}
*	}*
*	@endcode
*
*	@author Daniel Lindh <daniel@fareoffice.com>
* @ingroup founittest
*
* Requirements:
*		None
*
*/
abstract class FOUnitTestBase
{

	/**
	*	Constructor
	*/
	public function FOUnitTestBase()
	{
		$this->setSectionLabel();

		$this->_resetFailComment();

		$this->_testCount = 0;
		$this->_testResult = array();
	}

	/**
	* Section label for next doCompare result.
	*
	* Used in runTest() to separate different unit tests.
	*
	*	@param	$str_ - mixed -
	* 				The label.
	*/
	public function setSectionLabel($str_ = NULL)
	{
		$this->_currentSectionLabel = $str_;
		$this->_currentSectionText = array();
	}

	/**
	* Section text for the next doCompare result.
	*
	* Used in runTest() to comment different unit tests.
	*
	*	@param	$str_ - mixed -
	* 				The text.
	*/
	public function addSectionText($str_)
	{
		$this->_currentSectionText[] = $str_;
	}

	/**
	*	A comment written when the assert fails. Used to give hints about
	* what went wrong.
	*
	* Will be reseted after each test is performed.
	*
	*	@param	$str_ - mixed -
	* 				The comment.
	*
	*	@see _getFailComment(), _resetFailComment()
	*/
	function setFailComment($str_)
	{
		$this->_failComment = $str_;
	}

	/**
	*	Use with eval to verify that $code_ will generate an empty variable.
	*
	* Note: The php code send in to the need funktion should look like
	* 			this '5' or '"Fareoffice"' or '$var' or 'getValue()'
	*
	*	Example:
	*	@code
	* // Will succeed
	* eval($this->needEmpty('""'));
	*
	* $nullVar = NULL;
	*	eval($this->needEmpty('$nullVar'));
	*
	*	$falseVar = false;
	*	eval($this->needEmpty('$falseVar'));
	*
	*	$emptyArray = array();
	*	eval($this->needEmpty('$emptyArray'));
	*
	* // Will fail
	* eval($this->needEmpty('"Fareoffice"'));
	* eval($this->needEmpty('0'));
	*
	* $nonEmptyVar = 'Fareoffice';
	* eval($this->needEmpty('$nonEmptyVar'));
	*
	*	$falseVar = false;
	*	eval($this->needEmpty('$falseVar'));
	*	@endcode
	*
	*	@param	$code_ - mixed -
	*					Php code that should generate an empty result
	*
	*	@return - string - Php code that will be used in an eval() expression.
	*/
	public function needEmpty($code_)
	{
		return '
			$value1 = ' . $code_ . ';
			$value2= "";
			$this->_addTestResult
			(
				"needEmpty",
				emptyString($value1),
				"' . htmlEntities(str_replace('$', '\$', $code_)) . '",
				$value1,
				$value2
			);';
	}

	/**
	*	Use with eval to verify that $code will generate a value or some text.
	*
	* Note: The php code send in to the need funktion should look like
	* 			this '5' or '"Fareoffice"' or '$var' or 'getValue()'
	*
	*	Example:
	* @code
	* // Will succeed
	*	eval($this->needNotEmpty('"Fareoffice"'));
	*	eval($this->needNotEmpty('0'));
	*
	*	$nonEmptyVar = 'Fareoffice';
	*	eval($this->needNotEmpty('$nonEmptyVar'));
	*
	*	$trueVar = true;
	*	eval($this->needNotEmpty('$trueVar'));
	*
	*	$nonEmptyArray = array(0,1,2);
	*	eval($this->needNotEmpty('$nonEmptyArray'));
	*
	* // Will fail
	*	eval($this->needNotEmpty('""'));
	*
	*	$nullVar = NULL;
	*	eval($this->needNotEmpty('$nullVar'));
	*
	*	$falsVar = false;
	*	eval($this->needNotEmpty('$falseVar'));
	*
	*	$emptyArray = array();
	*	eval($this->needNotEmpty('$emptyArray'));
	*	@endcode
	*
	*	@param 	$code_ - mixed -
	*					Php code that should generate a result
	*
	*	@return - string - Php code that will be used in an eval() expression.
	*/
	public function needNotEmpty($code_)
	{
		return '
			$value1 = ' . $code_ . ';
			$value2= "";
			$this->_addTestResult
			(
				"needNotEmpty",
				!emptyString($value1),
				"' . htmlEntities(str_replace('$', '\$', $code_)) . '",
				$value1,
				$value2
			);';
	}

	/**
	*	Use with eval to verify that $code will generate true.
	*
	* Note: The php code send in to the need funktion should look like
	* 			this '5' or '"Fareoffice"' or '$var' or 'getValue()'
	*
	*	Example:
	*	@code
	* // Will succeed
	*	eval($this->needTrue('(1 == 1)'));
	* eval($this->needTrue('true'));
	* eval($this->needTrue('!false'));
	*
	* $trueVar = true;
	* eval($this->needTrue('$trueVar'));
	*	@endcode
	*
	*	@param	$code_ - mixed -
	*					Php code that should generate true.
	*
	*	@return - string - Php code that will be used in an eval() expression.
	*/
	public function needTrue($code_)
	{
		return '
			$value1 = ' . $code_ . ';
			$value2 = true;
			$this->_addTestResult
			(
				"needTrue",
				$this->isEqual($value1, $value2),
				"'.htmlEntities(str_replace('$', '\$', $code_)).'",
				$value1,
				$value2
			);';
	}

	/**
	*	Use with eval to verify that $code will generate false.
	*
	* Note: The php code send in to the need funktion should look like
	* 			this '5' or '"Fareoffice"' or '$var' or 'getValue()'
	*
	*	Example:
	*	@code
	* // Will succeed
	*	eval($this->needFalse('(1 != 1)'));
	* eval($this->needFalse('false'));
	* eval($this->needFalse('!true'));
	*
	* $falseVar = false;
	* eval($this->needFalse('$falseVar'));
	*	@endcode
	*
	*	@param	$code_ - mixed -
	*					Php code that should generate false.
	*
	*	@return - string - Php code that will be used in an eval() expression.
	*/
	public function needFalse($code_)
	{
		return '
			$value1 = ' . $code_ . ';
			$value2 = false;
			$this->_addTestResult
			(
				"needFalse",
				$this->isEqual($value1, $value2),
				"'.htmlEntities(str_replace('$', '\$', $code_)).'",
				$value1,
				$value2
			);';
	}

	/**
	*	Used with eval to verify that the return of the php code in $code_
	* and the value in $expecedReturn_ is equal.
	*
	* Note: The php code send in to the need funktion should look like
	*				this '5' or '"Fareoffice"' or '$var' or 'getValue()'
	*
	*	Example:
	*	@code
	*	$this->setSectionLabel('needEqual');
	*
	*	eval($this->needEqual('(3+2)', '5'));
	*
	*	$numVar = 5;
	*	eval($this->needEqual('$numVar', '5'));
	*
	*	$stringVar = 'Fareoffice';
	*	eval($this->needEqual('$stringVar', '"Fareoffice"'));
	*
	*	$rootDir = dir("/tmp");
	*	eval($this->needEqual('$rootDir->path', '"/tmp"'));
	*
	* $arr = array(1,2,3,4);
	* eval($this->needEqual('$arr', 'unserialize("a:4:{i:0;i:1;i:1;i:2;i:2;i:3;i:3;i:4;}")'));
	*	@endcode
	*
	*	@param 	$code_ - mixed -
	*					Php code that should generate a value equal to
	*					$expectedReturn_
	*
	*	@param 	$expectedReturn_ - mixed -
	*					Php code that should generate a value equal to the
	* 				value in $code_.
	*
	*	@return - string - Php code that will be used in an eval() expression.
	*/
	public function needEqual($code_, $expectedReturn_)
	{
		return '
			$value1 = ' . $code_ . ';
			$value2 = ' . $expectedReturn_ . ';
			$this->_addTestResult
			(
				"needEqual",
				$this->isEqual($value1, $value2),
				"'.htmlEntities(str_replace('$', '\$', $code_)).'" ,
				$value1,
				$value2
			);';
	}

	/**
	*	Used with eval to verify that the return of the php code in $code_
	* and the value in $expecedReturn_ is not equal.
	*
	* Note: The php code send in to the need funktion should look like
	*				this '5' or '"Fareoffice"' or '$var' or 'getValue()'
	*
	*	Example:
	*	@code
	*	$this->setSectionLabel('needDiff');
	*
	*	eval($this->needDiff('(3+2)', '4'));
	*
	*	$numVar = 5;
	*	eval($this->needDiff('$numVar', '4'));
	*
	*	$stringVar = 'Fareoffice';
	*	eval($this->needDiff('$stringVar', '"fareoffice"'));
	*
	*	$rootDir = dir("/tmp");
	*	eval($this->needDiff('$rootDir->path', '"/tMp"'));
	*
	* $arr = array(1,2,3,4);
	* eval($this->needDiff('$arr', 'unserialize("a:4:{i:0;si:1;i:1;i:2;i:2;i:3;i:3;i:4;}")'));
	*	@endcode
	*
	*	@param 	$code_ - mixed -
	*					Php code that should generate a value that is
	* 				different from $expectedReturn_
	*
	*	@param 	$expectedReturn_ - mixed -
	*					Php code that should generate a value that is
	* 				different from value in $code_.
	*
	*	@return - string - Php code that will be used in an eval() expression.
	*/
	public function needDiff($code_, $expectedReturn_)
	{
		return '
			$value1 = ' . $code_ . ';
			$value2 = ' . $expectedReturn_ . ';
			$this->_addTestResult
			(
				"needDiff",
				!$this->isEqual($value1, $value2),
				"'.htmlEntities(str_replace('$', '\$', $code_)).'" ,
				$value1,
				$value2
			);';
	}

	/*
	*	Used with eval to verify that the result of the $sql question
	* and the array in $expecedReturn is equal.
	*
	* Note: The php code send in to the need funktion should look like
	*				this '5' or '"Fareoffice"' or '$var' or 'getValue()'
	*
	*	Example:
	*	@code
	* eval($this->needEqualSqlResult
	* (
	*		'SELECT user_id, username FROM user WHERE user_id = 807',
	*		array(array('807', 'daniel'))
	*	));
	*	@endcode
	*
	*	@param 	$sql_ - mixed -
	*					Sql question that should return one or more
	*					columns and rows.
	*
	*	@param 	$expectedReturnArr_ - mixed -
	*					Php code that should return a two dimensional array,
	*					the first array represents the rows in the sql result,
	*					and the second array the columns. This array
	*					should be equal to the result of the $sql query.
	*
	*	@return - string - Php code that will be used in an eval() expression.
	*/
	/*
	 @todo: Need SQL support in FareOfficeLib before this can be activated.
	public function needEqualSqlResult($sql, $expectedReturnArr)
	{
		$result = executeOnDb($sql);
		while ($row = mysql_fetch_row($result))
		{
			$arr[] = $row;
		}

		return '
			$value1 = '.getHtmlArrayPhp($arr).';
			$value2 = '.$expectedReturnArr.';
			$this->_addTestResult
			(
				"needEqualSqlResult",
				$this->isEqual($value1, $value2),
				"'.htmlEntities(str_replace('$', '\$', $sql)).'",
				$value1,
				$value2
			);';
	}
	*/

	/**
	*	Should only be used by the NEED functions.
	*
	*	Will add a test result to the internal test array.
	*
	*	@param 	$type_ - string -
	*					Type of test performed
	*
	*	@param 	$status_ - boolean -
	*					Ok if the test passed.
	*
	*	@param 	$code_ - mixed -
	*					The code that generated $value1 throw an eval.
	*
	*	@param 	$value1_ - mixed -
	*					Value generated from $code
	*
	*	@param 	$value2_ - mixed -
	*					Value to be compared with value1.
	*
	* @todo support writeHtmlArray output the "ReportFailDetails" part.
	*/
	public function _addTestResult($type_, $status_, $code_, $value1_, $value2_)
	{
		$this->_testCount++;

		// L�gger till i vilken fil och vilken rad som koden k�rdes.
		$backTrace = debug_backtrace();
		$this->_testResult[$this->_testCount] = array
		(
			'file' => str_replace(': eval()\'d code', '', $backTrace[0]['file']),

			'class_name' 		=> strtolower(get_class($this)),
			'section_label' => $this->_currentSectionLabel,
			'section_text' 	=> $this->_currentSectionText,
			'fail_comment' => $this->_getFailComment(),

			'type' 	 => $type_,
			'status' => $status_,
			'code'	 => $code_,

			'return'					=> $value1_,
			'expected_return'	=> $value2_
		);

		$this->_resetFailComment();
	}

	/**
	*	Will return the result of the doTest test.
	*
	*	@return array	The result generated by the doTest.
	*/
	public function &getTestResult()
	{
		return $this->_testResult;
	}

	/**
	*	Compares $value1 with $value2, return true if equal.
	* Can also compare arrays, using serialize.
	*
	*	@param 	$value1_ - mixed -
	*					Value to be compared with value2
	*
	*	@param 	$value2_ - mixed -
	*					Value to be compared with value1
	*
	*	@return - string -	True if values are equal
	*/
	public function isEqual($value1_, $value2_)
	{
		if (is_array($value1__) || is_array($value2__))
		{
			return $this->_isEqualArray($value1_, $value2_);
		}

		//
		// Both variables must be of the same type.
		//
		if (gettype($value1_) == 'double' || gettype($value1_) == 'float')
		{
			$value1_ = (double)((string)$value1_);
		}

		if (gettype($value2_) == 'double' || gettype($value2_) == 'float')
		{
			$value2_ = (double)((string)$value2_);
		}

		if ($value1_ == $value2_)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	*	Compares $value1 with $value2, return true if equal, the values
	* has be arrays.
	*
	*	@param 	$value1_ - mixed -
	*					Value to be compared with value2
	*
	*	@param 	$value2_ - mixed -
	*					Value to be compared with value1
	*
	*	@return - string -	True if values are equal
	*/
	private function _isEqualArray($value1_, $value2_)
	{
		if (is_array($value1_) && is_array($value2_))
		{
			$diffArr = array_diff_assoc_recursive($value1_, $value2_);
			if (empty($diffArr))
			{
				$diffArr = array_diff_assoc_recursive($value2_, $value1_);
			}
		}
		else
		{
			$diffArr = true;
		}

		if (empty($diffArr))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	*	Returns the fail comment.
	*
	*	@return - string - The comment the will be written in case of test fail.
	*
	*	@see addFailComment(), _resetFailComments()
	*/
	private function _getFailComment()
	{
		return $this->_failComment;
	}

	/**
	*	Delete all fail fomments.
	*
	*	@see assert(), addFailComment()
	*/
	private function _resetFailComment()
	{
		$this->_failComment = '';
	}

	/**
	*	This function should be overrided in a child class
	* and include the unit tests.
	*
	*	Examples:
	*	@code
	*	function doTest()
	*	{
	*		eval($this->assert(
	*			'3+3',
	*			'6'
	*		));
	*	}
	*	@endcode
	*/
	abstract protected function doTest();

	/**
	 *  Section label used by the next call to doCompare.
	 */
	private	$_currentSectionLabel;

	/**
	 * Section text used by the next call to doCompare.
	 */
	private	$_currentSectionText;

	/**
	 * Number of test actually done.
	 */
	private	$_testCount;

	/**
	 * Array including all the test results, added with _addTestResult.
	 */
	private	$_testResult;

	/**
	 * A comment written when the assert fails. Used to give hints about
	 * what went wrong.
	 *
	 * Will be reseted after each test is performed.
	 */
	private $_failComment;
}
?>
