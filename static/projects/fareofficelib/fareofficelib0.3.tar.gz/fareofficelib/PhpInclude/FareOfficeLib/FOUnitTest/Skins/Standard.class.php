<?php

include_once('UnitTestSkin.class.php');

/**
 * This is the standard Unit Test Skin. The class that are responsible
 * for all GUI output.
 *
 * @author Daniel Lindh <daniel@fareoffice.com>
 * @ingroup founittest
 */
class standard extends unitTestSkin
{
	/**
	 * Constructor
	 */
	public function standard()
	{
		$this->_testCount = 0;
		$this->_reportedCompareCount = 0;
	}

	/**
	*	Write webpage header for the Unit Test Gui.
	*
	* The execution order for the webpage building are
	* begin();
	* writeGuiResult();
	* end();
	*
	* These three functions should create a full html page with < html >
	* < head >< body > etc.
	*/
	public function begin()
	{
		echo('<html>');
			$this->_writeHtmlHead();
			echo('<body>');

			echo('<div class="bodyarea">');
				echo('<h1>FareOffice Unit Tester ' . $this->getParent()->getVersion() . '</h1');

				echo('<div class="toolbar">');
				$this->_writeToolBar();
				echo('</div>');

				echo('<div class="contentarea">');
	}

	/**
	*	Write webpage footer for the Unit Test Gui.
	*
	* @see: begin()
	*/
	public function end()
	{
				if ($this->_testCount)
				{
					echo('<br/><b>Finish</b><br/>');
				}
				else
				{
					echo('You must choose a test case to run.');
				}
				echo('</div>');

				echo('<div class="filebrowser">');
				$this->_writeFileBrowser();
				echo('</div>');

				echo('<div class="status">');
				$this->_writeStatus();
				echo('</div>');

			echo('</div>');
			echo('</body>');
		echo('</html>');
	}

	/**
	 * Write the html < head > tag.
	 */
	private function _writeHtmlHead()
	{
		echo('<head>');
			echo('<title>');
				echo('FareOffice Unit Tester ' . $this->getParent()->getVersion());
			echo('</title>');

			echo('<meta name="author" content="Daniel Lindh, aka Arlukin, aka Master Po" />');
			echo('<meta name="robots" content="noindex,nofollow" />');
			echo('<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-15" />');

			$this->_writeCSSStyle();
		echo('</head>');
	}

	/**
	 * Write a html < style > tag for the html < head > tag.
	 */
	private function _writeCSSStyle()
	{
	?>
		<style>
			<!--
			body
			{
				font-family: Courier New;
				font-size: 10pt;
			}

			h1
			{
				text-align:center;
			}

			h2
			{
				margin-bottom: 0px;
			}

			.contentarea, .filebrowser, .status, .bodyarea
			{
				margin: 5px;
				padding: 5px;
				width: auto;
				float: left;
				border: 1px solid #0000ff;
			}

			.toolbar
			{
				margin: 5px;
				padding: 5px;
				width: auto;
				border: 1px solid #0000ff;
				float: top;
			}

			.bodyarea
			{
				border: 0px
			}

			a:link, a:visited
			{
				color:"#003399";
				text-decoration: none;
			}

			a:hover
			{
				color: #FF00FF
			}

			td
			{
				font-size: 10pt;
				padding: 1px;
				vertical-align: top;
			}

			-->
		</style>
	<?php
	}

	/**
	* Write a toolbar with which you can control the GUI.
	*/
	private function _writeToolBar()
	{
		$this->_writeStatusChanger();
		$this->_writeRunAllTests();
		$this->_writeTestCaseNavigator();
	}

	/**
	* Write the GUI buttons [Only Report Fails] [Details About Fails]
	*/
	private function _writeStatusChanger()
	{
		if ($this->getParent()->getOnlyReportFailes())
		{
			echo('<b><a href="' . $this->_getUrlArgument(false, -1) . '">');
				echo('[Only Report Fails]');
			echo('</a></b>');
		}
		else
		{
			echo('<a href="' . $this->_getUrlArgument(true, -1) . '">');
				echo('[Only Report Fails]');
			echo('</a>');
		}

		echo('&nbsp;');

		if ($this->getParent()->getReportFailDetails())
		{
			echo('<b><a href="'.$this->_getUrlArgument(-1, false).'">');
				echo('[Details About Fails]');
			echo('</a></b>');
		}
		else
		{
			echo('<a href="'.$this->_getUrlArgument(-1, true).'">');
				echo('[Details About Fails]');
			echo('</a>');
		}

		echo('&nbsp;');
	}

	/**
	* Write the [RUN ALL TESTS] button.
	*/
	private function _writeRunAllTests()
	{
		echo('<a href="'.$this->_getUrlArgument(-1, -1, -1, true).'">[RUN ALL TESTS]</a>&nbsp;');
	}

	/**
	* Write the [Back] [Next] buttons, to switch current test case.
	*/
	private function _writeTestCaseNavigator()
	{
		$currentTestCase = $this->getParent()->getCurrentTestCase();
		$total = $this->getParent()->getNumOfTestCases();

		if ($currentTestCase > 1)
		{
			echo('<b><a href="' . $this->_getUrlArgument(-1, -1, $currentTestCase-1) . '">[Back]</a></b>');
		}
		else
		{
			echo('[Back]');
		}

		echo(' ' . $currentTestCase . '/' . $total . ' ');

		if ($currentTestCase < $total )
		{
			echo('<b><a href="' . $this->_getUrlArgument(-1, -1, $currentTestCase+1) . '">[Next]</a></b>');
		}
		else
		{
			echo('[Next]');
		}
	}

	/**
	 * Write a file browse list of all test cases/classes.
	 *
	 * Key is zerobased and currentTestCase starts at 1.
	 */
	private function _writeFileBrowser()
	{
		foreach($this->getParent()->getTestCaseFiles() as $key => $row)
		{
			if ($row['package'] != $oldPackage)
			{
				echo('<B>'.$row['package'].'</B><br/>');
				$oldPackage = $row['package'];
			}

			if ($key == $this->getParent()->getCurrentTestCase())
			{
				echo('<b>&nbsp;&nbsp;<a href="' . $this->_getUrlArgument(-1, -1, $key) . '">'.$row['class_name'] . '</a></b><br/>');
			}
			else
			{
				echo('&nbsp;&nbsp;<a href="' . $this->_getUrlArgument(-1, -1, $key) . '">'.$row['class_name'] . '</a><br/>');
			}
		}
	}

	/**
	 * Write status and statistics about the tests.
	*/
	private function _writeStatus()
	{
		echo('Reported tests: ' . $this->_reportedCompareCount . '<br/>');
		echo('Executed tests: ' . $this->_testCount . '<br/>');
	}

	/**
	*	Used by writeFileBrowser to build the anchors (a href) on the
	* test gui.
	*/
	private function _getUrlArgument
	(
		$onlyReportFailes_ = -1,
		$echoDetails_ = -1,
		$currentTestCase_ = -1,
		$runAllTests_ = -1
	)
	{
		if ((int)$onlyReportFailes_ == -1)
		{
			$onlyReportFailes_ = $this->getParent()->getOnlyReportFailes();
		}

		if ((int)$echoDetails_ == -1)
		{
			$echoDetails_ = $this->getParent()->getReportFailDetails();
		}

		if ((int)$currentTestCase_ == -1)
		{
			$currentTestCase_ = $this->getParent()->getCurrentTestCase();
		}

		if ((int)$runAllTests_ == -1)
		{
			$runAllTests_ = 0;
		}

		$str  = '?formOnlyReportFailes=' . $onlyReportFailes_;
		$str .= '&formEchoDetails=' . $echoDetails_;
		$str .= '&formTestCase=' . $currentTestCase_;
		$str .= '&formRunAllTests=' . $runAllTests_;

		return $str;
	}

	/**
	*	Will write a html result from a UnitTest result.
	*
	* @see: begin()
	*/
	public function writeGuiResult($testResult)
	{
		foreach($testResult as $_testCount => $row)
		{
			$this->_testCount++;
			$this->_writeTestCaseName($row['status'], $row['class_name']);
			$this->_writeSectionLabel($row['status'], $row['section_label'], $row['section_text']);

			if ($row['status'] == true)
			{
				$this->_writeSuccededTest($row['type'], $row['code']);
			}
			else
			{
				$this->_writeFailedTest($row['type'], $row['code'], $row['file']);
				$this->_writeFailDetails($row['return'], $row['expected_return'], $row['fail_comment']);
			}
		}
	}

	/**
	 * Return at padded testCount number, ie. 0004
	 */
	private function _getTestCount()
	{
		return str_pad($this->_testCount, 4, '0', STR_PAD_LEFT);
	}

	/**
	 * Will write the class name above all tests from one test class.
	 *
	 * Will not write the class name if bOnlyReportFailes is set.
	 */
	private function _writeTestCaseName($status_, $className_)
	{
		if
		(
			$className_ != $this->_oldClassName &&
			(
				$status_ == false ||
				!$this->getParent()->getOnlyReportFailes()
			)
		)
		{
			echo('<h2>' . $className_ . '</h2>');

			$this->_oldClassName = $className_;
		}
	}

	/**
	 * Write the section label set by setSectionLabel in the unitTest.
	 */
	private function _writeSectionLabel($status_, $sectionLabel_, $sectionTextArr_)
	{
		if
		(
			$sectionLabel_ != $this->_oldSectionLabel &&
			(
				$status_ == false ||
				!$this->getParent()->getOnlyReportFailes()
			)
		)
		{
			echo('<br/>');
			echo('<b>' . $sectionLabel_ . '</b><br/>');

			foreach($sectionTextArr_ as $text)
			{
				echo($text . '<br/>');
			}

			$this->_oldSectionLabel = $sectionLabel_;
		}
	}

	/**
	 * Write output for a succeded test.
	 *
	 * Will not write any output if "only report fails" status is set.
	 */
	private function _writeSuccededTest($type_, $code_)
	{
		if (!$this->getParent()->getOnlyReportFailes())
		{
			$this->_reportedCompareCount++;
			echo($this->_getTestCount() . ' OK - ' . $type_ . ' - ' . $code_ . '<br/>');
		}
	}

	/**
	 * Write output for a failed test.
	 */
	private function _writeFailedTest($type_, $code_, $file_)
	{
		$this->_reportedCompareCount++;
		echo($this->_getTestCount() . ' <font color="red">ERROR - ' . $type_ . ' - ' . $code_ . '</font><br/>');
		echo('File: <font color="red">' . $file_ . '</font><br/>');
	}

	/**
	 * Write details about a failed test.
	 */
	private function _writeFailDetails($value1_, $value2_, $comment_)
	{
		if ($this->getParent()->getReportFailDetails())
		{
			$this->_writeFailComment($comment_);
			$this->_writeReturnVariable($value1_, $value2_);
			$this->_writeExpectedReturnVariable($value1_, $value2_);
			echo('<br/>');
		}
	}

	/**
	 * Write a failed test comment set by setFailedComment in the unitTest
	 */
	private function _writeFailComment($comment_)
	{
		if (!empty($comment_))
		{
			echo($comment_);
			echo('<br/>');
		}
	}

	/**
	 * Write the variable that was returned from the failed test.
	 *
	 * Output looks like below.
	 * - First comes the output in form of a php formated array/variable.
	 * - A copy section that can be used to copy directly into the test.
	 * - A difference section that shows what difference are between
	 *   return variable and expected return. It shows what is returned.
	 *
	 * Return:
	 *
	 * array
	 * (
	 *  '0' => 1,
	 *	'1' => 2,
	 *	'2' => 3,
	 *  '3' => 4
	 * )
	 *
	 * Copy:
	 * 'array( "0" => 1, "1" => 2, "2" => 3, "3" => 4)'
	 *
	 * Difference:
	 *
	 */
	private function _writeReturnVariable($value1_, $value2_)
	{
		echo('<i><b>Return:</b></i><br/>');

		if (is_array($value1_))
		{
			$search = array("'", '"', '<br/>', ' ', "\t", '&nbsp;');
			$replace = array("\'", '\"', '', '', '', '');
			echo('<pre>' . getHtmlArrayPhp($value1_) . '</pre>');
			echo('Copy:<br/>\'' . str_replace($search, $replace, getHtmlArrayPhp($value1_)) . '\'<br/>');
			echo('<br/>');
			echo('Difference:' . getHtmlArray(array_diff_assoc_recursive($value1_, $value2_)));
		}
		else
		{
			$search = array("'", '"');
			$replace = array("\'", '\"');
			echo($this->getVariableInfo($value1_).'<br/>');
			echo('Copy:<br/>\'"' . htmlentities(str_replace($search, $replace, $value1_)).'"\'<br/>');
		}
	}

	/**
	 * Write the expected return result from the failed test.
	 *
	 * Output looks like below.
	 * - First comes the output in form of a php formated array/variable.
	 * - A difference section that shows what difference are between
	 *   return variable and expected return. It shows what was expected
	 *   to be returned.
	 *
	 * Return:
	 *
	 * array
	 * (
	 *  '0' => 1,
	 *	'1' => 2,
	 *	'2' => 3,
	 *  '3' => 4
	 * )
	 *
	 * Copy:
	 * 'array( "0" => 1, "1" => 2, "2" => 3, "3" => 4)'
	 *
	 * Difference:
	 *
	 */
	private function _writeExpectedReturnVariable($value1_, $value2_)
	{
		echo('<i><b>Expected return:</b></i><br/>');
		if (is_array($value2_))
		{
			echo('<pre>'.getHtmlArrayPhp($value2_).'</pre>');
			echo('<br/>');
			echo('Difference:' . getHtmlArray(array_diff_assoc_recursive($value2_, $value1_)));
		}
		else
		{
			echo($this->getVariableInfo($value2_).'<br/>');
		}
	}

	/**
	* Return an information string about a variable.
	*
	* ie. string(6) "Daniel"
	*/
	function getVariableInfo($value)
	{
		if (is_bool($value) )
		{
			if ($value)
			{
				$humanReadableValue = 'true';
			}
			else
			{
				$humanReadableValue = 'false';
			}
		}
		else
		{
			$humanReadableValue = $value;
		}

		return gettype($value).'('.strlen($value).') "'.$humanReadableValue.'"';
	}

	/**
	 * Number of compares reported to the user.
	 */
	private	$_reportedCompareCount;

	/**
	 * Number of tests executed.
	 */
	private $_testCount;

	/**
	 * Used by _writeTestCaseName, to only write the class name label,
	 * once per test class
	 */
	private $_oldClassName;
}

?>
