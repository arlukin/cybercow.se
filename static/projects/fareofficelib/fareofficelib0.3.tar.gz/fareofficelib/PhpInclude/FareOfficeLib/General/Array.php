<?php
/**
*	Includes array manipulating functions
*
*	@author Daniel Lindh <daniel@fareoffice.com>
* @ingroup general
* @file Array.php
*/

/**
 * Return an humanredable html table representation of a php array.
 *
 * @public
 */
function getHtmlArray(&$arr_)
{
	$result = '';
	if (is_array($arr_))
	{
		$result_ .= '<table border="1" cellspacing="0" cellpadding="3">';

			$result_ .= _getHtmlArrayHeader(count($arr));

			foreach ($arr_ as $key => $val)
			{
				if (is_array($val))
				{
					$result_ .= _getHtmlArrayInnerArray($key, $val);
				}
				else
				{
					$result_ .= _getHtmlArrayBody($key, $val);
				}
			}

		$result_ .= '</table>';
	}

	return $result_;
}

/**
 * Helper function for getHtmlArray()
 *
 * @private
 */
function _getHtmlArrayHeader($count_)
{
	$result .= '<tr>';
		$result .= '<td colspan="4">Count:' . $count_ . '</td>';
	$result .= '</tr>';

	$result .= '<tr>';
		$result .= '<td>key</td>';
		$result .= '<td>value</td>';
		$result .= '<td>type</td>';
		$result .= '<td>size</td>';
	$result .= '</tr>';

	return $result;
}

/**
 * Helper function for getHtmlArray()
 *
 * @private
 */
function _getHtmlArrayBody($key_, $val_)
{
	$result = '<tr>';

		$result .= '<td>' . $key_ . '</td>';
		$result .= '<td>' . getVarContent($val_) . '</td>';
		$result .= '<td>' . gettype($val_) . '</td>';

		if (is_string($val_))
		{
			$result .= '<td>' . strlen($val_) . '</td>';
		}
		else
		{
			$result .= '<td>' . sizeof($val_) . '</td>';
		}

	$result .= '</tr>';

	return $result;
}

/**
 * Helper function for getHtmlArray()
 *
 * @private
 */
function _getHtmlArrayInnerArray($key_, $val_)
{
	static $sNumberOfLevels = 0;

	$result = '<tr>';
		$result .= '<td>' . $key_ . '</td>';
			$result .= '<td colspan="3">';

			if ($sNumberOfLevels > 15)
			{
				$result .= ' To many levels for debug output ';
			}
			else
			{
				$sNumberOfLevels++;
				$result .= getHtmlArray($val_);
				$sNumberOfLevels--;
			}

		$result .= '</td>';
	$result .= '</tr>';

	return $result;
}

/**
 * Return a human readable text output of a variable.
 *
 * A "false" variable will get the output "FALSE" in text.
 * An unsigned variable will get the output "NULL" in text.
 * An empty string variable will get the output "EMPTY" in text.
 *
 * @public
 */
function getVarContent($val_)
{
	if (is_null($val_))
	{
		$ret = 'NULL';
	}
	else if (empty($val_) && is_bool($val_))
	{
		$ret = 'FALSE';
	}
	else if (emptyString($val_) && !is_int($val_))
	{
		$ret = 'EMPTY';
	}
	else if (is_string($val_))
	{
		$ret = htmlspecialchars($val_);
	}
	else
	{
		$ret =  $val_;
	}

	return $ret;
}

/**
* Return a "php-coded" representation of a php array.
*
* Example of output
* @code
* array
* (
*   'first_name' => 'Daniel',
*   'last_name' => 'Lindh',
*   'age' => 32
* )
*	@endcode
* @public
*/
function getHtmlArrayPhp($arr_, $rowPrefix_ = '')
{
	if (is_array($arr_))
	{
		$currentRowPrefix = '';
		$str = 'array' . "<br/>" . $rowPrefix_ . '(' . "<br/>";
		foreach ($arr_ as $key => $row)
		{
			if (!empty($currentRowPrefix))
			{
				$str .= ",<br/>";
			}

			$currentRowPrefix = $rowPrefix_ . "&nbsp;&nbsp;" . '\'' . $key . '\' => ';

			if (is_string($row))
			{
				$arr = unserialize($row);
				if ($arr)
				{
					$row = $arr;
				}
			}

			if (is_array($row))
			{
				$recursiveStr = getHtmlArrayPhp($row, $rowPrefix_ . "&nbsp;&nbsp;");
				if (empty($recursiveStr))
				{
					$recursiveStr = 'array()';
				}

				$str .= $currentRowPrefix . $recursiveStr;
			}
			elseif (is_string($row))
			{
				$str .= $currentRowPrefix . '\'' . $row . '\'' ;
			}
			else
			{
				$str .= $currentRowPrefix . getVarContent($row);
			}
		}
		$str .= "<br/>" . $rowPrefix_ . ')';
	}

	return $str;
}

/**
 * Computes the difference of arrays with additional index check
 *
 * Copied from
 * http://se.php.net/manual/en/function.array-diff-assoc.php#73972
 *
 * @author chinello@gmail.com
 * @public
 */
function array_diff_assoc_recursive($array1, $array2)
{
	foreach($array1 as $key => $value)
	{
		if(is_array($value))
		{
			if(!is_array($array2[$key]))
			{
				$difference[$key] = $value;
			}
			else
			{
				$new_diff = array_diff_assoc_recursive($value, $array2[$key]);
				if($new_diff != FALSE)
				{
					$difference[$key] = $new_diff;
				}
			}
		}
		else
		{
			if (gettype($array2[$key]) == 'double' || gettype($array2[$key]) == 'float')
				$array2[$key] = (double)((string)$array2[$key]);

			if (gettype($value) == 'double' || gettype($value) == 'float')
				$value = (double)((string)$value);

			if((!is_array($array2) || !array_key_exists($key, $array2)) || (isset($array2[$key]) && isset($value) && $array2[$key] != $value))
			{
				$difference[$key] = $value;
			}
		}
	}
	return !isset($difference) ? 0 : $difference;
}

?>
